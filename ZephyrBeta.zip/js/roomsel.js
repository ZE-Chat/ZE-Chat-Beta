var selrname;

function openRoomCreate() {
  loadDialog('roomcreatebox', 'Raum erstellen', 'ucreateRoom', '');
//  uRoomCreateRoomDialog.dialog( "open" );
}

function decideRoomEnter(roomid, full, state, pass) {
  selrname = $("#"+roomid+"-rname").val();
  if(pass != 'yes' || bpr == 'yes') {
    if(state == 0 || bpr == 'yes') {
      if(full == 'green' || bpr == 'yes') {
        if($('.chroom[data-rid="'+roomid+'"]').length) {
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Du bist bereits in diesem Raum!');
        } else {
          enterRoom(roomid);
        }
      } else {
        showNotify('error', 'fa fa-exclamation-circle fa-lg', RoomSel_Lang.error, RoomSel_Lang.errort1);
      }
    } else {
      showNotify('error', 'fa fa-exclamation-circle fa-lg', RoomSel_Lang.error, RoomSel_Lang.errort2);
    }
  } else {
    inputRoomPW(roomid);
    showNotify('info', 'fa fa-info-circle fa-lg', RoomSel_Lang.info, RoomSel_Lang.infot1);
  }
}

function inputRoomPW(roomid) {
  dialog = $( "#passwordbox" ).dialog({
    autoOpen: false,
    title: RoomSel_Lang.ptitle,
    modal: true,
    buttons: [{ text: RoomSel_Lang.send, click: function () { enterRoom(roomid); $(this).dialog("close"); } }, { text: RoomSel_Lang.abort, click: function () {$(this).dialog("close"); } }]
  });
  dialog.dialog( "open" );
}

function enterRoom(roomid) {
  pass = $("#"+roomid+"-pass").val();
  if(pass == 'yes') {
    $("#"+roomid+"-pass").val($("#rpassword").val());
  }
  $.ajax({
    url: 'index.php',
    type: 'post',
    dataType: 'html',
    data: 'inc=initChatRoom&sid='+sid+'&roomname='+selrname+'&rid='+roomid+'&uid='+uid+'&username='+uname+'&theme='+theme+'&'+$('form#'+roomid+'-enter').serialize(),
    success: function(data) {
      switch(data) {
        case 'false':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', RoomSel_Lang.error, RoomSel_Lang.errort3);
        break;
        default:
          loadAJAX["rid"] = roomid;
          showNotify('info', 'fa fa-info-circle fa-lg', RoomSel_Lang.info, RoomSel_Lang.infot2);
          handleContent(data, $("#"+roomid+"-rname").val(), 'room_'+roomid);
      }
    }
  });
}

//-------------------------------------------------------------------------
//---------------------Initiate JavaScript Functionality-------------------
//-------------------------------------------------------------------------

function execute_roomSel() {
  $('.roomnamelegend').each(function(){
    if($(this).find(".roomnamewrapper").width() > $(this).width()) {
      $(this).find(".roomnamewrapper").wrap('<marquee scrollamount="3" behavior="alternate" direction="right">');
    }
  });
  
  roomSelAccordion = $( "#roomaccordion" ).accordion({
    heightStyle: "content"
  });
  roomSelAccordion.find("h3").css( "padding", "0 0 0 0" );
  roomSelAccordion.find("h3").css( "fontSize", "90%" );
}

$(document).ready(function(){
  execute_roomSel();
});