function execute_Radio() {

  var stream = {
    title: "DevStream",
    mp3: "http://www.zevolutions.de:7160/;stream/1"
  },
  ready = false,
  myPlayer = $("#jquery_jplayer_1"),
  myPlayerData,
  options = {
    ready: function (event) {
      if(event.jPlayer.status.noVolume) {
        $(".jp-gui").addClass("jp-no-volume");
      }
      ready = true;
      $(this).jPlayer("setMedia", stream);
    },
    volumechange: function(event) {
      if(event.jPlayer.options.muted) {
        myControl.volume.slider("value", 0);
      } else {
        myControl.volume.slider("value", event.jPlayer.options.volume);
      }
    },
    pause: function() {
      $(this).jPlayer("clearMedia");
    },
    error: function(event) {
      if(ready && event.jPlayer.error.type === $.jPlayer.error.URL_NOT_SET) {
        $(this).jPlayer("setMedia", stream).jPlayer("play");
      }
    },
    swfPath: "js",
    supplied: "mp3",
    cssSelectorAncestor: "#jp_container_1",
    wmode: "window",
    keyEnabled: true
  },
  myControl = {
    volume: $(options.cssSelectorAncestor + " .jp-volume-slider")
  };

  myPlayer.jPlayer(options);

  myPlayerData = myPlayer.data("jPlayer");

  $('.jp-gui ul li').hover(
    function() { $(this).addClass('ui-state-hover'); },
    function() { $(this).removeClass('ui-state-hover'); }
  );

  myControl.volume.slider({
    animate: "fast",
    max: 1,
    range: "min",
    step: 0.01,
    value : $.jPlayer.prototype.options.volume,
      slide: function(event, ui) {
        myPlayer.jPlayer("option", "muted", false);
        myPlayer.jPlayer("option", "volume", ui.value);
      }
  });

$.SHOUTcast({
   host : 'www.zevolutions.de',
   port : '7160',
   interval : 15000,
   stats : function(){
     if(!this.get('songtitle')) {
       $('#stationname').text("Offline");
       $('#songnamecon').hide();
       $('#djnamecon').hide();
       $('#jp_container_1').hide();
       $('#listenersholder').hide();
     } else {
       $('#songnamecon').show();
       $('#djnamecon').show();
       $('#jp_container_1').show();
       $('#listenersholder').show();
       $('#songname').text(this.get('songtitle','Off Air'));
       $('#stationname').text(this.get('servertitle','Offline'));
       $('#djname').text(this.get('dj','Offline'));
       $('#listeners').text(this.get('currentlisteners','0'));
     }
   }
}).startStats();

}

$(document).ready(function(){
  execute_Radio();
});