var roomSelAccordion = '';
var ucRoomVal1 = "0";
var ucRoomVal2 = "99";
var ucRoomVal3 = "0";

function ucreateRoom() {
  selrname = $("#rc_rname").val();
  var str = $('#createroom').serializefiles();
  str.append('inc', 'croomajax');
  str.append('sid', sid);
  str.append('mina', ucRoomVal1);
  str.append('maxa', ucRoomVal2);
  str.append('max', ucRoomVal3);
  openDialog.dialog( "close" );
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "json",
    success: function(data) {
      $( "#roomlist" ).find("span.fa-refresh").click();
      enterRoom(data.rid);
    }
  });
}

function execute_roomCreate() {
  $( "#rcr_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ 0, 99 ],
    slide: function( event, ui ) {
      $( "#rcr_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      ucRoomVal1 = ui.values[0];
      ucRoomVal2 = ui.values[1];
    }
  });
  
  $( "#rc_chatter_disp_slider" ).slider({
    range: "min",
    min: 0,
    max: 100,
    value: 0,
    slide: function( event, ui ) {
      if(ui.value == 0) {
        var show = "Unbegrenzt";
      } else {
        var show = ui.value;
      }
      $( "#rc_chatter_disp" ).html( show );
    },
    stop: function(event, ui) {
      ucRoomVal3 = ui.value;
    }
  });
  
  $('.color').colpick({
	  layout:'hex',
	  submit:0,
	  onChange:function(hsb,hex,rgb,el,bySetColor) {
      $(el).css('color','#'+hex);
      if(!bySetColor) $(el).val(hex);
	  }}
  ).keyup(function(){
	  $(this).colpickSetColor(this.value);
  });
  $('.color').each(function() {
    $(this).colpickSetColor($(this).val());
  });

  uRoomCreateRoomDialogForm = openDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    ucreateRoom();
  });

  $('#ButtonGLOBP').html("Erstellen");
  $('#ButtonGLOBN').html("Abbrechen");
  openDialog.dialog( "option", "width", 450 );
  openDialog.dialog( "option", "height", 650 );
}

$(document).ready(function(){
  execute_roomCreate();
});