var bidholder;
var acpDeleteBWDialog;
var acpCreateBWDialog;
var acpEditBWDialog;
var cBWVal1 = "0";
var cBWVal2 = "99";
var eBWVal1;
var eBWVal2;

function delBW() {
  var str = 'inc=admin&loc=badwords&dont=1&do=delbw&bid='+bidholder+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Badword gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function createBadword() {
  var str = 'inc=admin&loc=badwords&dont=1&do=createbw&sid='+sid+'&min='+cBWVal1+'&max='+cBWVal2+'&'+$("#bwcreate").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Badword erstellt!');
      reloadTab(activePanel);
    }
  });
}

function editBadword() {
  var str = 'inc=admin&loc=badwords&dont=1&do=editbw&sid='+sid+'&min='+eBWVal1+'&max='+eBWVal2+'&'+$("#bwedit").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Badword bearbeitet!');
      reloadTab(activePanel);
    }
  });
}

function openDelBW(bid) {
  bidholder = bid;
  acpDeleteBWDialog.dialog( "open" );
}

function openEditBW(bid) {
  bidholder = bid;
  var str = 'inc=admin&loc=badwords&dont=1&do=getbw&bid='+bid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildEditBW(data);
    }
  });
}

function openCreateBW() {
  acpCreateBWDialog.dialog( "open" );
}

function buildEditBW(data) {
  $("#acp_bwe_bid").val(data.id);
  $("#acp_bwe_word").val(data.word);
  switch(data.tswitch) {
    case "1": var rebuilt = '<option value="1" style="checked">Ja</option><option value="0">Nein</option>'; break;
    case "0": var rebuilt = '<option value="0" style="checked">Nein</option><option value="1">Ja</option>'; break;
  }
  $("#acp_bwe_text").html(rebuilt);
  switch(data.nswitch) {
    case "1": var rebuilt = '<option value="1" style="checked">Ja</option><option value="0">Nein</option>'; break;
    case "0": var rebuilt = '<option value="0" style="checked">Nein</option><option value="1">Ja</option>'; break;
  }
  $("#acp_bwe_name").html(rebuilt);
  switch(data.punish) {
    case "0": var rebuilt = '<option value="0" style="checked">Keine</option><option value="1">1 Min. verwirren</option><option value="2">1 Min. knebeln</option><option value="3">Verwarnung</option><option value="4">1 Std. bannen</option>'; break;
    case "1": var rebuilt = '<option value="1" style="checked">1 Min. verwirren</option><option value="0">Keine</option><option value="2">1 Min. knebeln</option><option value="3">Verwarnung</option><option value="4">1 Std. bannen</option>'; break;
    case "2": var rebuilt = '<option value="2" style="checked">1 Min. knebeln</option><option value="0">Keine</option><option value="1">1 Min. verwirren</option><option value="3">Verwarnung</option><option value="4">1 Std. bannen</option>'; break;
    case "3": var rebuilt = '<option value="3" style="checked">Verwarnung</option><option value="0">Keine</option><option value="1">1 Min. verwirren</option><option value="2">1 Min. knebeln</option><option value="4">1 Std. bannen</option>'; break;
    case "4": var rebuilt = '<option value="4" style="checked">1 Std. bannen</option><option value="0">Keine</option><option value="1">1 Min. verwirren</option><option value="2">1 Min. knebeln</option><option value="3">Verwarnung</option>'; break;
  }
  $("#acp_bwe_punish").html(rebuilt);
  
  eBWVal1 = data.minage;
  eBWVal2 = data.maxage;
  $( "#acp_bwe_age_disp" ).html( eBWVal1 + " - " + eBWVal2 );
  
  var t1 = parseInt(eBWVal1);
  var t2 = parseInt(eBWVal2);
  
  $( "#acp_bwe_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ t1, t2 ],
    slide: function( event, ui ) {
      $( "#acp_bwe_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      eBWVal1 = ui.values[0];
      eBWVal2 = ui.values[1];
    }
  });
  
  acpEditBWDialog.dialog( "open" );
}

function execute_ACPBadwords() {
  $("#acp_bw_new").button();
  $( ".bweditbutton" ).button({
    showLabel: false
  });
  $( ".bwdelbutton" ).button({
    showLabel: false
  });
  $( ".bwconbuttons" ).controlgroup();
  $( "#acp_bwc_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ 0, 99 ],
    slide: function( event, ui ) {
      $( "#acp_bwc_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      cBWVal1 = ui.values[0];
      cBWVal2 = ui.values[1];
    }
  });
  
  $( "#acp_bwe_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ 0, 99 ],
    slide: function( event, ui ) {
      $( "#acp_bwe_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      eBWVal1 = ui.values[0];
      eBWVal2 = ui.values[1];
    }
  });
  
  acpCreateBWDialog = $( "#acp_bw_creator" ).dialog({
    autoOpen: false,
    modal: true,
    width: 450,
    height: 480,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPBWC",
        click: function () {
          createBadword();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPBWC').html("Erstellen");
  $('#ButtonACPCANCEL').html("Abbrechen");

  form1 = acpCreateBWDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createBadword();
  });
    
  acpEditBWDialog = $( "#acp_bw_editor" ).dialog({
    autoOpen: false,
    modal: true,
    width: 450,
    height: 480,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPBWE",
        click: function () {
          editBadword();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPBWE').html("Bearbeiten");
  $('#ButtonACPCANCEL1').html("Abbrechen");

  form2 = acpEditBWDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editBadword();
  });
  
  acpDeleteBWDialog = $( "#acp_bw_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:150,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPBWD",
        click: function () {
          delBW();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPBWD').html("Löschen");
  $('#ButtonACPCANCEL2').html("Abbrechen");
}

$(document).ready(function(){
  execute_ACPBadwords();
});