var cpuBar;
var cpuBarValue;
var cpuBarValueInd;
var ramBar;
var ramBarValue;
var ramBarValueInd;
var userHolder;
var userHolderValue;

function execute_ACPMain() {
  cpuBarValue = Math.floor($( "#cpubar" ).attr("data-usage"));
  if(cpuBarValue < 1) { cpuBarValue = 1; }
  $( "#cpubar" ).progressbar({
      value: cpuBarValue
  });
  cpuBar = $("#cpubar");
  cpuBarValueInd = cpuBar.find( ".ui-progressbar-value" );
  
  if(cpuBarValue <= 25) {
    cpuBarValueInd.css({
      "background": '#009900'
    });
  } else if (cpuBarValue > 25 && cpuBarValue <= 75) {
    cpuBarValueInd.css({
      "background": '#FFA500'
    });
  } else if (cpuBarValue > 75) {
    cpuBarValueInd.css({
      "background": '#999900'
    });
  }
  
  ramBarValue = Math.floor($( "#rambar" ).attr("data-usage"));
  $( "#rambar" ).progressbar({
      value: ramBarValue
  });
  ramBar = $("#rambar");
  ramBarValueInd = ramBar.find( ".ui-progressbar-value" );
  
  if(ramBarValue <= 25) {
    ramBarValueInd.css({
      "background": '#009900'
    });
  } else if (ramBarValue > 25 && ramBarValue <= 75) {
    ramBarValueInd.css({
      "background": '#FFA500'
    });
  } else if (ramBarValue > 75) {
    ramBarValueInd.css({
      "background": '#999900'
    });
  }
  
  userHolder = $( "#userholder" );
  userHolderValue = Math.floor(userHolder.attr("data-usage"));
  var userHolderUser = '';
  for (var i = 0; i < userHolderValue; i++) {
    userHolderUser += '<i class="fa fa-user fa-2x"></i> ';
  }
  userHolder.html(userHolderUser);
}

$(document).ready(function(){
  execute_ACPMain();
});