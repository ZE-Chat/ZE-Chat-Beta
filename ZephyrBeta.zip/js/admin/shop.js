var oldCat;
var newCat;
var arrangeItem;
var handleItem;
var handleCat;
var shopDeleteItemDialog = '';
var shopEditItemDialog = '';
var shopCreateItemDialog = '';
var shopDeleteCatDialog = '';
var shopEditCatDialog = '';
var shopCreateCatDialog = '';
var shopDiscountDialog = '';

function resortItem() {
  var str = 'inc=admin&loc=shop&dont=1&do=resortitem&oc='+oldCat+'&nc='+newCat+'&iid='+arrangeItem+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
//      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie gewechselt!');
//      reloadTab(activePanel);
    }
  });
}

function openDeleteItem(iid) {
  handleItem = iid;
  shopDeleteItemDialog.dialog( "open" );
}

function openCreateItem() {
  shopCreateItemDialog.dialog( "open" );
}

function openCreateCat() {
  shopCreateCatDialog.dialog( "open" );
}

function openDeleteCat(cid) {
  handleCat = cid;
  shopDeleteCatDialog.dialog( "open" );
}

function openDiscountItem(iid) {
  handleItem = iid;
  shopDiscountDialog.dialog( "open" );
}

function delItem() {
  var str = 'inc=admin&loc=shop&dont=1&do=delitem&iid='+handleItem+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gegenstand gelöscht!');
      $(".item_"+handleItem).remove();
    }
  });
}

function delCat() {
  var str = 'inc=admin&loc=shop&dont=1&do=delcat&cid='+handleCat+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function editItem() {
  var str = $('#eitem').serializefiles();
  str.append('inc', 'admin');
  str.append('loc', 'shop');
  str.append('dont', '1');
  str.append('do', 'edititem');
  str.append('sid', sid);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gegenstand überarbeitet!');
      reloadTab(activePanel);
    }
  });
}

function editCat() {
  var str = 'inc=admin&loc=shop&dont=1&do=editcat&sid='+sid+'&'+$("#escat").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie überarbeitet!');
      reloadTab(activePanel);
    }
  });
}

function createCat() {
  var str = 'inc=admin&loc=shop&dont=1&do=createcat&sid='+sid+'&'+$("#cscat").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie erstellt!');
      reloadTab(activePanel);
    }
  });
}

function createItem() {
  var str = $('#citem').serializefiles();
  str.append('inc', 'admin');
  str.append('loc', 'shop');
  str.append('dont', '1');
  str.append('do', 'createitem');
  str.append('sid', sid);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gegenstand erstellt!');
      reloadTab(activePanel);
    }
  });
}

function openEditItem(iid) {
  var str = 'inc=admin&loc=shop&dont=1&do=getitem&iid='+iid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildItem(data);
    }
  });
}

function openEditCat(cid) {
  var str = 'inc=admin&loc=shop&dont=1&do=getcat&cid='+cid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildCat(data);
    }
  });
}

function discountItem() {
  var str = $('#discountitem').serializefiles();
  str.append('iid', handleItem);
  str.append('inc', 'admin');
  str.append('loc', 'shop');
  str.append('dont', '1');
  str.append('do', 'discountitem');
  str.append('sid', sid);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gegenstand rabattiert!');
      reloadTab(activePanel);
    }
  });
}

function buildItem(data) {
  $("#acp_e_iid").val(data.id);
  $("#acp_e_iname").val(data.name);
  $("#acp_e_itext").val(data.text);
  $("#acp_e_iuntil").val(data.until);
  $("#acp_e_icost").val(data.cost);
  $("#acp_e_icode").val(data.code);
  switch(data.dura) {
    case "0": var tdura = '<option value="0" style="checked">Unbegrenzt</option><option value="86400">Ein Tag</option><option value="604800">Eine Woche</option><option value="2678400">Ein Monat</option>'; break;
    case "86400": var tdura = '<option value="86400" style="checked">Ein Tag</option><option value="0">Unbegrenzt</option><option value="604800">Eine Woche</option><option value="2678400">Ein Monat</option>'; break;
    case "604800": var tdura = '<option value="604800" style="checked">Eine Woche</option><option value="0">Unbegrenzt</option><option value="86400">Ein Tag</option><option value="2678400">Ein Monat</option>'; break;
    case "2678400": var tdura = '<option value="2678400" style="checked">Ein Monat</option><option value="0">Unbegrenzt</option><option value="86400">Ein Tag</option><option value="604800">Eine Woche</option>'; break;
  }
  $("#acp_e_idura").html(tdura);
  switch(data.avail) {
    case "0": var tavail = '<option value="0" style="checked">Nein</option><option value="1">Ja</option>'; break;
    case "1": var tavail = '<option value="1" style="checked">Ja</option><option value="0">Nein</option>'; break;
  }
  $("#acp_e_iavail").html(tavail);
  switch(data.mage) {
    case "0": var tage = '<option value="0" style="checked">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "12": var tage = '<option value="12" style="checked">FSK 12</option><option value="0">Uneingeschränkt</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "16": var tage = '<option value="16" style="checked">FSK 16</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="18">FSK 18</option>'; break;
    case "18": var tage = '<option value="18" style="checked">FSK 18</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option>'; break;
  }
  $("#acp_e_iage").html(tage);
  switch(data.special) {
    case "0": var tspecial = '<option value="0" style="checked">Nein</option><option value="1">Ja</option>'; break;
    case "1": var tspecial = '<option value="1" style="checked">Ja</option><option value="0">Nein</option>'; break;
  }
  $("#acp_e_ispecial").html(tspecial);
  shopEditItemDialog.dialog( "open" );
}

function buildCat(data) {
  $("#acp_e_cid").val(data.id);
  $("#acp_e_cname").val(data.name);
  switch(data.age) {
    case "0": var tage = '<option value="0" style="checked">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "12": var tage = '<option value="12" style="checked">FSK 12</option><option value="0">Uneingeschränkt</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "16": var tage = '<option value="16" style="checked">FSK 16</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="18">FSK 18</option>'; break;
    case "18": var tage = '<option value="18" style="checked">FSK 18</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option>'; break;
  }
  $("#acp_e_cage").html(tage);
  shopEditCatDialog.dialog( "open" );
}

function execute_ACPShop() {
  $("#acp_shop_create_cat").button();
  $("#acp_shop_create_item").button();
  $("#acp_shop_change_news").button();
    
  $( ".cateditbutton" ).button({
    showLabel: false
  });
  $( ".catdeletebutton" ).button();
  $( ".itemeditbutton" ).button({
    showLabel: false
  });
  $( ".itemdeletebutton" ).button({
    showLabel: false
  });
  $( ".shopeditbuttons" ).controlgroup();
  $( "#acpshopdiscountbuttons input" ).checkboxradio();
  $( "#acpshopdiscountbuttons" ).controlgroup();
  $( ".itemholder" ).sortable({
    tolerance: "pointer",
    opacity: 0.5,
    forcePlaceholderSize: true,
    placeholder: "ui-state-highlight",
    connectWith: ".itemholder",
    remove: function(event, ui) {
      if(!$('.items', this).length) {
        $(this).html('<div id="acp_noitem_'+this.id+'" class="ui-widget-content ui-corner-all clearfix gradient noitem" style="width: 90%; padding: 4px; margin-bottom: 4px; margin-right: 5px;" align="center"><p>Keine Gegenstände in dieser Kategorie!</p><button id="" class="catdeletebutton" style="height: 20px; padding-top: 0px; width: 250px; margin: 10px;" onclick="openDeleteCat(\''+this.id.substr(4)+'\')">Löschen</button></div>');
        $( ".catdeletebutton" ).button();
      }
    },
    receive: function(event, ui) {
      oldCat = ui.sender.attr("data-cid");
      newCat = $("#"+this.id).attr("data-cid");
      arrangeItem = ui.item.attr("id");
      $('.noitem', "#"+this.id).remove();
      console.log("hier");
      resortItem();
    }
  }).disableSelection();
  
  shopDeleteItemDialog = $( "#acp_shop_item_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:160,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPSDI",
        click: function () {
          delItem();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSDI').html("Löschen");
  $('#ButtonACPCANCEL').html("Abbrechen");
  
  shopEditItemDialog = $( "#acp_shop_item_editor" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 650,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSEI",
        click: function () {
          editItem();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSEI').html("Anpassen");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  form = shopEditItemDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editItem();
  });
    
  shopCreateItemDialog = $( "#acp_shop_item_creator" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 650,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSCI",
        click: function () {
          createItem();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL3",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCI').html("Erstellen");
  $('#ButtonACPCANCEL3').html("Abbrechen");
    
  $( ".itemdate" ).datepicker({
    dateFormat: "dd-mm-yy",
    changeMonth: true,
    changeYear: true,
    yearRange: "-0:+5"
  });

  form2 = shopCreateItemDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createItem();
  });
    
  shopDeleteCatDialog = $( "#acp_shop_cat_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:160,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPSCD",
        click: function () {
          delCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL4",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCD').html("Löschen");
  $('#ButtonACPCANCEL4').html("Abbrechen");
  
  shopEditCatDialog = $( "#acp_shop_cat_editor" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 270,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSCE",
        click: function () {
          editCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL5",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCE').html("Anpassen");
  $('#ButtonACPCANCEL5').html("Abbrechen");

  form3 = shopEditCatDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editCat();
  });
    
  shopCreateCatDialog = $( "#acp_shop_cat_creator" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 270,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSCC",
        click: function () {
          createCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL6",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCC').html("Anlegen");
  $('#ButtonACPCANCEL6').html("Abbrechen");

  form3 = shopCreateCatDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createCat();
  });
  
  shopDiscountDialog = $( "#acp_shop_item_discounter" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 560,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSDiscount",
        click: function () {
          discountItem();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL7",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSDiscount').html("Rabattieren");
  $('#ButtonACPCANCEL7').html("Abbrechen");

  form3 = shopDiscountDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    discountItem();
  });
}

$(document).ready(function(){
  execute_ACPShop();
});
