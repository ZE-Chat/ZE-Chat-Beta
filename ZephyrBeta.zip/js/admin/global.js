function acpChangeSett(id) {
  var str = 'inc=admin&loc=global&dont=1&do=changeSett&sid='+sid+'&'+$("#"+id).serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Einstellung wurde aktualisiert!');
      reloadTab(activePanel);
    }
  });
}

function execute_ACPGlobal() {
/**  $('.userPerm').button();
  $(".acp_user_g_sw").selectmenu({
    change: function(event, ui) {
      changeAccGroup($(ui.item.element).closest("select").data('id'), ui.item.value);
    }
  });
  $(".acp_user_ug_sw").selectmenu({
    change: function(event, ui) {
      changeUserGroup($(ui.item.element).closest("select").data('id'), ui.item.value);
    }
  });
  ACPUserPermDialog = $( "#acp_user_editor" ).dialog({
    width: 400,
    height: 600,
    autoOpen: false,
    modal: true,
    buttons: {
      'ButtonD': userPermChange,
      Cancel: function() {
        ACPUserPermDialog.dialog( "close" );
      }
    },
    close: function() {
      form[ 0 ].reset();
    }
  });
  $('.ui-dialog-buttonpane button:contains(ButtonD)').attr("id","user_perm_dialog_box_send-button");            
  $('#user_perm_dialog_box_send-button').find('.ui-button-text').html("Ändern");
  form = ACPUserPermDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    userPermChange();
  });
**/
  $(".onoffswitch").switchButton({
    on_label: 'An',
    off_label: 'Aus'
  });
  $(".yesnoswitch").switchButton({
    on_label: 'Ja',
    off_label: 'Nein'
  });
  $('.color').colpick({
	  layout:'hex',
	  submit:0,
	  onChange:function(hsb,hex,rgb,el,bySetColor) {
      $(el).css('color','#'+hex);
      if(!bySetColor) $(el).val(hex);
	  }}
  ).keyup(function(){
	  $(this).colpickSetColor(this.value);
  });
  $('.color').each(function() {
    $(this).colpickSetColor($(this).val());
  });
  $('.globalbutton').button({
    showLabel: false
  });
  $('.globalform').submit(function(e){
        e.preventDefault();
  });
}

$(document).ready(function(){
  execute_ACPGlobal();
});