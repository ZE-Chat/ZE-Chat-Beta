//Accordion holder "PermChanger"
//Object
var ACPUserPermAccordion = '';

//Dialog holder "UserPermChanger"
//Object
var ACPUserPermDialog = '';

//Dialog holder "UserPermReseter"
//Object
var ACPUserPermResetDialog = '';

//UserID holder
//id
var ACPUserID = '';

var searchPattern = 'data-name';

function changeAccGroup(id, target) {
  var str = 'inc=admin&loc=users&dont=1&sid='+sid+'&do=changeAccGroup&aid='+id+'&target='+target;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Jop!', 'Is aktualisiert');
      reloadTab(activePanel);
    }
  });
}

function changeUserGroup(id, target) {
  var str = 'inc=admin&loc=users&dont=1&sid='+sid+'&do=changeUserGroup&uid='+id+'&target='+target;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Jop!', 'Is aktualisiert');
      reloadTab(activePanel);
    }
  });
}

function openUserPermReset(id) {
  ACPUserID = id;
  ACPUserPermResetDialog.dialog( "open" );
}

function resetPerm() {
  lloading = 'inc=admin&loc=users&dont=1&do=resetUserPerm&uid='+ACPUserID+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "json",
    success: function(data) {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Jop!', 'Is wieder normal');
      ACPUserPermResetDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function openUserPerm(id) {
  ACPUserID = id;
  lloading = 'inc=admin&loc=users&dont=1&do=getUserPerm&uid='+ACPUserID+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "json",
    success: function(data) {
      buildUserPerm(data);
    }
  });
}

function buildUserPerm(data) {
  var tmpin = '';
  for(o=0; o < data.length; o++) {
    tmpin += '<h3>'+data[o].gname+'</h3><div>';
    for(i=0; i <data[o].entry.length; i++) {
      tmpin += '<div class="ui-widget ui-widget-content ui-corner-all clearfix" style="width: 90%; padding: 5px; margin-bottom: 3px;">';
      tmpin += '<div class="fll"';
      if(data[o].entry[i].desc != '') {
        tmpin += ' title="'+data[o].entry[i].desc+'"';
      }
      tmpin += '>'+data[o].entry[i].shown+'</div><div class="flr"><input id="'+data[o].entry[i].name+'" name="'+data[o].entry[i].name+'" class="onoffswitch" type="checkbox"';
      if(data[o].entry[i].default != 'off') {
        tmpin += ' checked ';
      }
      tmpin += ' /></div></div>';
    }
    tmpin += '</div>';
  }
  $( "#acp_user_edit_accordion" ).html(tmpin);
  ACPUserPermAccordion.accordion("refresh");
  $("#acp_user_edit_accordion .onoffswitch").switchButton({
    on_label: 'An',
    off_label: 'Aus'
  });
  ACPUserPermDialog.dialog( "open" );
}


function userPermChange() {
  var str = $('#acp_user_edit_form').serializefiles();
  $( "#acp_user_edit_form input[type=checkbox]" ).each(function() {
    if($(this).prop('checked') != true) {
      str.append($(this).attr('name'), '0');
    }
  });
  str.append('inc', 'admin');
  str.append('loc', 'users');
  str.append('dont', '1');
  str.append('do', 'changeUserPerm');
  str.append('sid', sid);
  str.append('uid', ACPUserID);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Jau!', 'Geht');
      ACPUserPermDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function searchBox() {
  $("#acpuserfilterinput").keyup(function() { 
    var filter = $("#acpuserfilterinput").val().toUpperCase();
    if(filter != '') {
      $('.'+searchPattern+':not(:icontains('+ filter +'))').closest("div").hide(); 
      $('.'+searchPattern+':icontains('+ filter +')').closest("div").show(); 
    } else {
      $('.accountlist').show();
    }
  }).keyup();
}

function execute_ACPUser() {
  $('.userPerm').button();
  $( ".ACPuserDelButton" ).button({
    showLabel: false
  });
  $( ".acpuserbuttonset button" ).button({
    showLabel: false
  });
  $( ".acceditbuttons" ).controlgroup();
  $( ".acpuserbuttonset" ).controlgroup();
  $( ".makemesmall" ).controlgroup();
  
  $("#acpfiltersettings").selectmenu({
    change: function(event, ui) {
      searchPattern = ui.item.value;
      searchBox();
    }
  });
  $(".acp_user_g_sw").selectmenu({
    change: function(event, ui) {
      changeAccGroup($(ui.item.element).closest("select").data('id'), ui.item.value);
    }
  });
  $(".acp_user_ug_sw").selectmenu({
    change: function(event, ui) {
      changeUserGroup($(ui.item.element).closest("select").data('id'), ui.item.value);
    }
  });
  ACPUserPermDialog = $( "#acp_user_editor" ).dialog({
    width: 400,
    height: 600,
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPUEP",
        click: function () {
          userPermChange();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL1",
        click: function() {
          form[ 0 ].reset();
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      form[ 0 ].reset();
    }
  });
  $('#ButtonACPUEP').html("Anwenden");
  $('#ButtonACPCANCEL1').html("Abbrechen");

  form = ACPUserPermDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    userPermChange();
  });

  ACPUserPermResetDialog = $( "#acp_userperm_resetter" ).dialog({
    autoOpen: false,
    resizable: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPURP",
        click: function () {
          resetPerm();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL2",
        click: function() {
          form[ 0 ].reset();
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      form[ 0 ].reset();
    }
  });
  $('#ButtonACPURP').html("Standart");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  ACPUserPermAccordion = $( "#acp_user_edit_accordion" ).accordion({
    heightStyle: "content"
  });

  searchBox();
}

$(document).ready(function(){
  execute_ACPUser();
});