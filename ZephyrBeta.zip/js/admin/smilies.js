var oldCat;
var newCat;
var arrangeSmilie;
var handleSmilie;
var handleCat;
var smilieDeleteItemDialog = '';
var smilieEditItemDialog = '';
var smilieCreateItemDialog = '';
var smilieDeleteCatDialog = '';
var smilieEditCatDialog = '';
var smilieCreateCatDialog = '';

function openDeleteSmilie(smiid) {
  handleSmilie = smiid;
  smilieDeleteItemDialog.dialog( "open" );
}

function delSmilie() {
  var str = 'inc=admin&loc=smilies&dont=1&do=delsmilie&smiid='+handleSmilie+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Smilie gelöscht!');
      $(".item_"+handleSmilie).remove();
    }
  });
}

function openCreateSmilie() {
  smilieCreateItemDialog.dialog( "open" );
}

function createSmilie() {
  var str = $('#csmilie').serializefiles();
  str.append('inc', 'admin');
  str.append('loc', 'smilies');
  str.append('dont', '1');
  str.append('do', 'createsmilie');
  str.append('sid', sid);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Smilie erstellt!');
      reloadTab(activePanel);
    }
  });
}

function openCreateCat() {
  smilieCreateCatDialog.dialog( "open" );
}

function createCat() {
  var str = 'inc=admin&loc=smilies&dont=1&do=createcat&sid='+sid+'&'+$("#csmicat").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie erstellt!');
      reloadTab(activePanel);
    }
  });
}

function openDeleteCat(cid) {
  handleCat = cid;
  smilieDeleteCatDialog.dialog( "open" );
}

function delCat() {
  var str = 'inc=admin&loc=smilies&dont=1&do=delcat&cid='+handleCat+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function openEditCat(cid) {
  var str = 'inc=admin&loc=smilies&dont=1&do=getcat&cid='+cid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildCat(data);
    }
  });
}

function buildCat(data) {
  $("#acp_e_cid").val(data.sc_id);
  $("#acp_e_cname").val(data.sc_name);
  switch(data.sc_usk) {
    case "0": var tage = '<option value="0" style="checked">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "12": var tage = '<option value="12" style="checked">FSK 12</option><option value="0">Uneingeschränkt</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "16": var tage = '<option value="16" style="checked">FSK 16</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="18">FSK 18</option>'; break;
    case "18": var tage = '<option value="18" style="checked">FSK 18</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option>'; break;
  }
  $("#acp_e_cage").html(tage);
  var trank = '<option value="'+data.sc_lvl+'" style="checked">'+data.sc_lvlname+'</option>';
  for(i=0; i < data.sc_ranks.length; i++) {
    trank += '<option value="'+data.sc_ranks[i].order+'">'+data.sc_ranks[i].name+'</option>';
    console.log("ko");
  }
  $("#acp_e_crank").html(trank);
  smilieEditCatDialog.dialog( "open" );
}

function editCat() {
  var str = 'inc=admin&loc=smilies&dont=1&do=editcat&sid='+sid+'&'+$("#esmicat").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie überarbeitet!');
      reloadTab(activePanel);
    }
  });
}

function openEditSmilie(smiid) {
  var str = 'inc=admin&loc=smilies&dont=1&do=getsmilie&smiid='+smiid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildSmilie(data);
    }
  });
}

function buildSmilie(data) {
  $("#acp_e_smiid").val(data.smi_id);
  $("#acp_e_sname").val(data.smi_name);
  $("#acp_e_ssc").val(data.smi_sc);
  switch(data.smi_usk) {
    case "0": var tage = '<option value="0" style="checked">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "12": var tage = '<option value="12" style="checked">FSK 12</option><option value="0">Uneingeschränkt</option><option value="16">FSK 16</option><option value="18">FSK 18</option>'; break;
    case "16": var tage = '<option value="16" style="checked">FSK 16</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="18">FSK 18</option>'; break;
    case "18": var tage = '<option value="18" style="checked">FSK 18</option><option value="0">Uneingeschränkt</option><option value="12">FSK 12</option><option value="16">FSK 16</option>'; break;
  }
  $("#acp_e_sage").html(tage);
  
  var trank = '<option value="'+data.smi_lvl+'" style="checked">'+data.smi_lvlname+'</option>';
  for(i=0; i < data.smi_ranks.length; i++) {
    trank += '<option value="'+data.smi_ranks[i].order+'">'+data.smi_ranks[i].name+'</option>';
    console.log('rank: '+data.smi_ranks[i].name);
  }
  $("#acp_e_srank").html(trank);
  
  var tcats = '<option value="'+data.smi_cat+'" style="checked">'+data.smi_catname+'</option>';
  for(i=0; i < data.smi_cats.length; i++) {
    tcats += '<option value="'+data.smi_cats[i].id+'">'+data.smi_cats[i].name+'</option>';
    console.log('cat: '+data.smi_cats[i].name);
  }
  $("#acp_e_scat").html(tcats);
  
  smilieEditItemDialog.dialog( "open" );
}

function editSmilie() {
  var str = $('#esmilie').serializefiles();
  str.append('inc', 'admin');
  str.append('loc', 'smilies');
  str.append('dont', '1');
  str.append('do', 'editsmilie');
  str.append('sid', sid);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Smilie überarbeitet!');
      reloadTab(activePanel);
    }
  });
}

function resortSmilies() {
  var str = 'inc=admin&loc=smilies&dont=1&do=resortsmilies&nc='+newCat+'&smiid='+arrangeSmilie+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function(data) {
//      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie gewechselt!');
//      reloadTab(activePanel);
console.log(data);
    }
  });
}

function execute_ACPSmilies() {
  $("#acp_smilies_create_cbutton").button();
  $("#acp_smilies_create_sbutton").button();
  $( ".catdeletebutton" ).button();
  $( ".cateditbutton" ).button({
    showLabel: false
  });
  $( ".smilieeditbuttons" ).controlgroup();
  $( ".smiliesholder" ).sortable({
    tolerance: "pointer",
    opacity: 0.5,
    forceHelperSize: true,
    connectWith: ".smiliesholder",
    remove: function(event, ui) {
      if(!$('.items', this).length) {
        $(this).html('<div id="acp_noitem_'+this.id+'" class="ui-widget-content ui-corner-all clearfix gradient noitem" style="width: 90%; padding: 4px; margin-bottom: 4px; margin-right: 5px;" align="center"><p>Keine Smilies in dieser Kategorie!</p><button id="" class="catdeletebutton" style="height: 20px; padding-top: 0px; width: 250px; margin: 10px;" onclick="openDeleteCat(\''+this.id.substr(4)+'\')">Löschen</button></div>');
        $( ".catdeletebutton" ).button();
      }
    },
    receive: function(event, ui) {
      newCat = $("#"+this.id).attr("data-cid");
      arrangeSmilie = ui.item.attr("id");
      $('.noitem', "#"+this.id).remove();
      console.log("new: "+newCat);
      console.log("own: "+arrangeSmilie);
      resortSmilies();
    }
  }).disableSelection();
  
  smilieEditItemDialog = $( "#acp_smilie_editor" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 650,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSEI",
        click: function () {
          editSmilie();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSEI').html("Anpassen");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  form = smilieEditItemDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editSmilie();
  });
  
  smilieCreateItemDialog = $( "#acp_smilie_creator" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 650,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSCI",
        click: function () {
          createSmilie();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL3",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCI').html("Erstellen");
  $('#ButtonACPCANCEL3').html("Abbrechen");
    
  form2 = smilieCreateItemDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createSmilie();
  });
  
  smilieEditCatDialog = $( "#acp_smilie_cat_editor" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 335,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSCE",
        click: function () {
          editCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL5",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCE').html("Anpassen");
  $('#ButtonACPCANCEL5').html("Abbrechen");

  form3 = smilieEditCatDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editCat();
  });
  
  smilieCreateCatDialog = $( "#acp_smilie_cat_creator" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 335,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPSCC",
        click: function () {
          createCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL6",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCC').html("Anlegen");
  $('#ButtonACPCANCEL6').html("Abbrechen");

  form3 = smilieCreateCatDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createCat();
  });
  
  smilieDeleteCatDialog = $( "#acp_smilie_cat_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:160,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPSCD",
        click: function () {
          delCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL4",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSCD').html("Löschen");
  $('#ButtonACPCANCEL4').html("Abbrechen");
  
  smilieDeleteItemDialog = $( "#acp_smilie_smilie_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:160,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPSDI",
        click: function () {
          delSmilie();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPSDI').html("Löschen");
  $('#ButtonACPCANCEL').html("Abbrechen");
}
$(document).ready(function(){
  execute_ACPSmilies();
});