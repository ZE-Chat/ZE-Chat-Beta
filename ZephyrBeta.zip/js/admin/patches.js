var patchId = 'none';
var patchDialog1 = '';
var patchDialog2 = '';

function askPerformPatch(pid) {
  patchId = pid;
  patchDialog1.dialog( "open" );
}

function installPatchAuto() {

}

function installPatchMan() {

}

function execute_ACPPatches() {
  $('.acppatchinstallbutton').button();
  patchDialog1 = $( "#acp_patch_confirm" ).dialog({
    autoOpen: false,
    resizable: false,
    height: 140,
    modal: true
  });

  patchDialog2 = $( "#acp_patch_manual" ).dialog({
    autoOpen: false,
    resizable: false,
    height: 100,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPPC",
        click: function () {
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPPC').html("Gemacht!");
  $('#ButtonACPCANCEL1').html("Abbrechen");
}

$(document).ready(function(){
  execute_ACPPatches();
});