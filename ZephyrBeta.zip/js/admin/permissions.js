//Dialog holder "GroupCreate"
//Object
var permGCreateDialog = '';

//Dialog holder "PermCreate"
//Object
var permPCreateDialog = '';

//Dialog holder "GPermDeleter"
//Object
var permPGDeleteDialog = '';

//Dialog holder "PermDeleter"
//Object
var permPGDeletePDialog = '';

//Dialog holder "PermGDeleter"
//Object
var permPGDeleteGDialog = '';

//Dialog holder "GroupChanger"
//Object
var permGEditDialog = '';

//Default HTML from "GroupChanger"
//HTML String
var permGEditContent = '';

//Accordion holder "GroupChanger"
//Object
var permGEditAccordion = '';

//ID holder "GroupChanger"
//id
var permGEditId = '';

//Dialog holder "GroupDeleter"
//Object
var permGDeleteDialog = '';

//ID holder "GroupDeleter"
//id
var permGDeleteId = '';

//-------------Create new Group--------------

function permCreateGroup() {
  var str = $('#acp_perm_gcreate_form').serializefiles();
  $( "#acp_perm_gcreate_form input[type=checkbox]" ).each(function() {
    if($(this).prop('checked') != true) {
      str.append($(this).attr('name'), '0');
    }
  });
  str.append('inc', 'admin');
  str.append('loc', 'permissions');
  str.append('dont', '1');
  str.append('do', 'createGroupSettings');
  str.append('sid', sid);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Gruppe angelegt!');
      permGCreateDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

//--------------Initiate Group Changer-------

function changeGroupSettings(ACPgid) {
  lloading = 'inc=admin&loc=permissions&dont=1&do=getGroupSettings&gid='+ACPgid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "json",
    success: function(data) {
      buildGroupSett(data);
    }
  });
}

function buildGroupSett(data) {
  var tmpin = permGEditContent;
  for(o=0; o < data.length; o++) {
    tmpin += '<h3>'+data[o].gname+'</h3><div>';
    for(i=0; i <data[o].entry.length; i++) {
      tmpin += '<div class="ui-widget ui-widget-content ui-corner-all clearfix" style="width: 90%; padding: 5px; margin-bottom: 3px;">';
      tmpin += '<div class="fll" title="'+data[o].entry[i].name;
      if(data[o].entry[i].desc != '') {
        tmpin += ' - '+data[o].entry[i].desc;
      }
      tmpin += '">'+data[o].entry[i].shown+'</div><div class="flr"><input id="'+data[o].entry[i].name+'" name="'+data[o].entry[i].name+'" class="onoffswitch" type="checkbox"';
      if(data[o].entry[i].default != 'off') {
        tmpin += ' checked ';
      }
      tmpin += ' /></div></div>';
    }
    tmpin += '</div>';
  }
  $( "#acp_perm_gedit_accordion" ).html(tmpin);
  permGEditAccordion.accordion("refresh");
  $("#acp_perm_gedit_accordion .onoffswitch").switchButton({
    on_label: 'An',
    off_label: 'Aus'
  });
  $( "#groupeditname" ).val(data[0].title);
  $( "#editgroupradios"+data[0].state ).prop('checked', true);
  $( "#editgroupradios" ).controlgroup();
  $( "#editgroupradiosdel" ).controlgroup();
  permGEditId = data[0].gid;
  permGEditDialog.dialog( "open" );
}

//---------------Change Group Settings--------

function permChangeGroup() {
  var str = $('#acp_perm_gedit_form').serializefiles();
  $( "#acp_perm_gedit_form input[type=checkbox]" ).each(function() {
    if($(this).prop('checked') != true) {
      str.append($(this).attr('name'), '0');
    }
  });
  str.append('inc', 'admin');
  str.append('loc', 'permissions');
  str.append('dont', '1');
  str.append('do', 'changeGroupSettings');
  str.append('sid', sid);
  str.append('gid', permGEditId);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Gruppe geändert!');
      permGEditDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function updateOrder(id, order) {
  lloading = 'inc=admin&loc=permissions&dont=1&do=changeOrder&gid='+id+'&order='+order+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Reihenfolge wurde aktualisiert!');
      reloadTab(activePanel);
    }
  });
}

//--------------Delete Group-----------------

function delGroup() {
  lloading = 'inc=admin&loc=permissions&dont=1&do=deleteGroup&gid='+permGDeleteId+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Gruppe gelöscht!');
      permGDeleteDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function askDelPermGroup(gid) {
  permGDeleteId = gid;
  permGDeleteDialog.dialog( "open" );
}

//-------------Create Permission------------

function permCreatePerm() {
  var str = 'inc=admin&loc=permissions&dont=1&sid='+sid+'&'+$("#acp_perm_pcreate_form").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Recht angelegt!');
      permPCreateDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function deletePerm(id) {
  permGDeleteId = id;
  permPGDeleteDialog.dialog( "close" );
  permPGDeletePDialog.dialog( "open" );
}

function delPermP() {
  var str = 'inc=admin&loc=permissions&dont=1&do=deletePerm&sid='+sid+'&id='+permGDeleteId;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Recht gelöscht!');
      permPGDeletePDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function deleteGroup(id) {
  permGDeleteId = id;
  permPGDeleteDialog.dialog( "close" );
  permPGDeleteGDialog.dialog( "open" );
}

function delPermG() {
  var str = 'inc=admin&loc=permissions&dont=1&do=deletePermG&sid='+sid+'&id='+permGDeleteId;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Gruppe gelöscht!');
      permPGDeletePDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

//-------------------------------------------------------------------------
//---------------------Initiate JavaScript Functionality-------------------
//-------------------------------------------------------------------------

function execute_ACPPerm() {
  $( "#creategroupradios" ).controlgroup();
  $( "#createpermradios" ).controlgroup();
  $( "#createpermradiosb" ).controlgroup();
  permGCreateDialog = $( "#acp_perm_gcreator" ).dialog({
    width: 400,
    height: 600,
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPCG",
        click: function () {
          permCreateGroup();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPCG').html("Anlegen");
  $('#ButtonACPCANCEL1').html("Abbrechen");

  form = permGCreateDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    permCreateGroup();
  });

  permPCreateDialog = $( "#acp_perm_pcreator" ).dialog({
    width: 400,
    height: 600,
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPCP",
        click: function () {
          permCreatePerm();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPCP').html("Anlegen");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  form = permPCreateDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    permCreatePerm();
  });

  $( "#createpermradios1" ).on( "click", function() {
    $( "#onlyforperm" ).show();
  });
  $( "#createpermradios2" ).on( "click", function() {
    $( "#onlyforperm" ).hide();
  });
  $( "#acp_perm_create_gbutton" ).button().on( "click", function() {
    permGCreateDialog.dialog( "open" );
  });
  $( "#acp_perm_create_pbutton" ).button().on( "click", function() {
    permPCreateDialog.dialog( "open" );
  });
  $( "#acp_perm_delete_pbutton" ).button().on( "click", function() {
    permPGDeleteDialog.dialog( "open" );
  });
  $( "#acp_perm_gcreate_accordion" ).accordion({
      heightStyle: "content"
    });
  $(".onoffswitch").switchButton({
    on_label: 'An',
    off_label: 'Aus'
  });
  $("#acp_group_holder :button").button();
  $("#acp_perm_pgdeleter :button").button();

  permGDeleteDialog = $( "#acp_group_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:140,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPDG",
        click: function () {
          delGroup();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL3",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPDG').html("Löschen");
  $('#ButtonACPCANCEL3').html("Abbrechen");

  permPGDeletePDialog = $( "#acp_perm_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:140,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPDP",
        click: function () {
          delPermP();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL4",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPDP').html("Löschen");
  $('#ButtonACPCANCEL4').html("Abbrechen");

  permPGDeleteGDialog = $( "#acp_gperm_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPDPG",
        click: function () {
          delPermG();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL5",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPDPG').html("Löschen");
  $('#ButtonACPCANCEL5').html("Abbrechen");

  permPGDeleteDialog = $( "#acp_perm_pgdeleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height: 600,
    modal: true,
    buttons: {
      Cancel: function() {
        $( this ).dialog( "close" );
      }
    }
  });

  permGEditDialog = $( "#acp_perm_geditor" ).dialog({
    width: 400,
    height: 600,
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPEG",
        click: function () {
          permChangeGroup();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANEL6",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPEG').html("Ändern");
  $('#ButtonACPCANCEL6').html("Abbrechen");

  form = permGEditDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    permChangeGroup();
  });
  
  permGEditAccordion = $( "#acp_perm_gedit_accordion" ).accordion({
    heightStyle: "content"
  });
  $( ".permibuttons" ).controlgroup();
}

$(document).ready(function(){
  permGEditContent = $( "#acp_perm_gedit_accordion" ).html();
  execute_ACPPerm();
});