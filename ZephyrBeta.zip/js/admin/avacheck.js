//Dialog holder "AvaAccept"
//Object
var avaAcceptDialog = '';

//Dialog holder "AvaAccept"
//Object
var avaDenyDialog = '';

function acceptAva() {
  var str = 'inc=admin&loc=avacheck&dont=1&do=acceptAva&sid='+sid+'&'+$("#cavaedit").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Avatar wurde freigegeben!');
      avaAcceptDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function denyAva() {
  var str = 'inc=admin&loc=avacheck&dont=1&do=denyAva&sid='+sid+'&'+$("#cavadelete").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Avatar wurde abgelehnt!');
      avaDenyDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function execute_ACPAvaCheck() {
  $('#acp_cava_accept').button();
  $('#acp_cava_deny').button();
  
  avaAcceptDialog = $( "#acp_cava_editor" ).dialog({
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPCAVAA",
        click: function () {
          acceptAva();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      acpcAvaForm[ 0 ].reset();
    }
  });
  $('#ButtonACPCAVAA').html("Freigeben");
  $('#ButtonACPCANCEL1').html("Abbrechen");

  acpcAvaForm = avaAcceptDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    acceptAva();
  });
  
  $( "#acp_cava_accept" ).button().on( "click", function() {
    avaAcceptDialog.dialog( "open" );
  });
  
  avaDenyDialog = $( "#acp_cava_deleter" ).dialog({
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPCAVAD",
        click: function () {
          denyAva();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      acpc2AvaForm[ 0 ].reset();
    }
  });
  $('#ButtonACPCAVAD').html("Ablehnen");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  acpc2AvaForm = avaDenyDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    denyAva();
  });
  
  $( "#acp_cava_deny" ).button().on( "click", function() {
    avaDenyDialog.dialog( "open" );
  });
  
  $(".onoffswitch").switchButton({
    on_label: 'Ja',
    off_label: 'Nein'
  });
}

$(document).ready(function(){
  execute_ACPAvaCheck();
});