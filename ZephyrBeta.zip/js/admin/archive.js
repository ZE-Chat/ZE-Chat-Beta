var archiveDialog = '';

function openArchive() {
  archiveDialog.dialog( "open" );
}

function getArchive() {
  var str = 'inc=admin&loc=archive&dont=1&do=getarchive&sid='+sid+'&'+$("#archiveform").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildArchive(data);
    }
  });
}

function buildArchive(data) {
  var tempList = '';
  for(i=0; i < data.length; i++) {
    tempList += '<span style="font-size: 80%">'+data[i].mess_write_time+'</span> <span style="color: #'+data[i].mess_form+'">'+data[i].mess_author_name+': '+data[i].mess_content+'</span><br />';
  }
  $('#acpmessholder').html(tempList);
  showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Logfile geholt!');
}

function execute_ACPArchive() {
  $( "#acp_archive_get" ).button();
  $( ".archivedate" ).datetimepicker({
    dateFormat: "dd-mm-yy",
    changeMonth: true,
    changeYear: true,
    yearRange: "-0:+5"
  });
  
  $( "#atinput" ).autocomplete({
    minLength: 0,
    source: epMailAC,
    focus: function( event, ui ) {
      $( "#atinput" ).val( ui.item.label );
      return false;
    },
    select: function( event, ui ) {
      $( "#atinput" ).val( ui.item.label );
      $( "#at" ).val( ui.item.value );
      return false;
    }
  })
  .autocomplete( "instance" )._renderItem = function( ul, item ) {
    return $( "<li>" )
    .append( '<a><b>' + item.label + '</b><br><span style="font-size: 80%;">' + item.desc + '</span></a>' )
    .appendTo( ul );
  };
  
  archiveDialog = $( "#acp_archive_dialog" ).dialog({
    autoOpen: false,
    resizable: false,
    height:470,
    width:450,
    modal: false,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPAD",
        click: function () {
          getArchive();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPAD').html("Holen");
  $('#ButtonACPCANCEL').html("Abbrechen");
}

$(document).ready(function(){
  execute_ACPArchive();
});