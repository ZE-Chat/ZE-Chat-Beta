  var llang = 'none';
  var larea = 'none';
  var ldid = 'none';
  var langDeleteDialog = '';
  var langCreateDialog = '';

  function getLangfields() {
    lloading = 'inc=admin&loc=lang&dont=1&do=getLangfields&lang='+llang+'&area='+larea+'&sid='+sid;
    $.ajax({
      url: "index.php", 
      data: lloading,
      dataType: "json",
      success: function(data) {
        buildLangFields(data);
      }
    });
  }

  function delLangfields() {
    lloading = 'inc=admin&loc=lang&dont=1&do=deleteLangfields&id='+ldid+'&sid='+sid;
    $.ajax({
      url: "index.php", 
      data: lloading,
      dataType: "text",
      success: function() {
        showNotify('success', 'fa fa-check-circle fa-lg', ACPLang_Lang.success, ACPLang_Lang.deleted);
        getLangfields();
      }
    });
  }

  function askDelLangfields(lid) {
    ldid = lid;
    langDeleteDialog.dialog( "open" );
  }

  function buildLangFields(data) {
    var tmplangfields = '';
    for(i=0;i < data.length; i++) {
      tmplangfields += '<div id="acp_lang_nav_'+data[i].id+'" class="ui-widget-header ui-corner-all" align="left" style="width:100%; margin-left: -7px; padding: 4px; margin-top: 4px; display: inline-block;"><input name="id" class="ui-corner-all" style="display: none;" maxlength="32" value="'+data[i].id+'" readonly="readonly" /><input name="lang" class="ui-corner-all" style="display: none;" maxlength="32" value="'+data[i].language+'" readonly="readonly" /><input class="ui-corner-all" style="margin-right: 4px" name="code" value="'+data[i].code+'" /><input class="ui-corner-all" style="margin-right: 4px" name="area" value="'+data[i].area+'" /><input class="ui-corner-all" style="margin-right: 4px" name="content" value="'+data[i].content+'" /><span class="flr"><button class="ui-corner-all" id="acp_lang_'+data[i].id+'" type="button" style="margin-right: 20px; height: 24px; vertical-align: top;" onclick="setLangfields(\'acp_lang_nav_'+data[i].id+'\');">'+ACPLang_Lang.alter+'</button><button class="ui-corner-all" id="acp_lang_'+data[i].id+'" type="button" style="height: 24px; vertical-align: top;" onclick="askDelLangfields(\''+data[i].id+'\');">'+ACPLang_Lang.delete+'</button></span></div><br />';
    }
    $( "#acp_lang_holder" ).html(tmplangfields);
    $("#acp_lang_holder :button").button();
  }

  function setLangfields(row) {
    var str = 'inc=admin&loc=lang&dont=1&do=setLangfields&sid='+sid+'&'+$("#"+row+" :input").serialize();
    $.ajax({
      url: "index.php", 
      data: str,
      dataType: "text",
      success: function() {
        showNotify('success', 'fa fa-check-circle fa-lg', ACPLang_Lang.success, ACPLang_Lang.updated);
        getLangfields();
      }
    });
  }

  function createLangfields() {
    var str = 'inc=admin&loc=lang&dont=1&do=createLangfields&sid='+sid+'&'+$("#acp_lang_form").serialize();
    $.ajax({
      url: "index.php", 
      data: str,
      dataType: "text",
      success: function() {
        showNotify('success', 'fa fa-check-circle fa-lg', ACPLang_Lang.success, ACPLang_Lang.created);
        getLangfields();
        $("#langcodecreator").val("");
        $("#langconcreator").val("");
      }
    });
  }

  function execute_ACPLang() {
    langCreateDialog = $( "#acp_lang_creator" ).dialog({
      autoOpen: false,
      modal: true,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPLFC",
        click: function () {
          createLangfields();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL",
        click: function() {
          $( this ).dialog( "close" );
        }
      }],
      close: function() {
        form[ 0 ].reset();
      }
  });
  $('#ButtonACPLFC').html("Erstellen");
  $('#ButtonACPCANCEL').html("Abbrechen");

    form = langCreateDialog.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      createLangfields();
    });

    langDeleteDialog = $( "#acp_lang_deleter" ).dialog({
      autoOpen: false,
      resizable: false,
      height:140,
      modal: true,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPLFD",
        click: function () {
          delLangfields();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPLFD').html("Löschen");
  $('#ButtonACPCANCEL2').html("Abbrechen");

    $( "#acp_lang_create" ).button().on( "click", function() {
      langCreateDialog.dialog( "open" );
    });

    $( "#acp_llang" ).selectmenu({
      change: function( event, data ) {
        llang = data.item.value;
      }
    });
    $( "#acp_larea" ).selectmenu({
      change: function( event, data ) {
        larea = data.item.value;
      }
    });
    $("#acp_lang_get").button();
    $("#acp_lang_create").button();

    $('#langselector1').change(function() {
      var chosen = $("option:selected", this).text();
      $("#langselector2").toggleClass("hidden", chosen != ACPLang_Lang.makenew);
      if(chosen == ACPLang_Lang.makenew) { 
        $("#langselector1").attr("name", "unused");
        $("#langselector2").attr("name", "lang");
      } else {
        $("#langselector1").attr("name", "lang");
        $("#langselector2").attr("name", "unused");
      }
    });

    $('#areaselector1').change(function() {
      var chosen2 = $("option:selected", this).text();
      $("#areaselector2").toggleClass("hidden", chosen2 != ACPLang_Lang.makenew);
      if(chosen2 == ACPLang_Lang.makenew) { 
        $("#areaselector1").attr("name", "unused");
        $("#areaselector2").attr("name", "area");
      } else {
        $("#areaselector1").attr("name", "area");
        $("#areaselector2").attr("name", "unused");
      }
    });
  }

  $(document).ready(function(){
    execute_ACPLang();
  });
