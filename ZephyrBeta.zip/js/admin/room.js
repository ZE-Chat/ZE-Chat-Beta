var oldCat;
var newCat;
var arrangeItem;
var handleItem;
var handleCat;
var roomCreateCatDialog;
var roomDeleteCatDialog;
var roomEditCatDialog;
var roomCreateRoomDialog;
var roomDeleteRoomDialog;
var roomEditRoomDialog;
var cCatVal1 = "0";
var cCatVal2 = "99";
var eCatVal1;
var eCatVal2;
var cRoomVal1 = "0";
var cRoomVal2 = "99";
var cRoomVal3 = "0";
var eRoomVal1;
var eRoomVal2;
var eRoomVal3;

function resortRooms() {
  var str = 'inc=admin&loc=rooms&dont=1&do=resortroom&oc='+oldCat+'&nc='+newCat+'&rid='+arrangeItem+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST"
  });
}

function createRoomCat() {
  var str = 'inc=admin&loc=rooms&dont=1&do=createcat&sid='+sid+'&min='+cCatVal1+'&max='+cCatVal2+'&'+$("#rccat").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie überarbeitet!');
      reloadTab(activePanel);
    }
  });
}

function delRoomCat() {
  var str = 'inc=admin&loc=rooms&dont=1&do=delcat&cid='+handleCat+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function delRoomRoom() {
  var str = 'inc=admin&loc=rooms&dont=1&do=delroom&rid='+handleCat+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Raum gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function editRoomCat() {
  var str = 'inc=admin&loc=rooms&dont=1&do=editcat&sid='+sid+'&min='+eCatVal1+'&max='+eCatVal2+'&'+$("#rescat").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Kategorie bearbeitet!');
      reloadTab(activePanel);
    }
  });
}

function createRoom() {
  var str = $('#croom').serializefiles();
  str.append('inc', 'admin');
  str.append('loc', 'rooms');
  str.append('dont', '1');
  str.append('do', 'createroom');
  str.append('sid', sid);
  str.append('mina', cRoomVal1);
  str.append('maxa', cRoomVal2);
  str.append('max', cRoomVal3);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Raum erstellt!');
      reloadTab(activePanel);
    }
  });
}

function editRoomRoom() {
  var str = $('#eroom').serializefiles();
  str.append('inc', 'admin');
  str.append('loc', 'rooms');
  str.append('dont', '1');
  str.append('do', 'editroom');
  str.append('sid', sid);
  str.append('mina', eRoomVal1);
  str.append('maxa', eRoomVal2);
  str.append('max', eRoomVal3);
  $.ajax({
    url: "index.php", 
    data: str,
    cache: false,
    contentType: false,
    processData: false,
    type: "POST",
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Raum bearbeitet!');
      reloadTab(activePanel);
    }
  });
}

function openRoomCreateCat() {
  roomCreateCatDialog.dialog( "open" );
}

function openRoomCreateRoom() {
  roomCreateRoomDialog.dialog( "open" );
}

function openRoomDeleteCat(cid) {
  handleCat = cid;
  roomDeleteCatDialog.dialog( "open" );
}

function openRoomDeleteRoom(cid) {
  handleCat = cid;
  roomDeleteRoomDialog.dialog( "open" );
}

function setSysCol(col) {
  $("#acp_re_rcol").val(col);
  $("#acp_re_rcol").css({'color': '#'+col});
}

function setRoomDefCol(col) {
  $("#acp_re_rbgcol").val(col);
  $("#acp_re_rbgcol").css({'color': '#'+col});
}

function openRoomEditRoom(rid) {
  var str = 'inc=admin&loc=rooms&dont=1&do=getroom&rid='+rid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildRoomRoom(data);
    }
  });
}

function openRoomEditCat(cid) {
  var str = 'inc=admin&loc=rooms&dont=1&do=getcat&cid='+cid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildRoomCat(data);
    }
  });
}

function buildRoomCat(data) {
  $("#acp_re_cid").val(data.cat_id);
  $("#acp_re_cname").val(data.cat_name);
  switch(data.cat_can_create) {
    case "1": var rebuilt = '<option value="1" style="checked">Ja</option><option value="0">Nein</option>'; break;
    case "0": var rebuilt = '<option value="0" style="checked">Nein</option><option value="1">Ja</option>'; break;
  }
  $("#acp_re_allow").html(rebuilt);
  
  eCatVal1 = data.cat_visa_req_user_min_age;
  eCatVal2 = data.cat_visa_req_user_max_age;
  $( "#acp_re_age_disp" ).html( eCatVal1 + " - " + eCatVal2 );
  
  var t1 = parseInt(eCatVal1);
  var t2 = parseInt(eCatVal2);
  
  $( "#acp_re_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ t1, t2 ],
    slide: function( event, ui ) {
      $( "#acp_re_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      eCatVal1 = ui.values[0];
      eCatVal2 = ui.values[1];
    }
  });
  
  roomEditCatDialog.dialog( "open" );
}

function buildRoomRoom(data) {
  data = data[0];
  $("#acp_e_rid").val(data.room_id);
  $("#acp_re_rname").val(data.room_name);
  $("#acp_re_rtopic").val(data.room_topic);
  $("#acp_re_rrules").val(data.room_rules);
  $("#acp_re_rwelcome").val(data.room_welcome);
  $("#acp_re_rcol").val(data.room_color);
  $("#acp_re_rcol").css({'color': '#'+data.room_color});
  $("#acp_re_rbgcol").val(data.room_bg);
  $("#acp_re_rbgcol").css({'color': '#'+data.room_bg});
  switch(data.room_show_rules) {
    case "1": var rebuilt = '<option value="1" style="checked">Ja</option><option value="0">Nein</option>'; break;
    case "0": var rebuilt = '<option value="0" style="checked">Nein</option><option value="1">Ja</option>'; break;
  }
  $("#acp_re_srules").html(rebuilt);
  switch(data.room_state) {
    case "1": var rebuilt = '<option value="1" style="checked">Nein</option><option value="0">Ja</option>'; break;
    case "0": var rebuilt = '<option value="0" style="checked">Ja</option><option value="1">Nein</option>'; break;
  }
  $("#acp_re_ropen").html(rebuilt);
  
  eRoomVal1 = data.room_visa_req_user_min_age;
  eRoomVal2 = data.room_visa_req_user_max_age;
  $( "#acp_rer_age_disp" ).html( eRoomVal1 + " - " + eRoomVal2 );
  
  var t1 = parseInt(eRoomVal1);
  var t2 = parseInt(eRoomVal2);
  
  $( "#acp_rer_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ t1, t2 ],
    slide: function( event, ui ) {
      $( "#acp_rer_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      eRoomVal1 = ui.values[0];
      eRoomVal2 = ui.values[1];
    }
  });
  
  eRoomVal3 = data.room_max;
  var t3 = parseInt(eRoomVal3);
  
  if(eRoomVal3 == 0) {
    var show = "Unbegrenzt";
  } else {
    var show = eRoomVal3;
  }
  $( "#acp_re_chatter_disp" ).html( show );
  
  $( "#acp_re_chatter_disp_slider" ).slider({
    range: "min",
    min: 0,
    max: 100,
    value: t3,
    slide: function( event, ui ) {
      if(ui.value == 0) {
        var show = "Unbegrenzt";
      } else {
        var show = ui.value;
      }
      $( "#acp_re_chatter_disp" ).html( show );
    },
    stop: function(event, ui) {
      eRoomVal3 = ui.value;
    }
  });
  
  roomEditRoomDialog.dialog( "open" );
}

//-------------------------------------------------------------------------
//---------------------Initiate JavaScript Functionality-------------------
//-------------------------------------------------------------------------

function execute_ACPRoom() {
  $("#acp_room_create_cat").button();
  $("#acp_room_create_room").button();
    
  $( ".cateditbutton" ).button({
    showLabel: false
  });
  $( ".cateditcolbutton" ).button({
    showLabel: false
  });
  $( ".catdeletebutton" ).button();
  $( ".roomeditbutton" ).button({
    showLabel: false
  });
  $( ".roomdeletebutton" ).button({
    showLabel: false
  });
  $( ".roomeditbuttons" ).controlgroup();
  $( ".roomholder" ).sortable({
    tolerance: "pointer",
    opacity: 0.5,
    forcePlaceholderSize: true,
    placeholder: "ui-state-highlight",
    connectWith: ".roomholder",
    remove: function(event, ui) {
      if(!$('.items', this).length) {
        $(this).html('<div id="acp_noroom_'+this.id+'" class="ui-widget-content ui-corner-all clearfix gradient noitem" style="width: 90%; padding: 4px; margin-bottom: 4px; margin-right: 5px;" align="center"><p>Keine Räume in dieser Kategorie!</p><button id="" class="catdeletebutton" style="height: 20px; padding-top: 0px; width: 250px; margin: 10px;" onclick="openRoomDeleteCat(\''+this.id.substr(4)+'\')">Löschen</button></div>');
        $( ".catdeletebutton" ).button();
      }
    },
    receive: function(event, ui) {
      oldCat = ui.sender.attr("data-cid");
      newCat = $("#"+this.id).attr("data-cid");
      arrangeItem = ui.item.attr("id");
      $('.noitem', "#"+this.id).remove();
      console.log("hier");
      resortRooms();
    }
  }).disableSelection();
  
  $( "#acp_rc_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ 0, 99 ],
    slide: function( event, ui ) {
      $( "#acp_rc_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      cCatVal1 = ui.values[0];
      cCatVal2 = ui.values[1];
    }
  });
  
  $( "#acp_rcr_age_disp_slider" ).slider({
    range: true,
    min: 0,
    max: 99,
    values: [ 0, 99 ],
    slide: function( event, ui ) {
      $( "#acp_rcr_age_disp" ).html( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
    },
    stop: function(event, ui) {
      cRoomVal1 = ui.values[0];
      cRoomVal2 = ui.values[1];
    }
  });
  
  $( "#acp_rc_chatter_disp_slider" ).slider({
    range: "min",
    min: 0,
    max: 100,
    value: 0,
    slide: function( event, ui ) {
      if(ui.value == 0) {
        var show = "Unbegrenzt";
      } else {
        var show = ui.value;
      }
      $( "#acp_rc_chatter_disp" ).html( show );
    },
    stop: function(event, ui) {
      cRoomVal3 = ui.value;
    }
  });
  
  $('.color').colpick({
	  layout:'hex',
	  submit:0,
	  onChange:function(hsb,hex,rgb,el,bySetColor) {
      $(el).css('color','#'+hex);
      if(!bySetColor) $(el).val(hex);
	  }}
  ).keyup(function(){
	  $(this).colpickSetColor(this.value);
  });
  $('.color').each(function() {
    $(this).colpickSetColor($(this).val());
  });
  
  roomCreateRoomDialog = $( "#acp_room_room_creator" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 650,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPRCR",
        click: function () {
          createRoom();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPRCR').html("Anlegen");
  $('#ButtonACPCANCEL').html("Abbrechen");

    form2 = roomCreateRoomDialog.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      createRoom();
    });
  
  roomCreateCatDialog = $( "#acp_room_cat_creator" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 345,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPRCC",
        click: function () {
          createRoomCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPRCC').html("Anlegen");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  form3 = roomCreateCatDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createRoomCat();
  });
  
  roomEditCatDialog = $( "#acp_room_cat_editor" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 345,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPREC",
        click: function () {
          editRoomCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL3",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPREC').html("Anpassen");
  $('#ButtonACPCANCEL3').html("Abbrechen");

    form4 = roomEditCatDialog.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      editRoomCat();
    });
  
  roomDeleteCatDialog = $( "#acp_room_cat_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:160,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPRDC",
        click: function () {
          delRoomCat();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL4",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPRDC').html("Löschen");
  $('#ButtonACPCANCEL4').html("Abbrechen");
  
  roomDeleteRoomDialog = $( "#acp_room_room_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:160,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPRDR",
        click: function () {
          delRoomRoom();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL5",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPRDR').html("Löschen");
  $('#ButtonACPCANCEL5').html("Abbrechen");
  
  roomEditRoomDialog = $( "#acp_room_room_editor" ).dialog({
      autoOpen: false,
      modal: true,
      width: 450,
      height: 650,
      buttons: [{
        text: "Ok",
        "id": "ButtonACPRER",
        click: function () {
          editRoomRoom();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL6",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPRER').html("Anpassen");
  $('#ButtonACPCANCEL6').html("Abbrechen");

    form = roomEditRoomDialog.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      editRoomRoom();
    });
}

$(document).ready(function(){
  execute_ACPRoom();
});