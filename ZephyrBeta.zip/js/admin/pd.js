var pdCreateDialog = '';
var pdEditDialog = '';
var pdDeleteDialog = '';
var pdDeleteId = '';

function ACPPDmoveUp(id) {
  var newID = $("#acp_pd_"+id).prev(".pd_hold").attr('data-id');
  var str = 'inc=admin&loc=pd&dont=1&do=movePD&sid='+sid+'&pid='+id+'&nid='+newID;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "GET",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Feld nach oben geschoben!');
      reloadTab(activePanel);
    }
  });
}

function ACPPDmoveDown(id) {
  var newID = $("#acp_pd_"+id).next(".pd_hold").attr('data-id');
  var str = 'inc=admin&loc=pd&dont=1&do=movePD&sid='+sid+'&pid='+id+'&nid='+newID;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "GET",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Feld nach unten geschoben!');
      reloadTab(activePanel);
    }
  });
}

function createPD() {
  var str = 'inc=admin&loc=pd&dont=1&do=createPD&sid='+sid+'&'+$("#acppdcreate").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Feld wurde angelegt!');
      pdCreateDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function openEditPD(pid) {
  lloading = 'inc=admin&loc=pd&dont=1&do=getPD&pid='+pid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "json",
    success: function(data) {
      $("#acp_pdid").val(pid);
      $("#eacppdtitle").val(data.prof_field_name);
      $("#eacppddefault").val(data.prof_field_default);
      if(data.prof_field_type == '2') {
        $("#eacppdtype").html('<option value="2" style="checked">Text</option><option value="3">Select</option>');
      } else {
        $("#eacppdtype").html('<option value="3" style="checked">Select</option><option value="2">Text</option>');
      }
      pdEditDialog.dialog("open");
    }
  });
}

function editPD() {
  var str = 'inc=admin&loc=pd&dont=1&do=editPD&sid='+sid+'&'+$("#acppdedit").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Feld wurde bearbeitet!');
      pdEditDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

function delPD() {
  lloading = 'inc=admin&loc=pd&dont=1&do=delPD&pid='+pdDeleteId+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Feld wurde gelöscht!');
      pdDeleteDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}
function askDelPD(pid) {
  pdDeleteId = pid;
  pdDeleteDialog.dialog( "open" );
}

function execute_ACPPD() {
  $('.acp_pd_button').button();
  $('.acp_pd_up_button').button({
    showLabel: false
  });
  $('.acp_pd_down_button').button({
    showLabel: false
  });
  $('.acp_pd_button_edit').button({
    showLabel: false
  });
  $('.acp_pd_button_delete').button({
    showLabel: false
  });
  $( ".buttoned" ).controlgroup();
  $( ".buttonupdown" ).controlgroup();
  $(".acp_pd_up_button:first").button( "disable" );
  $(".acp_pd_down_button:last").button( "disable" );
  
  pdCreateDialog = $( "#acp_pd_creator" ).dialog({
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPPDC",
        click: function () {
          createPD();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      form[ 0 ].reset();
    }
  });
  $('#ButtonACPPDC').html("Erstellen");
  $('#ButtonACPCANCEL1').html("Abbrechen");

  form = pdCreateDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createPD();
  });
  
  $( "#acp_pd_create" ).button().on( "click", function() {
    pdCreateDialog.dialog( "open" );
  });
  
  
  pdEditDialog = $( "#acp_pd_editor" ).dialog({
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPPDE",
        click: function () {
          editPD();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      formPDE[ 0 ].reset();
    }
  });
  $('#ButtonACPPDE').html("Ändern");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  formPDE = pdEditDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editPD();
  });
  
  pdDeleteDialog = $( "#acp_pd_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:140,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPPDD",
        click: function () {
          delPD();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL3",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPPDD').html("Löschen");
  $('#ButtonACPCANCEL3').html("Abbrechen");
}

$(document).ready(function(){
  execute_ACPPD();
});