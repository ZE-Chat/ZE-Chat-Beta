//Dialog holder "NewsCreate"
//Object
var newsCreateDialog = '';

//Dialog holder "NewsEdit"
//Object
var newsEditDialog = '';

//Percent of ScreenWidth for Dialoge's
//Int
var newsDiaWidth = '';

//NewsID to delete
//Int
var newsDeleteId = '';

//Dialog holder "NewsDelete"
//Object
var newsDeleteDialog = '';

//--------------Create News-----------------

function createNews() {
  $("#news_content").sync();
  var str = 'inc=admin&loc=news&dont=1&do=createNews&sid='+sid+'&'+$("#wnews").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'News wurden eingetragen!');
      newsCreateDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

//--------------Edit News-----------------

function openEditNews(nid) {
  $("#edit_news_content").destroy();
  lloading = 'inc=admin&loc=news&dont=1&do=getnews&nid='+nid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "json",
    success: function(data) {
      $("#acp_nid").val(nid);
      $("#edit_news_title").val(data.title);
      $("#edit_news_content").val(data.content);
      makeBBCEditor("edit_news_content", "bold,italic,underline,strike,sup,sub,|,img,video,link,|,bullist,|,fontcolor,fontsize,fontfamily,|,justifyleft,justifycenter,justifyright,|,quote,code,table,removeFormat");
      newsEditDialog.dialog("open");
    }
  });
}

function editNews() {
  $("#edit_news_content").sync();
  var str = 'inc=admin&loc=news&dont=1&do=editNews&sid='+sid+'&'+$("#enews").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'News wurden bearbeitet!');
      newsEditDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}

//--------------Delete News-----------------

function delNews() {
  lloading = 'inc=admin&loc=news&dont=1&do=deleteNews&nid='+newsDeleteId+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'News wurden gelöscht!');
      newsDeleteDialog.dialog( "close" );
      reloadTab(activePanel);
    }
  });
}
function askDelNews(nid) {
  newsDeleteId = nid;
  newsDeleteDialog.dialog( "open" );
}

//-------------------------------------------------------------------------
//---------------------Initiate JavaScript Functionality-------------------
//-------------------------------------------------------------------------

function execute_ACPNews() {
  makeBBCEditor("news_content", "bold,italic,underline,strike,sup,sub,|,img,video,link,|,bullist,|,fontcolor,fontsize,fontfamily,|,justifyleft,justifycenter,justifyright,|,quote,code,table,removeFormat");
  makeBBCEditor("edit_news_content", "bold,italic,underline,strike,sup,sub,|,img,video,link,|,bullist,|,fontcolor,fontsize,fontfamily,|,justifyleft,justifycenter,justifyright,|,quote,code,table,removeFormat");
  $("#newssend").button();
  $(".acp_news_button").button();
  
  newsDiaWidth = $(window).width() * .80;
  
  newsCreateDialog = $( "#acp_news_creator" ).dialog({
    minWidth: newsDiaWidth,
    autoOpen: false,
    modal: false,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPNC",
        click: function () {
          createNews();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPNC').html("Erstellen");
  $('#ButtonACPCANCEL1').html("Abbrechen");

  form = newsCreateDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createNews();
  });
  
  $( "#acp_news_write" ).button().on( "click", function() {
    newsCreateDialog.dialog( "open" );
  });
  
  newsEditDialog = $( "#acp_news_editor" ).dialog({
    minWidth: newsDiaWidth,
    autoOpen: false,
    modal: false,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPNE",
        click: function () {
          editNews();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPNE').html("Anpassen");
  $('#ButtonACPCANCEL2').html("Abbrechen");

  form2 = newsEditDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editNews();
  });
  
  newsDeleteDialog = $( "#acp_news_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:140,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPND",
        click: function () {
          delNews();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL3",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPND').html("Löschen");
  $('#ButtonACPCANCEL3').html("Abbrechen");
}

$(document).ready(function(){
  execute_ACPNews();
});