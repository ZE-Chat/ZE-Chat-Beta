//Dialog holder "GroupChanger"
//Object
var reportEditDialog = '';

//ID holder "OpenReport"
//id
var OpenReportID = '';

function repUpdate() {
  var str = 'inc=admin&loc=reports&dont=1&do=updateReport&repid='+OpenReportID+'&sid='+sid+'&'+$("#ereport").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Meldung verarbeitet!');
      reloadTab(activePanel);
    }
  });
}

function loadReport() {
  reportEditDialog.dialog( "close" );
  lloading = 'inc=admin&loc=reports&dont=1&do=getReport&repid='+OpenReportID+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "json",
    success: function(data) {
      buildReport(data);
    }
  });
}

function buildReport(data) {
  $('#acp_area_container').prop('align', 'left');
  $('#acp_reporter_id').html(data.rep_uname);
  $('#acp_reporter_id').prop('title', 'ID: '+data.rep_uid);
  $('#acp_reporter_ip').html(data.rep_uip);
  
  $('#acp_reported_id').html(data.rep_tname);
  $('#acp_reported_id').prop('title', 'ID: '+data.rep_tid);
  $('#acp_reported_ip').html(data.rep_tip);
  
  $('#acp_reported_short').html(data.subject);
  
  $('#acp_reported_long').html(data.text);
  
  if(data.inc == 'chatroom') {
    if(data.area1 == 'avatar') {
      $('#acp_area_container').prop('align', 'center');
      $('#acp_reported_area1').html("Avatar");
      $('#acp_reported_area2').html('<img src="./files/userpic/'+data.area2+'" alt="" class="avatarsize ui-corner-all" style="display: block; margin-left: auto; margin-right: auto; margin-top: 12px; max-width: 250px;" />');
    } else {
      $('#acp_reported_area1').html(data.area1);
      $('#acp_reported_area2').html(data.area2);
    }
  } else {
    if(data.area1 == 'avatar') {
      $('#acp_area_container').prop('align', 'center');
      $('#acp_reported_area1').html("Avatar");
      $('#acp_reported_area2').html('<img src="./files/userpic/'+data.area2+'" alt="" class="avatarsize ui-corner-all" style="display: block; margin-left: auto; margin-right: auto; margin-top: 12px; max-width: 250px;" />');
    } else {
      $('#acp_area_container').prop('align', 'center');
      $('#acp_reported_area1').html("Profiltext");
      $('#acp_reported_area2').html('<span class="linkfake" onclick="loadProfile(\''+data.rep_tid+'\', \''+data.rep_uname+'\');">Profil öffnen</span>');
    }
  }
  
  $('#acp_reported_solver').html(data.sby);
  $('#acp_reported_comment').html(data.stext);
  
  reportEditDialog.dialog( "open" );
}

function execute_ACPReports() {
  reportEditDialog = $( "#acp_report_open" ).dialog({
    width: 400,
    height: 600,
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonACPOR",
        click: function () {
          repUpdate();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonACPCANCEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonACPOR').html("Abschliessen");
  $('#ButtonACPCANCEL1').html("Abbrechen");

  form = reportEditDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    repUpdate();
  });
  
  $( ".repholder" ).on( "click", function() {
    OpenReportID = $( this ).attr("data-repid");
    $( this ).addClass('gradient').removeClass('gradientred');
    loadReport();
  });
}

$(document).ready(function(){
  execute_ACPReports();
});