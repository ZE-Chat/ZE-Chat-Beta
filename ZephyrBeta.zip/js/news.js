function execute_News() {
  $( ".newsaccordion" ).accordion({
    heightStyle: "content"
  });
  $(".newsentry").each(function( index ) {
    var test = $(this).text();
    var resulter = XBBCODE.process({
      text: test,
      removeMisalignedTags: false,
      addInLineBreaks: true
    });
    $(this).html(resulter.html.trim());
  });
}

$(document).ready(function(){
  execute_News();
});