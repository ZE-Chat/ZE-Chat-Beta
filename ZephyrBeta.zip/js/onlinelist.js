var conuid;
var conname;
var conlevel;
var conavatar;
var conowner;
var globalInRoom = '';
var ignoreList = '';
var colorList = {};

function handleOnlinelist(data) {
  var nickname = '';
  if(loadAJAX["rid"] == 0) {
    if(data[0].user_name != 'Niemand') {
      nickname = '<div style="text-align: left">';
      for(i=0;i < data.length; i++) {
        nickname += '<span style="vertical-align: baseline;">';
        switch(data[i].user_ostatus) {
          case "1": nickname += '<span class="fa fa-circle-o-notch online1 fa-fw"></span>'; break;
          case "2": nickname += '<span class="fa fa-circle-o-notch online2 fa-fw"></span>'; break; 
          case "3": nickname += '<span class="fa fa-circle-o-notch online3 fa-fw"></span>'; break;
          case "4": nickname += '<span class="fa fa-circle-o-notch online4 fa-fw"></span>'; break;
        }
        switch(data[i].user_gender) {
          case "1": nickname += '<span class="fa fa-mars fa-fw"></span>'; break;
          case "2": nickname += '<span class="fa fa-venus fa-fw"></span>'; break; 
          case "0": nickname += '<span class="fa fa-genderless fa-fw"></span>'; break;
        }
//        if(data[i].user_name == 'Zion') { nickname += '<span class="fa icon-crown fa-fw"></span>'; }
        nickname += '<span style="margin-left: 4px; color: #'+data[i].user_color+';">'+trimName(data[i].user_name)+'</span>';
        if(data[i].ricon != '') {
          nickname += '<img class="flr" title="'+data[i].rname+'" style="padding-left: 4px; vertical-align:middle;" src="./files/groupicons/'+data[i].ricon+'" />';
        }
        nickname += '</span><br />';
      }
      nickname += '</div>';
    } else {
      nickname = '<span>'+data[0].user_name+'</span>';
    }
  } else {
    for(i=0;i < data.length; i++) {
      if(data[i].uid == uid) {
        conowner = data[i].owner;
        break;
      }
    }
    nickname = '<div style="text-align: left">';
    globalInRoom = '';
    for(i=0;i < data.length; i++) {
      nickname += '<span class="onlinelistmenu rcl hoverul" data-name="'+data[i].uname+'" data-uid="'+data[i].uid+'" data-level="'+data[i].level+'" style="vertical-align: baseline;">';
      switch(data[i].ostatus) {
        case "1": nickname += '<span class="fa fa-circle-o-notch fa-fw online1"></span>'; break;
        case "2": nickname += '<span class="fa fa-circle-o-notch fa-fw online2"></span>'; break; 
        case "3": nickname += '<span class="fa fa-circle-o-notch fa-fw online3"></span>'; break;
        case "4": nickname += '<span class="fa fa-circle-o-notch fa-fw online4"></span>'; break;
      }
      switch(data[i].gender) {
        case "1": nickname += '<span class="fa fa-mars fa-fw"></span>'; break;
        case "2": nickname += '<span class="fa fa-venus fa-fw"></span>'; break; 
        case "0": nickname += '<span class="fa fa-genderless fa-fw"></span>'; break;
      }
      if(data[i].uname in colorList) { data[i].color = colorList[data[i].uname]; }
      if(ignoreList.indexOf(','+data[i].uname+',') == -1) {
        nickname += '<span style="margin-left: 4px; color: #'+data[i].color+';">'+trimName(data[i].uname)+'</span>';
      } else {
        nickname += '<span style="margin-left: 4px; text-decoration: line-through; color: #'+data[i].color+';">'+trimName(data[i].uname)+'</span>';
      }
      if(data[i].ricon != '') {
        nickname += '<img class="flr" title="'+data[i].rname+'" style="padding-left: 4px; vertical-align:middle;" src="./files/groupicons/'+data[i].ricon+'" />';
      }
      if(data[i].conf != 0 && (acp == 'yes' || conowner == '1')) {
        nickname += '<i class="fa fa-random fa-fw flr" title="Verwirrt!"></i>';
      }
      if(data[i].mute != 0) {
        nickname += '<i class="fa fa-microphone-slash fa-fw flr" title="Geknebelt!"></i>';
      }
      nickname += '</span><br />';
      if(data[i].uid == uid && data[i].ostatus != currOS) {
        $(".osButtonicon").addClass("online"+data[i].ostatus).removeClass("online"+currOS);  
        currOS = data[i].ostatus;
      }
      globalInRoom += data[i].uname+',';
    }
    nickname += '</div>';
  }
  $( "#onlinelister" ).html(nickname);
  globalInRoom = globalInRoom.slice(0, -1);
}

function execute_Onlinebox() {
  $("#onlinelister").contextmenu({
    position: function(event, ui){
      return {my: "right top", at: "center", of: event, collision: "fit"};
    },
    delegate: ".onlinelistmenu",
    menu: [
      { title: "Profile", cmd: "profile", uiIcon: "fa fa-address-card-o fa-fw", action: function(event, ui) {
          loadProfile(conuid, conname);
        }
      },
      {title: "----", cmd: "prof"},
      { title: Onlinebox_Lang.talkto, cmd: "talkto", uiIcon: "fa fa-comment-o fa-fw", action: function(event, ui) {
          $("#"+activePanel).find('.text_input').val('/to "'+conname+'" ');
          $("#"+activePanel).find('.text_input').focus();
        }
      },
      { title: Onlinebox_Lang.whisper, cmd: "whisp", uiIcon: "fa fa-commenting-o fa-fw", action: function(event, ui) {
          $("#"+activePanel).find('.text_input').val('/w "'+conname+'" ');
          $("#"+activePanel).find('.text_input').focus();
        }
      },
      { title: Onlinebox_Lang.talkprivate, cmd: "priv", uiIcon: "fa fa-comments-o fa-fw", children: [
           { title: "Links", uiIcon: "fa fa-angle-double-left fa-fw", action: function(event, ui) {
                 loadBox('private', 'left', '&uid='+loadAJAX["uid"]+'&toid=0&open='+conuid);
             }
           },
           { title: "Rechts", uiIcon: "fa fa-angle-double-right fa-fw", action: function(event, ui) {
                 loadBox('private', 'right', '&uid='+loadAJAX["uid"]+'&toid=0&open='+conuid);
             }
           }
         ]
      },
      {title: "----", cmd: "first"},
      { title: Onlinebox_Lang.alert, cmd: "alert", uiIcon: "fa fa-bell-o fa-fw", action: function(event, ui) {
          notifyUser(conuid, conname);
        }
      },
      { title: Onlinebox_Lang.mail, cmd: "mail", uiIcon: "fa fa-paper-plane-o fa-fw", action: function(event, ui) {
          alert("Copy " + ui.target.text());
        }
      },
      { title: Onlinebox_Lang.friendship, cmd: "friend", uiIcon: "fa fa-handshake-o fa-fw", children: [
           { title: "Öffentlich", uiIcon: "fa fa-unlock-alt fa-fw", action: function(event, ui) {
                 inviteFriend(conuid, '1');
             }
           },
           { title: "Privat", uiIcon: "fa fa-lock fa-fw", action: function(event, ui) {
                 inviteFriend(conuid, '2');
             }
           }
         ]
      },
      { title: Onlinebox_Lang.recolor, cmd: "recol", uiIcon: "fa fa-paint-brush fa-fw", children: [
           { title: "Zufällig", uiIcon: "fa fa-paint-brush fa-fw", action: function(event, ui) {
               recolor(conname, 'random');
             }
           },
           { title: "Schwarz", uiIcon: "fa fa-paint-brush fa-fw ol-black", action: function(event, ui) {
                 recolor(conname, '000000');
             }
           },
           { title: "Grau", uiIcon: "fa fa-paint-brush fa-fw ol-grey", action: function(event, ui) {
                 recolor(conname, '808080');
             }
           },
           { title: "Silber", uiIcon: "fa fa-paint-brush fa-fw ol-silver", action: function(event, ui) {
                 recolor(conname, 'C0C0C0');
             }
           },
           { title: "Weiss", uiIcon: "fa fa-paint-brush fa-fw ol-white", action: function(event, ui) {
                 recolor(conname, 'FFFFFF');
             }
           },
           { title: "Lila", uiIcon: "fa fa-paint-brush fa-fw ol-purple", action: function(event, ui) {
                 recolor(conname, '800080');
             }
           },
           { title: "Pink", uiIcon: "fa fa-paint-brush fa-fw ol-fuchsia", action: function(event, ui) {
                 recolor(conname, 'FF00FF');
             }
           },
           { title: "Rot", uiIcon: "fa fa-paint-brush fa-fw ol-red", action: function(event, ui) {
                 recolor(conname, 'FF0000');
             }
           },
           { title: "Weinrot", uiIcon: "fa fa-paint-brush fa-fw ol-maroon", action: function(event, ui) {
                 recolor(conname, '800000');
             }
           },
           { title: "Khaki", uiIcon: "fa fa-paint-brush fa-fw ol-olive", action: function(event, ui) {
                 recolor(conname, '808000');
             }
           },
           { title: "Gelb", uiIcon: "fa fa-paint-brush fa-fw ol-yellow", action: function(event, ui) {
                 recolor(conname, 'FFFF00');
             }
           },
           { title: "Hellgrün", uiIcon: "fa fa-paint-brush fa-fw ol-lime", action: function(event, ui) {
                 recolor(conname, '00FF00');
             }
           },
           { title: "Grün", uiIcon: "fa fa-paint-brush fa-fw ol-green", action: function(event, ui) {
                 recolor(conname, '008000');
             }
           },
           { title: "Petrol", uiIcon: "fa fa-paint-brush fa-fw ol-teal", action: function(event, ui) {
                 recolor(conname, '008080');
             }
           },
           { title: "Dunkelblau", uiIcon: "fa fa-paint-brush fa-fw ol-navy", action: function(event, ui) {
                 recolor(conname, '000080');
             }
           },
           { title: "Blau", uiIcon: "fa fa-paint-brush fa-fw ol-blue", action: function(event, ui) {
                 recolor(conname, '0000FF');
             }
           },
           { title: "Türkis", uiIcon: "fa fa-paint-brush fa-fw ol-aqua", action: function(event, ui) {
                 recolor(conname, '00FFFF');
             }
           },
           { title: "Aufheben", uiIcon: "fa fa-recycle fa-fw", action: function(event, ui) {
                 recolor(conname, 'reset');
             }
           }
         ]
      },
      {title: "----", cmd: "ignotr"},
      { title: Onlinebox_Lang.ignore, cmd: "igno", uiIcon: "fa fa-eye-slash fa-fw", action: function(event, ui) {
          addIgnore(conname);
        }
      },
      { title: "Zulassen", cmd: "unigno", uiIcon: "fa fa-eye fa-fw", action: function(event, ui) {
          removeIgnore(conname);
        }
      },
      {title: "----", cmd: "second"},
      { title: Onlinebox_Lang.report, cmd: "report", uiIcon: "fa fa-exclamation-triangle fa-fw", action: function(event, ui) {
          alert("Copy " + ui.target.text());
        }
      },
      {title: "----", cmd: "third"},
      { title: "Verwirren", cmd: "ownerconf", uiIcon: "fa fa-random fa-fw", action: function(event, ui) {
          ownerConfuseUser(conuid);
        }
      },
      { title: "Entwirren", cmd: "ownerunconf", uiIcon: "fa fa-exchange fa-fw", action: function(event, ui) {
          ownerUnconfuseUser(conuid);
        }
      },
      { title: "Aus Raum entfernen", cmd: "ownerkick", uiIcon: "fa fa-sign-out fa-fw", action: function(event, ui) {
          ownerKickUser(conuid);
        }
      },
      {title: "----", cmd: "last"},
      { title: Onlinebox_Lang.admin, cmd: "admin", uiIcon: "fa fa-gavel fa-fw", children: [
           { title: Onlinebox_Lang.modify+'&nbsp;&nbsp;&nbsp;', uiIcon: "fa fa-wrench fa-fw", action: function(event, ui) {
               alert("Copy " + ui.target.text());
             }
           },
           { title: Onlinebox_Lang.information, uiIcon: "fa fa-info fa-fw", action: function(event, ui) {
               loadDialog2('admin', '&loc=info&dont=0&target='+conuid+'&sid='+sid, conname+' - Benutzerinfo');
             }
           },
           {title: "----"},
           { title: Onlinebox_Lang.confuse, uiIcon: "fa fa-random fa-fw", action: function(event, ui) {
               confuseUser(conuid);
             }
           },
           { title: "Entwirren", uiIcon: "fa fa-exchange fa-fw", action: function(event, ui) {
               unconfuseUser(conuid);
             }
           },
           { title: Onlinebox_Lang.move, uiIcon: "fa fa-arrow-circle-o-right fa-fw", action: function(event, ui) {
               alert("Copy " + ui.target.text());
             }
           },
           { title: Onlinebox_Lang.stick, uiIcon: "fa fa-lock fa-fw", action: function(event, ui) {
               alert("Copy " + ui.target.text());
             }
           },
           { title: Onlinebox_Lang.unstick, uiIcon: "fa fa-unlock fa-fw", action: function(event, ui) {
               alert("Copy " + ui.target.text());
             }
           },
           { title: Onlinebox_Lang.warn, uiIcon: "fa fa-plus-circle fa-fw", action: function(event, ui) {
               warnUser(conuid);
             }
           },
           { title: Onlinebox_Lang.parole, uiIcon: "fa fa-minus-circle fa-fw", action: function(event, ui) {
               unwarnUser(conuid);
             }
           },
           { title: Onlinebox_Lang.mute, uiIcon: "fa fa-microphone-slash fa-fw", action: function(event, ui) {
               gagUser(conuid);
             }
           },
           { title: Onlinebox_Lang.unmute, uiIcon: "fa fa-microphone fa-fw", action: function(event, ui) {
               ungagUser(conuid);
             }
           },
           {title: "----"},
           { title: Onlinebox_Lang.kick, uiIcon: "fa fa-sign-out fa-fw", action: function(event, ui) {
               kickUser(conuid);
             }
           },
           { title: Onlinebox_Lang.userban, uiIcon: "fa fa-ban fa-fw",
              children: [
                { title: "5&nbsp;Minuten", uiIcon: "fa fa-clock-o fa-fw", action: function(event, ui) {
                    banUser(conuid, '300');
                  }
                },
                {title: "----"},
                { title: "1&nbsp;Stunde", uiIcon: "fa fa-clock-o fa-fw", action: function(event, ui) {
                    banUser(conuid, '3600');
                  }
                },
                { title: "6&nbsp;Stunden", uiIcon: "fa fa-clock-o fa-fw", action: function(event, ui) {
                    banUser(conuid, '21600');
                  }
                },
                { title: "12&nbsp;Stunden", uiIcon: "fa fa-clock-o fa-fw", action: function(event, ui) {
                    banUser(conuid, '43200');
                  }
                },
                { title: "24&nbsp;Stunden", uiIcon: "fa fa-clock-o fa-fw", action: function(event, ui) {
                    banUser(conuid, '86400');
                  }
                },
                {title: "----"},
                { title: "7&nbsp;Tage", uiIcon: "fa fa-clock-o fa-fw", action: function(event, ui) {
                    banUser(conuid, '604800');
                  }
                },
                {title: "----"},
                { title: "Dauerhaft", uiIcon: "fa fa-trash fa-fw", action: function(event, ui) {
                    banUser(conuid, 'complete');
                  }
                }
              ]
           }
      ]}
    ],
    beforeOpen: function(event, ui) {
      conuid = ui.target.parent().attr("data-uid");
      conname = ui.target.parent().attr("data-name");
      conlevel = ui.target.parent().attr("data-level");
      $("#onlinelister").contextmenu("setEntry", "profile", conname+Onlinebox_Lang.openprofil);
      $("#onlinelister").contextmenu("showEntry", "third", false);
      $("#onlinelister").contextmenu("showEntry", "ownerconf", false);
      $("#onlinelister").contextmenu("showEntry", "ownerunconf", false);
      $("#onlinelister").contextmenu("showEntry", "ownerkick", false);

//--------------------------------------------------------------------------------------------------------
//-------------------Display adminmenu entries if permited, else hide them--------------------------------
//--------------------------------------------------------------------------------------------------------

      if(acp == "no") {
        $("#onlinelister").contextmenu("showEntry", "last", false);
        $("#onlinelister").contextmenu("showEntry", "admin", false);
      } else {
        $("#onlinelister").contextmenu("showEntry", "last", true);
        $("#onlinelister").contextmenu("showEntry", "admin", true);
      }

//--------------------------------------------------------------------------------------------------------
//-------------------Display menu entries if selected is not higher rank, else hide them------------------
//--------------------------------------------------------------------------------------------------------

      if(checkPermit(lvl, conlevel, 1) == false) {
        $("#onlinelister").contextmenu("showEntry", "ignotr", false);
        $("#onlinelister").contextmenu("showEntry", "igno", false);
        $("#onlinelister").contextmenu("showEntry", "unigno", false);
      } else {
        if(conowner == 1) {
          $("#onlinelister").contextmenu("showEntry", "third", true);
          $("#onlinelister").contextmenu("showEntry", "ownerconf", true);
          $("#onlinelister").contextmenu("showEntry", "ownerunconf", true);
          $("#onlinelister").contextmenu("showEntry", "ownerkick", true);
        }
        $("#onlinelister").contextmenu("showEntry", "ignotr", true);
        if(ignoreList.indexOf(','+conname+',') == -1) {
          $("#onlinelister").contextmenu("showEntry", "igno", true);
          $("#onlinelister").contextmenu("showEntry", "unigno", false);
        } else {
          $("#onlinelister").contextmenu("showEntry", "igno", false);
          $("#onlinelister").contextmenu("showEntry", "unigno", true);
        }
      }

//--------------------------------------------------------------------------------------------------------
//------------------Display menu entries if selected is not self user, else hide them---------------------
//--------------------------------------------------------------------------------------------------------

      if(conuid == uid) {
        $("#onlinelister").contextmenu("showEntry", "talkto", false);
        $("#onlinelister").contextmenu("showEntry", "whisp", false);
        $("#onlinelister").contextmenu("showEntry", "priv", false);
        $("#onlinelister").contextmenu("showEntry", "mail", false);
        $("#onlinelister").contextmenu("showEntry", "alert", false);
        $("#onlinelister").contextmenu("showEntry", "friend", false);
        $("#onlinelister").contextmenu("showEntry", "recol", false);
        $("#onlinelister").contextmenu("showEntry", "igno", false);
        $("#onlinelister").contextmenu("showEntry", "unigno", false);
        $("#onlinelister").contextmenu("showEntry", "report", false);
        $("#onlinelister").contextmenu("showEntry", "first", false);
        $("#onlinelister").contextmenu("showEntry", "second", false);
        $("#onlinelister").contextmenu("showEntry", "ignotr", false);
        $("#onlinelister").contextmenu("showEntry", "last", false);
        $("#onlinelister").contextmenu("showEntry", "prof", false);
        $("#onlinelister").contextmenu("showEntry", "admin", false);
        $("#onlinelister").contextmenu("showEntry", "third", false);
        $("#onlinelister").contextmenu("showEntry", "ownerconf", false);
        $("#onlinelister").contextmenu("showEntry", "ownerunconf", false);
        $("#onlinelister").contextmenu("showEntry", "ownerkick", false);
      } else {
        $("#onlinelister").contextmenu("showEntry", "talkto", true);
        $("#onlinelister").contextmenu("showEntry", "whisp", true);
        $("#onlinelister").contextmenu("showEntry", "priv", true);
        $("#onlinelister").contextmenu("showEntry", "mail", true);
        $("#onlinelister").contextmenu("showEntry", "alert", true);
        $("#onlinelister").contextmenu("showEntry", "friend", true);
        $("#onlinelister").contextmenu("showEntry", "recol", true);
        $("#onlinelister").contextmenu("showEntry", "report", true);
        $("#onlinelister").contextmenu("showEntry", "first", true);
        $("#onlinelister").contextmenu("showEntry", "second", true);
      }
    }
  });
  loadAJAX["onlinelist"] = 'true';
}

$(document).ready(function(){
  execute_Onlinebox();
});