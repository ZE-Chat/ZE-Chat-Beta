//PrivateID holder
//id
var PrivateID = '';

//Get user_clock settings
if(!user_clock) {
  var user_clock = 0;
}

//Get isActive settings
if(!isActive) {
  var isActive = true;
}

//Active PM Window
var activePM = '';

//Grab user message to send to server
function grabPrivMessage(toId, target) {
  activePM = toId;
  $(".text_input").prop('disabled', true);
  clearTimeout(window.mTimer);
  delete window.mTimer;
  sendPrivMessage(toId, target);
}

//Send message to server, force request
function sendPrivMessage(toId, target) {
  var mess = $('#text_input_'+toId).val();
  mess = mess.replace(/&/g, "Hex22");
  mess = mess.replace(/\+/g, "Hex23");
  mess = mess.replace(/\'/g, "Hex24");
  $.ajax({
    url: 'index.php',
    type: 'post',
    dataType: 'html',
    data: { inc: "sendmess", sid: loadAJAX["sid"], uid: loadAJAX["uid"], rid: "priv", tarid: target, toid: toId, mess: mess },
    success: function(data) {
      delete window.mess;
      $('#text_input_'+toId).val('');
      $(".text_input").prop('disabled', false);
      $('#text_input_'+activePM).focus();
      activePM = '';
      mTimer = setTimeout('updateData();',500);
    }
  });
}

function handlePrivMessages(data) {
  for(i=0; i < data.length; i++) {
    if(data[i].mess_type == 3) {
      if(!$( "#private-"+data[i].mess_target_room_id ).length) {
        if(Math.ceil(data[i].mess_id/2) == data[i].mess_id/2) {
          side = 'right';
        } else {
          side = 'left';
        }
        showPriv(data[i].mess_author_id, data[i].mess_target_room_id, side);
      }
      if($( "#private-"+data[i].mess_target_room_id ).length) {
        if(data[i].mess_author_name != 'System') {
          if(data[i].mess_content != "init-151-init") {
            var tmppriv = $( "#privstream-"+data[i].mess_target_room_id );
            var tmpident = "priv-"+data[i].mess_target_room_id;
            var messages = '';
            if(data[i].mess_author_id == loadAJAX["uid"]) {
              messages += '<span class="privateown flr" title="'+data[i].mess_write_time+'"><span style="color: #'+data[i].mess_form+'">'+data[i].mess_content+'</span></span><span class="clearfix"></span>';
            } else {
              messages += '<span class="privateother fll" title="'+data[i].mess_write_time+'"><span style="color: #'+data[i].mess_form+'">'+data[i].mess_content+'</span></span><span class="clearfix"></span>';
            }
            messages = messages.replace("Hex22", "&");
            messages = messages.replace("Hex23", "+");
            messages = messages.replace("Hex24", "'");
//            var message = $(tmppriv).html()+messages;
            $(tmppriv).append(messages);
//-------------------------------------------------------------------------------------
//---------------------------------Smilies---------------------------------------------
//-------------------------------------------------------------------------------------
            $('.smiliePRE').replaceWith(function(){
              var SMIpic = $(this).attr("data-pic");
              var SMIsc = $(this).attr("data-sc");
              var SMIlvl = $(this).attr("data-lvl");
              var SMIname = $(this).attr("data-name");
              var SMIusk = $(this).attr("data-usk");
              if(userage >= SMIusk) {
                var smilies = '<img style="vertical-align:middle;" alt="'+SMIname+'" class="smilieLOADEDP" data-sc="'+SMIsc+'" data-name="'+SMIname+'" data-usk="'+SMIusk+'" data-lvl="'+SMIlvl+'" src="/files/smilies/'+SMIpic+'" />';
              } else {
                var smilies = '<img style="vertical-align:middle;" alt="Check USK" class="uskWARN" src="/files/smilies/error.png" />';
              }
              return smilies;
            });
//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
            $(tmppriv).animate({"scrollTop": $(tmppriv)[0].scrollHeight}, "slow");
            var checkid = 'text_input_'+data[i].mess_target_room_id;
            if(document.activeElement.id != checkid) {
              $("#priv-"+data[i].mess_target_room_id).addClass("ui-state-highlight");
            }
          }
        } else {
          if(data[i].mess_content == 'recon') {
            $( "#private-"+data[i].mess_target_room_id ).find("span.fa-times").click();
          }
        }
      }
    }
    if(isActive == false) {
      document.title = "Neu! - "+pageTitle;
    }
  }
}

function showPriv(id, toid, side) {
  loadBox('private', side, '&uid='+loadAJAX["uid"]+'&toid='+toid+'&open='+id);
}

function execute_Private() {
  $('.privatewindow').on('click', function(event) {
    if($(this).children('.whead').hasClass("ui-state-highlight")) {
      $(this).children('.whead').removeClass("ui-state-highlight");
    }
  });
  $( ".sendbutt" ).button();
}

$(document).ready(function(){
  execute_Private();
});