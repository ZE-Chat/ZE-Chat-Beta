//Dialog holder "GBCreate"
//Object
var pgbCreateDialog = '';

//Percent of ScreenWidth for Dialoge's
//Int
var pDiaWidth = '';
var pDiaHeight = '';

var visitorID = '';
var profileID = '';
var profileName = '';

function createGB() {
  $("#wpgb_content").sync();
  var str = 'inc=ajaxprofile&do=createGB&sid='+sid+'&'+$("#wpgb").serialize();
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gästebucheintrag wurde hinterlassen!');
//      pgbCreateDialog.dialog('destroy').remove();
      openProfile.dialog('close');
      loadProfile(profileID, profileName);
    }
  });
}

function rateUser(score) {
  var str = 'inc=ajaxprofile&do=rateuser&sid='+sid+'&pid='+profileID+'&rating='+score;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function(data) {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Benutzer bewertet! Neue Bewertung in 30 Tagen möglich!');
      openProfile.dialog('close');
      loadProfile(profileID, profileName);
    }
  });
}

function insertGBImage(link) {
  var url = window.location.origin+'/files/userpic/'+link;
  $('#wpgb_content').insertAtCursor('<img src="'+url+'" />');
}

function execute_Profile() {
  profileID = $("#profile").attr("data-pid");
  profileName = $("#profile").attr("data-pname");
  makeBBCEditor("wpgb_content", "bold,italic,underline,|,img,link,|,bullist,|,fontcolor,fontsize,|,justifyleft,justifycenter,justifyright,|,quote,removeFormat");
  $('#p_gb_entry_button').button();
  $( "#proftabs" ).tabs();
  $(".bbcme").each(function( index ) {
    var test = $(this).text();
    var resulter = XBBCODE.process({
      text: test,
      removeMisalignedTags: false,
      addInLineBreaks: true
    });
    $(this).html(resulter.html.trim());
  });
  
  $('#pubarava').click(function() {
    var avaheight = $(window).height();
    var avaheight = avaheight*0.9;
    var avawidth = $(window).width();
    var avawidth = avawidth*0.9;
    var items = [];
    $( "#pavalist" ).find('.prof-gallery-item').each(function() {
      $(this).find('.avatarsize').css({"maxHeight": avaheight, "maxWidth": avawidth});
      items.push( {
        src: $(this)
      } );
    });
    $.magnificPopup.open({
      closeOnContentClick: true,
      showCloseBtn: false,
      items:items,
      gallery: {
        enabled: true 
      }
    });
  });
  
  $(".gbtext").each(function( index ) {
    var test = $(this).text();
    var resulter = XBBCODE.process({
      text: test,
      removeMisalignedTags: false,
      addInLineBreaks: true
    });
    $(this).html(resulter.html.trim());
  });
  
  $(".gbtext > img").css("max-width", "500px");
  
  pDiaWidth = $(window).width() * .60;
  pDiaHeight = $(window).height() * .80;
  
  pgbCreateDialog = $( "#p_gb_creator" ).dialog({
    minWidth: pDiaWidth,
    height: pDiaHeight,
    maxHeight: pDiaHeight,
    autoOpen: false,
    modal: false,
    buttons: [{
        text: "Ok",
        "id": "ButtonPGBC",
        click: function () {
          createGB();
          pgbCreateDialog.dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonPCANEL",
        click: function() {
          pgbCreateDialog.dialog( "close" );
        }
      }],
    close: function() {
      formPGB[ 0 ].reset();
    }
  });
  $('#ButtonPGBC').html("Eintragen");
  $('#ButtonPCANCEL').html("Abbrechen");

  formPGB = pgbCreateDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createGB();
  });
  
  $( "#p_gb_entry_button" ).button().on( "click", function() {
    pgbCreateDialog.dialog( "open" );
  });
  
  var rscore = $('#ratingprof').attr('data-rating');
  var rallow = $('#ratingprof').attr('data-allowed');
  if(rallow == 'true') {
    var rread = false;
  } else {
    var rread = true;
  }
  $('#ratingprof').raty({
    readOnly: rread,
    half: true,
    score: rscore,
    size: 24,
    round : { down: .26, full: .6, up: .76 },
    hints: ['Mies', 'Naja', 'Okay', 'Gut', 'Super'],
    click: function(score, evt) {
      rateUser(score);
    }
  });
  
}

$(document).ready(function(){
  execute_Profile();
});