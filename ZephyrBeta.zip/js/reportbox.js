var reportArea,
    reportID,
    reportItem,
    reportData;

$("body").delegate( ".repelem", "contextmenu", function() {
  var repCheck = "";

  if (window.getSelection) {
    var repCheck = window.getSelection().toString();
  } else if (document.selection && document.selection.type != "Control") {
    var repCheck = document.selection.createRange().text;
  }

  if(repCheck == "") {
    var el = this;
    reportArea = $(el).attr("data-reparea");
    reportID = $(el).attr("data-repid");
    reportItem = $(el).attr("data-repitem");
    reportData = $(el).attr("data-repdata");
    loadDialog('reportbox', 'Melden', 'doReport', '');
    $('#ButtonGLOBP').html("Melden");
    $('#ButtonGLOBN').html("Abbrechen");
    showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Scherzmeldungen werden geahndet!');
    return false;
  } else {

  }
});

function doReport() {
  var repshort = $("#repshort").val();
  var replong = $("#replong").val();
  lloading = 'inc=doreport&rarea='+reportArea+'&rid='+reportID+'&ritem='+reportItem+'&rdata='+reportData+'&rshort='+repshort+'&rlong='+replong+'&sid='+sid;
  console.log(lloading);
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    type: 'post',
    success: function() {
      openDialog.dialog("close");
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Deine Meldung wurde entgegen genommen! Es wird sich so bald wie möglich um dein Anliegen gekümmert!');
      reportArea = '';
      reportID = '';
      reportItem = '';
      reportData = '';
    }
  });
}