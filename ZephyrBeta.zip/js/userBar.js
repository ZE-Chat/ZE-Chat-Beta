var gbTotal;
var gbNew;
var gbStored = 0;

var flTotal;
var flNew;
var flStored = 0;

var mailsNew;
var mailsTotal;
var mailsStored = 0;

var presNew;
var presTotal;
var presStored = 0;

function handleUserbar(data) {
  if(("coins" in data) && $("#ze_coins").length) {
    if($("#ze_coins").html() != data["coins"]) {
      $("#ze_coins").html(data["coins"]);
    }
  }
  
//-------------------Mails---------------
  if(("mail" in data) && $("#ze_mails").length) {
    tmpMailt = data["mail"].mailt;
    tmpMailn = data["mail"].mailn;
    if(tmpMailn != mailsNew) {
      if(tmpMailn != mailsStored) {
        mailsStored = tmpMailn;
        mailsTotal = tmpMailt;
        mailsNew = tmpMailn;
        $("#ze_tmails").html(tmpMailt);
        $("#ze_mails").html(tmpMailn);
        if(tmpMailn != '0') {
          if(isActive == false) {
            showNotify('desktop-info', 'fa fa-info-circle fa-lg', 'Info!', 'Neue Chatmail!');
          } else {
            showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Neue Chatmail!');
          }
          $("#ubar_mails_holder").fadeIn();
        } else {
          $("#ubar_mails_holder").fadeOut();
        }
      }
    }
    if(tmpMailt != mailsTotal) {
      $("#ze_tmails").html(tmpMailt);
    }
  }

//-------------------Presents---------------
  if(("pres" in data) && $("#ze_presents").length) {
    tmpPrest = data["pres"].prest;
    tmpPresn = data["pres"].presn;
    if(tmpPresn != presNew) {
      if(tmpPresn != presStored) {
        presStored = tmpPresn;
        presTotal = tmpPrest;
        presNew = tmpPresn;
        $("#ze_tpresents").html(tmpPrest);
        $("#ze_presents").html(tmpPresn);
        if(tmpPresn != '0') {
          if(isActive == false) {
            showNotify('desktop-info', 'fa fa-info-circle fa-lg', 'Info!', 'Neues Geschenk!');
          } else {
            showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Neues Geschenk!');
          }
          $("#ubar_presents_holder").fadeIn();
        } else {
          $("#ubar_presents_holder").fadeOut();
        }
      }
    }
    if(tmpPrest != presTotal) {
      $("#ze_tpresents").html(tmpPrest);
    }
  }
  
//-----------------Guestbook-------------
  if(("gb" in data) && $("#ze_gbentry").length) {
    tmpGBt = data["gb"].gbt;
    tmpGBn = data["gb"].gbn;
    if(tmpGBn != gbNew) {
      if(tmpGBn != gbStored) {
        gbStored = tmpGBn;
        gbTotal = tmpGBt;
        gbNew = tmpGBn;
        $("#ze_tgbentry").html(tmpGBt);
        $("#ze_gbentry").html(tmpGBn);
        if(tmpGBn != '0') {
          if(isActive == false) {
            showNotify('desktop-info', 'fa fa-book fa-lg', 'Info!', 'Neuer Gästebucheintrag!');
          } else {
            showNotify('info', 'fa fa-book fa-lg', 'Info!', 'Neuer Gästebucheintrag!');
          }
          $("#ubar_gb_holder").fadeIn();
        } else {
          $("#ubar_gb_holder").fadeOut();
        }
      }
    }
    if(tmpGBt != gbTotal) {
      $("#ze_tgbentry").html(tmpGBt);
    }
  }
  
//-----------------Friendlist------------
  if(("fl" in data) && $("#ze_finvites").length) {
    tmpFLt = data["fl"].flt;
    tmpFLn = data["fl"].fln;
    if(tmpFLn != flNew) {
      if(tmpFLn != flStored) {
        flStored = tmpFLn;
        flTotal = tmpFLt;
        flNew = tmpFLn;
        $("#ze_tfinvites").html(tmpFLt);
        $("#ze_finvites").html(tmpFLn);
        if(tmpFLn != '0') {
          if(isActive == false) {
            showNotify('desktop-info', 'fa fa-users fa-lg', 'Info!', 'Neue Freundschaftsanfrage!');
          } else {
            showNotify('info', 'fa fa-users fa-lg', 'Info!', 'Neue Freundschaftsanfrage!');
          }
          $("#ubar_finv_holder").fadeIn();
        } else {
          $("#ubar_finv_holder").fadeOut();
        }
      }
    }
    if(tmpFLt != flTotal) {
      $("#ze_tfinvites").html(tmpFLt);
    }
  }
}

function execute_userBar() {
  $("#ubresizer").attr("data-hs", $("#userbar").outerHeight());
  var elm = $("#userbar");
  elm.insertBefore(elm.prev());
  
//-------------------Mails---------------
  if($("#ze_mails").length) {
    mailsTotal = $("#ze_tmails").html();
    mailsNew = $("#ze_mails").html();
  }

//-----------------Presents--------------
  if($("#ze_presents").length) {
    mailsTotal = $("#ze_tpresents").html();
    mailsNew = $("#ze_presents").html();
  }
  
//-----------------Guestbook-------------
  if($("#ze_gbentry").length) {
    gbTotal = $("#ze_tgbentry").html();
    gbNew = $("#ze_gbentry").html();
  }

//-----------------Friendlist------------
  if($("#ze_finvites").length) {
    flTotal = $("#ze_tfinvites").html();
    flNew = $("#ze_finvites").html();
  }
}

$(document).ready(function(){
  execute_userBar();
});