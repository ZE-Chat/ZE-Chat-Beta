var ulistSortNameState = 0;
var ulistSortOPState = 0;
var ulistSortDateState = 0;

function ulistSortName() {
  ulistSortDateState = 0;
  ulistSortOPState = 0;

  if(ulistSortNameState == 1) {
    ulistSortNameState = 0;
    $('#userListRowContainer .ulistrow').sort(ulistNameSortDescHelper).appendTo('#userListRowContainer');
  } else {
    ulistSortNameState = 1;
    $('#userListRowContainer .ulistrow').sort(ulistNameSortAscHelper).appendTo('#userListRowContainer');
  }
}

function ulistSortOP() {
  ulistSortDateState = 0;
  ulistSortNameState = 0;

  if(ulistSortOPState == 1) {
    ulistSortOPState = 0;
    $('#userListRowContainer .ulistrow').sort(ulistOPSortDescHelper).appendTo('#userListRowContainer');
  } else {
    ulistSortOPState = 1;
    $('#userListRowContainer .ulistrow').sort(ulistOPSortAscHelper).appendTo('#userListRowContainer');
  }
}

function ulistSortDate() {
  ulistSortNameState = 0;
  ulistSortOPState = 0;

  if(ulistSortDateState == 0) {
    ulistSortDateState = 1;
    $('#userListRowContainer .ulistrow').sort(ulistDateSortDescHelper).appendTo('#userListRowContainer');
  } else {
    ulistSortDateState = 0;
    $('#userListRowContainer .ulistrow').sort(ulistDateSortAscHelper).appendTo('#userListRowContainer');
  }
}

function ulistNameSortDescHelper(a, b) {
  var name1  = $(a).find(".ulnameholder").text().toUpperCase();
  var name2  = $(b).find(".ulnameholder").text().toUpperCase();
  return (name1) < (name2) ? 1 : -1;
}

function ulistNameSortAscHelper(a, b) {
  var name1  = $(a).find(".ulnameholder").text().toUpperCase();
  var name2  = $(b).find(".ulnameholder").text().toUpperCase();
  return (name1) > (name2) ? 1 : -1;
}

function ulistOPSortDescHelper(a, b) {
  var op1  = parseInt($(a).find(".ulistOPHolder").text());
  var op2  = parseInt($(b).find(".ulistOPHolder").text());
  return (op1) < (op2) ? 1 : -1;
}

function ulistOPSortAscHelper(a, b) {
  var op1  = parseInt($(a).find(".ulistOPHolder").text());
  var op2  = parseInt($(b).find(".ulistOPHolder").text());
  return (op1) > (op2) ? 1 : -1;
}

function ulistDateSortDescHelper(a, b) {
  var date1a  = $(a).find(".ulistDateHolder").text();
  if(date1a.indexOf('.') !== -1) {
    date1a = date1a.split('.');
    var date1b = $(a).find(".ulistDateHolder").attr("title");
    date1b = date1b.split(':');
    var date1 = new Date(date1a[2], date1a[1], date1a[0], date1b[0], date1b[1], date1b[2]);
  } else {
    var date1 = new Date(1900, 0, 0, 0, 0, 0);
  }
  var date2a  = $(b).find(".ulistDateHolder").text();
  if(date2a.indexOf('.') !== -1) {
    date2a = date2a.split('.');
    var date2b = $(b).find(".ulistDateHolder").attr("title");
    date2b = date2b.split(':');
    var date2 = new Date(date2a[2], date2a[1], date2a[0], date2b[0], date2b[1], date2b[2]);
  } else {
    var date2 = new Date(1900, 0, 0, 0, 0, 0);
  }
  return date1 < date2 ? 1 : -1;
};

function ulistDateSortAscHelper(a, b) {
  var date1a  = $(a).find(".ulistDateHolder").text();
  if(date1a.indexOf('.') !== -1) {
    date1a = date1a.split('.');
    var date1b = $(a).find(".ulistDateHolder").attr("title");
    date1b = date1b.split(':');
    var date1 = new Date(date1a[2], date1a[1], date1a[0], date1b[0], date1b[1], date1b[2]);
  } else {
    var date1 = new Date(1900, 0, 0, 0, 0, 0);
  }
  var date2a  = $(b).find(".ulistDateHolder").text();
  if(date2a.indexOf('.') !== -1) {
    date2a = date2a.split('.');
    var date2b = $(b).find(".ulistDateHolder").attr("title");
    date2b = date2b.split(':');
    var date2 = new Date(date2a[2], date2a[1], date2a[0], date2b[0], date2b[1], date2b[2]);
  } else {
    var date2 = new Date(1900, 0, 0, 0, 0, 0);
  }
  return date1 > date2 ? 1 : -1;
};

function execute_Userlist() {
  $("#ulfilterinput").keyup(function() { 
    var filter = $("#ulfilterinput").val().toUpperCase();
    if(filter != '') {
      $('.ulnameholder:not(:icontains('+ filter +'))').closest(".ulistrow").hide(); 
      $('.ulnameholder:icontains('+ filter +')').closest(".ulistrow").show(); 
    } else {
      $('.ulnameholder').closest(".ulistrow").show();
    }
  }).keyup();
}

$(document).ready(function(){
  execute_Userlist();
});