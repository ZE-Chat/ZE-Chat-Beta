$(document).ready(function(){
  if(sessionStorage.acpLang) {
    delete sessionStorage.acpLang;
  }
  if(sessionStorage.acpGlobal) {
    delete sessionStorage.acpGlobal;
  }
  if(sessionStorage.acpPerm) {
    delete sessionStorage.acpPerm;
  }
  if(sessionStorage.acpNews) {
    delete sessionStorage.acpNews;
  }
  if(sessionStorage.acpArchive) {
    delete sessionStorage.acpArchive;
  }
  if(sessionStorage.acpUser) {
    delete sessionStorage.acpUser;
  }
  if(sessionStorage.acpPD) {
    delete sessionStorage.acpPD;
  }
  if(sessionStorage.acpRoom) {
    delete sessionStorage.acpRoom;
  }
  if(sessionStorage.acpAvacheck) {
    delete sessionStorage.acpAvacheck;
  }
  if(sessionStorage.acpMain) {
    delete sessionStorage.acpMain;
  }
  if(sessionStorage.acpSmilies) {
    delete sessionStorage.acpSmilies;
  }
  if(sessionStorage.acpNavigation) {
    delete sessionStorage.acpNavigation;
  }
  if(sessionStorage.acpShop) {
    delete sessionStorage.acpShop;
  }
  if(sessionStorage.acpPatches) {
    delete sessionStorage.acpPatches;
  }
  if(sessionStorage.roomsel) {
    delete sessionStorage.roomsel;
  }
  if(sessionStorage.roomcreate) {
    delete sessionStorage.roomcreate;
  }
  if(sessionStorage.onlinebox) {
    delete sessionStorage.onlinebox;
  }
  if(sessionStorage.profile) {
    delete sessionStorage.profile;
  }
  if(sessionStorage.news) {
    delete sessionStorage.news;
  }
  if(sessionStorage.ChatRoom) {
    delete sessionStorage.ChatRoom;
  }
  if(sessionStorage.userBar) {
    delete sessionStorage.userBar;
  }
  if(sessionStorage.userlist) {
    delete sessionStorage.userlist;
  }
  if(sessionStorage.radio) {
    delete sessionStorage.radio;
  }
  if(sessionStorage.epMain) {
    delete sessionStorage.epMain;
  }
  if(sessionStorage.overview) {
    delete sessionStorage.overview;
  }
  if(sessionStorage.smilies) {
    delete sessionStorage.smilies;
  }
  if(sessionStorage.shop) {
    delete sessionStorage.shop;
  }
  if(sessionStorage.epFriends) {
    delete sessionStorage.epFriends;
  }
  if(sessionStorage.private) {
    delete sessionStorage.private;
  }
  if(sessionStorage.epPD) {
    delete sessionStorage.epPD;
  }
  if(sessionStorage.epAva) {
    delete sessionStorage.epAva;
  }
  if(sessionStorage.epMail) {
    delete sessionStorage.epMail;
  }
  if(sessionStorage.epGB) {
    delete sessionStorage.epGB;
  }
  if(sessionStorage.epSett) {
    delete sessionStorage.epSett;
  }
  if(sessionStorage.epPresent) {
    delete sessionStorage.epPresent;
  }
  if(sessionStorage.acpBW) {
    delete sessionStorage.acpBW;
  }
});