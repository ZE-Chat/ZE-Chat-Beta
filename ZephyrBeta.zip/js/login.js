function doLogin(style) {
  if(style == 'login') {
    var tmpdata = $('form#boxform_login').serialize();
  } else {
    var tmpdata = $('form#guestform').serialize();
  }
  $.ajax({
    url: 'index.php',
    type: 'post',
    dataType: 'json',
    data: tmpdata,
    success: function(data) {
      switch(data.state) {
        case 'true':
          sid   = data.sid;
          uid   = data.uid;
          aid   = data.aid;
          uname = data.uname;
          userage = data.age;
          ucol  = data.ucol;
          lvl   = data.lvl;
          acp   = data.acp;
          mod   = data.mod;
          bpr   = data.bpr;
          loadAJAX["sid"] = sid;
          loadAJAX["uid"] = uid;
          loadAJAX["aid"] = aid;
          loadAJAX["uname"] = uname;
          showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Du bist nun als '+data.name+' eingeloggt!');
          var side = $("#loginbox").parent().attr("id");
          if(side == 'rtcol') { side = 'right'; }
          if(side == 'ltcol') { side = 'left'; }
          loadBox('userbar', side, '&uid='+uid+'&sid='+sid);
          loadBox('roomlist', side, '&uid='+uid+'&sid='+sid);
          if(uid > 0) {
            loadContent('overview', 'Übersicht', '&uid='+uid+'&dont=0&sid='+sid);
          }
          $( "#loginbox" ).remove();
          $("#regbutton").remove();
          if(style != 'login') {
            openDialog.dialog('destroy').remove();
          }
          loading = 'inc=navigation&sid='+sid;
          $.ajax({
            url: "index.php", 
            data: loading,
            dataType: "html",
            success: function(data) {
              $("#navholder").html(data);
              navmenu = $("#menu").menu({
                          items: "> :not(.ui-widget-header)"
                        }).hide();
            }
          });
          if(acp == 'yes') {
            loading = 'inc=getreports&sid='+sid;
            $.ajax({
              url: "index.php", 
              data: loading,
              dataType: "text",
              success: function(data) {
                if(data != 'nope' && data != '0') {
                  new PNotify({
                    title: "Moderation!",
                    hide: false,
                    text: data+' offene Meldungen im Adminpanel!',
                    type: 'error',
                    icon: 'ui-icon fa fa-exclamation-triangle fa-lg',
                    styling: 'jqueryui',
                    stack: stack_center
                  });
                }
              }
            });
            loading = 'inc=getopenava&sid='+sid;
            $.ajax({
              url: "index.php", 
              data: loading,
              dataType: "text",
              success: function(data) {
                if(data != 'nope' && data != '0') {
                  if(data == '1') {
                    var nText = data+' Bild wartet auf Freischaltung im Adminpanel!';
                  } else {
                    var nText = data+' Bilder warten auf Freischaltung im Adminpanel!';
                  }
                  new PNotify({
                    title: "Moderation!",
                    hide: false,
                    text: nText,
                    type: 'error',
                    icon: 'ui-icon fa fa-exclamation-triangle fa-lg',
                    styling: 'jqueryui',
                    stack: stack_center
                  });
                }
              }
            });
          }
          break;
        case 'pass':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Falsches Passwort!');
          break;
        case 'closed':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Chat ist geschlossen!');
          break;
        case 'unknown':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Dieser Login ist nicht bekannt!');
          break;
        case 'ban':
          showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Du bist gebannt!');
          break;
        case 'tban':
          showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Du bist gebannt bis "'+uname+'"!');
          break;
        case 'gnamechar':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Der gewünschte Name enthält unzulässige Zeichen!');
          break;
        case 'gnamebad':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Der gewünschte Name wird bereits verwendet!');
          break;
        case 'gage':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Du bist leider zu jung für diesen Chat!');
          break;
        case 'rules':
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Die Chatregeln sind zu akzeptieren!');
          break;
        case 'act':
          if(uname == 2) {
          showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Erwarte Adminfreischaltung!');
          } else {
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Account nicht aktiviert!');
          }
          break;
        default:
          showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Überprüfe deine Eingaben!');
      }
    }
  });
}

$(document).ready(function(){
  $( ".loginbutton" ).button();
  $('form#boxform_login').submit(function(e){
    e.preventDefault();
  });
});