/**
 *        This file is part of "ZE Chat v1.1 - Zephyr".
 *
 *        "ZE Chat v1.1 - Zephyr" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "ZE Chat v1.1 - Zephyr" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015 - 2016
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015 - 2016
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

var loadAJAX = {},
    lastRequest,
    navmenu,
    chheight,
    chwidth,
    chwidgets,
    divMouseDown,
    tabs,
    activePanel,
    openDialog,
    openDialog2,
    smiArea,
    mTimer,
    lTimer,
    playSound = true,
    openUserlist,
    openProfile,
    pageTitle = document.title,
    currOS = '1',
    refreshTimeout = false,
    rlCount = 0,
    tmprid,
    theme = '',
    errorCounter = 0,
    sid   = 'none',
    uid   = 'none',
    aid   = 'none',
    uname = 'none',
    userage = '0',
    lvl   = 'none',
    acp   = 'none',
    mod   = {},
    bpr   = 'none',
    ucol  = '000',
    stack_center = {"dir1": "down", "dir2": "right", "firstpos1": 25, "firstpos2": ($(window).width() / 2) - (Number(PNotify.prototype.options.width.replace(/\D/g, '')) / 2)},
    tabTitle    = $( "#tab_title" ),
    tabContent  = $( "#tab_content" ),
    tabTemplate = "<li><div class='tabiconwrapper'><span class='flr tabrefresher fa fa-refresh' role='presentation'></span><span><a href='#{href}'>#{label}</a></span><span class='flr tabcloser fa fa-times' role='presentation'></span></div></li>" 

//----------------------------------------------------------------------------------------
//Turn given textarea into BBCEditor
//"bold,italic,underline,strike,sup,sub,|,img,video,link,|,bullist,|,fontcolor,fontsize,fontfamily,|, justifyleft, justifycenter,justifyright,|, quote,code,table,removeFormat"
//----------------------------------------------------------------------------------------
function makeBBCEditor(id, wbbSett) {
  var wbbSett = {buttons: wbbSett, traceTextarea: true, autoresize: false};
  return $("#"+id).wysibb(wbbSett);
}

//----------------------------------------------------------------------------------------
//Shorten given name after X characters, return result
//----------------------------------------------------------------------------------------
function trimName(name) {
  if(arguments.length == 1) {
    var maxChars = 14;
    var shortendChars = 10;
  } else {
    var maxChars = arguments[1];
    var shortendChars = arguments[2];
  }
  if(typeof name !== "undefined" && name.length > maxChars) {
    name = name.substr(0,shortendChars);
    name = name+'[...]';
  }
  return name;
}

//----------------------------------------------------------------------------------------
//Relogin user without reconfirmation
//----------------------------------------------------------------------------------------
function doNameChange(newuid) {
  loading = 'inc=donamechange&sid='+sid+'&oldid='+uid+'&newid='+newuid;
  $.ajax({
    url: "index.php", 
    data: loading,
    type: 'post',
    dataType: 'json',
    success: function(data) {
      uid   = newuid;
      aid   = data.aid;
      uname = data.name;
      ucol  = data.ucol;
      lvl   = data.lvl;
      acp   = data.acp;
      bpr   = data.bpr;
      loadAJAX["uid"] = newuid;
      loadAJAX["aid"] = data.aid;
      loadAJAX["uname"] = data.name;
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Du bist hast zu '+data.name+' gewechselt!');
      refreshOpen();
    }
  });
}

//----------------------------------------------------------------------------------------
//Show notification on screen top-center with given style, icon, title and content
//----------------------------------------------------------------------------------------
function showNotify(form, icon, title, cont) {
  PNotify.prototype.options.delay = 5000;
  if(form.indexOf('desktop') != -1) {
    switch(form) {
      case 'dektop-info':
        new PNotify({
          title: title,
          text: cont,
          type: 'info',
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          desktop: {
            desktop: true
          }
        });
      break;
      case 'desktop-success':
        new PNotify({
          title: title,
          text: cont,
          type: 'success',
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          desktop: {
            desktop: true
          }
        });
      break;
      case 'desktop-error':
        new PNotify({
          title: title,
          text: cont,
          type: 'error',
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          desktop: {
            desktop: true
          }
        });
      break;
      default:
        new PNotify({
          title: title,
          text: cont,
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          desktop: {
            desktop: true
          }
        });
      break;
    }
  } else {
    switch(form) {
      case 'info':
        new PNotify({
          title: title,
          text: cont,
          type: 'info',
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          stack: stack_center
        });
      break;
      case 'success':
        new PNotify({
          title: title,
          text: cont,
          type: 'success',
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          stack: stack_center
        });
      break;
      case 'error':
        new PNotify({
          title: title,
          text: cont,
          type: 'error',
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          stack: stack_center
        });
      break;
      default:
        new PNotify({
          title: title,
          text: cont,
          icon: 'ui-icon '+icon,
          styling: 'jqueryui',
          stack: stack_center
        });
      break;
    }
  }
}

//----------------------------------------------------------------------------------------
//Load given sub-site into frontpage.
//Then handleContent();
//----------------------------------------------------------------------------------------
function loadContent(toload, name, atr){
  if($("#"+toload).length || $("#"+name.replace(/\s/g, '').toLowerCase()).length) {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Ladefehler!', 'Tab bereits geöffnet!');
  } else {
    $("body").css("cursor: progress");
    loading = 'inc='+toload+atr;
    $.ajax({
      url: "index.php", 
      data: loading,
      dataType: "html",
      success: function(data) {
        if(toload == 'admin') {
          toload = name.replace(/\s/g, "").toLowerCase();
        }
        if(toload == 'editprofile') {
          toload = name.replace(/\s/g, "").toLowerCase();
        }
        handleContent(data, name, toload);
      }
    });
  }
}

//----------------------------------------------------------------------------------------
//Load given dialog into frontpage.
//Then handleUserlist(); or handleDialog();
//----------------------------------------------------------------------------------------
function loadDialog(toload, name, func, atr){
  console.log(toload);
  var tdiaid = toload.split("&");
  var diaid = tdiaid[0];
  console.log(diaid);
  if($("#"+diaid).length) {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Ladefehler!', 'Dialog bereits geöffnet!');
  } else {
    $("body").css("cursor: progress");
//    $.get( "index.php", { inc: toload, uid: loadAJAX["uid"], sid: loadAJAX["sid"] } )
//    .done(function( data ) {
//      if(func == 'userlist') {
//        handleUserlist(name, data);
//      } else {
//        handleDialog(name, data, func, atr);
//      }
//    });
    loading = 'inc='+toload+'&uid='+loadAJAX["uid"]+'&sid='+loadAJAX["sid"];
    $.ajax({
      url: "index.php", 
      data: loading,
      dataType: "html",
      success: function(data) {
        if(func == 'userlist') {
          handleUserlist(name, data);
        } else if(func == 'smilies') {
          handleSmilieList(name, data);
        } else {
          handleDialog(name, data, func, atr);
        }
      }
    });
  }
}

//----------------------------------------------------------------------------------------
//Load given dialog into frontpage.
//Then handleDialog2();
//----------------------------------------------------------------------------------------
function loadDialog2(toload, data, name){
  if($("#"+toload).length) {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Ladefehler!', 'Dialog bereits geöffnet!');
  } else {
    if(toload == 'itembox') {
      var hdh2 = 'auto';
    } else {
      var hdh2 = 405;
    }
    $("body").css("cursor: progress");
    loading = 'inc='+toload+data;
    $.ajax({
      url: "index.php", 
      data: loading,
      dataType: "html",
      success: function(data) {
        handleDialog2(data, name, hdh2);
      }
    });
  }
}

//----------------------------------------------------------------------------------------
//Load given box into frontpage.
//Then handleBox();
//----------------------------------------------------------------------------------------
function loadBox(toload, side, data){
  if($("#"+toload).length) {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Ladefehler!', 'Box bereits geöffnet!');
  } else {
    $("body").css("cursor: progress");
    loading = 'inc='+toload+data;
    $.ajax({
      url: "index.php", 
      data: loading,
      dataType: "html",
      success: function(data) {
        handleBox(toload, data, side);
      }
    });
  }
}

//----------------------------------------------------------------------------------------
//Reload given box
//----------------------------------------------------------------------------------------
function reloadBox(toload){
  if(toload != undefined) {
    $("body").css("cursor: progress");
    loading = 'inc='+toload+'&uid='+loadAJAX.uid+'&sid='+loadAJAX.sid;
    $.ajax({
      url: "index.php", 
      data: loading,
      dataType: "html",
      success: function(data) {
        $("#"+toload).html($(data).html());
        $( ".side" ).resizable({
          maxWidth: 206,
          minHeight: 75,
          minWidth: 206
        });
      }
    });
  } else {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Ladefehler!', 'Diese Box kann nicht aktualisiert werden!');
  }
}

//----------------------------------------------------------------------------------------
//Reload given tab
//----------------------------------------------------------------------------------------
function reloadTab(toload){
  if(toload != undefined) {
    $("body").css("cursor: progress");
    if(toload.indexOf("room_") > -1) {
      tmprid = toload.split("_");
      tmprid = tmprid[1];
      var tmptext = $("#"+toload).find(".chatstream").html();
      loading = 'inc=initChatRoom&uid='+loadAJAX.uid+'&sid='+loadAJAX.sid+'&rid='+tmprid;
      $.ajax({
        url: "index.php", 
        data: loading,
        dataType: "html",
        success: function(data) {
          var jqObj = jQuery(data);
          jqObj.find(".chatstream").html(tmptext);
          $("#"+toload).html(jqObj);
          tabs.tabs( "refresh" );
//          fixChatHeight();
//          prepareButtons(tmprid);
        }
      });
    } else {
      if(toload.indexOf("acp") > -1) {
        loading = $("#"+toload).find(".tabcon").attr("data-load");
      } else if (toload.indexOf("ep") > -1) {
        loading = $("#"+toload).find(".tabcon").attr("data-load");
      } else {
        loading = 'inc='+toload+'&uid='+loadAJAX.uid+'&sid='+loadAJAX.sid;
      }
      $.ajax({
        url: "index.php", 
        data: loading,
        dataType: "html",
        success: function(data) {
          $("#"+toload).html(data);
          tabs.tabs( "refresh" );
        }
      });
    }
  } else {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Ladefehler!', 'Dieser Tab kann nicht aktualisiert werden!');
  }
}

//----------------------------------------------------------------------------------------
//Handle content passed via loadContent()
//Inject into DOM
//----------------------------------------------------------------------------------------
function handleContent(data, name, idname) {
  var label = name;
  if(idname.indexOf("room_") > -1) {
    var tmprid = idname.split("_");
    tmprid = tmprid[1];
    label = label+'&nbsp;(<span class="onlinecount" id="onlinecount_'+tmprid+'">0</span>)';
  }
  var id = idname.toLowerCase(),
      li = $( tabTemplate.replace( /#\{href\}/g, "#" + id ).replace( /#\{label\}/g, label ) ),
      tabContentHtml = data;
  tabs.find( ".ui-tabs-nav" ).append( li );
  tabs.append( "<div id='" + id + "'><p>" + tabContentHtml + "</p></div>" );
  tabs.tabs( "refresh" );
  tabs.tabs( "option", "active", -1 );
  $('.ui-tabs-panel').css({'height':chheight});
  $("body").css("cursor: default");
}

//----------------------------------------------------------------------------------------
//Handle content passed via loadDialog()
//Inject into DOM
//----------------------------------------------------------------------------------------
function handleDialog(name, data, func, atr) {
  data = $(data);
  openDialog = data.dialog({
    title: name,
    modal: true,
    minWidth: 313,
    close: function(event, ui){
      $(this).dialog("destroy");
      $(this).remove();
    },
    buttons: [{ text: "Ja", "id": "ButtonGLOBP", click: function () { window[func](atr); } }, { text: "Nein", "id": "ButtonGLOBN", click: function () {$(this).dialog("close"); } }]
  });
  $("body").css("cursor: default");
}

//----------------------------------------------------------------------------------------
//Handle content passed via loadDialog2()
//Inject into DOM
//----------------------------------------------------------------------------------------
function handleDialog2(data, name, hd2h) {
  data = $(data);
  openDialog2 = data.dialog({
    title: name,
    height: hd2h,
    minWidth: 450,
    close: function(event, ui){
      $(this).dialog("destroy");
      $(this).remove();
    },
  });
  $("body").css("cursor: default");
}

//----------------------------------------------------------------------------------------
//Handle content passed via loadDialog()
//Inject into DOM
//----------------------------------------------------------------------------------------
function handleUserlist(name, data) {
  var ulDiaHeight = $(window).height() * .75;
  data = $(data);
  openUserlist = data.dialog({
    title: name,
    height: ulDiaHeight,
    minWidth: 550,
    close: function(event, ui){
      $(this).dialog("destroy");
      $(this).remove();
    },
  });
  $("body").css("cursor: default");
}

//----------------------------------------------------------------------------------------
//Handle content passed via loadDialog()
//Inject into DOM
//----------------------------------------------------------------------------------------
function handleSmilieList(name, data) {
  var ulDiaHeight = $(window).height() * .75;
  data = $(data);
  openUserlist = data.dialog({
    title: name,
    height: ulDiaHeight,
    minWidth: 550,
    close: function(event, ui){
      $(this).dialog("destroy");
      $(this).remove();
    },
  });
  $("body").css("cursor: default");
}

//----------------------------------------------------------------------------------------
//Handle content passed via loadBox()
//Inject into DOM
//----------------------------------------------------------------------------------------
function handleBox(loader, data, side) {
  if(side == 'right') {
    sider = $('#rtcol');
    if(sider.width() != 206) {
      $('#rtcol').animate({ "width": "206px" }, "fast" );
      $('.acenter').animate({ "marginRight": "216px" }, "fast" );
    }
  } else {
    sider = $('#ltcol');
    if(sider.width() != 206) {
      $('#ltcol').animate({ "width": "206px" }, "fast" );
      $('.acenter').animate({ "marginLeft": "216px" }, "fast" );
    }
  }
  sider.append(data);
  if(!$(data).find('.privatewindow')) {
    $( ".side" ).resizable({
      maxWidth: 206,
      minHeight: 75,
      minWidth: 206
    });
  }
  $("body").css("cursor: default");
  loadAJAX[loader] = 'true';
}

//----------------------------------------------------------------------------------------
//Show/Hide userwarns in userbox
//----------------------------------------------------------------------------------------
function toggleWarns(warns) {
  if(warns == 0) {
    $("#ubar_warns").html(warns);
    $("#ubar_warnholder").fadeOut();
  } else {
    $("#ubar_warnholder").fadeIn();
    $("#ubar_warns").html(warns);
  }
}

//----------------------------------------------------------------------------------------
//Send user X friendship invitation
//----------------------------------------------------------------------------------------
function inviteFriend(fid, mode){
  var str = 'inc=editprofile&uid='+uid+'&dont=1&area=friends&do=requestFriend&fid='+fid+'&mode='+mode+'&sid='+sid;
  $.ajax({
    url: 'index.php',
    type: 'post',
    dataType: 'text',
    data: str,
    success: function(data) {
      if(data == 'ok') {
        showNotify('success', 'fa fa-check-circle fa-lg', 'Abgeschlossen!', 'Freundschaftsanfrage gesendet!');
      } else {
        showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Offene Freundschaftsanfrage vorhanden!');
      }
    }
  });
}

//----------------------------------------------------------------------------------------
//Call userprofile XY
//Then pass data to handleProfile();
//----------------------------------------------------------------------------------------
function loadProfile(toload, name){
  if($("#profile").hasClass('ui-dialog-content')) {
    openProfile.dialog('destroy').remove();
  }
  $("body").css("cursor: progress");
  $.get( "index.php", { inc: "profile" , pid: toload, sid: sid} )
  .done(function( data ) {
    handleProfile(name, data);
  });
}

//----------------------------------------------------------------------------------------
//Handle content passed from loadProfile();
//Inject into DOM
//----------------------------------------------------------------------------------------
function handleProfile(name, data) {
  data = $(data);
  openProfile = data.dialog({
    title: name+"'s Profil",
    width: 800,
    height: 600,
    resizable: false,
    modal: false,
    close: function(event, ui){
      $(this).dialog("destroy");
      $(this).remove();
    }
  });
  $("body").css("cursor: default");
}

//----------------------------------------------------------------------------------------
//Refresh all marked objects in DOM (data-reloadable="true")
//----------------------------------------------------------------------------------------
function refreshOpen() {
  showNotify('', 'fa fa-exclamation-circle fa-lg', 'Refresh!', 'Ein Systemrefresh wird durchgeführt!');
  $.ajax({async:false});
  $('body').find('[data-reloadable="true"]').each(function(index) {
    if($(this).hasClass('side')==true) {
      reloadBox($(this).attr("id"));
    }
    if($(this).hasClass('tabcon')==true) {
      reloadTab($(this).parent().attr("id"));
    }
  });
  loading = 'inc=navigation&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: loading,
    dataType: "html",
    success: function(data) {
      $("#navholder").html(data);
      navmenu = $("#menu").menu({
        items: "> :not(.ui-widget-header)"
      }).hide();
      showNotify('success', 'fa fa-check-circle fa-lg', 'Refresh!', 'Der Systemrefresh ist abgeschlossen!');
      $.ajax({async:true});
    }
  });
}

//----------------------------------------------------------------------------------------
//Update Usercounts for room entered
//----------------------------------------------------------------------------------------
function updateRoomCounts(data) {
  $('.onlinecount').each(function(index) {
    var id = $(this).attr("id").split("_");
    id = id[1];
    var tcount = 0;
    for (i=0; i<data.length; i++) {
      if (data[i].rid == id) {
        tcount++;
      }
    }
    $(this).text(tcount);
    if($(this).hasClass('rloc')==true) {
      var tmpmax = $("#onlinecounter_"+id).text();
      if(tcount >= tmpmax) {
        $("#fullindicator_"+id).css({'color':'red'});
      } else {
        $("#fullindicator_"+id).css({'color':'green'});
      }
    }
  });
}

//----------------------------------------------------------------------------------------
//Load smilielist into frontpage.
//----------------------------------------------------------------------------------------

function openSmilieList(target) {
  smiArea = target;
  loadDialog('smilies', 'Smiliesliste', 'smilies', '');
}

//----------------------------------------------------------------------------------------
//Send frequent pull to Server
//Pass data to handleData();
//----------------------------------------------------------------------------------------
function updateData() {
  lTimer = setTimeout('forceLogout',15000);
  $.ajax({
    url: 'index.php',
    type: 'post',
    dataType: 'json',
    data: loadAJAX,
    success: function(data) {
      lastRequest = data;
      handleData(data);
    },
    complete: function() {
      mTimer = setTimeout(updateData, 3000);
    }
  });
  if($("#roomlist").length) {
    rlCount++;
    if(rlCount == 20) {
      var panelId = "roomlist";
      loadAJAX[panelId] = 'false';
      reloadBox(panelId);
      loadAJAX[panelId] = 'true';
      rlCount = 0;
    }
  }
}

//----------------------------------------------------------------------------------------
//Pass given data from updateData() to destinated functions
//----------------------------------------------------------------------------------------
function handleData(data) {
  if(data.logout) {
    console.log("ServerError:\n" + JSON.stringify(loadAJAX) + "\n" + JSON.stringify(data));
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = window.location.protocol +'//'+ window.location.host + window.location.pathname;
  }
  if(loadAJAX["onlinelist"] == 'true' && $("#onlinelist").length && ("onlinelist" in data)) {
    handleOnlinelist(data["onlinelist"]);
  }
  if(loadAJAX["userbar"] == 'true' && $("#userbar").length && ("userbar" in data)) {
    handleUserbar(data["userbar"]);
  }
  if("messages" in data) {
    handleMessages(data.messages);
  }
  if("private" in data) {
    handlePrivMessages(data.private);
  }
  if(data.refresh==true) {
    refreshOpen();
  }
  if("roomcounts" in data) {
    updateRoomCounts(data["roomcounts"]);
  }
  clearTimeout(lTimer);
  errorCounter = 0;
}

//----------------------------------------------------------------------------------------
//Check if clicked tab is a chatroom
//----------------------------------------------------------------------------------------
function checkTab() {
  var panelID = tabs.find( ".ui-tabs-active" ).closest( "li" ).attr( "aria-controls" );
  activePanel = panelID;
  if(panelID.indexOf("room_") > -1) {
    var tmp_rid = panelID.split("_");
    loadAJAX["rid"] = tmp_rid[1];
    $('a[href="#'+activePanel+'"]').closest("li").removeClass("ui-state-highlight");
  } else {
    loadAJAX["rid"] = 0;
  }
}

//----------------------------------------------------------------------------------------
//Handle errors and perform emergency logout if errorcount hits 5
//----------------------------------------------------------------------------------------
function forceLogout() {
  if(errorCounter < 5) {
    console.log("FL-Error:\n" + JSON.stringify(loadAJAX) + "\n" + JSON.stringify(lastRequest));
    showNotify('', 'fa fa-exclamation-circle fa-lg', 'Achtung!', 'Updaterfehler #'+errorCounter+'!<br />Versuche zu beheben...');
    clearTimeout(mTimer);
    clearTimeout(lTimer);
    mTimer = setTimeout(updateData, 500);
    errorCounter++;
  } else {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehlgeschlagen!', 'Updaterfehler!<br />Konnte nicht beheben. Bitte neu einloggen.');
    setTimeout(performLogout2(), 10000);
  }
}

//----------------------------------------------------------------------------------------
//Gracefully log user out
//----------------------------------------------------------------------------------------
function performLogout(id) {
  clearTimeout(lTimer);
  clearTimeout(mTimer);
  loading = 'inc=doLogout&sid='+id;
  $.ajax({
    url: 'index.php',
    type: 'post',
    dataType: 'text',
    data: loading
  }).done(function() {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = window.location.protocol +'//'+ window.location.host + window.location.pathname;
  });
}

//----------------------------------------------------------------------------------------
//Ungracefully log user out
//----------------------------------------------------------------------------------------
function performLogout2() {
  clearTimeout(lTimer);
  clearTimeout(mTimer);
  localStorage.clear();
  sessionStorage.clear();
  window.location.href = window.location.protocol +'//'+ window.location.host + window.location.pathname;
}

//----------------------------------------------------------------------------------------
//Play the Pling! ;D
//----------------------------------------------------------------------------------------
function playPling() {
  if(playSound == true) {
    var sound = $("#plingsound")[0];
    sound.load();
    sound.play();
  }
}

//----------------------------------------------------------------------------------------
//Play the Plong! ;D
//----------------------------------------------------------------------------------------
function playPlong() {
  if(playSound == true) {
    var sound2 = $("#plongsound")[0];
    sound2.load();
    sound2.play();
  }
}

//----------------------------------------------------------------------------------------
//Get current mainframe width and calculate how many widgets fit next to eachother
//Assuming widget width is 206px
//----------------------------------------------------------------------------------------
function calcWindow() {
  chwidth = $("#ctcol").width();
  chwidgets = Math.floor(chwidth / 206);
  chheight = $(window).height();
  chheight = chheight-85;
  $('.acenter').css({'height':chheight});
  $('#ltcol').css({'height':chheight});
  $('#rtcol').css({'height':chheight});
  chheight = chheight-12;
  $('.ui-tabs').css({'height':chheight});
  chheight = chheight-48;
  $('.ui-tabs-panel').css({'height':chheight});
  stack_center.firstpos2 = ($(window).width() / 2) - (Number(PNotify.prototype.options.width.replace(/\D/g, '')) / 2);
}

//----------------------------------------------------------------------------------------
//Reset Deathtimer
//----------------------------------------------------------------------------------------
function resetRefreshTimeout() {
  refreshTimeout = false;
}

//----------------------------------------------------------------------------------------
//Check contextmenu-permissions
//----------------------------------------------------------------------------------------
function checkPermit(gid, gid2, mode) {
  var order1 = RankIcons["order"+gid];
  var order2 = RankIcons["order"+gid2];
  if(mode == 0) {
    if(order1 > order2) {
      return true;
    } else {
      return false;
    }
  } else {
    if(order1 >= order2) {
      return true;
    } else {
      return false;
    }
  }
}

//----------------------------------------------------------------------------------------
//Include JavaScriptFile XY
//----------------------------------------------------------------------------------------
function loadJSFile(file) {
  $.getScript( file )
    .done(function( script, textStatus ) {
    })
    .fail(function( jqxhr, settings, exception ) {
      console.log( jqxhr );
      console.log( exception );
  });
}

//----------------------------------------------------------------------------------------
//-----------------------------Initiate JavaScript Functionality--------------------------
//----------------------------------------------------------------------------------------

$(document).ready(function(){
  theme = $("#theme").val();
  $.ajaxSetup({
    data: { theme: theme }
  });
  
  if(typeof(Storage)==="undefined") {
    alert('Your browser does not support localstorage! Please upgrade your browser or use another');
    window.stop(); //works in all browsers but IE    
    if ($.browser.msie) { document.execCommand("Stop"); }; //works in IE, 
  }

  loadJSFile('./js/reset.js');
  loadJSFile('./js/reportbox.js');

  navmenu = $("#menu").menu({
        items: "> :not(.ui-widget-header)"
      }).hide();

  $("#mainmenubutton").button({
      showLabel: false
    });
  $("body").delegate( "#mainmenubutton", "click", function() {
        // Make use of the general purpose show and position operations
        // open and place the menu where we want.
        navmenu.show().position({
              my: "left top",
              at: "left bottom",
              of: this
        });
        // Register a click outside the menu to close it
        $( document ).on( "click", function() {
              navmenu.hide();
        });
        // Make sure to return false here or the click registration
        // above gets invoked.
        return false;
   });
  
  $("#loginbutton").button();
  $("#regbutton").button();

  tabs = $( "#tabs" ).tabs({
    heightStyle: "fill",
    activate: function( event, ui ) {
      checkTab();
    }
  });
  tabs.find( ".ui-tabs-nav" ).sortable({
    axis: "x",
    stop: function() {
      tabs.tabs( "refresh" );
    }
  });

  tabs.delegate( "span.fa-times", "click", function() {
    var panelId = $( this ).closest( "li" ).remove().attr( "aria-controls" );
    if(panelId.indexOf("room_") > -1) {
      tmprid = panelId.split("_");
      tmprid = tmprid[1];
      lloading = 'inc=ajaxcr&do=leaveroom&rid='+tmprid+'&sid='+sid;
      $.ajax({
        url: "index.php", 
        data: lloading,
        dataType: "text"
      });
    }
    $( "#" + panelId ).remove();
    tabs.tabs( "refresh" );
  });

  tabs.delegate( "span.fa-refresh", "click", function() {
    if(refreshTimeout == false) {
      var panelId = $( this ).closest( "li" ).attr( "aria-controls" );
      reloadTab(panelId);
      refreshTimeout = true;
      setTimeout(resetRefreshTimeout, "5000");
    } else {
      showNotify('', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Bitte warte 5 Sekunden ehe du wieder etwas neu lädst!');
    }
  });
 
  tabs.bind( "keyup", function( event ) {
    if ( event.altKey && event.keyCode === $.ui.keyCode.BACKSPACE ) {
      var panelId = tabs.find( ".ui-tabs-active" ).remove().attr( "aria-controls" );
      $( "#" + panelId ).remove();
      tabs.tabs( "refresh" );
    }
  });

  var tooltips = $( "[title]" ).tooltip({
    position: {
      my: "left top",
      at: "right+5 top-5"
    }
  });

  $(function() {
    $( "#ltcol" ).sortable({
      handle: ".whead",
      tolerance: "pointer",
      opacity: 0.5,
      forcePlaceholderSize: true,
      connectWith: ".widgetholder",
      placeholder: "ui-state-highlight",
        remove: function(event, ui) {
            if(!$('.widget', this).length) {
              $('#ltcol').css({'width':5});
              $('.acenter').animate({ "marginLeft": "5px" }, "fast" );
            }
        },
        receive: function(event, ui) {
              $('#ltcol').animate({ "width": "206px" }, "fast" );
              $('.acenter').animate({ "marginLeft": "216px" }, "fast" );
        }
    });
  });

  $( "#ltcol" ).delegate( "span.fa-refresh", "click", function() {
    if(refreshTimeout == false) {
      var panelId = $(this).parent().parent().attr("id");
      loadAJAX[panelId] = 'false';
      reloadBox(panelId);
      loadAJAX[panelId] = 'true';
      refreshTimeout = true;
      setTimeout(resetRefreshTimeout, "5000");
    } else {
      showNotify('', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Bitte warte 5 Sekunden ehe du wieder etwas neu lädst!');
    }
  });

  $( "#ltcol" ).delegate( "span.fa-times", "click", function() {
    var panelId = $(this).parent().parent().attr("id");
    loadAJAX[panelId] = 'false';
    $( "#" + panelId ).remove();
    showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Box geschlossen!');
    if(!$('.widget', "#ltcol").length) {
      $('#ltcol').css({'width':5});
      $('.acenter').animate({ "marginLeft": "5px" }, "fast" );
    }
  });

  $( "#ltcol" ).delegate( "span.fa-chevron-circle-up", "click", function() {
    var panelId = $(this).parent().parent().attr("id");
    $(this).removeClass("fa-chevron-circle-up");
    $(this).addClass("fa-chevron-circle-down");
    $("#"+panelId).animate({ "height": "18px" }, "fast" );
  });

  $( "#ltcol" ).delegate( "span.fa-chevron-circle-down", "click", function() {
    var panelId = $(this).parent().parent().attr("id");
    var setHeight = $(this).attr('data-hs');
    $(this).removeClass("fa-chevron-circle-down");
    $(this).addClass("fa-chevron-circle-up");
    if(setHeight == 'auto') { setHeight = $("#"+panelId).prop('scrollHeight')+"px"; }
    $("#"+panelId).animate({ "height": setHeight }, "fast" );
  });

  $( "#rtcol" ).delegate( "span.fa-refresh", "click", function() {
    if(refreshTimeout == false) {
      var panelId = $(this).parent().parent().attr("id");
      loadAJAX[panelId] = 'false';
      reloadBox(panelId);
      loadAJAX[panelId] = 'true';
      refreshTimeout = true;
      setTimeout(resetRefreshTimeout, "5000");
    } else {
      showNotify('', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Bitte warte 5 Sekunden ehe du wieder etwas neu lädst!');
    }
  });

  $( "#rtcol" ).delegate( "span.fa-times", "click", function() {
    var panelId = $(this).parent().parent().attr("id");
    loadAJAX[panelId] = 'false';
    $( "#" + panelId ).remove();
    showNotify('info', 'fa fa-info-circle fa-lg', 'Info!', 'Box geschlossen!');
    if(!$('.widget', "#rtcol").length) {
      $('#rtcol').css({'width':5});
      $('.acenter').animate({ "marginRight": "5px" }, "fast" );
    }
  });

  $( "#rtcol" ).delegate( "span.fa-chevron-circle-up", "click", function() {
    var panelId = $(this).parent().parent().attr("id");
    $(this).removeClass("fa-chevron-circle-up");
    $(this).addClass("fa-chevron-circle-down");
    $("#"+panelId).animate({ "height": "18px" }, "fast" );
  });

  $( "#rtcol" ).delegate( "span.fa-chevron-circle-down", "click", function() {
    var panelId = $(this).parent().parent().attr("id");
    var setHeight = $(this).attr('data-hs');
    $(this).removeClass("fa-chevron-circle-down");
    $(this).addClass("fa-chevron-circle-up");
    if(setHeight == 'auto') { setHeight = $("#"+panelId).prop('scrollHeight')+"px"; }
    $("#"+panelId).animate({ "height": setHeight }, "fast" );
  });
  
  $( "body" ).delegate(".fa-refresh", "mouseover", function() {
    $( this ).addClass("fa-spin");
  });
  $( "body" ).delegate(".fa-refresh", "mouseout", function() {
    $( this ).removeClass("fa-spin");
  });

    $( ".side" ).resizable({
      maxWidth: 206,
      minHeight: 75,
      minWidth: 206
    });

  $(function() {
    $( "#rtcol" ).sortable({
      handle: ".whead",
      tolerance: "pointer",
      opacity: 0.5,
      forcePlaceholderSize: true,
      connectWith: ".widgetholder",
      placeholder: "ui-state-highlight",
        remove: function(event, ui) {
            if(!$('.widget', this).length) {
              $('#rtcol').css({'width':5});
              $('.acenter').animate({ "marginRight": "5px" }, "fast" );
            }
        },
        receive: function(event, ui) {
              $('#rtcol').animate({ "width": "206px" }, "fast" );
              $('.acenter').animate({ "marginRight": "216px" }, "fast" );
        }
    });
  });
  loadAJAX["sid"] = sid;
  loadAJAX["uid"] = uid;
  loadAJAX["aid"] = aid;
  loadAJAX["rid"] = 0;
  loadAJAX["uname"] = uname;
  loadAJAX["inc"] = 'updater';
  mTimer = setTimeout('updateData();',500);
  $(document).tooltip({
    content: function () {
      return $(this).prop('title');
    }
  });
  loadJSFile('./js/private.js');
  console.log(window.location.origin);
  PNotify.desktop.permission();
  calcWindow();
});

window.onerror = function(msg, url, line, col, error) {
   var extra = !col ? '' : '\ncolumn: ' + col;
   extra += !error ? '' : '\nerror: ' + error;
   console.log("Error: " + msg + "\nurl: " + url + "\nline: " + line + extra);
   var suppressErrorAlert = true;
   return suppressErrorAlert;
};

(function($) {
$.fn.serializefiles = function() {
    var obj = $(this);
    /* ADD FILE TO PARAM AJAX */
    var formData = new FormData();
    $.each($(obj).find("input[type='file']"), function(i, tag) {
        $.each($(tag)[0].files, function(i, file) {
            formData.append(tag.name, file);
        });
    });
    var params = $(obj).serializeArray();
    $.each(params, function (i, val) {
        formData.append(val.name, val.value);
    });
    return formData;
};
})(jQuery);

$(window).resize(function() {
  calcWindow();
});

jQuery.expr[':'].icontains = function(a, i, m) {
  return jQuery(a).text().toUpperCase()
      .indexOf(m[3].toUpperCase()) >= 0;
};

; (function($) {
    $.fn.focusToEnd = function() {
        return this.each(function() {
            var v = $(this).val();
            $(this).focus().val("").val(v);
        });
    };
})(jQuery);