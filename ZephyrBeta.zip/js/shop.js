var shopSearchPattern = 'data-name';

function shopSearchBox() {
  $("#shopfilterinput").keyup(function() { 
    var filter = $("#shopfilterinput").val().toUpperCase();
    if(filter != '') {
      $('.'+shopSearchPattern+':not(:icontains('+ filter +'))').closest("div").hide(); 
      $('.'+shopSearchPattern+':icontains('+ filter +')').closest("div").show(); 
    } else {
      $('.item').show();
    }
  }).keyup();
}

function buyItem(iid) {
  var str = 'inc=ajaxshop&do=buyitem&iid='+iid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function(data) {
      if(data != 'error') {
        showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', '"'+data+'" wurde gekauft!');
      } else {
        showNotify('error', 'fa fa-times-circle fa-lg', 'Fehler!', 'Nicht genug Coins!');
      }
    }
  });
}

function execute_Shop() {
  $("#shopfiltersettings").selectmenu({
    change: function(event, ui) {
      shopSearchPattern = ui.item.value;
      shopSearchBox();
    }
  });
  shopSearchBox();
  $('.itemnametag').quickfit();
}

$(document).ready(function(){
  execute_Shop();
});