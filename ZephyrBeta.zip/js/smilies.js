var showSmiCat;

function getSmilies(catid) {
  console.log(catid);
  var str = 'inc=ajaxsmilie&catid='+catid+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      buildSmilies(data);
    }
  });
}

function buildSmilies(data) {
  tempSmiList = '';
  for(i=0; i < data.length; i++) {
    tempSmiList += '<div onclick="addSmilie(\''+data[i].smi_sc+'\')" class="ui-corner-all gradient" style="cursor: pointer; position: relative; margin: 5px; vertical-align: middle; width: 100px; height: 145px; padding: 5px; display: inline-block; border: 1px solid #a6c9e2;" onclick="" title="">';
    tempSmiList += '<p class="sminametag" style="font-weight: bold; white-space: nowrap;">'+data[i].smi_name+'</p>';
    tempSmiList += '<p style="font-style: italic; font-size: 70%;">'+data[i].smi_sc+'</p>';
    tempSmiList += '<div class="wraptocenter" style="height: 100px"><span></span><img src="./files/smilies/'+data[i].smi_pic+'" alt="" class="ui-corner-all" style="max-width: 90px; max-height: 90px;" /></div>';
    tempSmiList += '</div>';
  }
  $("#smiliesListRowContainer").html(tempSmiList);
  $('.sminametag').quickfit();
}

function addSmilie(sc) {
  $('#'+smiArea).val($('#'+smiArea).val() + ' '+sc+' ');
}

function execute_Smilies() {
  $( "#slCatSelector" ).on('change', function() {
      showSmiCat = this.value;
      getSmilies(showSmiCat);
  });
  showSmiCat = $("#slCatSelector option:first-child").val();
  getSmilies(showSmiCat);
}

$(document).ready(function(){
  execute_Smilies();
});