/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
//Switch for (in)active BrowserTab
//bool
var isActive = true;

//Display Clock at Messages?
//Int
var user_clock;

var show_mini_avatar;

var tfSet;

//Allow autoscroll
//Int
var allowScroll = 1;

//Helper Height
var chheight2;

//Send message to group
//Int
var sendToGroup = '-1';

//Pickcol
var pickcol;

var userName;
var userAlias;

var messUSK = '0';

var onlineBoxDialog = '';
var smilieBoxDialog = '';

var minavaTimeout;
var minavaId = 'none';

cchname = '';
cchuid = '';

function switchTimer() {
  if(user_clock == 1) {
    var timeShowText = 'Zeitstempel wird verborgen.';
    user_clock = 0;
    $('.clockbuttonicon').addClass('fa-calendar-times-o').removeClass('fa-calendar-check-o');
    $('.timestamp').hide();
  } else {
    var timeShowText = 'Zeitstempel wird angezeigt.';
    user_clock = 1;
    $('.clockbuttonicon').addClass('fa-calendar-check-o').removeClass('fa-calendar-times-o');
    $('.timestamp').show();
  }
  lloading = 'inc=ajaxcr&do=toggletime&to='+user_clock+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', timeShowText);
    }
  });
}

function switchFSK() {
  if(messUSK == '0') {
    $('.fskbuttonicon').addClass('fa-male ol-red').removeClass('fa-child');
    showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'FSK 18 Nachrichtenmodus aktiviert!');
    messUSK = '18';
  } else {
    $('.fskbuttonicon').addClass('fa-child').removeClass('fa-ban ol-red');
    showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'FSK 18 Nachrichtenmodus deaktiviert!');
    messUSK = '0';
  } 
}

function switchMiniAvatar() {
  if(show_mini_avatar == '0') {
    var avaShowText = 'Chatavatare aktiviert!';
    $('.minavabuttonicon').addClass('fa-user').removeClass('fa-user-times');
    show_mini_avatar = '1';
    $('.chat_min_avatar').show();
  } else {
    var avaShowText = 'Chatavatare deaktiviert!';
    $('.minavabuttonicon').addClass('fa-user-times').removeClass('fa-user');
    show_mini_avatar = '0';
    $('.chat_min_avatar').hide();
  } 
  lloading = 'inc=ajaxcr&do=toggleava&to='+show_mini_avatar+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', avaShowText);
    }
  });
}

function switchTF() {
  if(tfSet == '0') {
    var tfShowText = 'Textformatierung aktiviert!';
    $('.tfbuttonicon').addClass('fa-underline').removeClass('fa-font');
    tfSet = '1';
  } else {
    var tfShowText = 'Textformatierung deaktiviert!';
    $('.tfbuttonicon').addClass('fa-font').removeClass('fa-underline');
    tfSet = '0';
  } 
  lloading = 'inc=ajaxcr&do=toggletf&to='+tfSet+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', tfShowText);
    }
  });
}

function switchSounds() {
  if(playSound == true) {
    $('.psbuttonicon').addClass('fa-bell-slash-o').removeClass('fa-bell-o');
    showNotify('success', 'fa fa-bell-slash-o fa-lg', 'Erfolg!', 'Benachrichtigungstöne deaktiviert!');
    playSound = false;
  } else {
    $('.psbuttonicon').addClass('fa-bell-o').removeClass('fa-bell-slash-o');
    showNotify('success', 'fa fa-bell-o fa-lg', 'Erfolg!', 'Benachrichtigungstöne aktiviert!');
    playSound = true;
  } 
}

function addIgnore(name) {
  ignoreList += ','+name+',';
  showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', name+' wird jetzt von dir ignoriert!');
}

function removeIgnore(name) {
  ignoreList = ignoreList.replace(','+name+',', '');
  showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', name+' wird nicht mehr von dir ignoriert!');
}

function openOnlineStatusBox() {
  onlineBoxDialog.dialog("open");
}

function openSmilieBox() {
  smilieBoxDialog.dialog("open");
}

function showScore() {
  lloading = 'inc=ajaxcr&do=showscore&rid='+loadAJAX["rid"]+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Deine Bewertung wird angezeigt!');
    }
  });
}

function changeOnlineStatus(state, mode, osShowText) {
  if(state == currOS) {
    if(mode == 1) {
      showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Dein Status ist bereits: <br />'+osShowText); 
    }
  } else {
    $(".osButtonicon").addClass("online"+state).removeClass("online"+currOS);
    currOS = state;
    if(mode == 1) {
      lloading = 'inc=ajaxcr&do=switchos&to='+state+'&sid='+sid;
      $.ajax({
        url: "index.php", 
        data: lloading,
        dataType: "text",
        success: function() {
          showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Dein Status ist nun: <br />'+osShowText);
        }
      });
    }
  }
}

function notifyUser(id, name) {
  lloading = 'inc=ajaxcr&do=notifyuser&target='+id+'&rid='+loadAJAX["rid"]+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', name+' wurde auf dich aufmerksam gemacht!');
    }
  });
}

function callModerator() {
  lloading = 'inc=ajaxcr&do=callmod&rid='+loadAJAX["rid"]+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Das Moderatorenteam wurde informiert!');
    }
  });
}

function banUser(id, duration) {
  lloading = 'inc=ajaxcr&do=banuser&target='+id+'&duration='+duration+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer wurde gebannt!');
    }
  });
}

function kickUser(id) {
  lloading = 'inc=ajaxcr&do=kickuser&target='+id+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer wurde gekickt!');
    }
  });
}

function ownerKickUser(id) {
  lloading = 'inc=ajaxcr&do=ownerkickuser&target='+id+'&sid='+sid+'&rid='+loadAJAX["rid"];
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer wurde gekickt!');
    }
  });
}

function confuseUser(id) {
  lloading = 'inc=ajaxcr&do=confuseuser&target='+id+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer ist jetzt verwirrt!');
    }
  });
}

function ownerConfuseUser(id) {
  lloading = 'inc=ajaxcr&do=ownerconfuseuser&target='+id+'&sid='+sid+'&rid='+loadAJAX["rid"];
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer ist jetzt verwirrt!');
    }
  });
}

function unconfuseUser(id) {
  lloading = 'inc=ajaxcr&do=unconfuseuser&target='+id+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer ist nicht mehr verwirrt!');
    }
  });
}

function ownerUnconfuseUser(id) {
  lloading = 'inc=ajaxcr&do=ownerunconfuseuser&target='+id+'&sid='+sid+'&rid='+loadAJAX["rid"];
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer ist nicht mehr verwirrt!');
    }
  });
}

function warnUser(id) {
  lloading = 'inc=ajaxcr&do=warnuser&target='+id+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer wurde verwarnt!');
    }
  });
}

function unwarnUser(id) {
  lloading = 'inc=ajaxcr&do=unwarnuser&target='+id+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer wurde entwarnt!');
    }
  });
}

function gagUser(id) {
  lloading = 'inc=ajaxcr&do=gaguser&target='+id+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer wurde geknebelt!');
    }
  });
}

function ungagUser(id) {
  lloading = 'inc=ajaxcr&do=ungaguser&target='+id+'&sid='+sid;
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Benutzer wurde entknebelt!');
    }
  });
}

//Grab user message to send to server
function grabMessage() {
  var tmpm = $('#text_input_'+loadAJAX["rid"]).val();
  if((jQuery.trim( tmpm )).length==0) {
    $('#text_input_'+loadAJAX["rid"]).val('');
    $('#text_input_'+loadAJAX["rid"]).focus();
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Hey!', 'Schreibe bitte mehr als das!');
  } else {
    $(".text_input").prop('disabled', true);
    sendMessage();
  }
}

//Send message to server, force request
function sendMessage() {
  var mess = $('#text_input_'+loadAJAX["rid"]).val();
  $.ajax({
    async: true,
    url: 'index.php',
    type: 'post',
    dataType: 'html',
    data: { inc: "sendmess", sid: loadAJAX["sid"], uid: loadAJAX["uid"], rid: loadAJAX["rid"], stg: sendToGroup, usk: messUSK, mess: mess },
    success: function(data) {
      delete window.mess;
      $('#text_input_'+loadAJAX["rid"]).val('');
      $(".text_input").prop('disabled', false);
      $('#text_input_'+loadAJAX["rid"]).focus();
    },
    complete: function() {
      clearTimeout(window.mTimer);
      mTimer = setTimeout(updateData, 500);
    }
  });
}

function handleMessages(data) {
  for(i=0; i < data.length; i++) {
    if(ignoreList.indexOf(','+data[i].mess_author_name+',') == -1 && (data[i].mess_type == 0 || data[i].mess_type == 1 || data[i].mess_type == 3 || data[i].mess_type == 4)) {
      var name_check = '0';
      if(data[i].mess_author_name in colorList) { data[i].mess_form = colorList[data[i].mess_author_name]; }
      if(data[i].mess_author_id != '0') {
        if(data[i].mess_content.toLowerCase().search(userName.toLowerCase()) != -1) {
          name_check = userName;
        }
        if(userAlias.match(',') && name_check == '0') {
          var tmp_alias = userAlias.split(',');
          for(o=0;o<tmp_alias.length;o++) {
            if(data[i].mess_content.toLowerCase().search(tmp_alias[o].toLowerCase().trim()) != -1) {
              name_check = tmp_alias[o].trim();
              }
          }
        }
        if(userAlias != '' && name_check == '0') {
          if(data[i].mess_content.toLowerCase().search(userAlias.toLowerCase()) != -1) {
            name_check = userAlias;
          }
        }
      }
      var tmproom = $( "#chatstream-"+data[i].mess_room_id );
      var tmpident = "room_"+data[i].mess_room_id;
      var defCol = $(tmproom).css("color");
      var mess = data[i].mess_content;
      var messages = '';
      if(name_check != '0') {
        messages += '&nbsp;<i class="fa fa-flag-o fa-fw"></i>';
        var regEx = new RegExp(name_check, "ig");
        mess = mess.replace(regEx, function (match) { return '<span class="ui-state-highlight">'+match+'</span>'; });
      }
      if(data[i].mess_usk != '0') {
        messages += '&nbsp;<span class="fa fa-male ol-red fa-fw" style="line-height: 1.5;" title="FSK 18 Nachricht!">&nbsp;</span>';
      }
      if(RankIcons[data[i].mess_req_lvl] != '' && data[i].mess_author_id != '0') {
        messages += '&nbsp;<img title="'+RankIcons["name"+data[i].mess_req_lvl]+'" style="padding-left: 4px; vertical-align:middle;" src="./files/groupicons/'+RankIcons[data[i].mess_req_lvl]+'" />';
      }
      messages += '&nbsp;<span class="timestamp" style="color: #'+defCol+'; font-size: 60%; font-style:italic;';
      if(user_clock != 1) {
        messages += 'display: none;';
      }
      messages += '">('+data[i].mess_write_time+')&nbsp;</span>';
      if(data[i].mess_type != 0 && show_mini_avatar == 1) {
        messages += '<span class="chat_min_avatar repelem" data-reparea="chatroom" data-repid="'+data[i].mess_author_id+'" data-repitem="avatar" data-repdata="'+data[i].mess_avatar+'"><img id="min_ava_'+data[i].mess_id+'" class="chat_min_ava_img curpoint ui-corner-all" style="max-height: 20px; max-weight: 20px; vertical-align:middle; margin-top: 1px; margin-bottom: 1px;" src="./files/userpic/'+data[i].mess_avatar+'" />&nbsp;</span>';
      }
      if(data[i].mess_type == 0) {
        messages += '<span style="color: #'+defCol+'; font-size: 80%;">'+data[i].mess_author_name+'</span>:&nbsp;<span style="color: #'+defCol+'; font-size: 80%;">'+data[i].mess_content+'</span><br />';
      } else if(data[i].mess_type == 3) {
        mess = mess.replace(/-REPME-/g, defCol);
        messages += '<span style="color: #'+data[i].mess_form+'">'+data[i].mess_author_name+'</span><i class="fa fa-comment-o" style="margin-left: 4px; margin-right: 4px;" title="Sagt zu"></i><span style="color: #'+data[i].mess_form+'" class="repelem" data-reparea="chatroom" data-repid="'+data[i].mess_author_id+'" data-repitem="'+data[i].mess_room_id+'" data-repdata="'+data[i].mess_id+'">'+mess+'</span><br />';
      } else if(data[i].mess_type == 4) {
        mess = mess.replace(/-REPME-/g, defCol);
        messages += '<span style="color: #'+data[i].mess_form+'">'+data[i].mess_author_name+'</span><i class="fa fa-commenting-o" style="margin-left: 4px; margin-right: 4px;" title="Flüstert zu"></i><span style="color: #'+data[i].mess_form+'" class="repelem" data-reparea="chatroom" data-repid="'+data[i].mess_author_id+'" data-repitem="'+data[i].mess_room_id+'" data-repdata="'+data[i].mess_id+'">'+mess+'</span><br />';
      } else {
        mess = mess.replace(/-REPME-/g, defCol);
        if(data[i].mess_action == 0) {
          messages += '<span class="chatcontentmenu rcl hoverul" data-name="'+data[i].mess_author_name+'" data-uid="'+data[i].mess_author_id+'" style="color: #'+data[i].mess_form+'">'+data[i].mess_author_name+'</span>:&nbsp;<span style="color: #'+data[i].mess_form+'" class="repelem" data-reparea="chatroom" data-repid="'+data[i].mess_author_id+'" data-repitem="'+data[i].mess_room_id+'" data-repdata="'+data[i].mess_id+'">'+mess+'</span><br />';
        } else {
          var tmprating = mess.split("-555-");
          var score = tmprating[0];
          var rates = tmprating[1];
          mess = '<span class="inchatrating" data-rating="'+score+'" style="color: #FFD700"></span> <span style="color: '+defCol+'; font-size: 70%; font-style:italic;">('+rates+' Bewertungen)</span>'
          messages += '<span class="chatcontentmenu rcl hoverul" data-name="'+data[i].mess_author_name+'" data-uid="'+data[i].mess_author_id+'" style="color: #'+data[i].mess_form+'">'+data[i].mess_author_name+'</span>:&nbsp;<span style="color: #'+data[i].mess_form+'" class="repelem" data-reparea="chatroom" data-repid="'+data[i].mess_author_id+'" data-repitem="'+data[i].mess_room_id+'" data-repdata="'+data[i].mess_id+'">'+mess+'</span><br />';
        }
      }
      messages = messages.replace(/&quot;/g, '"');
      $(tmproom).append(messages);
      $('.inchatrating').each(function() {
        $( this ).raty({
          readOnly: true,
          half: true,
          score: function() {
            return $(this).attr('data-rating');
          },
          size: 24,
          round : { down: .26, full: .6, up: .76 },
          hints: ['Mies', 'Naja', 'Okay', 'Gut', 'Super']
        });
        $(this).removeClass("inchatrating");
      });
//-------------------------------------------------------------------------------------
//---------------------------------Smilies---------------------------------------------
//-------------------------------------------------------------------------------------
      $('.smiliePRE').replaceWith(function(){
        var SMIpic = $(this).attr("data-pic");
        var SMIsc = $(this).attr("data-sc");
        var SMIlvl = $(this).attr("data-lvl");
        var SMIname = $(this).attr("data-name");
        var SMIusk = $(this).attr("data-usk");
        if(userage >= SMIusk) {
          var smilies = '<img style="vertical-align:middle;" onclick="takeSmilie(\''+SMIsc+'\')" alt="'+SMIname+'" class="smilieLOADED" data-sc="'+SMIsc+'" data-name="'+SMIname+'" data-usk="'+SMIusk+'" data-lvl="'+SMIlvl+'" src="/files/smilies/'+SMIpic+'" />';
        } else {
          var smilies = '<img style="vertical-align:middle;" alt="Check USK" class="uskWARN" src="/files/smilies/error.png" />';
        }
        return smilies;
      });
//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
      $(tmproom).animate({"scrollTop": $(tmproom)[0].scrollHeight}, "slow");
      if(acp == "no") {
        $(".badword").prop('title', 'Badword blockiert!');
      }
      if(tmpident != activePanel && data[i].mess_author_id != '0') {
        $('a[href="#'+tmpident+'"]').closest("li").addClass("ui-state-highlight");
      }
    }
    if(data[i].mess_type == 2) {
      if(isActive == false) {
        showNotify('desktop-info', 'fa fa-info-circle fa-lg', 'Online!', data[i].mess_content);
      } else {
        showNotify('info', 'fa fa-info-circle fa-lg', 'Online!', data[i].mess_content);
      }
    }
    if(ignoreList.indexOf(','+data[i].mess_author_name+',') == -1 && data[i].mess_type == 5) {
      if(playSound == false) {
        var soundicon = 'fa fa-bell-slash-o fa-lg';
      } else {
        var soundicon = 'fa fa-bell-o fa-lg';
      }
      if(isActive == false) {
        showNotify('desktop-info', soundicon, 'Hey!', data[i].mess_content+' will deine Aufmerksamkeit!');
      } else {
        showNotify('info', soundicon, 'Hey!', data[i].mess_content+' will deine Aufmerksamkeit!');
      }
      playPlong();
    }
    if(data[i].mess_type == 6) {
      var youtubeDialog = $('<div id="youtube_'+data[i].mess_id+'"><p><iframe width="560" height="315" src="https://www.youtube.com/embed/'+data[i].mess_content+'" frameborder="0"></iframe></p></div>');
      youtubeDialog.dialog({ title: '', width: '600', close: function( event, ui ) { $( this ).dialog('destroy').remove(); }}).parent().find('.ui-dialog-title').html('<span><i class="fa fa-youtube-play fa-lg fa-fw"></i>&nbsp;Von&nbsp;'+data[i].mess_author_name+'</span>');
    }
    if(data[i].mess_type == 7) {
      toggleWarns(data[i].mess_content);
    }
    if(data[i].mess_type == 8) {
      switch(data[i].mess_action) {
        case '1': showNotify('info', 'fa fa-volume-off fa-lg', data[i].mess_author_name, data[i].mess_content); break;
        case '2': showNotify('', 'fa fa-volume-down fa-lg', data[i].mess_author_name, data[i].mess_content); break;
        case '3': 
          if(isActive == false) {
            showNotify('desktop-success', 'fa fa-volume-up fa-lg', data[i].mess_author_name, data[i].mess_content); 
          } else {
            showNotify('success', 'fa fa-volume-up fa-lg', data[i].mess_author_name, data[i].mess_content); 
          }
        break;
      }
    }
    if(data[i].mess_type == 9 && data[i].mess_content == sid) {
      var panelId = "room_"+data[i].mess_room_id;
      lloading = 'inc=ajaxcr&do=leaveroomf&rid='+data[i].mess_room_id+'&sid='+sid;
      $.ajax({
        url: "index.php", 
        data: lloading,
        dataType: "text"
      });
      $( "li[aria-controls='"+panelId+"']" ).remove();
      $( "#" + panelId ).remove();
      tabs.tabs( "refresh" );
    }
    if(data[i].mess_type == 10) {
      new PNotify({
        title: "Moderation!",
        hide: false,
        text: data[i].mess_content,
        type: 'error',
        icon: 'ui-icon fa fa-exclamation-triangle fa-lg',
        styling: 'jqueryui',
        stack: stack_center
      });
    }
    if(isActive == false && data[i].mess_author_id != '0') {
      document.title = "Neu! - "+pageTitle;
      playPling();
    }
  }
}

function recolor(name, color) {
  if(color != 'reset') {
    if(color == 'random') {
      color = Math.random().toString(16).slice(2, 8).toUpperCase();
    }
    colorList[name] = color;
    showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', name+' wurde von dir umgefärbt!');
  } else {
    if(name in colorList) { 
      delete colorList[name];
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', name+' hat wieder seine Farbe!');
    }
  }
}

function takeSmilie(sc) {
  $('#text_input_'+loadAJAX["rid"]).val($('#text_input_'+loadAJAX["rid"]).val() + ' ' + sc + ' ');
}

function useTab() {
  var tmp_nicks = globalInRoom.split(",").sort();
  console.log("Nickliste: "+tmp_nicks);
  var tmp_mess = $("#text_input_"+loadAJAX["rid"]).val();
  var lastIndex = tmp_mess.lastIndexOf(" ");
  
  var finalMessage = tmp_mess.substring(0, lastIndex);
  var finalMatch = '';
  var ini = '';
  var tmp_match;
  
  var last_word = tmp_mess.trim().split(" ").splice(-1);
  last_word = last_word[0];
  console.log("Letztes Wort: "+last_word+"("+last_word.length+")");
  if(last_word.length == 0) {
    finalMatch = tmp_nicks[0];
    finalMessage = finalMatch;
    console.log("Empty last word");
  } else {
    if($.inArray(last_word, tmp_nicks) !== -1) {
      ini = $.inArray(last_word, tmp_nicks);
      ini++;
      if(ini >= tmp_nicks.length) {
        ini = 0;
      }
      finalMatch = tmp_nicks[ini];
      finalMessage = finalMessage.trim().slice(0, -last_word.length);
      finalMessage = finalMessage+" "+finalMatch;
      console.log("Replacing last word matching");
    } else {
      for(i=0;i < tmp_nicks.length; i++) {
        tmp_match = tmp_nicks[i].toLowerCase().match("^"+last_word.toLowerCase(), 'gi');
        if(tmp_match != null) {
          finalMatch = tmp_nicks[i];
          finalMessage = finalMessage+" "+finalMatch;
          console.log("Replacing last word matching partial");
          break;
        }
      }
    }
  }
  if(finalMatch == "") {
    finalMatch = tmp_nicks[0];
    finalMessage = finalMessage+" "+finalMatch;
    console.log("Just tab pressed");
  }
  finalMessage = finalMessage.replace(/ +(?= )/g,'');
  finalMessage = finalMessage.trim()+" ";
  $("#text_input_"+loadAJAX["rid"]).val(finalMessage);
  $("#text_input_"+loadAJAX["rid"]).focus();
}

function clearChatContent(stream, welcome) {
  $("#"+stream).html($("#"+welcome).html()+"<br />");
}

function changeColor() {
  if(CRoom_Sett["userColor"] != pickcol) {
    lloading = 'inc=ajaxcr&do=changecolor&to='+pickcol+'&sid='+sid;
    $.ajax({
      url: "index.php", 
      data: lloading,
      dataType: "text",
      success: function() {
        showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolg!', 'Farbe gewechselt!');
        CRoom_Sett["userColor"] = pickcol;
        $('.text_input').css('border', "1px solid #"+pickcol);
        $('.sinsmi').css('color', "#"+pickcol);
      }
    });
  }
}

function addSmilie(smilie) {
  var rid = loadAJAX["rid"];
  var text = $("#text_input_"+rid).val();
  $("#text_input_"+rid).val(text+" "+smilie+" ");
  $("#text_input_"+rid).focus();
}

function basicSmilie(text) {
  /*
  text = text.replace(/0:\)/g, '<i class="fa icon-emo-saint fa-fw"></i>');
  text = text.replace(/:\)/g, '<i class="fa icon-emo-happy fa-fw"></i>');
  text = text.replace(/7-\(/g, '<i class="fa icon-emo-angry fa-fw"></i>');
  text = text.replace(/:\(/g, '<i class="fa icon-emo-unhappy fa-fw"></i>');
  text = text.replace(/;\(/g, '<i class="fa icon-emo-cry fa-fw"></i>');
  text = text.replace(/:\|/g, '<i class="fa icon-emo-sleep fa-fw"></i>');
  text = text.replace(/;\)/g, '<i class="fa icon-emo-wink fa-fw"></i>');
  text = text.replace(/;P/g, '<i class="fa icon-emo-wink2 fa-fw"></i>');
  text = text.replace(/;good/g, '<i class="fa icon-emo-thumbsup fa-fw" style="margin-left: -14px; width: 45px;"></i>');
  text = text.replace(/;evil/g, '<i class="fa icon-emo-devil fa-fw"></i>');
  text = text.replace(/:o/g, '<i class="fa icon-emo-surprised fa-fw"></i>');
  text = text.replace(/:P/g, '<i class="fa icon-emo-tongue fa-fw"></i>');
  text = text.replace(/;coffee/g, '<i class="fa icon-emo-coffee fa-fw" style="margin-left: -14px; width: 45px;"></i>');
  text = text.replace(/8-\)/g, '<i class="fa icon-emo-sunglasses fa-fw"></i>');
  text = text.replace(/x\)/g, '<i class="fa icon-emo-squint fa-fw"></i>');
  text = text.replace(/xD/g, '<i class="fa icon-emo-laugh fa-fw"></i>');
  text = text.replace(/;\//g, '<i class="fa icon-emo-displeased fa-fw"></i>');
  text = text.replace(/;beer/g, '<i class="fa icon-emo-beer fa-fw" style="margin-left: -14px; width: 45px;"></i>');
  text = text.replace(/;gun/g, '<i class="fa icon-emo-shoot fa-fw" style="margin-left: -14px; width: 45px;"></i>');
  text = text.replace(/:D/g, '<i class="fa icon-emo-grin fa-fw"></i>');
  return text; */
  return text;
}

function prepareButtons(room) {
  $( ".ccl button" ).button({
    showLabel: false
  });
  $( ".contChatTalkTo" ).selectmenu({
    position: { my: "left bottom", at: "left top", collision: "none" },
    width: 'auto',
    change: function(event, data) {
      sendToGroup = data.item.value;
    }
  });
  $( ".contChatFSize" ).selectmenu({
    position: { my: "left bottom", at: "left top", collision: "none" },
    width: 120,
    change: function( event, data ) {
      $( ".chatstream" ).css({'fontSize': data.item.value});
    }
  });
  $( ".ccl" ).controlgroup();
  $( ".ccl" ).find(".ui-icon-triangle-1-s").addClass("ui-icon-triangle-1-n").removeClass("ui-icon-triangle-1-s");
  $( "#teamchat_select-"+room+"-menu").addClass("ui-corner-top").removeClass("ui-corner-bottom");
  $( "#fontsize_select-"+room+"-menu").addClass("ui-corner-top").removeClass("ui-corner-bottom");
  $( ".modbutton" ).button({
    showLabel: false
  });
  $( ".clearbutton" ).button({
    showLabel: false
  });
  $( ".ccr" ).controlgroup();
  $( ".sendbutt" ).button();
}

function fixChatHeight() {
  chheight2 = $(window).height();
  chheight2 = chheight2-215;
  $('.chatstream').css({'height':chheight2});
}

$(window).resize(function() {
  fixChatHeight();
});

var twidth;

$(document).ready(function(){
  $( "body" ).delegate(".chat_min_ava_img", "click", function() {
    if ( $( this ).hasClass( "enlarged" ) ) {
      clearTimeout(minavaTimeout);
      $(".enlarged")
      .animate({
         maxWidth: "20px", 
         maxHeight: "20px"
      }, 'slow');
      $(".enlarged").removeClass("enlarged");
    } else {
      clearTimeout(minavaTimeout);
      $(".enlarged")
      .animate({
         maxWidth: "20px", 
         maxHeight: "20px"
      }, 'slow');
      $(".enlarged").removeClass("enlarged");
      minavaId = $(this).attr("id");
      $("#"+minavaId).addClass("enlarged");
      $("#"+minavaId).animate({
        maxWidth: "250px",
        maxHeight: "250px"
      }, 'slow', "linear", function() {
        minavaId = 'none';
        minavaTimeout = setTimeout(function () {
          $(".enlarged")
          .animate({
            maxWidth: "20px", 
            maxHeight: "20px"
          }, 'slow');
          $(".enlarged").removeClass("enlarged");
        }, 3000);
      });
    }
  });
  $(".chatstream").contextmenu({
    position: function(event, ui){
      return {my: "right top", at: "center", of: event, collision: "fit"};
    },
    delegate: ".chatcontentmenu",
    menu: [
      { title: "Profil&nbsp;öffnen", cmd: "profile", uiIcon: "fa fa-user fa-fw", action: function(event, ui) {
          loadProfile(cchuid, cchname);
        }
      },
      {title: "----", cmd: "prof"},
      { title: "Ansprechen", cmd: "talkto", uiIcon: "fa fa-comment-o fa-fw", action: function(event, ui) {
          $("#"+activePanel).find('.text_input').val('/to "'+cchname+'" ');
          $("#"+activePanel).find('.text_input').focus();
        }
      },
      { title: "Anflüstern", cmd: "whisp", uiIcon: "fa fa-commenting-o fa-fw", action: function(event, ui) {
          $("#"+activePanel).find('.text_input').val('/w "'+cchname+'" ');
          $("#"+activePanel).find('.text_input').focus();
        }
      },
      { title: "Privat&nbsp;schreiben&nbsp;", cmd: "priv", uiIcon: "fa fa-comments-o fa-fw", children: [
           { title: "Links", uiIcon: "fa fa-angle-double-left fa-fw", action: function(event, ui) {
                 loadBox('private', 'left', '&uid='+loadAJAX["uid"]+'&toid=0&open='+cchuid);
             }
           },
           { title: "Rechts", uiIcon: "fa fa-angle-double-right fa-fw", action: function(event, ui) {
                 loadBox('private', 'right', '&uid='+loadAJAX["uid"]+'&toid=0&open='+cchuid);
             }
           }
         ]
      },
      {title: "----", cmd: "first"},
      { title: "Melden", cmd: "report", uiIcon: "fa fa-exclamation-triangle fa-fw", action: function(event, ui) {
          alert("Copy " + ui.target.text());
        }
      },
    ],
    beforeOpen: function(event, ui) {
      cchuid = ui.target.attr("data-uid");
      cchname = ui.target.attr("data-name");
      $(".chatstream").contextmenu("setEntry", "profile", cchname+"'s&nbsp;Profil");
      if(cchuid == uid) {
        $(".chatstream").contextmenu("showEntry", "talkto", false);
        $(".chatstream").contextmenu("showEntry", "whisp", false);
        $(".chatstream").contextmenu("showEntry", "priv", false);


        $(".chatstream").contextmenu("showEntry", "report", false);
        $(".chatstream").contextmenu("showEntry", "first", false);
        $(".chatstream").contextmenu("showEntry", "prof", false);

      } else {
        $(".chatstream").contextmenu("showEntry", "talkto", true);
        $(".chatstream").contextmenu("showEntry", "whisp", true);
        $(".chatstream").contextmenu("showEntry", "priv", true);

        $(".chatstream").contextmenu("showEntry", "report", true);
        $(".chatstream").contextmenu("showEntry", "first", true);
        $(".chatstream").contextmenu("showEntry", "prof", true);
      }
    }
  });

  execute_ChatRoom(loadAJAX["rid"]);
  twidth = $('#text_input_div-'+loadAJAX["rid"]).outerWidth() - 120;
});

window.onfocus = function () {
  document.title = pageTitle;
  isActive = true;
};

window.onblur = function () {
  isActive = false;
};

function execute_ChatRoom(rid) {
  user_clock = CRoom_Sett["clock"];
  show_mini_avatar = CRoom_Sett["minava"];
  tfSet = CRoom_Sett["tfSet"];
  pickcol = CRoom_Sett["userColor"];
  userName = CRoom_Sett["userName"];
  userAlias = CRoom_Sett["userAlias"];
  fixChatHeight();
  prepareButtons(rid);
  $('#text_input_'+rid).css('width', twidth+'px');
  $('#text_input_'+rid).inputHistory({
    enter: function () { }
  });
  $('.ccbutton').colpick({
    layout:'hex',
    color: pickcol,
    submit:0,
    onChange:function(hsb,hex,rgb,el,bySetColor) {
      pickcol = hex;
    },
    onHide:function() {
      changeColor();
    },
    onShow: function (colorDiv,e) {
      var $colorDiv = $(colorDiv);
      var div = {
        top: parseInt($colorDiv.css('top'), 10),
        left: parseInt($colorDiv.css('left'), 10)
      };
      div.right = div.left + $colorDiv.outerWidth();
      div.bottom = div.top + $colorDiv.outerHeight();

      var $win = $(window);
      var viewport = {
        top: $win.scrollTop(),
        left: $win.scrollLeft()
      };
      viewport.right = viewport.left + $win.width();
      viewport.bottom = viewport.top + $win.height();

      if(div.bottom>viewport.bottom) {
        div.top = div.top - $colorDiv.outerHeight() - 23;
        $colorDiv.css('top',div.top+'px');
      }
      if(div.right>viewport.right) {
        div.left = div.left - $colorDiv.outerWidth();
        $colorDiv.css('left',div.left+'px');
      }
    }
  });
  if(user_clock == 0) {
    $('.clockbuttonicon').addClass('fa-calendar-times-o').removeClass('fa-calendar-check-o');
    $('.timestamp').hide();
  } else {
    $('.clockbuttonicon').addClass('fa-calendar-check-o').removeClass('fa-calendar-times-o');
    $('.timestamp').show();
  }

  if(show_mini_avatar == '1') {
    $('.minavabuttonicon').addClass('fa-user').removeClass('fa-user-times');
    $('.chat_min_avatar').show();
  } else {
    $('.minavabuttonicon').addClass('fa-user-times').removeClass('fa-user');
    $('.chat_min_avatar').hide();
  } 

  if(tfSet == '1') {
    $('.tfbuttonicon').addClass('fa-underline').removeClass('fa-font');
  } else {
    $('.tfbuttonicon').addClass('fa-font').removeClass('fa-underline');
  } 

  if(playSound == true) {
    $('.psbuttonicon').addClass('fa-bell-o').removeClass('fa-bell-slash-o');
  } else {
    $('.psbuttonicon').addClass('fa-bell-slash-o').removeClass('fa-bell-o');
  } 
  
  smilieBoxDialog = $( "#smiliebox-"+rid ).dialog({
    autoOpen: false,
    resizable: true
  });
  
  var showRules = $( "#chatroomholder-"+rid ).attr("data-rules");
  if(showRules == '1') {
    $( "#rulesbox-"+rid ).dialog({
      autoOpen: true,
      dialogClass: "noclose",
      modal: true,
      buttons: [{
        text: "Ok",
        "id": "ButtonCHATRA",
        click: function () {
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonCHATRD",
        click: function() {
          $( this ).dialog( "close" );
          var panelId = "room_"+rid;
          lloading = 'inc=ajaxcr&do=leaveroom&rid='+rid+'&sid='+sid;
          $.ajax({
            url: "index.php", 
            data: lloading,
            dataType: "text"
          });
          $( "li[aria-controls='"+panelId+"']" ).remove();
          $( "#" + panelId ).remove();
          tabs.tabs( "refresh" );
        }
      }],
        close: function() {
          $( this ).dialog( "close" );
        }
    });
    $('#ButtonCHATRA').html("Annehmen");
    $('#ButtonCHATRD').html("Ablehnen");
  }
  
  if(onlineBoxDialog == '') {
    OSDis = true;
    onlineBoxDialog = $( "#onlinestatusbox-"+rid ).dialog({
      autoOpen: false,
      resizable: false,
      height:85,
    });
    $('#ostatus1').button({
      showLabel: false
    });
    $('#ostatus2').button({
      showLabel: false
    });
    $('#ostatus3').button({
      showLabel: false
    });
    $('#ostatus4').button({
      disabled: OSDis,
      showLabel: false
    });
    $( "#onlinebuttons" ).controlgroup();
  } else {
    $( "#onlinestatusbox-"+rid ).remove();
  }
}