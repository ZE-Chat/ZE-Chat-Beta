function changeEPMainText() {
  $("#ep_main_content").sync();
  var str = 'inc=editprofile&area=main&dont=1&do=changemain&sid='+sid+'&'+$("#ep_main_form").serialize();
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Dein Profiltext wurde aktualisiert!');
      reloadTab(activePanel);
    }
  });
}

function insertImage(link) {
  var url = window.location.origin+'/files/userpic/'+link;
  $('#ep_main_content').insertAtCursor('<img src="'+url+'" />');
}

function execute_epMain() {
  makeBBCEditor("ep_main_content", "bold,italic,underline,|,img,link,|,bullist,|,fontcolor,fontsize,|,justifyleft,justifycenter,justifyright,|,quote,removeFormat");
  $("#ep_main_sub").button();  
}

$(document).ready(function(){
  execute_epMain();
});