function epChangeSett(id) {
  var str = 'inc=editprofile&area=sett&dont=1&do=change&sid='+sid+'&'+$("#"+id).serialize();
  var doit = true;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }

  if(id == 'ep_sett_4') {
    var passwd1 = $("#sett_input_4_1").val();
    var passwd2 = $("#sett_input_4_2").val();
    if(passwd1 != passwd2 || passwd1 == '') {
      doit = false;
    }
  }

  if(id == 'ep_sett_5') {
    var email1 = $("#sett_input_5_1").val();
    var email2 = $("#sett_input_5_2").val();
    if(email1 != email2 || email1 == '') {
      doit = false;
    }
  }

  if(doit == true) {
    $.ajax({
      url: "index.php", 
      data: str,
      dataType: "text",
      method: "POST",
      success: function() {
        showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Einstellungen wurden übernommen!');
        reloadTab(activePanel);
      }
    });
  } else {
    if(id == 'ep_sett_4') {
      showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Die Passwörter stimmen nicht überein oder sind leer!');
    }
    if(id == 'ep_sett_5') {
      showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Die E-Mail-Adressen stimmen nicht überein oder sind leer!');
    }
  }
}

function execute_epSett() {
  $('.epsettbutton').button({
    showLabel: false
  });
  $('.pdform').submit(function(e){
        e.preventDefault();
  });
}

$(document).ready(function(){
  execute_epSett();
});