//Dialog holder "ItemDelete"
//Object
var eppDeleteDialog = '';

//Dialog holder "ItemSend"
//Object
var eppSendDialog = '';

//ItemID 
//Int
var itemID;

//ItemName 
//varChar
var itemName;

function pdel(pid) {
  itemID = pid;
  eppDeleteDialog.dialog("open");
}

function performDelete() {
  var str = 'inc=editprofile&area=present&dont=1&do=delitem&sid='+sid+'&iid='+itemID;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gegenstand wurde gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function psend(pid, iname) {
  itemID = pid;
  itemName = iname;
  $( "#ep_item_send_name_holder" ).html(iname);
  eppSendDialog.dialog("open");
}

function performSend() {
  var str = 'inc=editprofile&area=present&dont=1&do=senditem&sid='+sid+'&iid='+itemID+'&'+$("#itemsendform").serialize();
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-gift fa-lg', 'Erfolgreich!', itemName+' verschenkt!');
      reloadTab(activePanel);
    }
  });
}

function acceptItem(iid) {
  var str = 'inc=editprofile&area=present&dont=1&do=acceptitem&sid='+sid+'&iid='+iid;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Geschenk wurde angenommen!');
      reloadTab(activePanel);
    }
  });
}

function abortItem(iid) {
  var str = 'inc=editprofile&area=present&dont=1&do=abortitem&sid='+sid+'&iid='+iid;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Geschenk wurde zurückgezogen!');
      reloadTab(activePanel);
    }
  });
}

function denyItem(iid) {
  var str = 'inc=editprofile&area=present&dont=1&do=denyitem&sid='+sid+'&iid='+iid;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Geschenk wurde abgelehnt!');
      reloadTab(activePanel);
    }
  });
}

function filterTrans(filter) {
  if(filter != 'all') {
    $('.data-itemstate:not(:icontains('+ filter +'))').closest("div").hide(); 
    $('.data-itemstate:icontains('+ filter +')').closest("div").show(); 
  } else {
    $('.transitem').show();
  }
}

function execute_epPresent() {
  $( ".presbuttons button" ).button({
    showLabel: false
  });
  $( ".presbuttons" ).controlgroup();
  $( "#epitemfiltersettings" ).selectmenu({
    change: function(event, data) {
      filterTrans(data.item.value);
    }
  });

  eppDeleteDialog = $( "#ep_item_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:150,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPITEMD",
        click: function () {
          performDelete();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonEPITEMD').html("Löschen");
  $('#ButtonEPCANCEL1').html("Abbrechen");

  eppSendDialog = $( "#ep_item_sender" ).dialog({
    autoOpen: false,
    resizable: false,
    height:300,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPITEMS",
        click: function () {
          performSend();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonEPITEMD').html("Verschenken");
  $('#ButtonEPCANCEL1').html("Abbrechen");

  $( "#iatinput" ).autocomplete({
      minLength: 0,
      source: epItemAC,
      focus: function( event, ui ) {
        $( "#iatinput" ).val( ui.item.label );
        return false;
      },
      select: function( event, ui ) {
        $( "#iatinput" ).val( ui.item.label );
        $( "#iat" ).val( ui.item.value );
        return false;
      }
    })
    .autocomplete( "instance" )._renderItem = function( ul, item ) {
      return $( "<li>" )
        .append( '<a><b>' + item.label + '</b><br><span style="font-size: 80%;">' + item.desc + '</span></a>' )
        .appendTo( ul );
    };
}

$(document).ready(function(){
  execute_epPresent();
});