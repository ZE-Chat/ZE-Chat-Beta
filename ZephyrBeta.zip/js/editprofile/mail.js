//Dialog holder "MailDelete"
//Object
var epMailDeleteDialog = '';

//Dialog holder "GBCreate"
//Object
var epMailCreateDialog = '';

//Percent of ScreenWidth for Dialoge's
//Int
var pDiaWidth = '';
var pDiaHeight = '';

var deleteMailId = '';

function insertMailImage(link) {
  var url = window.location.origin+'/files/userpic/'+link;
  $('#wpmail_content').insertAtCursor('<img src="'+url+'" />');
}

function openDeleteMail(id) {
  deleteMailId = id;
  epMailDeleteDialog.dialog( "open" );
}

function delMail() {
  var str = 'inc=editprofile&area=mail&dont=1&do=delmail&sid='+sid+'&mailid='+deleteMailId;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Mail wurde gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function openSendMail(mailId, subject, sendto, sendtoId) {
  $( "#atinput" ).val( sendto );
  $( "#at" ).val( sendtoId );
  $( "#subject" ).val( subject );
  if(mailId != '') { openMail(mailId, 2); }
  epMailCreateDialog.dialog( "open" );
}

function sendMail() {
  $("#wpmail_content").sync();
  var str = 'inc=editprofile&area=mail&dont=1&do=sendmail&sid='+sid+'&'+$("#wepmail").serialize();
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-paper-plane-o fa-lg', 'Erfolgreich!', 'Mail wurde versandt!');
      reloadTab(activePanel);
    }
  });
}

function openMail(id, mode) {
  var str = 'inc=editprofile&area=mail&dont=1&do=getmail&sid='+sid+'&mailid='+id;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "json",
    method: "POST",
    success: function(data) {
      if(mode == 1) {
        var showMail = $('<div id="mail_'+data.id+'"><p id="mail_text_'+data.id+'">'+data.text+'</p></div>');
        showMail.dialog({ title: '', width: pDiaWidth, height: pDiaHeight, close: function( event, ui ) { $( this ).dialog('destroy').remove(); }}).parent().find('.ui-dialog-title').html('<span><i class="fa fa-paper-plane-o fa-lg fa-fw"></i>&nbsp;'+data.subject+'</span>');
        var test = $("#mail_text_"+data.id).text();
        var resulter = XBBCODE.process({
          text: test,
          removeMisalignedTags: false,
          addInLineBreaks: true
        });
        $("#mail_text_"+data.id).html(resulter.html.trim());
        var imgW = pDiaWidth-100;
        $("#mail_text_"+data.id+" > img").css("max-width", imgW+"px");
        var imgH = pDiaHeight-100;
        $("#mail_text_"+data.id+" > img").css("max-height", imgH+"px");
        $("#mailstate_"+data.id).removeClass("fa-folder-o").addClass("fa-folder-open-o");
      } else {
        $("#wpmail_content").next().html("");
        $("#wpmail_content").html("");
        $('#wpmail_content').insertAtCursor('[quote]'+data.text+'[/quote]');
        var test = $("#wpmail_content").next().text();
        var resulter = XBBCODE.process({
          text: test,
          removeMisalignedTags: false,
          addInLineBreaks: true
        });
        $("#wpmail_content").next().html(resulter.html);
        $("#mailstate_"+data.id).removeClass("fa-folder-o").addClass("fa-folder-open-o");
      }
    }
  });
}

function execute_epMail() {
  makeBBCEditor("wpmail_content", "bold,italic,underline,|,img,link,|,bullist,|,fontcolor,fontsize,|,justifyleft,justifycenter,justifyright,|,quote,removeFormat");

  $( ".mailbuttonset button" ).button({
    showLabel: false
  });

  $( ".mailbuttonset" ).controlgroup();

  epMailDeleteDialog = $( "#ep_mail_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:160,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPMAILD",
        click: function () {
          delMail();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANEL",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonEPMAILD').html("Löschen");
  $('#ButtonEPCANCEL').html("Abbrechen");
  
  pDiaWidth = $(window).width() * .60;
  pDiaHeight = $(window).height() * .80;
  
  epMailCreateDialog = $( "#ep_mail_sender" ).dialog({
    minWidth: pDiaWidth,
    height: pDiaHeight,
    maxHeight: pDiaHeight,
    autoOpen: false,
    modal: false,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPMAILS",
        click: function () {
          sendMail();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonEPMAILS').html("Senden");
  $('#ButtonEPCANCEL1').html("Abbrechen");

  formPGB = epMailCreateDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    sendMail();
  });
  
  $("#ep_mail_sub").button();
  
  $( "#mailaccordion" ).has( "h3" ).accordion({
    heightStyle: "content",
    collapsible: true,
    active: false,
    activate: function( event, ui ) {
      if(ui.newHeader.length>0){
        var srcObj = $(ui.newHeader[0]).children('span').children('i');
        var state = srcObj.attr('data-state');
        if(state == "new") {
          var mailid = srcObj.attr('data-mailid');
          var str = 'inc=editprofile&area=mail&dont=1&do=getmail&sid='+sid+'&mailid='+mailid;
          $.ajax({
            url: "index.php", 
            data: str,
            dataType: "JSON",
            method: "POST",
            success: function() {
              srcObj.attr("title", "Gelesen");
              srcObj.addClass("fa-envelope-open-o").removeClass("fa-envelope-o");
              srcObj.attr("data-state", "old");
            }
          });
        }
      }
    }
  });
  
  $(".mailtext").each(function( index ) {
    var test = $(this).text();
    var resulter = XBBCODE.process({
      text: test,
      removeMisalignedTags: false,
      addInLineBreaks: true
    });
    $(this).html(resulter.html.trim());
  });
  
  $( "#atinput" ).autocomplete({
      minLength: 0,
      source: epMailAC,
      focus: function( event, ui ) {
        $( "#atinput" ).val( ui.item.label );
        return false;
      },
      select: function( event, ui ) {
        $( "#atinput" ).val( ui.item.label );
        $( "#at" ).val( ui.item.value );
        return false;
      }
    })
    .autocomplete( "instance" )._renderItem = function( ul, item ) {
      return $( "<li>" )
        .append( '<a><b>' + item.label + '</b><br><span style="font-size: 80%;">' + item.desc + '</span></a>' )
        .appendTo( ul );
    };
}

$(document).ready(function(){
  execute_epMail();
});