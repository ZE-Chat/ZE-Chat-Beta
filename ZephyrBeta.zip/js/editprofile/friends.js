function fao(fid) {
  var str = 'inc=editprofile&area=friends&dont=1&do=accepto&sid='+sid+'&fid='+fid;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Ihr seid jetzt öffentlich befreundet!');
      reloadTab(activePanel);
    }
  });
}

function fap(fid) {
  var str = 'inc=editprofile&area=friends&dont=1&do=acceptp&sid='+sid+'&fid='+fid;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Ihr seid jetzt privat befreundet!');
      reloadTab(activePanel);
    }
  });
}

function fad(fid) {
  var str = 'inc=editprofile&area=friends&dont=1&do=deny&sid='+sid+'&fid='+fid;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Freundschaft abgelehnt!');
      reloadTab(activePanel);
    }
  });
}

function fchange(fid, mode) {
  var str = 'inc=editprofile&area=friends&dont=1&do=change&sid='+sid+'&fid='+fid+'&mode='+mode;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      if(mode == 3) {
        showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Eure Freunschaft ist jetzt öffentlich!');
      } else {
        showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Eure Freunschaft ist jetzt privat!');
      }
      reloadTab(activePanel);
    }
  });
}

function fd(fid) {
  var str = 'inc=editprofile&area=friends&dont=1&do=delete&sid='+sid+'&fid='+fid;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Ihr seid jetzt keine Freunde mehr!');
      reloadTab(activePanel);
    }
  });
}

function execute_epFriends() {
  $('.friendbuttonset button').button({
    showLabel: false
  });
  $( ".friendbuttonset" ).controlgroup();
  $('.friendform').submit(function(e){
        e.preventDefault();
  });
}

$(document).ready(function(){
  execute_epFriends();
});