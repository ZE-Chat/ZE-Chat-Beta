//Dialog holder "GBDelete"
//Object
var epgbDeleteDialog = '';

//Dialog holder "GBPrivatise"
//Object
var epgbPrivateDialog = '';

//GBID 
//Int
var epgbId = '';

function delGB() {
  var str = 'inc=editprofile&area=gb&dont=1&do=delgb&sid='+sid+'&gid='+epgbId;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gästebucheintrag wurde gelöscht!');
      reloadTab(activePanel);
    }
  });
}

function privGB() {
  var str = 'inc=editprofile&area=gb&dont=1&do=privgb&sid='+sid+'&gid='+epgbId;
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Gästebucheintrag wurde privatisiert!');
      reloadTab(activePanel);
    }
  });
}

function execute_epGB() {
  $( "#ep_gb_holder" ).delegate( "span.fa-times-circle", "click", function() {
    epgbId = $(this).attr("data-gid");
    epgbDeleteDialog.dialog("open");
  });
  
  $( "#ep_gb_holder" ).delegate( "span.fa-unlock-alt", "click", function() {
    epgbId = $(this).attr("data-gid");
    epgbPrivateDialog.dialog("open");
  });
  
  $(".gbtext").each(function( index ) {
    var test = $(this).text();
    var resulter = XBBCODE.process({
      text: test,
      removeMisalignedTags: false,
      addInLineBreaks: true
    });
    $(this).html(resulter.html.trim());
  });
  
  epgbDeleteDialog = $( "#ep_gb_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:150,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPGBD",
        click: function () {
          delGB();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonEPGBD').html("Löschen");
  $('#ButtonEPCANCEL1').html("Abbrechen");
  
  epgbPrivateDialog = $( "#ep_gb_privater" ).dialog({
    autoOpen: false,
    resizable: false,
    height:180,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPGBP",
        click: function () {
          privGB();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonEPGBP').html("Privatisieren");
  $('#ButtonEPCANCEL2').html("Abbrechen");
}

$(document).ready(function(){
  execute_epGB();
});