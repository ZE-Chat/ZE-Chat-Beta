var epForm = '';

function epChangePD(id) {
  var str = 'inc=editprofile&area=pd&dont=1&do=change&sid='+sid+'&'+$("#"+id).serialize();
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Steckbrief wurde aktualisiert!');
      reloadTab(activePanel);
    }
  });
}

function execute_epPD() {
  $('.pdbutton').button({
    showLabel: false
  });
  $('.pdform').submit(function(e){
        e.preventDefault();
  });
}

$(document).ready(function(){
  execute_epPD();
});