//Dialog holder "AvaCreate"
//Object
var avaCreateDialog = '';

//Dialog holder "AvaEdit"
//Object
var avaEditDialog = '';

//AvaID to delete
//Int
var avaDeleteId = '';

//Dialog holder "AvaDelete"
//Object
var avaDeleteDialog = '';

//--------------Create Ava-----------------

function createAva() {
  if(!(/\.(gif|jpg|jpeg|tiff|png)$/i).test($('#EPCava').val())) {
    showNotify('error', 'fa fa-exclamation-circle fa-lg', 'Fehler!', 'Dateityp nicht erlaubt!<br />Verwende gif, png, jpg oder jpeg!');
  } else {
    var str = $('#epavacreate').serializefiles();
    str.append('inc', 'editprofile');
    str.append('area', 'ava');
    str.append('dont', '1');
    str.append('do', 'createAva');
    str.append('sid', sid);
    if(epAdmin != false) {
      str.append('acp', epAdmin);
    }
    $.ajax({
      url: "index.php", 
      data: str,
      cache: false,
      contentType: false,
      processData: false,
      type: "POST",
      dataType: "text",
      success: function() {
        showNotify('success', 'fa fa-check-circle fa-lg', 'Jau!', 'Geht');
        avaCreateDialog.dialog( "close" );
        refreshOpen();
      }
    });
  }
}

//--------------Edit News-----------------

function openEditAva(aid) {
  lloading = 'inc=editprofile&area=ava&dont=1&do=getava&aid='+aid+'&sid='+sid;
  if(epAdmin != false) {
    lloading += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "json",
    success: function(data) {
      $("#ep_aid").val(aid);
      $("#EPEdesc").val(data.ava_desc);
      switch(data.ava_usk) {
        case '0':
          $("#EPEusk").html('<option value="0" style="checked">0 Jahre</option><option value="12">12 Jahre</option><option value="16">16 Jahre</option><option value="18">18 Jahre</option>');
          break;
        case '12':
          $("#EPEusk").html('<option value="12" style="checked">12 Jahre</option><option value="0">0 Jahre</option><option value="16">16 Jahre</option><option value="18">18 Jahre</option>');
          break;
        case '16':
          $("#EPEusk").html('<option value="16" style="checked">16 Jahre</option><option value="0">0 Jahre</option><option value="12">12 Jahre</option><option value="18">18 Jahre</option>');
          break;
        case '18':
          $("#EPEusk").html('<option value="18" style="checked">18 Jahre</option><option value="0">0 Jahre</option><option value="12">12 Jahre</option><option value="16">16 Jahre</option>');
          break;
      }
      if(data.ava_priv == '0') {
        $("#EPEpriv").html('<option value="0" style="checked">Öffentlich</option><option value="1">Privat</option>');
      } else {
        $("#EPEpriv").html('<option value="1" style="checked">Privat</option><option value="0">Öffentlich</option>');
      }
      if(data.ava_main == '0') {
        $("#EPEmain").html('<option value="0" style="checked">Nein</option><option value="1">Ja</option>');
      } else {
        $("#EPEmain").html('<option value="1" style="checked">Ja</option><option value="0">Nein</option>');
      }
      avaEditDialog.dialog("open");
    }
  });
}

function editAva() {
  var str = 'inc=editprofile&area=ava&dont=1&do=editava&sid='+sid+'&'+$("#epavaedit").serialize();
  if(epAdmin != false) {
    str += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: str,
    dataType: "text",
    method: "POST",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Avatar wurde bearbeitet!');
      avaEditDialog.dialog( "close" );
      refreshOpen();
    }
  });
}

//--------------Delete Ava-----------------

function delAva() {
  lloading = 'inc=editprofile&area=ava&dont=1&do=deleteAva&aid='+avaDeleteId+'&sid='+sid;
  if(epAdmin != false) {
    lloading += '&acp='+epAdmin;
  }
  $.ajax({
    url: "index.php", 
    data: lloading,
    dataType: "text",
    success: function() {
      showNotify('success', 'fa fa-check-circle fa-lg', 'Erfolgreich!', 'Avatar wurde gelöscht!');
      avaDeleteDialog.dialog( "close" );
      refreshOpen();
    }
  });
}
function askDelAva(aid) {
  avaDeleteId = aid;
  avaDeleteDialog.dialog( "open" );
}

//-------------------------------------------------------------------------
//---------------------Initiate JavaScript Functionality-------------------
//-------------------------------------------------------------------------

function execute_epAva() {
  $('.acp_ava_edit').button({
    showLabel: false
  });
  $('.acp_ava_del').button({
    showLabel: false
  });
  $( "#acpmainava" ).controlgroup();
  $('#acp_ava_create').button();
  $( ".avabuttons" ).controlgroup();
  
  avaCreateDialog = $( "#ep_ava_creator" ).dialog({
    autoOpen: false,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPAVAC",
        click: function () {
          createAva();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANCEL1",
        click: function() {
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      epAvaForm[ 0 ].reset();
    }
  });
  $('#ButtonEPAVAC').html("Hochladen");
  $('#ButtonEPCANCEL1').html("Abbrechen");

  epAvaForm = avaCreateDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    createAva();
  });
  
  $( "#ep_ava_create" ).button().on( "click", function() {
    avaCreateDialog.dialog( "open" );
  });
  
  avaEditDialog = $( "#ep_ava_editor" ).dialog({
    autoOpen: false,
    modal: false,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPAVAE",
        click: function () {
          editAva();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANCEL2",
        click: function() {
          $( this ).dialog( "close" );
        }
      }],
    close: function() {
      epAvaForm2[ 0 ].reset();
    }
  });
  $('#ButtonEPAVAE').html("Anpassen");
  $('#ButtonEPCANCEL2').html("Abbrechen");

  epAvaForm2 = avaEditDialog.find( "form" ).on( "submit", function( event ) {
    event.preventDefault();
    editAva();
  });
  
  avaDeleteDialog = $( "#ep_ava_deleter" ).dialog({
    autoOpen: false,
    resizable: false,
    height:140,
    modal: true,
    buttons: [{
        text: "Ok",
        "id": "ButtonEPAVAD",
        click: function () {
          delAva();
          $( this ).dialog( "close" );
        }
      }, {
        text: "Cancel",
        "id": "ButtonEPCANCEL3",
        click: function() {
          $( this ).dialog( "close" );
        }
      }]
  });
  $('#ButtonEPAVAD').html("Löschen");
  $('#ButtonEPCANCEL2').html("Abbrechen");
}

$(document).ready(function(){
  execute_epAva();
});