<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015-2017
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015-2017
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

ini_set('display_errors',1);
error_reporting(E_ALL);

//Setting Header Information
header("Content-Type: text/html; charset=utf-8");
date_default_timezone_set('Europe/Berlin');

//Define install Path

define("ZE_PATH", realpath(dirname(__FILE__)));

require_once './main/check.main.php';

$TPL_DONT = 1;
$ZE_INFO = '';
$activatemess = false;

//        Including correct inc file
switch(ZE_INC){
  case 'loginbox':
    $TPL_DONT = 0;
    $TPL = 'login';
    require_once './inc/loginbox.inc.php';
    break;
  case 'itembox':
    $TPL_DONT = 0;
    $TPL = 'itembox';
    require_once './inc/itembox.inc.php';
    break;
  case 'guestbox':
    $TPL_DONT = 0;
    $TPL = 'guest';
    require_once './inc/guestbox.inc.php';
    break;
  case 'lostpwbox':
    $TPL_DONT = 0;
    $TPL = 'lostpwbox';
    require_once './inc/lostpwbox.inc.php';
    break;
  case 'roomcreatebox':
    $TPL_DONT = 0;
    $TPL = 'roomcreatebox';
    require_once './inc/roomcreatebox.inc.php';
    break;
  case 'userlistbox':
    $TPL_DONT = 0;
    $TPL = 'userlist';
    require_once './inc/userlist.inc.php';
    break;
  case 'smilies':
    $TPL_DONT = 0;
    $TPL = 'smilies';
    require_once './inc/smilies.inc.php';
    break;
  case 'radiobox':
    $TPL_DONT = 0;
    $TPL = 'radiobox';
    require_once './inc/radiobox.inc.php';
    break;
  case 'onlinelist':
    $TPL_DONT = 0;
    $TPL = 'onlinelist';
    require_once './inc/onlinelist.inc.php';
    break;
  case 'private':
    $TPL_DONT = 0;
    $TPL = 'private';
    require_once './inc/private.inc.php';
    break;
  case 'navigation':
    $TPL_DONT = 0;
    $TPL = 'navigation';
    require_once './inc/navigation.inc.php';
    break;
  case 'updater':
    $TPL_DONT = 1;
    require_once './ajax/updater.ajax.php';
    break;
  case 'ajaxprofile':
    $TPL_DONT = 1;
    require_once './ajax/profile.ajax.php';
    break;
  case 'ajaxshop':
    $TPL_DONT = 1;
    require_once './ajax/shop.ajax.php';
    break;
  case 'ajaxsmilie':
    $TPL_DONT = 1;
    require_once './ajax/smilies.ajax.php';
    break;
  case 'croomajax':
    $TPL_DONT = 1;
    require_once './ajax/croom.ajax.php';
    break;
  case 'doreport':
    $TPL_DONT = 1;
    require_once './ajax/doReport.ajax.php';
    break;
  case 'getreports':
    $TPL_DONT = 1;
    require_once './ajax/getreport.ajax.php';
    break;
  case 'getopenava':
    $TPL_DONT = 1;
    require_once './ajax/getopenava.ajax.php';
    break;
  case 'userbar':
    $TPL_DONT = 0;
    $TPL = 'userbar';
    require_once './inc/userbar.inc.php';
    break;
  case 'roomlist':
    $TPL_DONT = 0;
    $TPL = 'roomlist';
    require_once './inc/roomlist.inc.php';
    break;
  case 'acp':
    $TPL_DONT = 0;
    $TPL = 'main';
    require_once './inc/admin/main.adm.php';
    break;
  case 'overview':
    $TPL_DONT = 0;
    $TPL = 'overview';
    require_once './inc/overview.inc.php';
    break;
  case 'editprofile':
    require_once './inc/editprofile.inc.php';
    break;
  case 'admin':
    require_once './inc/admin/acphub.adm.php';
    break;
  case 'registerbox':
    $TPL_DONT = 0;
    $TPL = 'registerbox';
    require_once './inc/registerbox.inc.php';
    break;
  case 'reportbox':
    $TPL_DONT = 0;
    $TPL = 'reportbox';
    require_once './inc/reportbox.inc.php';
    break;
  case 'adduserbox':
    $TPL_DONT = 0;
    $TPL = 'adduserbox';
    require_once './inc/adduserbox.inc.php';
    break;
  case 'deletenickbox':
    $TPL_DONT = 0;
    $TPL = 'deletenickbox';
    require_once './inc/deletenickbox.inc.php';
    break;
  case 'profile':
    $TPL_DONT = 0;
    $TPL = 'profile';
    require_once './inc/profile.inc.php';
    break;
  case 'dologin':
    $TPL_DONT = 1;
    require_once './ajax/dologin.ajax.php';
    break;
  case 'doLogout':
    $TPL_DONT = 1;
    require_once './ajax/doLogout.ajax.php';
    break;
  case 'doadduser':
    $TPL_DONT = 1;
    require_once './ajax/doadduser.ajax.php';
    break;
  case 'donamechange':
    $TPL_DONT = 1;
    require_once './ajax/donamechange.ajax.php';
    break;
  case 'dodeletenick':
    $TPL_DONT = 1;
    require_once './ajax/dodeletenick.ajax.php';
    break;
  case 'sendmess':
    $TPL_DONT = 1;
    require_once './ajax/messages/sendmess.ajax.php';
    break;
  case 'setup':
    require_once './install/setup.php';
    break;
  case 'doregister':
    $TPL_DONT = 1;
    require_once './ajax/doregister.ajax.php';
    break;
  case 'dolostpw':
    $TPL_DONT = 1;
    require_once './ajax/dolostpw.ajax.php';
    break;
  case 'ajaxcr':
    $TPL_DONT = 1;
    require_once './ajax/chatroom.ajax.php';
    break;
  case 'initChatRoom':
    $TPL_DONT = 1;
    $TPL = 'chatroom';
    require_once './inc/initChatRoom.inc.php';
    break;
  case 'news':
    $TPL_DONT = 0;
    $TPL = 'news';
    require_once './inc/news.inc.php';
    break;
  case 'shop':
    $TPL_DONT = 0;
    $TPL = 'shop';
    require_once './inc/shop.inc.php';
    break;
  case 'activate':
    require_once './inc/activate.inc.php';
    $inc = '';
    $activatemess = true;
  default:
    $TPL_DONT = 0;
    $TPL = 'frontpage';
    require_once './inc/frontpage.inc.php';
    require_once './inc/onlinelist.inc.php';
    require_once './inc/loginbox.inc.php';
    require_once './inc/news.inc.php';
    break;
}

if($TPL_DONT == 0 && ZE_INC != 'setup') {
  if(!isset($ZE_USER)) {
    require_once './class/user.class.php';
    $ZE_USER = new user($db);
  }
  $ZE_USER->cleanUpGuests($ZE_SETTINGS->getGuestRank());
  $ZE_TPL->draw($TPL);
}

if(ZE_INC != 'setup') {
  mysqli_close($db);
}

?>