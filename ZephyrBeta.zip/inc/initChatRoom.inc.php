<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Initiate Zephyr Parser
require_once './class/zephyr.class.php';
$tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/';
zephyr::configure("base_url", NULL );
zephyr::configure("tpl_dir", $tpl_path );
zephyr::configure("cache_dir", "cache/" );
zephyr::configure("path_replace", false);
$ZE_TPL = new zephyr;

if(isset($_GET["uid"])) {
  $uid = htmlspecialchars($_GET["uid"]);
  } elseif(isset($_POST["uid"])) {
    $uid = htmlspecialchars($_POST["uid"]);
  } else {
  $uid = '';
}

if(isset($_GET["rid"])) {
  $rid = htmlspecialchars($_GET["rid"]);
  } elseif(isset($_POST["rid"])) {
    $rid = htmlspecialchars($_POST["rid"]);
  } else {
  $rid = '';
}

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include AvatarClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

//Include RoomClass
require_once './class/rooms.class.php';
$ZE_ROOMSEL = new room($db);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include MessageClass
require_once './class/message.class.php';
$ZE_MESS = new message($db);

$ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
$ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
$ZE_user_color = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_color');
$ZE_user_gender = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_gender');
$ZE_userage = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_age');
$forced = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_global_forced_room');
$ZE_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_global_warns');
$ZE_username = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
$ZE_minava = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_min_ava');
$ZE_tf = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_tf_switch');
$ZE_useralias = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_alias');
$ZE_SID = $ZE_SESS->getInfo('sess_user_id', $uid, 'sess_id');
$ZE_avatar = $ZE_AVA->getMainAva($uid);
$ZE_avatar = $ZE_avatar["ava_link"];
$ucs = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_clock_switch');

$roomdata = $ZE_ROOMSEL->getRoom($rid);

if($roomdata[0]["room_owner_id"] == $uid) {
  $owner = 1;
} else {
  $owner = 0;
}

$found = 0;
$query =
  mysqli_query($db, "SELECT `sr_uname` FROM `".ZE_PRE."_session_room` WHERE `sr_rid` = '$rid' AND `sr_uid` = '$uid'")
    OR die("Error: <br>".mysqli_error($db));
while($row = mysqli_fetch_object($query)){
  $found = 1;
}
mysqli_free_result($query);

$delete = "DELETE FROM `".ZE_PRE."_session_room` WHERE `sr_uid` = '$uid' AND `sr_rid` = '$rid'";
$do_it = mysqli_query($db, $delete);

$ZE_SESS->createSR($ZE_SID, $uid, $ZE_username, $rid, $owner, $forced, $ZE_user_color, $ZE_user_gender, $ZE_user_lvl, $ZE_avatar, $ZE_userage);

if($found == 0) {
  $message = '"'.$ZE_username.'" hat den Raum betreten!';
  if($ZE_account_id < 2000) {
    $message = "Gast ".$message;
  }
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          $rid,
                          '0',
                          '0',
                          '0',
                          '0',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $message,
                          'content',
                          '0');
  if($ZE_warns > 0) {

  }
} else {
//  $message = '"'.$ZE_username.'" hat den Raum aktualisiert!';
}

$now = time();
$ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_last_message_got', $now);
$ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_last_message_id', $ZE_MESS->getLastID());

$roomwel = $roomdata[0]["room_welcome"];
$roomwelcome = preg_replace('~\[UNAME\]~', $ZE_username, $roomwel);
$changer = 'link';
$roomwelcome = link2click($roomwelcome);

if($ZE_userage < 18) {
  $allow18 = false;
} else {
  $allow18 = true;
}

$allow_mava = $ZE_SETTINGS->cP('chat_miniava', $uid, $ZE_user_lvl);
if($allow_mava == false) {
  $ZE_minava = 0;
}

$allow_tf = $ZE_SETTINGS->cP('chat_tf', $uid, $ZE_user_lvl);
if($allow_tf == false) {
  $ZE_tf = 0;
}

$ZE_TPL->assign("ZE_SID", $ZE_SID);
$ZE_TPL->assign("ZE_UID", $uid);
$ZE_TPL->assign("ZE_RID", $rid);
$ZE_TPL->assign("ZE_UNAME", $ZE_username);
$ZE_TPL->assign("ZE_UALIAS", $ZE_useralias);
$ZE_TPL->assign("ZE_UCOL", $ZE_user_color);
$ZE_TPL->assign("ZE_RWELCOME", $roomwelcome);
$ZE_TPL->assign("ZE_RNAME", $roomdata[0]["room_name"]);
$ZE_TPL->assign("ZE_RBG", $roomdata[0]["room_bg"]);
$ZE_TPL->assign("ZE_RCOL", $roomdata[0]["room_color"]);
$ZE_TPL->assign("ZE_RIMG", $roomdata[0]["room_image"]);
$ZE_TPL->assign("ZE_RTOPIC", $roomdata[0]["room_topic"]);
$ZE_TPL->assign("ZE_RSR", $roomdata[0]["room_show_rules"]);
$ZE_TPL->assign("ZE_RRULES", $roomdata[0]["room_rules"]);
$ZE_TPL->assign("ZE_TEAMCHAT", $ZE_SETTINGS->cP('chat_groupchat', $uid, $ZE_user_lvl));
$ZE_TPL->assign("ZE_USK18", $allow18);
$ZE_TPL->assign("ZE_TIMER", $ucs);
$ZE_TPL->assign("ZE_MINAVA", $ZE_minava);
$ZE_TPL->assign("ZE_MAVA", $allow_mava);
$ZE_TPL->assign("ZE_TF", $ZE_tf);
$ZE_TPL->assign("ZE_ATF", $allow_tf);
$ZE_TPL->assign("ZE_RANKS", $ZE_SETTINGS->getRankList());
$ZE_TPL->assign("ZE_DEFAULT_GROUP", $ZE_SETTINGS->getDefaultRank());

$TPL_DONT = 0;

?>