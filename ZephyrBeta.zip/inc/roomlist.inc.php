<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Initiate Zephyr Parser
require_once './class/zephyr.class.php';
$tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/';
zephyr::configure("base_url", NULL );
zephyr::configure("tpl_dir", $tpl_path );
zephyr::configure("cache_dir", "cache/" );
zephyr::configure("path_replace", false);
$ZE_TPL = new zephyr;

if(isset($_GET["uid"])) {
  $uid = htmlspecialchars($_GET["uid"]);
  } elseif(isset($_POST["uid"])) {
    $uid = htmlspecialchars($_POST["uid"]);
  } else {
  $uid = '';
}

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include RoomClass
require_once './class/rooms.class.php';
$ZE_ROOMSEL = new room($db);

//Include CategoryClass
require_once './class/category.class.php';
$ZE_CATSEL = new category($db);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

$ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
$ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
$ZE_userage = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_age');
$ZE_username = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
$ZE_SID = $ZE_SESS->getInfo('sess_user_id', $uid, 'sess_id');

$rooms = $ZE_ROOMSEL->getRoomsFull($ZE_user_lvl, $ZE_userage);
$cats = $ZE_CATSEL->getCategorysFull();
$final = array();
$catarr = array();

for($i=0; $i<count($cats); $i++) {
  if($ZE_userage >= $cats[$i]["cat_visa_req_user_min_age"] && $ZE_userage <= $cats[$i]["cat_visa_req_user_max_age"]) {
    $catarr[] = array("cat_id" => $cats[$i]["cat_id"], "cat_name" => $cats[$i]["cat_name"]);
    $helper = array();
    for($o=0; $o<count($rooms); $o++) {
      if($rooms[$o]["room_cat_id"] == $cats[$i]["cat_id"] && ($ZE_userage >= $rooms[$o]["room_visa_req_user_min_age"] && $ZE_userage <= $rooms[$o]["room_visa_req_user_max_age"])) {
        $inroom = $ZE_SESS->roomUserNames($rooms[$o]["room_id"]);
        $ircount = count($inroom);
        if($ircount < $rooms[$o]["room_max"] || $rooms[$o]["room_max"] == 0 || $uid == $rooms[$o]["room_owner_id"] || $ZE_SETTINGS->cp('bypass_room', $uid, $ZE_user_lvl) != false) {
          $full = "green";
        } else {
          $full = "red";
        }
        if($rooms[$o]["room_pass"] != '') {
          $pass = "yes";
        } else {
          $pass = "no";
        }
        if($rooms[$o]["room_max"] == 0) {
          $rooms[$o]["room_max"] = "∞";
        }
        $helper[] = array("rid" => $rooms[$o]["room_id"],
                          "rname" => $rooms[$o]["room_name"],
                          "rtopic" => $rooms[$o]["room_topic"],
                          "rrules" => $rooms[$o]["room_rules"],
                          "rstate" => $rooms[$o]["room_state"],
                          "rtemp" => $rooms[$o]["room_temp"],
                          "rpass" => $pass,
                          "rmax" => $rooms[$o]["room_max"],
                          "rfull" => $full,
                          "ruser" => $ircount,
                          "ruserl" => $inroom);
        $inroom = '';
        $ZE_SESS = new session($db);
      }
    }
    usort($helper, function ($item1, $item2) {
      return $item2['ruser'] <=> $item1['ruser'];
    });
    $final[] = array("cname"  => $cats[$i]["cat_name"],
                     "create" => $cats[$i]["cat_can_create"],
                     "rooms" => $helper);
  }
}

$ZE_TPL->assign("ZE_ROOMS", $final);
$ZE_TPL->assign("ZE_CATS", $catarr);
$ZE_TPL->assign("ZE_SID", $ZE_SID);
$ZE_TPL->assign("ZE_UID", $uid);
$ZE_TPL->assign("ZE_UNAME", $ZE_username);
$ZE_TPL->assign($ZE_SETTINGS->getFullData());
$ZE_TPL->assign($ZE_LANGUAGE->getFull('roomsel', DEF_LANG));
?>