<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
//Initiate Zephyr Parser
require_once './class/zephyr.class.php';
$tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/';
zephyr::configure("base_url", NULL );
zephyr::configure("tpl_dir", $tpl_path );
zephyr::configure("cache_dir", "cache/" );
zephyr::configure("path_replace", false);
$ZE_TPL = new zephyr;

if(isset($_GET["uid"])) {
  $uid = htmlspecialchars($_GET["uid"]);
  } elseif(isset($_POST["uid"])) {
    $uid = htmlspecialchars($_POST["uid"]);
  } else {
  $uid = '';
}

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include AvatarClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

//Include GuestbookClass
require_once './class/gb.class.php';
$ZE_GB = new guestbook($db);

//Include FriendsClass
require_once './class/friends.class.php';
$ZE_FLIST = new friends($db);

//Include MailClass
require_once './class/mails.class.php';
$ZE_MAIL = new mails($db);

//Include ShopClass
require_once './class/shop.class.php';
$ZE_SHOP = new shop($db);

$ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
$ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
$ZE_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
$ZE_user_gender = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_gender');
$ZE_acc_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_global_warns');
$ZE_coins = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_coins');
$tmp_ava = $ZE_AVA->getMainAva($uid);
if($tmp_ava["ava_state"] == '1') {
  $ZE_user_ava = $tmp_ava["ava_link"];
} else {
  $ZE_user_ava = "waiting_user.jpg";
}

if($ZE_SETTINGS->cp('friends', $uid, $ZE_user_lvl) != false) {
  $ZE_user_friends = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_flist');
  $ZE_total_friends = $ZE_FLIST->countFriends($uid);
  $ZE_TPL->assign('ZE_FINV', $ZE_user_friends);
  $ZE_TPL->assign('ZE_TFINV', $ZE_total_friends);
  $ZE_TPL->assign('ZE_SFINV', '1');
} else {
  $ZE_TPL->assign('ZE_FINV', '0');
  $ZE_TPL->assign('ZE_TFINV', '0');
  $ZE_TPL->assign('ZE_SFINV', '0');
}

if($ZE_SETTINGS->cp('gbook', $uid, $ZE_user_lvl) != false) {
  $ZE_user_gb = $ZE_GB->countNewEntries($uid);
  $ZE_total_gb = $ZE_GB->countEntries($uid);
  $ZE_TPL->assign('ZE_GB', $ZE_user_gb);
  $ZE_TPL->assign('ZE_TGB', $ZE_total_gb);
  $ZE_TPL->assign('ZE_SGB', '1');
} else {
  $ZE_TPL->assign('ZE_GB', '0');
  $ZE_TPL->assign('ZE_TGB', '0');
  $ZE_TPL->assign('ZE_SGB', '0');
}

if($ZE_SETTINGS->cp('mails', $uid, $ZE_user_lvl) != false) {
  $ZE_user_mails = $ZE_MAIL->countNewMails($uid);
  $ZE_total_mails = $ZE_MAIL->countMails($uid);
  $ZE_TPL->assign('ZE_MAIL', $ZE_user_mails);
  $ZE_TPL->assign('ZE_TMAIL', $ZE_total_mails);
  $ZE_TPL->assign('ZE_SMAIL', '1');
} else {
  $ZE_TPL->assign('ZE_MAIL', '0');
  $ZE_TPL->assign('ZE_TMAIL', '0');
  $ZE_TPL->assign('ZE_SMAIL', '0');
}
if($ZE_SETTINGS->cp('presents', $uid, $ZE_user_lvl) != false) {
  $ZE_user_presents = $ZE_SHOP->countNewPresents($uid);
  $ZE_total_presents = $ZE_SHOP->countPresents($uid);
  $ZE_TPL->assign('ZE_PRES', $ZE_user_presents);
  $ZE_TPL->assign('ZE_TPRES', $ZE_total_presents);
  $ZE_TPL->assign('ZE_SPRES', '1');
} else {
  $ZE_TPL->assign('ZE_PRES', '0');
  $ZE_TPL->assign('ZE_TPRES', '0');
  $ZE_TPL->assign('ZE_SPRES', '0');
}
/**
$ZE_coins = $ZE_ACC->getInfo($ZE_account_id, 'acc_coins');
$userrank = $ZE_RANKS->getTitle($ZE_user_lvl);
$tmp_ava = $ZE_AVA->getMainAva($ZE_user_id);
if(!isset($tmp_ava[0]["ava_link"])) {
  $ZE_user_avatar = 'default_user.jpg';
  if($ZE_user_gender == 1) {
    $ZE_user_avatar = 'm_'.$ZE_user_avatar;
  }
  if($ZE_user_gender == 2) {
    $ZE_user_avatar = 'f_'.$ZE_user_avatar;
  }
} else {
  if($tmp_ava[0]["ava_state"] != 0) {
    $ZE_user_avatar = $tmp_ava[0]["ava_link"];
  } else {
    $ZE_user_avatar = 'waiting_user.jpg';
  }
}
**/
//require_once './config/secure.php';

$ZE_TPL->assign('ZE_ACCID', $ZE_account_id);
$ZE_TPL->assign('ZE_USERNAME', $ZE_user_name);
$ZE_TPL->assign('ZE_USERRANK', $ZE_SETTINGS->getRankTitle($ZE_user_lvl));
$ZE_TPL->assign('ZE_USERAVATAR', $ZE_user_ava);
$ZE_TPL->assign('ZE_WARNS', $ZE_acc_warns);
$ZE_TPL->assign('ZE_COINS', $ZE_coins);
$ZE_TPL->assign('UID', $uid);
$ZE_TPL->assign('SID', $sid);
?>