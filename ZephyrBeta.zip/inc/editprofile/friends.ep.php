<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include FriendsClass
require_once './class/friends.class.php';
$ZE_FLIST = new friends($db);

//Include UserClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

//Include MailsClass
require_once './class/mails.class.php';
$ZE_MAIL = new mails($db);

if($TPL_DONT != 1) {
  $friends = $ZE_FLIST->getFriendlist($uid);
  for($i=0; $i < count($friends); $i++) {
    $fava = $ZE_AVA->getMainAva($friends[$i]["fid"]);
    $fon = $ZE_SESS->checkIsOnline($friends[$i]["fid"]);
    $friends[$i]["fava"] = $fava["ava_link"];
    $friends[$i]["fonline"] = $fon;
  }
  $ZE_TPL->assign("ZE_FRIENDS", $friends);
  $ZE_TPL->assign("ZE_SID", $sid);
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'requestFriend') {
    $res = $ZE_FLIST->createFriends(htmlspecialchars($_POST["uid"]), htmlspecialchars($_POST["fid"]), htmlspecialchars($_POST["mode"]));
    if($res == true) { echo 'ok'; } else { echo 'fehler'; }
  }
  if($do == 'accepto') {
    $res = $ZE_FLIST->acceptFriend($uid, htmlspecialchars($_POST["fid"]), 3);
    if($res != false) { 
      $inviter = $ZE_FLIST->getInfo('fl_id', $res, 'fl_friend_1');
      $uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
      $ZE_MAIL->sendMail('0', $inviter, clock(), 'Information!', $uname.' hat dein Freundschaftsangebot öffentlich angenommen!');
      echo 'ok'; 
    } else { echo 'fehler'; }
  }
  if($do == 'acceptp') {
    $res = $ZE_FLIST->acceptFriend($uid, htmlspecialchars($_POST["fid"]), 4);
    if($res != false) { 
      $inviter = $ZE_FLIST->getInfo('fl_id', $res, 'fl_friend_1');
      $uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
      $ZE_MAIL->sendMail('0', $inviter, clock(), 'Information!', $uname.' hat dein Freundschaftsangebot privat angenommen!');
      echo 'ok'; 
    } else { echo 'fehler'; }
  }
  if($do == 'delete') {
    $f1 = $ZE_FLIST->getInfo('fl_id', htmlspecialchars($_POST["fid"]), 'fl_friend_1');
    $f2 = $ZE_FLIST->getInfo('fl_id', htmlspecialchars($_POST["fid"]), 'fl_friend_2');
    if($f1 == $uid) { $inviter = $f2; } else { $inviter = $f1; }
    $uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
    $ZE_MAIL->sendMail('0', $inviter, clock(), 'Information!', $uname.' hat eure Freundschaft beendet!');
    $ZE_FLIST->deleteFriend(htmlspecialchars($_POST["fid"]));
  }
  if($do == 'deny') {
    $fid = htmlspecialchars($_POST["fid"]);
    $inviter = $ZE_FLIST->getInfo('fl_id', htmlspecialchars($_POST["fid"]), 'fl_friend_1');
    $uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
    $ZE_MAIL->sendMail('0', $inviter, clock(), 'Information!', $uname.' hat dein Freundschaftsangebot abgelehnt!');
    $ZE_FLIST->denyFriend($uid, htmlspecialchars($_POST["fid"]));
  }
  if($do == 'change') {
    $res = $ZE_FLIST->updateInfo(htmlspecialchars($_POST["fid"]), 'fl_state', htmlspecialchars($_POST["mode"]));
  }
}

?>