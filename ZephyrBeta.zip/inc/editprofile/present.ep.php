<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include ShopClass
require_once './class/shop.class.php';
$ZE_SHOP = new shop($db);

//Include AvatarClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

if($TPL_DONT != 1) {
  $aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
  $age = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_age');

  $inv = $ZE_SHOP->getInven($uid);
  $inventory = array();
  $counter = 0;
  for($i=0; $i < count($inv); $i++) {
    $iid = $inv[$i]["item"];
    $tmpitem = $ZE_SHOP->getShopItem($iid, $age) ?? array();
    if(!empty($tmpitem)) {
      $tmpinv = $inv[$i]["id"];
      $tmpid = $tmpitem["id"];
      $tmpname = $tmpitem["name"];
      $tmppic = $tmpitem["pic"];
      $tmpsince = date("d.m.Y, H:i:s", $inv[$i]["bought"]);
      if($inv[$i]["sender"] == '') {
        $tmpsender = '';
      } else {
        $tmpsender = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $inv[$i]["sender"], 'user_name');
      }
      $inventory[$counter] = array("id"     => $tmpid,
                                   "name"   => $tmpname,
                                   "pic"    => $tmppic,
                                   "sender" => $tmpsender,
                                   "since"  => $tmpsince,
                                   "inv"    => $tmpinv);
      $counter++;
    }
  }

  $trans = $ZE_SHOP->getPresents($uid);
  $transactions = array();
  $counter = 0;
  for($i=0; $i < count($trans); $i++) {
    $dont = false;
    $iid = $trans[$i]["item"];
    $tmpitem = $ZE_SHOP->getShopItem($iid, $age) ?? array();
    if(!empty($tmpitem)) {
      $tmpid = $trans[$i]["id"];
      $tmpiname = $tmpitem["name"];
      $tmppic = $tmpitem["pic"];
      $tmpstate = $trans[$i]["state"];
      $tmpdate = redoDate(date("Y-m-d H:i:s", $trans[$i]["date"]));
      $tmptext = $trans[$i]["text"];
      if($trans[$i]["sender"] == $uid) {
        $tmpoid = $trans[$i]["getter"];
        $tmpdirec = 'send';
      } else {
        $tmpoid = $trans[$i]["sender"];
        $tmpdirec = 'get';
      }
      $tmpname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $tmpoid, 'user_name');
      $tmpava_arr = $ZE_AVA->getMainAva($tmpoid);
      $tmpava = $tmpava_arr["ava_link"];
      if($tmpdirec == 'get' && $tmpstate == 4) {
        $dont = true;
      }
      if($dont == false) {
        $transactions[$counter] = array("id"    => $tmpid,
                                        "item"  => $tmpiname,
                                        "pic"   => $tmppic,
                                        "state" => $tmpstate,
                                        "date"  => $tmpdate,
                                        "text"  => $tmptext,
                                        "other" => $tmpname,
                                        "ava"   => $tmpava,
                                        "direc" => $tmpdirec);
        $counter++;
      }
    }
  }

  rsort($transactions);
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("ZE_INVEN", $inventory);
  $ZE_TPL->assign("ZE_TRANS", $transactions);
  $ZE_TPL->assign("ZE_USERS", $ZE_USER->listUsersSmall());
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'delitem') {
    $ZE_SHOP->deleteInfo(ZE_PRE.'_inv', 'inv_id', htmlspecialchars($_POST["iid"]));
  }
  if($do == 'senditem') {
    if(htmlspecialchars($_POST["at"]) == '') {
      $getter = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_name', htmlspecialchars($_POST["atinput"]), 'user_id');
    } else {
      $getter = htmlspecialchars($_POST["at"]);
    }
    $invid = htmlspecialchars($_POST["iid"]);
    $item = $ZE_SHOP->getInfo(ZE_PRE.'_inv', 'inv_item_id', 'inv_id', $invid);
    $ZE_SHOP->sendItem($uid, $getter, $item, htmlspecialchars($_POST["message"]), $invid);
  }
  if($do == 'acceptitem') {
    $ZE_SHOP->acceptItem(htmlspecialchars($_POST["iid"]));
  }
  if($do == 'abortitem') {
    $ZE_SHOP->denyItem(htmlspecialchars($_POST["iid"]), 0);
  }
  if($do == 'denyitem') {
    $ZE_SHOP->denyItem(htmlspecialchars($_POST["iid"]), 1);
  }
}

?>