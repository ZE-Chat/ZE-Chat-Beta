<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

$ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
$ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
$ZE_gender = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_gender');
$ZE_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
$ZE_user_alias = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_alias');
$ZE_user_op = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_online_points');
$ZE_user_privacy = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_profile_public');
$ZE_acc_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_global_warns');
$ZE_bday = str_replace("-", ".", $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_birthday'));
$ZE_max_coins = floor($ZE_user_op / 100);
$ZE_user_op_left = $ZE_user_op % 100;

if($TPL_DONT != 1) {
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("ZE_ACCID", $ZE_account_id);
  $ZE_TPL->assign("ZE_BDAY", $ZE_bday);
  $ZE_TPL->assign("ZE_PRIVACY", $ZE_user_privacy);
  $ZE_TPL->assign("ZE_ALIAS", $ZE_user_alias);
  $ZE_TPL->assign("ZE_OP", $ZE_user_op);
  $ZE_TPL->assign("ZE_OPL", $ZE_user_op_left);
  $ZE_TPL->assign("ZE_MAX_COINS", $ZE_max_coins);
  $ZE_TPL->assign("ZE_GENDER", $ZE_gender);
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'change') {
    switch(htmlspecialchars($_POST["sett"])) {
      case 'coins':
        if(htmlspecialchars($_POST["exchange"]) == '1') {
          $ZE_coins = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_coins');
          $ZE_coins = $ZE_coins + $ZE_max_coins;
          $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_online_points', $ZE_user_op_left);
          $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_coins', $ZE_coins);
        }
        break;
      case 'privacy': $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_profile_public', htmlspecialchars($_POST["privacy"])); break;
      case 'nickalias': $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_alias', htmlspecialchars($_POST["alias"])); break;
      case 'password':
        $pwhash = password_hash(htmlspecialchars($_POST["pass1"]), PASSWORD_BCRYPT);
        $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_pass', $pwhash);
        break;
      case 'email':
        $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_email', htmlspecialchars($_POST["mail1"]));
        break;
      case 'gender':
        $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_gender', htmlspecialchars($_POST["gender"]));
        $ZE_SESS->updateInfo3('sr_uid', $uid, 'sr_gender', htmlspecialchars($_POST["gender"]));
        break;
    }
  }
}

?>