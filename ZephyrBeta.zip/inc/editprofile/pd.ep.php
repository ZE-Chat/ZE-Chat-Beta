<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include ProfileClass
require_once './class/profile.class.php';
$ZE_PROF = new profiles($db);

if($TPL_DONT != 1) {
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("ZE_PROFILES", $ZE_PROF->getUserProfile($uid, ''));
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'change') {
    $ZE_PROF->changeFieldContent(htmlspecialchars($_POST["pid"]), $uid, htmlspecialchars($_POST["content"]));
    echo "Hi";
  }
}

?>