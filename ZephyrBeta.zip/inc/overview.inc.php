<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
 
if(isset($_GET["uid"])) {
  $uid = htmlspecialchars($_GET["uid"]);
  } elseif(isset($_POST["uid"])) {
    $uid = htmlspecialchars($_POST["uid"]);
  } else {
  $uid = '';
}

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);
 
//Include AvatarClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

//Include FriendsClass
require_once './class/friends.class.php';
$ZE_FLIST = new friends($db);

//Initiate Zephyr Parser
require_once './class/zephyr.class.php';
$tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/';
zephyr::configure("base_url", NULL );
zephyr::configure("tpl_dir", $tpl_path );
zephyr::configure("cache_dir", "cache/" );
zephyr::configure("path_replace", false);
$ZE_TPL = new zephyr;

if($uid > 0) {
  $friends = array();
  $friends = $ZE_FLIST->getFriendlist($uid);
  for($i=0; $i < count($friends); $i++) {
    $fava = $ZE_AVA->getMainAva($friends[$i]["fid"]);
    $fon = $ZE_SESS->checkIsOnline($friends[$i]["fid"]);
    $friends[$i]["fava"] = $fava["ava_link"];
    $friends[$i]["fonline"] = $fon;
  }
  usort($friends, function ($item1, $item2) {
    if($item1['fonline'] == $item2['fonline'])
      return $item1['fname'] <=> $item2['fname'];
    else
      return $item2['fonline'] <=> $item1['fonline'];
  });
  $userlist = $ZE_USER->listUsers(true);
  selectRandomUser:
  $randomuser = array_rand($userlist);
  $ruser = $userlist[$randomuser];
  $ruid = $ruser["uid"];
  if($ruid == $uid && count($userlist) > 1) {
    goto selectRandomUser;
  }
  $rava = $ZE_AVA->getMainAva($ruid);
  $rava = $rava["ava_link"];
  $rname = $ruser["uname"];
} else {
  $friends = 'guest';
  $ruid = 'guest';
}

$ZE_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
$ZE_user_ip = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_last_used_ip');
$ZE_user_ls = redoDateArr($ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_last_login'));

$ZE_TPL->assign("ZE_FRIENDS", $friends);
$ZE_TPL->assign("ZE_USERNAME", $ZE_user_name);
$ZE_TPL->assign("ZE_USERIP", $ZE_user_ip);
$ZE_TPL->assign("ZE_USERLS", $ZE_user_ls);
$ZE_TPL->assign("ZE_RUSER", $rname);
$ZE_TPL->assign("ZE_RAVA", $rava);
$ZE_TPL->assign("ZE_RUID", $ruid);

//$ZE_TPL->assign("ZE_NEWS_CON", $news);

?>