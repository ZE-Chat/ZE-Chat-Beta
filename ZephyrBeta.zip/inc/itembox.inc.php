<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);
 
//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include ShopClass
require_once './class/shop.class.php';
$ZE_SHOP = new shop($db);

//Initiate Zephyr Parser
require_once './class/zephyr.class.php';
$tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/';
zephyr::configure("base_url", NULL );
zephyr::configure("tpl_dir", $tpl_path );
zephyr::configure("cache_dir", "cache/" );
zephyr::configure("path_replace", false);
$ZE_TPL = new zephyr;

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

if(isset($_GET["iid"])) {
  $iid = htmlspecialchars($_GET["iid"]);
  } elseif(isset($_POST["iid"])) {
    $iid = htmlspecialchars($_POST["iid"]);
  } else {
  $iid = '';
}

if(isset($_GET["mode"])) {
  $mode = htmlspecialchars($_GET["mode"]);
  } elseif(isset($_POST["mode"])) {
    $mode = htmlspecialchars($_POST["mode"]);
  } else {
  $mode = '';
}

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');
$aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
$age = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_age');

$item = $ZE_SHOP->getShopItem($iid, $age);
if($item["text"] == '') {
  $item["text"] = 'Keine Beschreibung vorhanden!';
}
switch($item["dura"]) {
  case "0": $item["dura"] = 'Unbegrenzt'; break;
  case "86400": $item["dura"] = 'Ein Tag'; break;
  case "604800": $item["dura"] = 'Eine Woche'; break;
  case "2678400": $item["dura"] = 'Ein Monat'; break;
}
switch($item["special"]) {
  case "0": $item["special"] = 'Nein'; break;
  case "1": $item["special"] = 'Ja'; break;
}
$ZE_TPL->assign($item);

if($mode == 'prof') {
  $inven = $ZE_SHOP->getInvenItem(htmlspecialchars($_GET["invenid"]));
  if($inven["present"] == 1) {
    $sender = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $inven["sender"], 'user_name') ?? false;
    $text = $inven["text"] ?? false;
    $ZE_TPL->assign('PSENDER', $sender);
    $ZE_TPL->assign('PTEXT', $text);
  }
  $ZE_TPL->assign('IS_PRESENT', $inven["present"]);
}

//$ZE_TPL->assign($ZE_LANGUAGE->getFull('registerbox', DEF_LANG));

$ZE_TPL->assign('ZE_MODE', $mode);

?>