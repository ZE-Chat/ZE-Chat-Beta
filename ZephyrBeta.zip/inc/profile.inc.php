<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
 
//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);
 
 //Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

 //Include ProfileClass
require_once './class/profile.class.php';
$ZE_PROF = new profiles($db);

//Include AvatarClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

//Include GuestbookClass
require_once './class/gb.class.php';
$ZE_GB = new guestbook($db);

//Include FriendsClass
require_once './class/friends.class.php';
$ZE_FLIST = new friends($db);

//Include ShopClass
require_once './class/shop.class.php';
$ZE_SHOP = new shop($db);

//Initiate Zephyr Parser
require_once './class/zephyr.class.php';
$tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/';
zephyr::configure("base_url", NULL );
zephyr::configure("tpl_dir", $tpl_path );
zephyr::configure("cache_dir", "cache/" );
zephyr::configure("path_replace", false);
$ZE_TPL = new zephyr;

if(isset($_GET["pid"])) {
  $pid = htmlspecialchars($_GET["pid"]);
  } elseif(isset($_POST["pid"])) {
    $pid = htmlspecialchars($_POST["pid"]);
  } else {
  $pid = '';
}

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

$acp = false;

if($sid != 'none') {
  $visitorID = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');
  $lvl = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_level');
  $acp = $ZE_SETTINGS->cP('show_acp', $visitorID, $lvl);
  if($visitorID == $pid) {
    $gbmode = 'all';
    $ZE_GB->markRead($pid);
  } else {
    $gbmode = $visitorID;
  }
  $allava = $ZE_AVA->getAllAva($visitorID, '0');
  $privava = $ZE_AVA->getAllAva($visitorID, '1');
  $vaid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $visitorID, 'user_acc_id');
  $vage = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $vaid, 'acc_age');
} else {
  $visitorID = 'guest';
  $allava = array();
  $privava = array();
  $gbmode = '0';
  $vage = '10';
}

$inv = $ZE_SHOP->getInven($pid);
$inventory = array();
$counter = 0;
for($i=0; $i < count($inv); $i++) {
  $iid = $inv[$i]["item"];
  $invenid = $inv[$i]["id"];
  $tmpitem = $ZE_SHOP->getShopItem($iid, $vage) ?? array();
  if(!empty($tmpitem)) {
    $tmpid = $tmpitem["id"];
    $tmpname = $tmpitem["name"];
    $tmppic = $tmpitem["pic"];
    if($inv[$i]["sender"] == '') {
      $tmpsender = '';
    } else {
      $tmpsender = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $inv[$i]["sender"], 'user_name');
    }
    $inventory[$counter] = array("id"      => $tmpid,
                                 "name"    => $tmpname,
                                 "pic"     => $tmppic,
                                 "sender"  => $tmpsender,
                                 "invenid" => $invenid);
    $counter++;
  }
}

//var_dump($inv);

$aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $pid, 'user_acc_id');


$friends = $ZE_FLIST->getFriendlist($pid);

for($i=0; $i < count($friends); $i++) {
  $fava = $ZE_AVA->getMainAva($friends[$i]["fid"]);
  $fon = $ZE_SESS->checkIsOnline($friends[$i]["fid"]);
  $friends[$i]["fava"] = $fava["ava_link"];
  $friends[$i]["fonline"] = $fon;
}

$mainava = $ZE_AVA->getMainAva($pid);
if($visitorID == 'guest') {
  if($mainava["ava_usk"] != 0) {
    $mainava["ava_link"] = $mainava["ava_usk"].'_user.jpg';
  }
} else {
  if($mainava["ava_usk"] >= $vage) {
    $mainava["ava_link"] = $mainava["ava_usk"].'_user.jpg';
  }
}

$public_ava = $ZE_AVA->getAllAva($pid, '0');
for($i=0; $i < count($public_ava); $i++) {
  if($visitorID == 'guest') {
    if($public_ava[$i]["ava_usk"] != 0) {
      $public_ava[$i]["ava_link"] = $public_ava[$i]["ava_usk"].'_user.jpg';
    }
  } else {
    if($public_ava[$i]["ava_usk"] >= $vage) {
      $public_ava[$i]["ava_link"] = $public_ava[$i]["ava_usk"].'_user.jpg';
    }
  }
}

if($visitorID > 0) {
  if($ZE_USER->canRateUser($visitorID, $pid) == true) {
    $canrate = 'true';
  } else {
    $canrate = 'false';
  }
} else {
  $canrate = 'false';
}

$tmprates = $ZE_USER->getRating($pid);
$score = $tmprates["score"];
$rates = $tmprates["rates"];

$ZE_TPL->assign("ACP", $acp);
$ZE_TPL->assign("ZE_FRIENDS", $friends);
$ZE_TPL->assign("ZE_USERAVATAR", $mainava);
$ZE_TPL->assign("SID", $sid);
$ZE_TPL->assign("PID", $pid);
$ZE_TPL->assign("VID", $visitorID);
$ZE_TPL->assign("ZE_CANRATE", $canrate);
$ZE_TPL->assign("ZE_SCORE", $score);
$ZE_TPL->assign("ZE_RATES", $rates);
$ZE_TPL->assign("ZE_MAIN", $ZE_PROF->getMainText($pid));
$ZE_TPL->assign("ZE_UNAME", $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $pid, 'user_name'));
$ZE_TPL->assign("ZE_AGE", $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_age'));
$ZE_TPL->assign("ZE_GENDER", $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $pid, 'user_gender'));
$ZE_TPL->assign("ZE_PROFILES", $ZE_PROF->getUserProfile($pid, ''));
$ZE_TPL->assign("ZE_PUBAVA", $public_ava);
$ZE_TPL->assign("ZE_VPUBAVA", $allava);
$ZE_TPL->assign("ZE_VPRIVAVA", $privava);
$ZE_TPL->assign("ZE_USERRANK", $ZE_SETTINGS->getRankTitle($ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $pid, 'user_level')));
$ZE_TPL->assign("ZE_GB", $ZE_GB->getAllEntries($pid, $gbmode));
$ZE_TPL->assign("ZE_INVEN", $inventory);

//$ZE_TPL->assign($ZE_LANGUAGE->getFull('registerbox', DEF_LANG));

?>