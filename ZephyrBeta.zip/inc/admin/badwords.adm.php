<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

authACP('acp_badwords', $uid, $lvl, $ip, $TPL);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include BadwordsClass
require_once './class/badwords.class.php';
$ZE_BAD = new badwords($db);

if($TPL_DONT != 1) {
  $bw = $ZE_BAD->getBadwords();
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("ZE_BW", $bw);
  $ZE_TPL->assign($ZE_SETTINGS->getFullData());
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'delbw') {
    $ZE_BAD->deleteInfo(htmlspecialchars($_POST["bid"]));
  }
  if($do == 'createbw') {
    $ZE_BAD->createBadword(htmlspecialchars($_POST["word"]),
                           htmlspecialchars($_POST["min"]),
                           htmlspecialchars($_POST["max"]),
                           htmlspecialchars($_POST["text"]),
                           htmlspecialchars($_POST["name"]),
                           htmlspecialchars($_POST["punish"]));
  }
  if($do == 'editbw') {
    $bid = htmlspecialchars($_POST["bid"]);
    $ZE_BAD->updateInfo($bid, 'bad_word', htmlspecialchars($_POST["word"]));
    $ZE_BAD->updateInfo($bid, 'bad_min_age', htmlspecialchars($_POST["min"]));
    $ZE_BAD->updateInfo($bid, 'bad_max_age', htmlspecialchars($_POST["max"]));
    $ZE_BAD->updateInfo($bid, 'bad_text', htmlspecialchars($_POST["text"]));
    $ZE_BAD->updateInfo($bid, 'bad_name', htmlspecialchars($_POST["name"]));
    $ZE_BAD->updateInfo($bid, 'bad_punish', htmlspecialchars($_POST["punish"]));
  }
  if($do == 'getbw') {
    echo json_encode($ZE_BAD->getBadword(htmlspecialchars($_POST["bid"])));
  }
}

?>