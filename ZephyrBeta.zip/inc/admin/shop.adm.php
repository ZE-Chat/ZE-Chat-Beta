<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

authACP('acp_shop', $uid, $lvl, $ip, $TPL);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include ShopClass
require_once './class/shop.class.php';
$ZE_SHOP = new shop($db);

//Include MailClass
require_once './class/mails.class.php';
$ZE_MAIL = new mails($db);

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

if($TPL_DONT != 1) {
  $shop = array();
  $scats = $ZE_SHOP->getShopCats('99');
  for($i=0; $i<count($scats); $i++) {
    $tempid    = $scats[$i]["id"];
    $tempname  = $scats[$i]["name"];
    $tempage   = $scats[$i]["age"];
    $tempitems = $ZE_SHOP->getCatItems($tempid, '99') ?? array();
    $shop[] = array("cid"   => $tempid,
                    "cname" => $tempname,
                    "cage"  => $tempage,
                    "items" => $tempitems);
  }
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign($ZE_SETTINGS->getFullData());
  $ZE_TPL->assign("ZE_SHOP", $shop);
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'resortitem') {
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_cats_id', htmlspecialchars($_POST["nc"]));
  }
  if($do == 'delitem') {
    $ZE_SHOP->deleteItem(htmlspecialchars($_POST["iid"]));
  }
  if($do == 'delcat') {
    $ZE_SHOP->deleteInfo(ZE_PRE.'_item_cats', 'item_cats_id', htmlspecialchars($_POST["cid"]));
  }
  if($do == 'getitem') {
    echo json_encode($ZE_SHOP->getShopItem(htmlspecialchars($_POST["iid"]), '99'));
  }
  if($do == 'getcat') {
    echo json_encode($ZE_SHOP->getShopCat(htmlspecialchars($_POST["cid"])));
  }
  if($do == 'edititem') {
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_name', htmlspecialchars($_POST["name"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_text', $_POST["text"]);
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_duration', htmlspecialchars($_POST["dura"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_available', htmlspecialchars($_POST["avail"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_available_until', htmlspecialchars($_POST["until"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_cost', htmlspecialchars($_POST["cost"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_min_age', htmlspecialchars($_POST["age"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_special', htmlspecialchars($_POST["special"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_code', $_POST["code"]);
    if(isset($_FILES['icon'])) {
      $img = $ZE_SHOP->getInfo(ZE_PRE.'_item', 'item_pic', 'item_id', htmlspecialchars($_POST["iid"]));
      $path = $_FILES['icon']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $name = random_gen(16).'.'.$ext;
      move_uploaded_file($_FILES['icon']['tmp_name'], "./files/shopitems/".$name);
      if($img != false) {
        $file = './files/shopitems/'.$img;
        unlink($file);
      }
      $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', htmlspecialchars($_POST["iid"]), 'item_pic', $name);
    }
  }
  if($do == 'createitem') {
    $name = '';
    if(isset($_FILES['icon'])) {
      $path = $_FILES['icon']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $name = random_gen(16).'.'.$ext;
      move_uploaded_file($_FILES['icon']['tmp_name'], "./files/shopitems/".$name);
    }
    $ZE_SHOP->createItem(htmlspecialchars($_POST["name"]),
                         $name,
                         htmlspecialchars($_POST["cat"]),
                         $_POST["text"],
                         htmlspecialchars($_POST["dura"]),
                         htmlspecialchars($_POST["avail"]),
                         htmlspecialchars($_POST["until"]),
                         htmlspecialchars($_POST["cost"]),
                         htmlspecialchars($_POST["age"]),
                         htmlspecialchars($_POST["special"]),
                         $POST["code"]);
  }
  if($do == 'createcat') {
    $ZE_SHOP->createItemCats(htmlspecialchars($_POST["name"]), htmlspecialchars($_POST["age"]));
  }
  if($do == 'editcat') {
    $ZE_SHOP->updateInfo(ZE_PRE.'_item_cats', 'item_cats_id', htmlspecialchars($_POST["cid"]), 'item_cats_name', htmlspecialchars($_POST["name"]));
    $ZE_SHOP->updateInfo(ZE_PRE.'_item_cats', 'item_cats_id', htmlspecialchars($_POST["cid"]), 'item_cats_min_age', htmlspecialchars($_POST["age"]));
  }
  if($do == 'discountitem') {
    $iid        = htmlspecialchars($_POST["iid"]);
    $cost       = htmlspecialchars($_POST["cost"]);
    $until_date = htmlspecialchars($_POST["until_date"]);
    $until_time = htmlspecialchars($_POST["until_time"]);
    $inform     = htmlspecialchars($_POST["inform"]);
    
    $until = $until_date.' '.$until_time;
    $until_timestamp = strtotime($until);
    
    if($inform == '1') {
      $subject = "Rabattaktion!";
      $tomorrow = date("d.m.Y", strtotime('tomorrow'));
      $iteminfo = $ZE_SHOP->getShopItem($iid, '99');
      $itemage = $iteminfo["mage"];
      if(isset($_POST["text"]) && htmlspecialchars($_POST["text"]) != '') {
        $text = htmlspecialchars($_POST["text"]);
      } else {
        $item_name = $iteminfo["name"];
        $orig_cost = $iteminfo["cost"];
        $until = str_replace("-", ".", $until);
        $text = "Eine neue Rabattaktion hat begonnen! Bis $until Uhr kannst du \"$item_name\" für nur $cost statt $orig_cost Coins kaufen!";
      }
      $users = $ZE_USER->listUsersWithAge();
      for($i=0; $i<count($users); $i++) {
        if($users[$i]["age"] >= $itemage) {
          $tmpid = $users[$i]["uid"];
          $ZE_MAIL->sendMail(0, $tmpid, clock(), $subject, $text);
        }
      }
    }
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', $iid, 'item_discount_cost', $cost);
    $ZE_SHOP->updateInfo(ZE_PRE.'_item', 'item_id', $iid, 'item_discount_until', $until_timestamp);
  }
}

?>