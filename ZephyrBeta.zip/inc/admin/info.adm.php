<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

authACP('acp_info', $uid, $lvl, $ip, $TPL);

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

if(isset($_GET["target"])) {
  $target = htmlspecialchars($_GET["target"]);
  } elseif(isset($_POST["target"])) {
    $target = htmlspecialchars($_POST["target"]);
  } else {
  $target = '';
}

$tsid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
$tacc = $ZE_SESS->getInfo('sess_id', $tsid, 'sess_acc_id');

if($TPL_DONT != 1) {
  $browser = $ZE_SESS->getInfo('sess_id', $tsid, 'sess_user_browser');
  $os = $ZE_SESS->getInfo('sess_id', $tsid, 'sess_user_os');
  
  $osi = 'fa-question';
    
  if (preg_match('/Windows/i', $os)) { $osi = 'fa-windows'; }
  if (preg_match('/Android/i', $os)) { $osi = 'fa-android'; }
  if (preg_match('/BlackBerry/i', $os) || preg_match('/Mobile/i', $os)) { $osi = 'fa-mobile'; }
  if (preg_match('/Mac/i', $os) || preg_match('/iPhone/i', $os) || preg_match('/iPod/i', $os) || preg_match('/iPad/i', $os)) { $osi = 'fa-apple'; }
  if (preg_match('/Linux/i', $os) || preg_match('/Ubuntu/i', $os)) { $osi = 'fa-linux'; }
  
  if(preg_match('/Internet Explorer/i',$browser)) { 
    $browseri = 'fa-internet-explorer';
  } elseif(preg_match('/Firefox/i',$browser)) { 
    $browseri = 'fa-firefox';
  } elseif(preg_match('/Google Chrome/i',$browser)) { 
    $browseri = 'fa-chrome';
  } elseif(preg_match('/Safari/i',$browser)) { 
    $browseri = 'fa-safari'; 
  } elseif(preg_match('/Opera/i',$browser)) { 
    $browseri = 'fa-opera';
  } elseif(preg_match('/Netscape/i',$browser)) { 
    $browseri = 'fa-desktop'; 
  } elseif(preg_match('/Maxthon/i',$browser)) { 
    $browseri = 'fa-desktop'; 
  } elseif(preg_match('/Konqueror/i',$browser)) { 
    $browseri = 'fa-desktop';
  } elseif(preg_match('/Edge/i',$browser)) { 
    $browseri = 'fa-edge';
  } else {
    $browseri = 'fa-question';
  }
  
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("TACCID", $tacc);
  $ZE_TPL->assign("TUSERID", $target);
  $ZE_TPL->assign("TGROUP", $ZE_SETTINGS->getRankTitle($ZE_SESS->getInfo('sess_id', $tsid, 'sess_user_level')));
  $ZE_TPL->assign("TLOGIN", $ZE_SESS->getInfo('sess_id', $tsid, 'sess_logged_in'));
  $ZE_TPL->assign("TWARNS", $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $tacc, 'acc_global_warns'));
  $ZE_TPL->assign("TLMESS", $ZE_SESS->getInfo('sess_id', $tsid, 'sess_last_sent_message_time'));
  $ZE_TPL->assign("TPING", $ZE_SESS->getInfo('sess_id', $tsid, 'sess_ping'));
  $ZE_TPL->assign("TIP", $ZE_SESS->getInfo('sess_id', $tsid, 'sess_user_ip'));
  $ZE_TPL->assign("TBROWSER", $browser);
  $ZE_TPL->assign("TBROWSERI", $browseri);
  $ZE_TPL->assign("TOS", $os);
  $ZE_TPL->assign("TOSI", $osi);
  $ZE_TPL->assign("TDESIGN", $ZE_SESS->getInfo('sess_id', $tsid, 'sess_design_switch'));
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
}

?>