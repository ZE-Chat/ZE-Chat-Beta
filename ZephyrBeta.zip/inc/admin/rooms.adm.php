<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

authACP('acp_room', $uid, $lvl, $ip, $TPL);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include RoomClass
require_once './class/rooms.class.php';
$ZE_ROOMSEL = new room($db);

//Include CategoryClass
require_once './class/category.class.php';
$ZE_CATSEL = new category($db);

if($TPL_DONT != 1) {
  $rooms = $ZE_ROOMSEL->getRoomsFull('99', '99');
  $cats = $ZE_CATSEL->getCategorysFull();
  $final = array();

  for($i=0; $i<count($cats); $i++) {
    $helper = array();
    for($o=0; $o<count($rooms); $o++) {
      if($rooms[$o]["room_cat_id"] == $cats[$i]["cat_id"]) {
        if($rooms[$o]["room_pass"] != '') {
          $pass = "yes";
        } else {
          $pass = "no";
        }
        if($rooms[$o]["room_max"] == 0) {
          $rooms[$o]["room_max"] = "unbegrenzt";
        }
        $helper[] = array("rid"    => $rooms[$o]["room_id"],
                          "rname"  => $rooms[$o]["room_name"],
                          "rtopic" => $rooms[$o]["room_topic"],
                          "rrules" => $rooms[$o]["room_rules"],
                          "rstate" => $rooms[$o]["room_state"],
                          "rtemp"  => $rooms[$o]["room_temp"],
                          "rmina"   => $rooms[$o]["room_visa_req_user_min_age"],
                          "rmaxa"   => $rooms[$o]["room_visa_req_user_max_age"],
                          "rpass"  => $pass,
                          "rmax"   => $rooms[$o]["room_max"]);
      }
    }
    $final[] = array("cid"    => $cats[$i]["cat_id"],
                     "cname"  => $cats[$i]["cat_name"],
                     "create" => $cats[$i]["cat_can_create"],
                     "cmina"  => $cats[$i]["cat_visa_req_user_min_age"],
                     "cmaxa"  => $cats[$i]["cat_visa_req_user_max_age"],
                     "rooms"  => $helper);
  }

  $ZE_TPL->assign("ZE_ROOMS", $final);
  $ZE_TPL->assign("ZE_CATS", $cats);
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign($ZE_SETTINGS->getFullData());
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'resortroom') {
    $ZE_ROOMSEL->updateInfo(htmlspecialchars($_POST["rid"]), 'room_cat_id', htmlspecialchars($_POST["nc"]));
  }
  if($do == 'createcat') {
    $ZE_CATSEL->createCategory(htmlspecialchars($_POST["name"]), htmlspecialchars($_POST["min"]), htmlspecialchars($_POST["max"]), htmlspecialchars($_POST["allow"]));
  }
  if($do == 'delcat') {
    $ZE_CATSEL->deleteCategory(htmlspecialchars($_POST["cid"]));
  }
  if($do == 'getcat') {
    echo json_encode($ZE_CATSEL->getCategory(htmlspecialchars($_POST["cid"])));
  }
  if($do == 'getroom') {
    echo json_encode($ZE_ROOMSEL->getRoom(htmlspecialchars($_POST["rid"])));
  }
  if($do == 'editcat') {
    $cid = htmlspecialchars($_POST["cid"]);
    $ZE_CATSEL->updateCategory($cid, 'cat_name', htmlspecialchars($_POST["name"]));
    $ZE_CATSEL->updateCategory($cid, 'cat_visa_req_user_min_age', htmlspecialchars($_POST["min"]));
    $ZE_CATSEL->updateCategory($cid, 'cat_visa_req_user_max_age', htmlspecialchars($_POST["max"]));
    $ZE_CATSEL->updateCategory($cid, 'cat_can_create', htmlspecialchars($_POST["allow"]));
  }
  if($do == 'createroom') {
    $name = '';
    if(isset($_FILES['bg'])) {
      $path = $_FILES['bg']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $name = random_gen(16).'.'.$ext;
      move_uploaded_file($_FILES['bg']['tmp_name'], "./files/roombg/".$name);
    }
    $now = clock();
    $ZE_ROOMSEL->createRoom(htmlspecialchars($_POST["cat"]),
                            htmlspecialchars($_POST["name"]),
                            htmlspecialchars($_POST["topic"]),
                            htmlspecialchars($_POST["rules"]),
                            htmlspecialchars($_POST["srules"]),
                            htmlspecialchars($_POST["welcome"]),
                            '',
                            htmlspecialchars($_POST["mina"]),
                            htmlspecialchars($_POST["maxa"]),
                            htmlspecialchars($_POST["open"]),
                            '0',
                            '1',
                            '',
                            '0',
                            '0',
                            $now,
                            '',
                            htmlspecialchars($_POST["col"]),
                            htmlspecialchars($_POST["bgcol"]),
                            $name,
                            htmlspecialchars($_POST["max"]));
    echo 'done';
  }
  if($do == 'delroom') {
    $ZE_ROOMSEL->deleteRoom(htmlspecialchars($_POST["rid"]));
  }
  if($do == 'editroom') {
    $rid = htmlspecialchars($_POST["rid"]);
    $imgs = htmlspecialchars($_POST["imgs"]);
    if($imgs == '1') {
      $imgage = $ZE_ROOMSEL->getInfo('room_id', $rid, 'room_image');
      if($image != '') {
        $file = './pic/roombg/'.$image;
        unlink($file);
      }
      $name = '';
      if(isset($_FILES['bg'])) {
        $path = $_FILES['bg']['name'];
        $ext = pathinfo($path, PATHINFO_EXTENSION);
        $name = random_gen(16).'.'.$ext;
        move_uploaded_file($_FILES['bg']['tmp_name'], "./files/roombg/".$name);
      }
      $ZE_ROOMSEL->updateInfo($rid, 'room_image', $name);
    }
    if($imgs == '2') {
      $imgage = $ZE_ROOMSEL->getInfo('room_id', $rid, 'room_image');
      if($image != '') {
        $file = './pic/roombg/'.$image;
        unlink($file);
      }
      $name = '';
      $ZE_ROOMSEL->updateInfo($rid, 'room_image', $name);
    }
    
    $ZE_ROOMSEL->updateInfo($rid, 'room_name', htmlspecialchars($_POST["name"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_topic', htmlspecialchars($_POST["topic"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_rules', htmlspecialchars($_POST["rules"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_show_rules', htmlspecialchars($_POST["srules"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_welcome', htmlspecialchars($_POST["welcome"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_visa_req_user_min_age', htmlspecialchars($_POST["mina"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_visa_req_user_max_age', htmlspecialchars($_POST["maxa"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_state', htmlspecialchars($_POST["open"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_color', htmlspecialchars($_POST["col"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_background', htmlspecialchars($_POST["bgcol"]));
    $ZE_ROOMSEL->updateInfo($rid, 'room_max', htmlspecialchars($_POST["max"]));
    echo 'done';
  }
}

?>