<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include SmiliesClass
require_once './class/smilies.class.php';
$ZE_SMI = new smilies($db);

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');

if($TPL_DONT != 1) {
  $ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
  $ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
  $ZE_userage = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_age');
  $ZE_username = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
  $ZE_TPL->assign("ZE_CATEGORIES", $ZE_SMI->getSmilieCategories());
  $ZE_TPL->assign("ZE_SMILIES", $ZE_SMI->buildSmilies($ZE_SETTINGS->getHighestRankOrder(), '99'));
  $ZE_TPL->assign("ZE_PG", $ZE_SETTINGS->getRankListDESC());
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("ZE_UID", $uid);
  $ZE_TPL->assign("ZE_UNAME", $ZE_username);
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }
  if($do == 'resortsmilies') {
    $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_cat', htmlspecialchars($_POST["nc"]));
    echo "done";
    die();
  }
  if($do == 'getcat') {
    echo json_encode($ZE_SMI->getSmilieCat(htmlspecialchars($_POST["cid"])));
    die();
  }
  if($do == 'getsmilie') {
    echo json_encode($ZE_SMI->getSmilie(htmlspecialchars($_POST["smiid"])));
    die();
  }
  if($do == 'createsmilie') {
    $icon = '';
    if(isset($_FILES['icon'])) {
      $path = $_FILES['icon']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $icon = random_gen(16).'.'.$ext;
      move_uploaded_file($_FILES['icon']['tmp_name'], "./files/smilies/".$icon);
    }
    $ZE_SMI->createSmilie(htmlspecialchars($_POST["name"]),
	                        htmlspecialchars($_POST["sc"]),
                          $icon,
						              htmlspecialchars($_POST["cat"]),
						              htmlspecialchars($_POST["age"]),
						              htmlspecialchars($_POST["rank"]));
  }
  if($do == 'editsmilie') {
    $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_name', htmlspecialchars($_POST["name"]));
    $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_sc', $_POST["sc"]);
    $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_cat', htmlspecialchars($_POST["cat"]));
    $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_usk', htmlspecialchars($_POST["age"]));
    $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_lvl', htmlspecialchars($_POST["rank"]));
    if(isset($_FILES['icon'])) {
//      $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_sc', 'jop');
      $img = $ZE_SMI->getInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_pic');
      $path = $_FILES['icon']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $name = random_gen(16).'.'.$ext;
      move_uploaded_file($_FILES['icon']['tmp_name'], "./files/smilies/".$name);
      if($img != false) {
        $file = './files/smilies/'.$img;
        unlink($file);
      }
      $ZE_SMI->updateInfo('smilies', 'smi_id', htmlspecialchars($_POST["smiid"]), 'smi_pic', $name);
    }
  }
  if($do == 'editcat') {
    $ZE_SMI->updateInfo('smilies_category', 'sc_id', htmlspecialchars($_POST["cid"]), 'sc_name', htmlspecialchars($_POST["name"]));
    $ZE_SMI->updateInfo('smilies_category', 'sc_id', htmlspecialchars($_POST["cid"]), 'sc_usk', htmlspecialchars($_POST["age"]));
    $ZE_SMI->updateInfo('smilies_category', 'sc_id', htmlspecialchars($_POST["cid"]), 'sc_lvl', htmlspecialchars($_POST["rank"]));
    echo "done";
    die();
  }
  if($do == 'createcat') {
    $ZE_SMI->createSmilieCategory(htmlspecialchars($_POST["name"]), htmlspecialchars($_POST["age"]), htmlspecialchars($_POST["rank"]));
    echo "done";
    die();
  }
  if($do == 'delcat') {
    $ZE_SMI->deleteInfo('smilies_category', 'sc_id', htmlspecialchars($_POST["cid"]));
    echo "done";
    die();
  }
  if($do == 'delsmilie') {
    $ZE_SMI->deleteSmilie(htmlspecialchars($_POST["smiid"]));
    echo "done";
    die();
  }
  if($do == 'getPD') {
//    echo json_encode($ZE_PROF->getProfileField(htmlspecialchars($_GET["pid"])));
//    die();
  }
}

?>