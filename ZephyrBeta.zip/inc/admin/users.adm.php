<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

authACP('acp_usercenter', $uid, $lvl, $ip, $TPL);

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

if($TPL_DONT != 1) {
  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("UID", $uid);
  $ZE_TPL->assign("ZE_PG", $ZE_SETTINGS->getRankList());
  $ZE_TPL->assign("ZE_USERS", $ZE_USER->listUsersACP());

} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }

  if($do == 'changeAccGroup') {
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', htmlspecialchars($_GET["aid"]), 'acc_global_level', htmlspecialchars($_GET["target"]));
    $ZE_SESS->updateSessionLevel();
    $ZE_SESS->forceUpdateUser(htmlspecialchars($_GET["aid"]));
    echo 'done';
  }
  if($do == 'changeUserGroup') {
    $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', htmlspecialchars($_GET["uid"]), 'user_level', htmlspecialchars($_GET["target"]));
    $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', htmlspecialchars($_GET["uid"]), 'user_level_orig', htmlspecialchars($_GET["target"]));
    $ZE_SESS->updateSessionLevel();
    $ZE_SESS->forceUpdateUser(htmlspecialchars($_GET["uid"]));
    echo 'done';
  }
  if($do == 'changeUserPerm') {
    $uid = htmlspecialchars($_POST["uid"]);
    foreach($_POST as $name => $value) {
      if($name != 'uid' && $name != 'inc' && $name != 'loc' && $name != 'dont' && $name != 'do' && $name != 'sid' && $name != 'changeUserPerm') {
        if($value == 'on') { $value = '1'; }
        $ZE_USER->updateUserPermState($uid, $name, $value);
      }
    }
    $ZE_SESS->forceUpdateUser(htmlspecialchars($_POST["uid"]));
    echo 'done';
  }
  if($do == 'resetUserPerm') {
    $ZE_USER->resetPerm(htmlspecialchars($_GET["uid"]));
    $ZE_SESS->forceUpdateUser(htmlspecialchars($_GET["uid"]));
    echo 'done';
  }

  if($do == 'getUserPerm') {
    $setts = $ZE_USER->getUserPermissions(htmlspecialchars($_GET["uid"]));
    echo json_encode($setts);
    die();
  }

}

?>