<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Initiate Zephyr Parser
if(isset($_GET["dont"])) {
  $TPL_DONT = htmlspecialchars($_GET["dont"]);
  } elseif(isset($_POST["dont"])) {
    $TPL_DONT = htmlspecialchars($_POST["dont"]);
  } else {
  $TPL_DONT = 1;
}

if(isset($_GET["loc"])) {
  $TPL = htmlspecialchars($_GET["loc"]);
  } elseif(isset($_POST["loc"])) {
    $TPL = htmlspecialchars($_POST["loc"]);
  } else {
  $TPL = '';
}

if($TPL_DONT != 1) {
  require_once './class/zephyr.class.php';
  $tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/admin/';
  zephyr::configure("base_url", NULL );
  zephyr::configure("tpl_dir", $tpl_path );
  zephyr::configure("cache_dir", "cache/" );
  zephyr::configure("path_replace", false);
  $ZE_TPL = new zephyr;
}

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

if(isset($_GET["do"])) {
  $doing = htmlspecialchars($_GET["do"])."->\n".q($_GET);
  } elseif(isset($_POST["do"])) {
    $doing = htmlspecialchars($_POST["do"])."->\n".q($_POST);
  } else {
  $doing = 'page opening';
}

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');
$lvl = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_level');

$ip = getenv("REMOTE_ADDR");
$rank = $ZE_SETTINGS->getRankTitle($lvl);

writeLog('acp', "USERID $uid ### IP $ip ### LEVEL $rank ### @".date("Y-m-d H:i:s")." ### TRY ACCESSING ACP\n");

require_once './inc/admin/acpsecure.adm.php';
authACP('show_acp', $uid, $lvl, $ip, $TPL);

writeLog('acp', "USERID $uid ### IP $ip ### LEVEL $rank ### @".date("Y-m-d H:i:s")." ### ACCESSING ACP ### LOCATION $TPL ### DOING $doing\n\n");

switch($TPL){
  case 'news':
    require_once './inc/admin/news.adm.php';
    break;
  case 'lang':
    require_once './inc/admin/lang.adm.php';
    break;
  case 'permissions':
    require_once './inc/admin/permissions.adm.php';
    break;
  case 'users':
    require_once './inc/admin/users.adm.php';
    break;
  case 'rooms':
    require_once './inc/admin/rooms.adm.php';
    break;
  case 'global':
    require_once './inc/admin/global.adm.php';
    break;
  case 'pd':
    require_once './inc/admin/pd.adm.php';
    break;
  case 'info':
    require_once './inc/admin/info.adm.php';
    break;
  case 'shop':
    require_once './inc/admin/shop.adm.php';
    break;
  case 'badwords':
    require_once './inc/admin/badwords.adm.php';
    break;
  case 'patches':
    require_once './inc/admin/patches.adm.php';
    break;
  case 'maintain':
    require_once './inc/admin/maintain.adm.php';
    break;
  case 'reports':
    require_once './inc/admin/reports.adm.php';
    break;
  case 'navigation':
    require_once './inc/admin/navigation.adm.php';
    break;
  case 'avacheck':
    require_once './inc/admin/avacheck.adm.php';
    break;
  case 'smilies':
    require_once './inc/admin/smilies.adm.php';
    break;
  case 'archive':
    require_once './inc/admin/archive.adm.php';
    break;	
}
?>