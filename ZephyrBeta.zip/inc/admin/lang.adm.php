<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

authACP('acp_languages', $uid, $lvl, $ip, $TPL);

if($TPL_DONT != 1) {
  //Include UserClass
  require_once './class/user.class.php';
  $ZE_USER = new user($db);

  //Include SessionClass
  require_once './class/session.class.php';
  $ZE_SESS = new session($db);

  $uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');

  $ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
  $ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
  $ZE_userage = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_age');
  $ZE_username = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
  $languages = $ZE_LANGUAGE->countLanguages();
  $areas = $ZE_LANGUAGE->countAreas();

  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("ZE_UID", $uid);
  $ZE_TPL->assign("ZE_UNAME", $ZE_username);

  $ZE_TPL->assign("ZE_LANG_SWITCH", $languages);
  $ZE_TPL->assign("ZE_AREA_SWITCH", $areas);
  $ZE_TPL->assign($ZE_LANGUAGE->getFull('_acp_lang', DEF_LANG));
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }

  if($do == 'getLangfields') {
    if(isset($_GET["lang"])) {
      $lang = htmlspecialchars($_GET["lang"]);
      } elseif(isset($_POST["lang"])) {
        $lang = htmlspecialchars($_POST["lang"]);
      } else {
      $lang = '';
    }
    if(isset($_GET["area"])) {
      $area = htmlspecialchars($_GET["area"]);
      } elseif(isset($_POST["area"])) {
        $area = htmlspecialchars($_POST["area"]);
      } else {
      $area = '';
    }
    $langs = $ZE_LANGUAGE->getFull($area, $lang, 1);
    echo json_encode($langs);
    die();
  }

  if($do == 'setLangfields') {
    $id = htmlspecialchars($_GET["id"]);
    $lang = htmlspecialchars($_GET["lang"]);
    $code = htmlspecialchars($_GET["code"]);
    $area = htmlspecialchars($_GET["area"]);
    $content = $_GET["content"];
    $ZE_LANGUAGE->updateFull($id, $lang, $code, $area, $content);
    echo 'done';
  }
  if($do == 'createLangfields') {
    $lang = htmlspecialchars($_GET["lang"]);
    $code = htmlspecialchars($_GET["code"]);
    $area = htmlspecialchars($_GET["area"]);
    $content = $_GET["content"];
    $ZE_LANGUAGE->createLang($lang, $code, $area, $content);
    echo 'done';
  }
  if($do == 'deleteLangfields') {
    $id = htmlspecialchars($_GET["id"]);
    $ZE_LANGUAGE->deleteEntry($id);
    echo 'done';
  }
}
?>