<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

authACP('acp_permissions', $uid, $lvl, $ip, $TPL);

if($TPL_DONT != 1) {
  //Include UserClass
  require_once './class/user.class.php';
  $ZE_USER = new user($db);

  //Include SessionClass
  require_once './class/session.class.php';
  $ZE_SESS = new session($db);

  $uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');

  $ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
  $ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
  $ZE_userage = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_age');
  $ZE_username = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');

  $ZE_TPL->assign("ZE_SID", $sid);
  $ZE_TPL->assign("ZE_UID", $uid);
  $ZE_TPL->assign("ZE_UNAME", $ZE_username);
  
  $ZE_GROUPS = $ZE_SETTINGS->getAllGroups();
  $ZE_GC = array();
  
  for($i=0; $i < count($ZE_GROUPS); $i++) {
    $ZE_GC[] = $i;
  }
  $ZE_TPL->assign("ZE_ORDER", $ZE_SETTINGS->getRankOrder($ZE_user_lvl));
  $ZE_TPL->assign("ZE_GROUPS", $ZE_GROUPS);
  $ZE_TPL->assign("ZE_GROUPS_COUNT", $ZE_GC);
  $ZE_TPL->assign("ZE_PERMS", $ZE_SETTINGS->getAllPermissions());
  $ZE_TPL->assign("ZE_PG", $ZE_SETTINGS->getPermG());
  $ZE_TPL->assign("ZE_PGDEL", $ZE_SETTINGS->getPGDeleteList());

//  $ZE_TPL->assign($ZE_LANGUAGE->getFull('_acp_lang', DEF_LANG));
} else {
  if(isset($_GET["do"])) {
    $do = htmlspecialchars($_GET["do"]);
    } elseif(isset($_POST["do"])) {
      $do = htmlspecialchars($_POST["do"]);
    } else {
    $do = '';
  }

  if($do == 'getGroupSettings') {
    if(isset($_GET["gid"])) {
      $gid = htmlspecialchars($_GET["gid"]);
      } elseif(isset($_POST["gid"])) {
        $gid = htmlspecialchars($_POST["gid"]);
      } else {
      $gid = '';
    }
    $setts = $ZE_SETTINGS->getGroupPermissions($gid);
    echo json_encode($setts);
    die();
  }

  if($do == 'changeGroupSettings') {
    $gid = htmlspecialchars($_POST["gid"]);

    $img = $ZE_SETTINGS->getGroupInfo($gid, 'ranks_icon');
    if(isset($_FILES['groupediticon'])) {
      $path = $_FILES['groupediticon']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $name = random_gen(16).'.'.$ext;
      move_uploaded_file($_FILES['groupediticon']['tmp_name'], "./files/groupicons/".$name);
      if($img != false) {
        $file = './files/groupicons/'.$img;
        unlink($file);
      }
      $ZE_SETTINGS->updateGroupInfo($gid, 'ranks_icon', $name);
    }

    foreach($_POST as $name => $value) {
      if($name != 'gid' && $name != 'inc' && $name != 'loc' && $name != 'dont' && $name != 'do' && $name != 'sid' && $name != 'groupeditname' && $name != 'groupediticon' && $name != 'editgroupstate' && $name != 'groupediticondelete') {
        if($value == 'on') { $value = '1'; }
        $ZE_SETTINGS->updateGroupPermState($gid, $name, $value);
      }
    }

    $ZE_SETTINGS->updateGroupInfo($gid, 'ranks_title', htmlspecialchars($_POST["groupeditname"]));
    $ZE_SETTINGS->updateGroupInfo($gid, 'ranks_state', htmlspecialchars($_POST["editgroupstate"]));

    if($_POST["groupediticondelete"] != 0) {
      $file = './files/groupicons/'.$ZE_SETTINGS->getGroupInfo($gid, 'ranks_icon');
      unlink($file);
      $ZE_SETTINGS->updateGroupInfo($gid, 'ranks_icon', '');
    }
    $ZE_SESS->forceUpdateGroup($gid);
    echo 'done';
  }

  if($do == 'createGroupSettings') {
    $imgname = '';
    if(isset($_FILES['groupicon'])) {
      $path = $_FILES['groupicon']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $imgname = random_gen(16).'.'.$ext;
      move_uploaded_file($_FILES['groupicon']['tmp_name'], "./files/groupicons/".$imgname);
    }

    $gid = $ZE_SETTINGS->createGroup(htmlspecialchars('0', $_POST["groupname"]), $imgname, htmlspecialchars($_POST["creategroupstate"]));

    foreach($_POST as $name => $value) {
      if($name != 'gid' && $name != 'inc' && $name != 'loc' && $name != 'dont' && $name != 'do' && $name != 'sid' && $name != 'groupname' && $name != 'groupicon' && $name != 'creategroupstate') {
        if($value == 'on') { $value = '1'; }
        $ZE_SETTINGS->updateGroupPermState($gid, $name, $value);
      }
    }
    echo 'done';
  }

  if($do == 'deleteGroup') {
    $id = htmlspecialchars($_GET["gid"]);
    $ZE_SETTINGS->deleteGroup($id);
    $ZE_SESS->forceUpdateGroup($id);
    echo 'done';
  }

  if($do == 'createPerm') {
    $ZE_SETTINGS->createPerm(htmlspecialchars($_GET["name"]), htmlspecialchars($_GET["desc"]), htmlspecialchars($_GET["shown"]), htmlspecialchars($_GET["group"]), htmlspecialchars($_GET["state"]));
    echo 'done';
  }

  if($do == 'createPermG') {
    $ZE_SETTINGS->createPermG(htmlspecialchars($_GET["shown"]));
    echo 'done';
  }

  if($do == 'deletePerm') {
    $ZE_SETTINGS->deletePerm(htmlspecialchars($_GET["id"]));
    $ZE_SESS->forceUpdateGroup(htmlspecialchars($_GET["id"]));
    echo 'done';
  }

  if($do == 'deletePermG') {
    $ZE_SETTINGS->deletePermG(htmlspecialchars($_GET["id"]));
    echo 'done';
  }
  
  if($do == 'changeOrder') {
    $ZE_SETTINGS->updateGroupInfo(htmlspecialchars($_GET["gid"]), 'ranks_order', htmlspecialchars($_GET["order"]));
    echo 'done';
  }
}
?>