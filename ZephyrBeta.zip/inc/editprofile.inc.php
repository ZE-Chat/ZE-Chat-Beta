<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Initiate Zephyr Parser
if(isset($_GET["dont"])) {
  $TPL_DONT = htmlspecialchars($_GET["dont"]);
  } elseif(isset($_POST["dont"])) {
    $TPL_DONT = htmlspecialchars($_POST["dont"]);
  } else {
  $TPL_DONT = 1;
}

if(isset($_GET["area"])) {
  $TPL = htmlspecialchars($_GET["area"]);
  } elseif(isset($_POST["area"])) {
    $TPL = htmlspecialchars($_POST["area"]);
  } else {
  $TPL = '';
}

if(isset($_GET["acp"])) {
  $acp = htmlspecialchars($_GET["acp"]);
  } elseif(isset($_POST["acp"])) {
    $acp = htmlspecialchars($_POST["acp"]);
  } else {
  $acp = false;
}

if($TPL_DONT != 1) {
  require_once './class/zephyr.class.php';
  $tpl_path = 'styles/'.ZE_USED_STYLE.'/tpl/editprofile/';
  zephyr::configure("base_url", NULL );
  zephyr::configure("tpl_dir", $tpl_path );
  zephyr::configure("cache_dir", "cache/" );
  zephyr::configure("path_replace", false);
  $ZE_TPL = new zephyr;
  $ZE_TPL->assign("ZE_ADMIN", $acp);
}

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');
$lvl = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_level');

if($acp != false && $ZE_SETTINGS->cP('acp_usercenter', $uid, $lvl) != false) {
//Include UserClass
  require_once './class/user.class.php';
  $ZE_USER = new user($db);

  if(isset($_GET["do"])) {
    $doing = htmlspecialchars($_GET["do"])."->\n".q($_GET);
    } elseif(isset($_POST["do"])) {
      $doing = htmlspecialchars($_POST["do"])."->\n".q($_POST);
    } else {
    $doing = 'page opening';
  }

  $ip = getenv("REMOTE_ADDR");
  $rank = $ZE_SETTINGS->getRankTitle($lvl);

  $file = './logs/acp.log';
  $row = "USERID $uid ### IP $ip ### LEVEL $rank ### @".date("Y-m-d H:i:s")." ### ACCESSING USERPROFILE ID$acp ### LOCATION $TPL ### DOING $doing\n\n";
  file_put_contents($file, $row, FILE_APPEND | LOCK_EX);

  $uid = $acp;
}

switch($TPL){
  case 'sett':
    require_once './inc/editprofile/sett.ep.php';
    break;
  case 'main':
    require_once './inc/editprofile/main.ep.php';
    break;
  case 'ava':
    require_once './inc/editprofile/ava.ep.php';
    break;
  case 'gb':
    require_once './inc/editprofile/gb.ep.php';
    break;
  case 'present':
    require_once './inc/editprofile/present.ep.php';
    break;
  case 'friends':
    require_once './inc/editprofile/friends.ep.php';
    break;
  case 'mail':
    require_once './inc/editprofile/mail.ep.php';
    break;
  case 'pd':
    require_once './inc/editprofile/pd.ep.php';
    break;
}
?>