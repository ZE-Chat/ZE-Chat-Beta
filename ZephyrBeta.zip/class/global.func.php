<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
 
function str_shuffle_unicode($str) {
  $tmp = preg_split("//u", $str, -1, PREG_SPLIT_NO_EMPTY);
  shuffle($tmp);
  return join("", $tmp);
}

function isEnabled($func) {
  return is_callable($func) && false === stripos(ini_get('disable_functions'), $func);
}

function random_gen($length)
{
  srand((double)microtime()*1000000);
  $char_list = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $char_list .= "abcdefghijklmnopqrstuvwxyz";
  $char_list .= "1234567890";
  $random = '';

  for($i = 0; $i < $length; $i++)
  {
    $random .= substr($char_list,(rand()%(strlen($char_list))), 1);
  }
  return $random;
}

function getUpdate($path, $name, $url) {
  file_put_contents($path.'/'.$name, fopen($url, 'r'));
  $zip = new ZipArchive;
  $res = $zip->open($name);

  if ($res === TRUE) {
    $zip->extractTo($path);
    $zip->close();
    unlink($path.'/'.$name);
    return true;
  } else {
    return false;
  }
}

function updateCHMOD($path, $file) {
  chmod($path.'/'.$file ,0777);
}

function updateFile($link, $old, $new) {
  $content = file_get_contents($link);
  $content = str_replace($old, $new, $content);
  $handle = fopen($link, "w");
  $content = fputs($handle, $content);
  fclose($handle);
}

function textWrap($text, $length) { 
  $new_text = ''; 
  $usage = '#([^\n\r .]{'.$length.'})#i';
  $text_1 = explode('>',$text); 
  $sizeof = sizeof($text_1); 
  for ($i=0; $i<$sizeof; ++$i) { 
    $text_2 = explode('<',$text_1[$i]); 
      if (!empty($text_2[0])) { 
        $new_text .= preg_replace($usage, '\\1  ', $text_2[0]); 
      } 
      if (!empty($text_2[1])) { 
        $new_text .= '<' . $text_2[1] . '>';    
      } 
    } 
  return $new_text; 
} 

function clock() {
  $now = date('Y-m-d H:i:s');
  return $now;
}

function checkinput($input) {
  return htmlspecialchars($input);
}

function getInfo($user_agent) {
     // OS
    $os = "Unknown OS Platform";

    $os_array = array(
                     '/windows nt 10.0/i'    =>  'Windows 10',
                     '/windows nt 6.3/i'     =>  'Windows 8.1',
                     '/windows nt 6.2/i'     =>  'Windows 8',
                     '/windows nt 6.1/i'     =>  'Windows 7',
                     '/windows nt 6.0/i'     =>  'Windows Vista',
                     '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                     '/windows nt 5.1/i'     =>  'Windows XP',
                     '/windows xp/i'         =>  'Windows XP',
                     '/windows nt 5.0/i'     =>  'Windows 2000',
                     '/windows me/i'         =>  'Windows ME',
                     '/win98/i'              =>  'Windows 98',
                     '/win95/i'              =>  'Windows 95',
                     '/win16/i'              =>  'Windows 3.11',
                     '/macintosh|mac os x/i' =>  'Mac OS X',
                     '/mac_powerpc/i'        =>  'Mac OS 9',
                     '/linux/i'              =>  'Linux',
                     '/ubuntu/i'             =>  'Ubuntu',
                     '/iphone/i'             =>  'iPhone',
                     '/ipod/i'               =>  'iPod',
                     '/ipad/i'               =>  'iPad',
                     '/android/i'            =>  'Android',
                     '/blackberry/i'         =>  'BlackBerry',
                     '/webos/i'              =>  'Mobile'
                     );

    foreach ($os_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $os = $value;
        }
    } 

    if (preg_match('/WOW64/i', $user_agent) || preg_match('/x64/i', $user_agent)) { $os .= ' (x64)'; }

    // Next get the name of the useragent yes seperately and for good reason
    if(preg_match('/MSIE/i',$user_agent) && !preg_match('/Opera/i',$user_agent)) 
    { 
        $bname = 'Internet Explorer'; 
        $ub = "MSIE"; 
    } 
    elseif(preg_match('/Firefox/i',$user_agent)) 
    { 
        $bname = 'Mozilla Firefox'; 
        $ub = "Firefox"; 
    } 
    elseif(preg_match('/Edge/i',$user_agent)) 
    { 
        $bname = 'MS Edge'; 
        $ub = "Edge"; 
    }
    elseif(preg_match('/Chrome/i',$user_agent)) 
    { 
        $bname = 'Google Chrome'; 
        $ub = "Chrome"; 
    } 
    elseif(preg_match('/Safari/i',$user_agent)) 
    { 
        $bname = 'Apple Safari'; 
        $ub = "Safari"; 
    } 
    elseif(preg_match('/Opera/i',$user_agent)) 
    { 
        $bname = 'Opera'; 
        $ub = "Opera"; 
    } 
    elseif(preg_match('/Netscape/i',$user_agent)) 
    { 
        $bname = 'Netscape'; 
        $ub = "Netscape"; 
    } 
    elseif(preg_match('/maxthon/i',$user_agent)) 
    { 
        $bname = 'Maxthon'; 
        $ub = "Maxthon"; 
    } 
    elseif(preg_match('/Konqueror/i',$user_agent)) 
    { 
        $bname = 'Konqueror'; 
        $ub = "Konqueror"; 
    } else {
      $bname = 'Unknown Browser';
      $ub = 'Unknown Version';
    }

    // finally get the correct version number
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
    ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $user_agent, $matches)) {
        // we have no matching number just continue
    }

    // see how many we have
    $i = count($matches['browser']);
    if ($i != 1) {
        //we will have two since we are not using 'other' argument yet
        //see if version is before or after the name
        if (strripos($user_agent,"Version") < strripos($user_agent,$ub)){
            $version= $matches['version'][0];
        }
        else {
            $version= $matches['version'][1];
        }
    }
    else {
        $version= $matches['version'][0];
    }

    // check if we have a number
    if ($version==null || $version=="") {$version="?";}

    return array(
        'userAgent' => $user_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $os,
        'pattern'    => $pattern
    );
}

function q($input) {
    $glue = ', ';
    $function = function ($v, $k) use (&$function, $glue) {
        if (is_array($v)) {
            $arr = [];
            foreach ($v as $key => $value) {
                $arr[] = $function($value, $key);
            }
            $result = "{" . implode($glue, $arr) . "}";
        } else {
            $result = sprintf("%s=%s", $k, var_export($v, true));
        }
        return $result;
    };
    return implode($glue, array_map($function, $input, array_keys($input))) . "\n";
}

function calcAge($birthday) {
  list($d, $m, $y) = explode('-', $birthday);
  if(strlen($m) < 2) { $m = '0'.$m; }
  if(strlen($d) < 2) { $d = '0'.$d; }
  $birthday = $y.$m.$d;
  $age = floor((date("Ymd") - $birthday) / 10000);
  return $age;
}

//$changer = $ZE_SETT->chat_link_protect;

function link2click($str) {
  global $changer;
  if($changer === 0 || !isset($changer)) {
    $search = array('/&amp;/',);
    $replace = array('&',);
    $str = preg_replace( $search, $replace, $str);
    $s_patter[] = '"(( |^)((ftp|http|https){1}://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)"i';
    $r_patter[] = ' <a href=\'\1\' target=\'_blank\'>Link</a>';
    $s_patter[] = '"( |^)(www.[-a-zA-Z0-9@:%_\+.~#?&//=]+)"i';
    $r_patter[] = '\\1 <a href=\'http://\2\' target=\'_blank\'>Link</a>';
    $s_patter[] = '"([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})"i';
    $r_patter[] = ' <a href=\'mailto:\1\'>Email</a>';
    $str = preg_replace($s_patter,$r_patter,$str);
    return $str;
  } elseif($changer === 'link') {
    $search = array('/&amp;/',);
    $replace = array('&',);
    $str = preg_replace( $search, $replace, $str);
    $s_patter[] = '"(( |^)((ftp|http|https){1}://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)"i';
    $r_patter[] = ' <a href=\'\1\' target=\'_blank\'>\1</a>';
    $s_patter[] = '"( |^)(www.[-a-zA-Z0-9@:%_\+.~#?&//=]+)"i';
    $r_patter[] = '\\1 <a href=\'http://\2\' target=\'_blank\'>http://\2</a>';
    $s_patter[] = '"([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})"i';
    $r_patter[] = ' <a href=\'mailto:\1\'>\1</a>';
    $str = preg_replace($s_patter,$r_patter,$str);
    return $str;
  } else {
    $search = array('/&amp;/',);
    $replace = array('&',);
    $str = preg_replace( $search, $replace, $str);
    $s_patter[] = '"(( |^)((ftp|http|https){1}://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)"i';
    $r_patter[] = ' <span id=\'4sdf8f2s1\' class=\'chatlink\' onClick=\'zeLink(this)\' linkdata=\'\1\' >Link</span>';
    $s_patter[] = '"( |^)(www.[-a-zA-Z0-9@:%_\+.~#?&//=]+)"i';
    $r_patter[] = '\\1 <span id=\'4sdf8f2s1\' class=\'chatlink\' onClick=\'zeLink(this)\' linkdata=\'http://\2\' >Link</span>';
    $s_patter[] = '"([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})"i';
    $r_patter[] = ' <a href=\'mailto:\1\'>Email</a>';
    $str = preg_replace($s_patter,$r_patter,$str);
    $str = preg_replace('/4sdf8f2s1/', 'random_gen(8)', $str);
    return $str;
  }
}

/**
function link2click($str) {
  $str .= " ";
  $search = array('/&amp;/',);
  $replace = array('&',);
  $str = preg_replace($search, $replace, $str);
  $s_patter = array("/(s?ftp|https?|www):\/\/[a-z0-9-\.]+\.[a-z]{2,3}\/?\??[a-z0-9-\.\s]*(\s|\/)/i",
                    "/[_a-z0-9!#$%&\\'*+\-\/=?^_`.{|}~]+@[a-z0-9-\.]+\.[a-z]{2,3}/i");
  $r_patter = array("<span onClick='zeLink(\'$0\')'>Link</span>",
                    "<a href='mailto:$0'>Mail</a>");
  $str = preg_replace($s_patter,$r_patter,$str);
  return $str;
}
**/

function redoDate($str) {
  $tmp_full_date = $str;
  $tmp_split_full_date = explode(" ", $tmp_full_date);
  $tmp_split_date = explode("-", $tmp_split_full_date[0]);
  $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
  $str = 'Am '.$tmp_split_date.' um '.$tmp_split_full_date[1].' Uhr';
  return $str;
}

function redoDateArr($str) {
  $tmp_full_date = $str;
  $tmp_split_full_date = explode(" ", $tmp_full_date);
  $tmp_split_date = explode("-", $tmp_split_full_date[0]);
  $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
  $arr = array('day' => $tmp_split_date, 'time' => $tmp_split_full_date[1]);
  return $arr;
}

function str_replace2($findro, $replacementro, $subjectro, $limitro = 0, &$countro = 0){
  if ($limitro == 0) {
    return str_replace($findro, $replacementro, $limitro, $countro);
  }
  $ptn = '/' . preg_quote($findro) . '/';
  return preg_replace($ptn, $replacementro, $subjectro, $limitro, $countro);
}

function msort($array, $key, $sort_flags = SORT_REGULAR) {
    if (is_array($array) && count($array) > 0) {
        if (!empty($key)) {
            $mapping = array();
            foreach ($array as $k => $v) {
                $sort_key = '';
                if (!is_array($key)) {
                    $sort_key = $v[$key];
                } else {
                    foreach ($key as $key_key) {
                        $sort_key .= $v[$key_key];
                    }
                    $sort_flags = SORT_STRING;
                }
                $mapping[$k] = $sort_key;
            }
            asort($mapping, $sort_flags);
            $sorted = array();
            foreach ($mapping as $k => $v) {
                $sorted[] = $array[$k];
            }
            return $sorted;
        }
    }
    return $array;
}

function writeLog($log, $content) {
  $file = './logs/'.$log.'.log';
  file_put_contents($file, $content, FILE_APPEND | LOCK_EX);
}

?>