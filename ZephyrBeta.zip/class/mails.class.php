<?php
/**
 *	This file is part of "ZE Chat v0.9".
 *
 *	"ZE Chat v0.9" is free softwore. Feel free to use and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	"ZE Chat v0.9" is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	Developed by Alexander Pakusch aka Zion, 2010-2014
 *	You are not allowed to sell this software or remove the Copyrights.
 *
 *	<http://www.zevolutions.de/>
 *	<admin@zevolutions.de>
 */

class mails {

  public $_count = 0;
  public $_data = array();

  public $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getSubjects($uid) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_mail` WHERE `mail_sender` = '$uid' OR `mail_getter` = '$uid' ORDER BY `mail_id` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      if($row->mail_sender != '0') {
        if($row->mail_sender == $uid) {
          $who = 'sender';
          $other = $row->mail_getter;
          $query2 =
            mysqli_query($this->_db, "SELECT `user_name` FROM `".ZE_PRE."_user` WHERE `user_id` = '$row->mail_getter'")
              OR die("Error: <br>".mysqli_error($this->_db));
          if(mysqli_num_rows($query2) > 0){
            while($row2 = mysqli_fetch_object($query2)){
              $tname = $row2->user_name;
            }
          } else {
            $tname = 'Unbekannt/Gelöscht';
          }
        } else {
          $who = 'getter';
          $other = $row->mail_sender;
          $query2 =
            mysqli_query($this->_db, "SELECT `user_name` FROM `".ZE_PRE."_user` WHERE `user_id` = '$row->mail_sender'")
              OR die("Error: <br>".mysqli_error($this->_db));
          if(mysqli_num_rows($query2) > 0){
            while($row2 = mysqli_fetch_object($query2)){
              $tname = $row2->user_name;
            }
          } else {
            $tname = 'Unbekannt/Gelöscht';
          }
        }
      } else {
        $tname = 'System';
        $who = 'getter';
        $other = $row->mail_getter;
      }
      $tdate = $this->redoDate($row->mail_date);
      $expire_date = strtotime($row->mail_date . ' + 14 days');
      if (time() > $expire_date){
        $candel =  1;
      } else {
        $candel =  0;
      }
      $this->_data[$this->_count] =
      array("id"      => "$row->mail_id",
            "who"     => $who,
            "other"   => $other,
            "tname"   => $tname,
            "sender"  => "$row->mail_sender",
            "getter"  => "$row->mail_getter",
            "date"    => $tdate,
            "candel"  => $candel,
            "subject" => "$row->mail_subject",
            "text"    => "$row->mail_text",
            "state"   => "$row->mail_state");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  private function redoDate($str) {
    $tmp_full_date = $str;
    $tmp_split_full_date = explode(" ", $tmp_full_date);
    $tmp_split_date = explode("-", $tmp_split_full_date[0]);
    $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
    $str = 'am '.$tmp_split_date.' um '.$tmp_split_full_date[1].' Uhr';
    return $str;
  }

  public function getMail($mid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_mail` WHERE `mail_id` = '$mid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data = array(
            "id"      => $mid,
            "sender"  => "$row->mail_sender",
            "getter"  => "$row->mail_getter",
            "date"    => "$row->mail_date",
            "subject" => "$row->mail_subject",
            "text"    => "$row->mail_text",
            "state"   => "$row->mail_state");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function sendMail($aid, $gid, $time, $subject, $text) {
    $text = mysqli_real_escape_string($this->_db, $text);
    $query = "INSERT INTO `".ZE_PRE."_mail`
     (mail_sender,
      mail_getter,
      mail_date,
      mail_subject,
      mail_text,
      mail_state)
    VALUES
     ('$aid',
      '$gid',
      '$time',
      '$subject',
      '$text',
      '1')";
    $insert = mysqli_query($this->_db, $query);
  }

  public function updateInfo($mid, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_mail` Set `$field` = '$value' WHERE `mail_id` = '$mid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function deleteMail($mid) {
    $query = "DELETE FROM `".ZE_PRE."_mail` WHERE `mail_id` = '$mid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function countNewMails($uid) {
    $query = mysqli_query($this->_db, "SELECT `mail_id` FROM `".ZE_PRE."_mail` WHERE `mail_getter` = '$uid' AND `mail_state` = '1'")
      OR die("Error: <br>".mysqli_error($this->_db));
    $this->_count = mysqli_num_rows($query);
    mysqli_free_result($query);
    return $this->_count;
  }

  public function countMails($uid) {
    $query = mysqli_query($this->_db, "SELECT `mail_id` FROM `".ZE_PRE."_mail` WHERE `mail_getter` = '$uid'")
      OR die("Error: <br>".mysqli_error($this->_db));
    $this->_count = mysqli_num_rows($query);
    mysqli_free_result($query);
    return $this->_count;
  }

}
?>