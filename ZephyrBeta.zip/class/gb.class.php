<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class guestbook {

  public $_count = 0;
  public $_data = array();

  public $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getAllEntries($uid, $mode) {
    $this->_count=0;
    if($mode == 'all') {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_guestbook` WHERE `gb_getter` = '$uid' ORDER BY `gb_id` DESC")
          OR die("Error: <br>".mysqli_error($this->_db));
    } else {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_guestbook` WHERE `gb_getter` = '$uid' AND (`gb_sender` = '$mode' OR `gb_state` = '1') ORDER BY `gb_id` DESC")
          OR die("Error: <br>".mysqli_error($this->_db));
    }
    while($row = mysqli_fetch_object($query)) {
      $tmp_name = "Unbekannt";
      $query2 =
        mysqli_query($this->_db, "SELECT `user_name` FROM `".ZE_PRE."_user` WHERE `user_id` = '$row->gb_sender'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $tmp_name = $row2->user_name;
      }
      $newdate = $this->redoDate($row->gb_date);
      $this->_data[$this->_count] =
      array("id"     => "$row->gb_id",
            "sender" => "$row->gb_sender",
            "sname"  => $tmp_name,
            "getter" => "$row->gb_getter",
            "date"   => $newdate,
            "text"   => "$row->gb_text",
            "state"  => "$row->gb_state",
            "newgb"  => "$row->gb_new");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function makeEntry($uid, $aid, $time, $text, $state) {
    $text = mysqli_real_escape_string($this->_db, $text);
    $query = "INSERT INTO `".ZE_PRE."_guestbook`
     (gb_sender,
      gb_getter,
      gb_date,
      gb_text,
      gb_state,
      gb_new)
    VALUES
     ('$aid',
      '$uid',
      '$time',
      '$text',
      '$state',
      '1')";
    $insert = mysqli_query($this->_db, $query);
//    $query = "UPDATE `".ZE_PRE."_session` Set `sess_update` = '1' WHERE `sess_user_id` = '$uid'";
//     $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));
  }

  public function updateInfo($gid, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_guestbook` Set `$field` = '$value' WHERE `gb_id` = '$gid'";
    $update = mysqli_query($this->_db, $query);
  }
  
  public function markRead($uid) {
    $query = "UPDATE `".ZE_PRE."_guestbook` Set `gb_new` = '0' WHERE `gb_getter` = '$uid'";
    $update = mysqli_query($this->_db, $query);
  }
  
  private function redoDate($str) {
    $tmp_full_date = $str;
    $tmp_split_full_date = explode(" ", $tmp_full_date);
    $tmp_split_date = explode("-", $tmp_split_full_date[0]);
    $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
    $str = 'Am '.$tmp_split_date.' um '.$tmp_split_full_date[1].' Uhr';
    return $str;
  }

  public function deleteEntry($gid) {
    $query = "DELETE FROM `".ZE_PRE."_guestbook` WHERE `gb_id` = '$gid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function countNewEntries($uid) {
    $this->_count=0;
    $query = mysqli_query($this->_db, "SELECT `gb_id` FROM `".ZE_PRE."_guestbook` WHERE `gb_getter` = '$uid' AND `gb_new` = '1'")
      OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function countEntries($uid) {
    $this->_count=0;
    $query =
      mysqli_query($this->_db, "SELECT `gb_id` FROM `".ZE_PRE."_guestbook` WHERE `gb_getter` = '$uid' ORDER BY `gb_id` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

}

?>