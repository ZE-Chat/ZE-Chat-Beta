<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class room {
  private $_count = 0;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getRoomsFull($userlvl, $userage) {
    $this->_count = 0;
    $this->_data = array();
    if($userlvl < 80) {
      $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_room` WHERE
                  `room_visa_req_user_min_age` <= '$userage'
                  AND
                  `room_visa_req_user_max_age` >= '$userage'
                  ORDER BY `room_id`, `room_cat_id`, `room_temp`")
        OR die("Error: <br>".mysqli_error($this->_db));
    } else {
      $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_room` ORDER BY `room_id`, `room_cat_id`, `room_temp` ASC")
        OR die("Error: <br>".mysqli_error($this->_db));
    }
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count]
      = array(
              "room_id"                    => "$row->room_id",
              "room_cat_id"                => "$row->room_cat_id",
              "room_name"                  => "$row->room_name",
              "room_topic"                 => "$row->room_topic",
              "room_rules"                 => "$row->room_rules",
              "room_show_rules"            => "$row->room_show_rules",
              "room_welcome"               => "$row->room_welcome",
              "room_visa_req_user_min_age" => "$row->room_visa_req_user_min_age",
              "room_visa_req_user_max_age" => "$row->room_visa_req_user_max_age",
              "room_state"                 => "$row->room_state",
              "room_temp"                  => "$row->room_temp",
              "room_owner_id"              => "$row->room_owner_id",
              "room_pass"                  => "$row->room_pass",
              "room_freeze_online_points"  => "$row->room_freeze_online_points",
              "room_log_switch"            => "$row->room_log_switch",
              "room_opened_time"           => "$row->room_opened_time",
              "room_bot"                   => "$row->room_bot",
              "room_max"                   => "$row->room_max",
              "room_color"                 => "$row->room_color",
              "room_bg"                    => "$row->room_background",
              "room_image"                 => "$row->room_image");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getRoom($rid) {
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_room` WHERE `room_id` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[0]
      = array(
              "room_id"                    => "$row->room_id",
              "room_cat_id"                => "$row->room_cat_id",
              "room_name"                  => "$row->room_name",
              "room_topic"                 => "$row->room_topic",
              "room_rules"                 => "$row->room_rules",
              "room_show_rules"            => "$row->room_show_rules",
              "room_welcome"               => "$row->room_welcome",
              "room_visa_req_user_min_age" => "$row->room_visa_req_user_min_age",
              "room_visa_req_user_max_age" => "$row->room_visa_req_user_max_age",
              "room_state"                 => "$row->room_state",
              "room_temp"                  => "$row->room_temp",
              "room_owner_id"              => "$row->room_owner_id",
              "room_pass"                  => "$row->room_pass",
              "room_freeze_online_points"  => "$row->room_freeze_online_points",
              "room_log_switch"            => "$row->room_log_switch",
              "room_opened_time"           => "$row->room_opened_time",
              "room_bot"                   => "$row->room_bot",
              "room_max"                   => "$row->room_max",
              "room_color"                 => "$row->room_color",
              "room_bg"                    => "$row->room_background",
              "room_image"                 => "$row->room_image");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function updateCompleteRoom($rid, $cat_id, $name, $topic, $rules, $show_rules, $welcome, $user_lvl, $min_age, $max_age, $state, $pass, $fop) {
    $query = "UPDATE `".ZE_PRE."_room` Set
      `room_cat_id` = '$cat_id',
      `room_name` = '$name',
      `room_topic` = '$topic',
      `room_rules` = '$rules',
      `room_show_rules` = '$show_rules',
      `room_welcome` = '$welcome',
      `room_visa_req_user_lvl` = '$user_lvl',
      `room_visa_req_user_min_age` = '$min_age',
      `room_visa_req_user_max_age` = '$max_age',
      `room_state` = '$state',
      `room_pass` = '$pass',
      `room_freeze_online_points` = '$fop'
    WHERE `room_id` = '$rid'";
    $update = mysqli_query($this->_db, $query) OR die("Error <br>".mysqli_error($this->_db));
  }

  public function updateRoom($roomid, $field, $value) {
    $query = "UPDATE `".ZE_PRE."_room` Set `$field` = '$value' WHERE `room_id` = '$roomid'";
      $update = mysqli_query($this->_db, $query);
  }

  public function getInfo($s_field, $s_param, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_room` WHERE `$s_field` = '$s_param'")
        OR die("Error <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        return $row->$field;
      }
    mysqli_free_result($query);
  }

  public function countRooms($cid, $lvl, $age) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `room_cat_id` FROM `".ZE_PRE."_room` WHERE (`room_cat_id` = '$cid') AND (`room_visa_req_user_lvl` <= '$lvl') AND (`room_visa_req_user_min_age` <= '$age' AND `room_visa_req_user_max_age` >= '$age')")
        OR die("Error <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $this->_count++;
      }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function getRoomName($rid) {
    $query =
      mysqli_query($this->_db, "SELECT `room_name` FROM `".ZE_PRE."_room` WHERE `room_id` = '$rid'")
        OR die("Error <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        return $row->room_name;
      }
    mysqli_free_result($query);
  }
  
  public function updateInfo($rid, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_room` Set `$field` = '$value' WHERE `room_id` = '$rid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function removeBot($bid) {
    $bid = mysqli_real_escape_string($this->_db, $bid);
    $query = "UPDATE `".ZE_PRE."_room` Set `room_bot` = '0' WHERE `room_bot` = '$bid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function getRoomList($userlvl, $userage) {
    $this->_count = 0;
    if($userlvl < 80) {
    $query =
      mysqli_query($this->_db, "SELECT `room_id`, `room_name`, `room_pass` FROM `".ZE_PRE."_room` WHERE
                  `room_visa_req_user_lvl` <= '$userlvl'
                  AND
                  `room_visa_req_user_min_age` <= '$userage'
                  AND
                  `room_visa_req_user_max_age` >= '$userage' ORDER BY `room_id`")
        OR die("Error: <br>".mysqli_error($this->_db));
    } else {
      $query =
      mysqli_query($this->_db, "SELECT `room_id`, `room_name`, `room_pass` FROM `".ZE_PRE."_room` ORDER BY `room_id`")
        OR die("Error: <br>".mysqli_error($this->_db));
    }
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count]
      = array(
              "room_id"                    => "$row->room_id",
              "room_name"                  => "$row->room_name",
              "room_topic"                 => "$row->room_topic",
              "room_rules"                 => "$row->room_rules",
              "room_show_rules"            => "$row->room_show_rules",
              "room_state"                 => "$row->room_state",
              "room_pass"                  => "$row->room_pass",
              "room_max"                   => "$row->room_max");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getRoomListADM() {
    $this->_data = array(); 
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `room_id`, `room_name` FROM `".ZE_PRE."_room` ORDER BY `room_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count]
      = array(
              "room_id"                    => "$row->room_id",
              "room_name"                  => "$row->room_name");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getRoomRules($roomid) {
    $query =
      mysqli_query($this->_db, "SELECT `room_rules` FROM `".ZE_PRE."_room` WHERE `room_id` = '$roomid' AND `room_show_rules` > '2'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->room_rules;
    }
  }

  public function getRoomWelcome($roomid) {
    $query =
      mysqli_query($this->_db, "SELECT `room_welcome` FROM `".ZE_PRE."_room` WHERE `room_id` = '$roomid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->room_welcome;
    }
  }
  
  public function getRoomOptions() {
    $data = '';
    $query =
      mysqli_query($this->_db, "SELECT `room_id`, `room_name` FROM `".ZE_PRE."_room` ORDER BY `room_id`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $data .= '<option value="'.$row->room_id.'">'.$row->room_name.'</option>';
    }
    mysqli_free_result($query);
    return $data;
  }

  public function deleteRoom($roomid) {
    $image = $this->getInfo('room_id', $roomid, 'room_image');
    if($image != '') {
      $file = './pic/roombg/'.$image;
      unlink($file);
    }
    $query = "DELETE FROM `".ZE_PRE."_room` WHERE `room_id` = '$roomid'";
      $delete = mysqli_query($this->_db, $query);
  }

  public function checkRooms() {
    $query =
      mysqli_query($this->_db, "SELECT `room_id` FROM `".ZE_PRE."_room` WHERE `room_temp` = '1'");
        while($row = mysqli_fetch_object($query)) {
          $tmp = $row->room_id;
          if($this->countUserInRoom($tmp) == 0) {
            $check_time = time();
            $room_time = $row->room_opened_time;
            $room_time = strtotime($room_time);
            $room_time = $room_time+60;
            $checking = $check_time-$room_time;
            if($checking > 0) {
              $this->deleteRoom($tmp);
            }
          }
        }
    mysqli_free_result($query);
  }

  public function countUserInRoom($roomid) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `sr_sid` FROM `".ZE_PRE."_session_room` WHERE `sr_rid` = '$roomid'")
        OR die("Error <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function switchRooms($roomid, $newid) {
      $query = "UPDATE `".ZE_PRE."_room` Set `room_id` = '0' WHERE `room_id` = '$newid'";
        $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_room` Set `room_id` = '$newid' WHERE `room_id` = '$roomid'";
        $update = mysqli_query($this->_db, $query) OR die("2Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_room` Set `room_id` = '$roomid' WHERE `room_id` = '0'";
        $update = mysqli_query($this->_db, $query) OR die("3Error <br>".mysqli_error($this->_db));
  }

  public function getUserInRoom($roomid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sess_user_id`, `sess_online_status`, `sess_room_owner` FROM `".ZE_PRE."_session` WHERE `sess_room_id` = '$roomid' ORDER BY `sess_logged_in`")
        OR die("Error <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $query2 =
        mysqli_query($this->_db, "SELECT `user_name`, `user_level` FROM `".ZE_PRE."_user` WHERE `user_id` = '$row->sess_user_id'")
          OR die("Error <br>".mysqli_error($this->_db));
        while($row2 = mysqli_fetch_object($query2)) {
          $name = $row2->user_name;
          $level = $row2->user_level;
        }
      $this->_data[$this->_count]
      = array(
              "name"          => "$name",
              "user_id"       => "$row->sess_user_id",
              "level"         => "$level",
              "online_status" => "$row->sess_online_status",
              "owner"         => "$row->sess_room_owner");
      $this->_count++;
      }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getInformation($uid, $number) {

    $this->_count = 0;
    $this->_data = array();

    $tmp_data = array();

    $query =
      mysqli_query($this->_db, "SELECT `fl_friend_1`, `fl_friend_2` FROM `".ZE_PRE."_friendlist` WHERE (`fl_friend_1` = '$uid' || `fl_friend_2` = '$uid')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      if($row->fl_friend_1 == $uid) {
        $check = $row->fl_friend_2;
      } else {
        $check = $row->fl_friend_1;
      }
      $query2 = mysqli_query($this->_db, "SELECT `blog_id`, `blog_user_id`, `blog_date`, `blog_votes`, `blog_subject`, `blog_tags` FROM `".ZE_PRE."_blog` WHERE `blog_user_id` = '$check' ORDER BY `blog_date` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $this->_data[$this->_count] =
          array("dir"    => "blog",
                "id"     => "$row2->blog_id",
                "userid" => "$row2->blog_user_id",
                "date"   => "$row2->blog_date",
                "subject"=> "$row2->blog_subject",
                "tags"   => "$row2->blog_tags",
                "votes"  => "$row2->blog_votes");
        $this->_count++;
      }
      $query3 =
        mysqli_query($this->_db, "SELECT `fl_friend_1`, `fl_friend_2`, `fl_date` FROM `".ZE_PRE."_friendlist` WHERE (`fl_friend_1` = '$check' || `fl_friend_2` = '$check') AND `fl_state` = '3'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row3 = mysqli_fetch_object($query3)) {
        if($row3->fl_friend_1 == $check) {
          $checker = $row3->fl_friend_2;
        } else {
          $checker = $row3->fl_friend_1;
        }
        $fldate = strtotime($row3->fl_date);
        $this->_data[$this->_count] =
          array("dir"    => "friends",
                "id"     => "$check",
                "userid" => "$checker",
                "date"   => "$fldate",
                "subject"=> "$this->_count",
                "tags"   => "",
                "votes"  => "");
        $this->_count++;
      }
    }

    usort($this->data_array, function($item1, $item2) {
      $ts1 = $item1['date'];
      $ts2 = $item2['date'];
      return $ts2 - $ts1;
    });

    mysqli_free_result($query);
    return $this->_data;
  }

  public function createRoom($cat_id, $name, $topic, $rules, $show_rules, $welcome, $user_lvl, $min_age, $max_age, $room_state, $temp, $owner, $pass, $fop, $log, $opened, $bot, $col, $bgcol, $bgimg, $max='0') {
    $query = "INSERT INTO `".ZE_PRE."_room`
     (room_cat_id,
      room_name,
      room_topic,
      room_rules,
      room_show_rules,
      room_welcome,
      room_visa_req_user_min_age,
      room_visa_req_user_max_age,
      room_state,
      room_temp,
      room_owner_id,
      room_pass,
      room_freeze_online_points,
      room_log_switch,
      room_opened_time,
      room_bot,
      room_max,
      room_color,
      room_background,
      room_image)
      VALUES
     ('$cat_id',
      '$name',
      '$topic',
      '$rules',
      '$show_rules',
      '$welcome',
      '$min_age',
      '$max_age',
      '$room_state',
      '$temp',
      '$owner',
      '$pass',
      '$fop',
      '$log',
      '$opened',
      '$bot',
      '$max',
      '$col',
      '$bgcol',
      '$bgimg')";
    $create = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
    $room_id = mysqli_insert_id($this->_db);
    return $room_id;
  }
}

?>