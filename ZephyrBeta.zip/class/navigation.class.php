<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class nav {

  private $_count;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getNav() {
    $this->_count = 0;
    $this->_data = array('items' => array(), 'parents' => array());
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_menu` ORDER BY `menu_parent`, `menu_order`, `menu_label`")
        OR die("Error: <br>".mysqli_error($this->_db));

    while($items = mysqli_fetch_assoc($query)) {
      $this->_data['items'][$items['menu_id']] = $items;
      $this->_data['parents'][$items['menu_parent']][] = $items['menu_id'];
    }

    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getSpecificNav($id) {
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_menu` WHERE `menu_id` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));

    $this->_data = mysqli_fetch_assoc($query);

    mysqli_free_result($query);
    return $this->_data;
  }

  public function addNav($order, $parent, $label, $htmlid, $state, $special, $groups, $onclick, $p1, $p2, $p3, $p4, $icon) {
    $p1 = mysqli_real_escape_string($this->_db, $p1);
    $p2 = mysqli_real_escape_string($this->_db, $p2);
    $p3 = mysqli_real_escape_string($this->_db, $p3);
    $p4 = mysqli_real_escape_string($this->_db, $p4);
    $query = "INSERT INTO `".ZE_PRE."_menu`
     (menu_order,
      menu_parent,
      menu_label,
      menu_htmlid,
      menu_state,
      menu_special,
      menu_groups,
      menu_onclick,
      menu_param_1,
      menu_param_2,
      menu_param_3,
      menu_param_4,
      menu_icon)
      VALUES
     ('$order',
      '$parent',
      '$label',
      '$htmlid',
      '$state',
      '$special',
      '$groups',
      '$onclick',
      '$p1',
      '$p2',
      '$p3',
      '$p4',
      '$icon')";
    $write = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function deleteNav($id) {
    $query = "DELETE FROM `".ZE_PRE."_menu` WHERE `menu_id` = '$id'";
      $delete = mysqli_query($this->_db, $query);
  }

  public function getInfo($s_field, $s_param, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_menu` WHERE `$s_field` = '$s_param'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }
  
  public function updateInfo($id, $field, $value) {
    $query = "UPDATE `".ZE_PRE."_menu` Set `$field` = '$value' WHERE `menu_id` = '$id'";
    $update = mysqli_query($this->_db, $query);
  }

}

?>