<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class report {

  public $_count = 0;
  public $_data = array();

  public $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getReports() {
    $this->_count = 0;
    $this->_data = array();
    $now = time();
    $query =
      mysqli_query($this->_db, "SELECT `rep_id`, `rep_user`, `rep_target`, `rep_date`, `rep_subject`, `rep_inc`, `rep_state`, `rep_solved_date`, `rep_solved_by` FROM `".ZE_PRE."_report` ORDER BY `rep_id` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $dati = date("d.m.Y - H:i:s", $row->rep_date);
      $datt = explode(" - ", $dati);
      if(date('Y-m-d') == date('Y-m-d', $row->rep_date)) {
        $datt1 = $datt[1];
        $datt2 = $datt[0];
      } else {
        $datt1 = $datt[0];
        $datt2 = $datt[1];
      }
      $datt = $datt[1];
      $this->_data[$this->_count] =
      array("id"      => "$row->rep_id",
            "rep_uid" => "$row->rep_user",
            "uname"   => "",
            "rep_tid" => "$row->rep_target",
            "date"    => $datt1,
            "date2"   => $datt2,
            "subject" => "$row->rep_subject",
            "inc"     => "$row->rep_inc",
            "state"   => "$row->rep_state",
            "sdate"   => "$row->rep_solved_date",
            "sby"     => "$row->rep_solved_by");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getReport($rid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_report` WHERE `rep_id` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data =
      array("id"        => "$row->rep_id",
            "rep_uid"   => "$row->rep_user",
            "rep_uname" => "",
            "rep_uip"   => "$row->rep_user_ip",
            "rep_tid"   => "$row->rep_target",
            "rep_tip"   => "$row->rep_target_ip",
            "rep_tname" => "",
            "date"      => "$row->rep_date",
            "subject"   => "$row->rep_subject",
            "inc"       => "$row->rep_inc",
            "area1"     => "$row->rep_area_id_1",
            "area2"     => "$row->rep_area_id_2",
            "text"      => "$row->rep_text",
            "state"     => "$row->rep_state",
            "sdate"     => "$row->rep_solved_date",
            "sby"       => "$row->rep_solved_by",
            "stext"     => "$row->rep_solved_text");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getMessageReport($mid) {
    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_message` WHERE `mess_id` = '$mid'") OR die("Error1: <br>".mysqli_error($this->_db));

    while($row = mysqli_fetch_object($query)) {
      $this->_data = "<span style=\"font-size: 60%; font-style:italic;\">(".date("d.m. H:i:s", $row->mess_write_time).")</span> $row->mess_author_name: $row->mess_content";
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getRoomNameReport($rid) {
    $query =
      mysqli_query($this->_db, "SELECT `room_name` FROM `".ZE_PRE."_room` WHERE `room_id` = '$rid'")
        OR die("Error <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        return $row->room_name;
      }
    mysqli_free_result($query);
  }

  public function createReport($uid, $uip, $tid, $tip, $subject, $inc, $area1, $area2, $text) {
    $now = time();
    $subject = mysqli_real_escape_string($this->_db, $subject);
    $text = mysqli_real_escape_string($this->_db, $text);
    $query = "INSERT INTO `".ZE_PRE."_report`
     (rep_user,
      rep_user_ip,
      rep_target,
      rep_target_ip,
      rep_date,
      rep_subject,
      rep_inc,
      rep_area_id_1,
      rep_area_id_2,
      rep_text,
      rep_state,
      rep_solved_date,
      rep_solved_by,
      rep_solved_text)
    VALUES
     ('$uid',
      '$uip',
      '$tid',
      '$tip',
      '$now',
      '$subject',
      '$inc',
      '$area1',
      '$area2',
      '$text',
      '1',
      '',
      '',
      '')";
    $do_it = mysqli_query($this->_db, $query);
    $rep_id = mysqli_insert_id($this->_db);
  }

  public function updateInfo($id, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_report` Set `$field` = '$value' WHERE `rep_id` = '$id'";
    $update = mysqli_query($this->_db, $query);
  }

  public function deleteInfo($id) {
    $query = "DELETE FROM `".ZE_PRE."_report` WHERE `rep_id` = '$id'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function getInfo($field, $s_field, $value) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_report` WHERE `$s_field` = '$value'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }

  public function countOpenTickets() {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `rep_id` FROM `".ZE_PRE."_report` WHERE `rep_state` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }
}
?>