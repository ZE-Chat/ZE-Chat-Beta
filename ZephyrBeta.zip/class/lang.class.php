<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class lang {
  private $_count = 0;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function updateInfo($id, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_lang` Set `$field` = '$value' WHERE `lang_id` = '$id'";
    $update = mysqli_query($this->_db, $query);
  }

  public function deleteEntry($id) {
    $query = "DELETE FROM `".ZE_PRE."_lang` WHERE `lang_id` = '$id'";
      $delete = mysqli_query($this->_db, $query);
  }

  public function updateFull($id, $lang, $code, $area, $content) {
    $code = mysqli_real_escape_string($this->_db, $code);
    $area = mysqli_real_escape_string($this->_db, $area);
    $content = mysqli_real_escape_string($this->_db, $content);
    $query = "UPDATE `".ZE_PRE."_lang` Set `lang_code` = '$code', `lang_area` = '$area', `lang_content` = '$content' WHERE `lang_id` = '$id'";
    $update = mysqli_query($this->_db, $query);
  }

  public function getInfo($id, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_lang` WHERE `lang_id` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->$field;
    }
    mysqli_free_result($query);
  }

  public function getWord($lang, $area, $key) {
    $query =
      mysqli_query($this->_db, "SELECT `lang_content` FROM `".ZE_PRE."_lang` WHERE (`lang_language` = '$lang' AND `lang_area` = '$area' AND `lang_code` = '$key')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->lang_content;
    }
    mysqli_free_result($query);
  }

  public function getFull($area, $lang, $admin=0) {
    $this->_data = array();
    $this->_count = 0;

    if($admin != 0) {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_lang` WHERE (`lang_language` = '$lang' AND `lang_area` = '$area') ORDER BY `lang_code`")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $this->_data[$this->_count] =
        array("id"                 => "$row->lang_id",
              "language"           => "$row->lang_language",
              "code"               => "$row->lang_code",
              "area"               => "$row->lang_area",
              "content"            => "$row->lang_content");
        $this->_count++;
      }
    } else {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_lang` WHERE (`lang_language` = '$lang' AND `lang_area` = '$area') ORDER BY `lang_id`")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $this->_data[$row->lang_code] = $row->lang_content;
      }
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function detectLanguage() {
    $this->_data = array();
    $this->_count = 0;
    $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

    $detected = 1;

    $query =
      mysqli_query($this->_db, "SELECT `lang_language`, `lang_content` FROM `".ZE_PRE."_lang` WHERE (`lang_code` = 'browser' AND `lang_area` = 'langcode' AND `lang_content` = '$lang')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $detected = $row->lang_language;
    }
    mysqli_free_result($query);
    return $detected;
  }

  public function countLanguages() {
    $this->_data = array();
    $this->_count = 0;

    $query =
      mysqli_query($this->_db, "SELECT `lang_language`, `lang_content` FROM `".ZE_PRE."_lang` WHERE (`lang_code` = 'langcode' AND `lang_area` = 'langcode') ORDER BY `lang_content` REGEXP '^[a-z]' DESC, `lang_content`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] =
        array("id"                 => "$row->lang_language",
              "language"           => "$row->lang_content");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function countAreas() {
    $this->_data = array();
    $this->_count = 0;

    $query =
      mysqli_query($this->_db, "SELECT `lang_area` FROM `".ZE_PRE."_lang` GROUP BY `lang_area` ORDER BY `lang_area` REGEXP '^[a-z]' DESC, `lang_area`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = $row->lang_area;
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function createLang($lang, $code, $area, $content) {
    $lang = mysqli_real_escape_string($this->_db, $lang);
    $code = mysqli_real_escape_string($this->_db, $code);
    $area = mysqli_real_escape_string($this->_db, $area);
    $content = mysqli_real_escape_string($this->_db, $content);
    $query = "INSERT INTO `".ZE_PRE."_lang`
     (lang_language,
      lang_code,
      lang_area,
      lang_content)
      VALUES
     ('$lang',
      '$code',
      '$area',
      '$content')";
    $create = mysqli_query($this->_db, $query);
  }

}
?>