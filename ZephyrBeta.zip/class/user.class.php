<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class user {
  private $_count = 0;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function updateInfo($table, $ident, $id, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `$table` Set `$field` = '$value' WHERE `$ident` = '$id'";
    $update = mysqli_query($this->_db, $query);
  }

  public function getInfo($table, $ident, $id, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `$table` WHERE `$ident` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $res = $row->$field;
    }
    mysqli_free_result($query);

    if($field == 'user_level') {
      if(!is_numeric($id)) {
        $query =
          mysqli_query($this->_db, "SELECT `user_id` FROM `".ZE_PRE."_user` WHERE `$ident` = '$id'")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row = mysqli_fetch_object($query)) {
          $res2 = $row->user_id;
        }
        mysqli_free_result($query);
        $id = $res2;
      }
      $this->_count=0;
      $this->_data = array();
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_inv` WHERE `inv_user_id` = '$id' ORDER BY `inv_item_bought`")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)) {
        $query2 =
          mysqli_query($this->_db, "SELECT `item_id`, `item_code` FROM `".ZE_PRE."_item` WHERE `item_id` = '$row->inv_item_id' AND `item_special` = '1' AND `item_code` LIKE '%group%' ORDER BY `item_code` LIMIT 1")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row2 = mysqli_fetch_object($query2)) {
          $code = explode("->", $row2->item_code);
          $res = $code[1];
        }
      }
    }
    return $res;
  }
  
  public function checkIfUserExist($id) {
    $res = false;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_account` WHERE `acc_id` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($query) > 0){
      $res = true;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_account` WHERE `acc_email` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($query) > 0){
      $res = true;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_user` WHERE `user_name` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($query) > 0){
      $res = true;
    }
    mysqli_free_result($query);

    return $res;
  }

  public function getAccFull($aid) {
    $this->_data = array();
    $this->_count = 0;

    if($aid == 'all') {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_account`")
          OR die("Error: <br>".mysqli_error($this->_db));
    } else {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_account` WHERE `acc_id` = '$aid'")
          OR die("Error: <br>".mysqli_error($this->_db));
    }
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] =
      array("id"               => "$row->acc_id",
            "registered"       => "$row->acc_registered",
            "pass"             => "$row->acc_pass",
            "email"            => "$row->acc_email",
            "age"              => "$row->acc_age",
            "birthday"         => "$row->acc_birthday",
            "main_user"        => "$row->acc_main_user",
            "to_delete"        => "$row->acc_to_delete",
            "last_login"       => "$row->acc_global_last_login",
            "glevel"           => "$row->acc_global_level",
            "banned"           => "$row->acc_global_banned",
            "banned_to"        => "$row->acc_global_banned_to",
            "forced_room"      => "$row->acc_global_forced_room",
            "restricted_rooms" => "$row->acc_global_restricted_rooms",
            "activated"        => "$row->acc_global_activated",
            "activation_code"  => "$row->acc_global_activation_code",
            "user_count"       => "$row->acc_global_user_count",
            "warns"            => "$row->acc_global_warns",
            "first_login"      => "$row->acc_global_first_login",
            "coins"            => "$row->acc_coins",
            "coin_timeout"     => "$row->acc_coin_timeout");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function checkRegister($email, $username) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `acc_id` FROM `".ZE_PRE."_account` WHERE `acc_email` = '$email'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);

    $query =
      mysqli_query($this->_db, "SELECT `user_id` FROM `".ZE_PRE."_user` WHERE `user_name` = '$username'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);

    if($this->_count == 0) {
      return 'good';
    } else {
      return 'bad';
    }
  }

  public function lookUpMail($email) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `acc_id` FROM `".ZE_PRE."_account` WHERE `acc_email` = '$email'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);

    if($this->_count == 0) {
      return false;
    } else {
      return true;
    }
  }

  public function listUsersACP() {
    $this->_data = array();
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_account`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $helper = array();
      $helpcount = 0;
      $accid     = $row->acc_id;
      $accreg    = $row->acc_registered;
      $accmail   = $row->acc_email;
      $accage    = $row->acc_age;
      $accwarns  = $row->acc_global_warns;
      $accllogin = $row->acc_global_last_login;
      $acclevel  = $row->acc_global_level;
      $acctitle  = $this->getUserRankTitle($acclevel);
      $acccoins  = $row->acc_coins;
      $query2 =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_user` WHERE `user_acc_id` = '$accid'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)){
        $utitle = $this->getUserRankTitle($row2->user_level);
        $helper[$helpcount] = array("uid"     => "$row2->user_id",
                                    "uname"   => "$row2->user_name",
                                    "ucolor"  => "$row2->user_color",
                                    "ulevel"  => "$row2->user_level",
                                    "utitle"  => $utitle,
                                    "ugender" => "$row2->user_gender",
                                    "ullogin" => "$row2->user_last_login",
                                    "uluip"   => "$row2->user_last_used_ip");
        $helpcount++;
      }
      $this->_data[$this->_count] = array("aid" => $accid,
                                          "areg" => $accreg,
                                          "amail" => $accmail,
                                          "aage" => $accage,
                                          "awarns" => $accwarns,
                                          "allogin" => $accllogin,
                                          "alevel" => $acclevel,
                                          "atitle" => $acctitle,
                                          "acoins" => $acccoins,
                                          "users" => $helper);
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function listUsers($mode) {
    $this->_data = array();
    $this->_count = 0;
    $query = 
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_user` ORDER BY `user_online_points_total` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      if($row->user_last_seen != '0000-00-00 00:00:00') {
        $tmp_full_date = $row->user_last_seen;
        $tmp_split_full_date = explode(" ", $tmp_full_date);
        $tmp_split_time = $tmp_split_full_date[1];
        $tmp_split_date = explode("-", $tmp_split_full_date[0]);
        $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
      } else {
        $tmp_split_date = 'Nie';
        $tmp_split_time = 'Nie';
      }
      if($mode == true) {
        $upub = '1';
      } else {
        $upub = $row->user_profile_public;
      }
      $name = str_replace(" ", "&nbsp;", $row->user_name);
      $this->_data[$this->_count] = array("uid"     => "$row->user_id",
                                          "uname"   => $name,
                                          "ucolor"  => "$row->user_color",
                                          "useend"  => $tmp_split_date,
                                          "useent"  => $tmp_split_time,
                                          "uop"     => "$row->user_online_points",
                                          "utop"    => "$row->user_online_points_total",
                                          "upublic" => $upub);
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function listUsersSmall() {
    $this->_data = array();
    $this->_count = 0;
    $query = 
      mysqli_query($this->_db, "SELECT `user_id`, `user_name`, `user_level` FROM `".ZE_PRE."_user` ORDER BY `user_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $trank = $this->getUserRankTitle($row->user_level);
      $this->_data[$this->_count] = array("uid"     => "$row->user_id",
                                          "uname"   => "$row->user_name",
                                          "urank"   => $trank);
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function listUsersWithAge() {
    $this->_data = array();
    $this->_count = 0;
    $query = 
      mysqli_query($this->_db, "SELECT `user_id`, `user_acc_id` FROM `".ZE_PRE."_user` ORDER BY `user_id`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $age = $this->getInfo(ZE_PRE."_account", 'acc_id', $row->user_acc_id, 'acc_age');
      $this->_data[$this->_count] = array("uid"   => "$row->user_id",
                                          "age"   => "$age");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getAccUsers($aid) {
    $this->_data = array();
    $this->_count = 0;
    $query = 
      mysqli_query($this->_db, "SELECT `user_id`, `user_name`, `user_color`, `user_gender` FROM `".ZE_PRE."_user` WHERE `user_acc_id` = '$aid' ORDER BY `user_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = array("uid"     => "$row->user_id",
                                          "uname"   => "$row->user_name",
                                          "ucolor"  => "$row->user_color",
                                          "ugender" => "$row->user_gender");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  function getUserRankTitle($rid) {
    $query =
      mysqli_query($this->_db, "SELECT `ranks_title` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->ranks_title;
    }
    mysqli_free_result($query);
  }

  public function getUserPermissions($uid) {
    $this->_count=0;
    $this->_data = array();
    $gid = $this->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission_groups` ORDER BY `pg_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $helper = array();
      $query2 =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission` WHERE `perm_group` = '$row->pg_id' ORDER BY `perm_shown`")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $holding = 'off';
        $query3 =
          mysqli_query($this->_db, "SELECT `perm_state` FROM `".ZE_PRE."_permissions` WHERE `perm_gid` = '$gid' AND `perm_pid` = '$row2->perm_id'")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row3 = mysqli_fetch_object($query3)) {
          if($row3->perm_state == 1) {
            $holding = 'on';
          }
        }
        $query4 =
          mysqli_query($this->_db, "SELECT `perm_state` FROM `".ZE_PRE."_permissions` WHERE `perm_uid` = '$uid' AND `perm_pid` = '$row2->perm_id'")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row4 = mysqli_fetch_object($query4)) {
          if($row4->perm_state == 1) {
            $holding = 'on';
          } else if($row4->perm_state == 0) {
            $holding = 'off';
          } else {}
        }
        $helper[] = array("id"      => "$row2->perm_id",
                          "name"    => "$row2->perm_name",
                          "desc"    => "$row2->perm_desc",
                          "shown"   => "$row2->perm_shown",
                          "group"   => "$row2->perm_group",
                          "default" => "$holding");
      }
      $this->_data[$this->_count] = array("gname" => "$row->pg_name",
                                          "entry" => $helper);
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function updateUserPermState($uid, $perm, $state) {
    $found = false;
    $query =
      mysqli_query($this->_db, "SELECT `perm_id` FROM `".ZE_PRE."_permission` WHERE `perm_name` = '$perm'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $pid = $row->perm_id;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT `perm_id` FROM `".ZE_PRE."_permissions` WHERE (`perm_pid` = '$pid' AND `perm_uid` = '$uid')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $found = true;
    }
    mysqli_free_result($query);
    if($found != false) {
      $query = "UPDATE `".ZE_PRE."_permissions` Set `perm_state` = '$state' WHERE (`perm_pid` = '$pid' AND `perm_uid` = '$uid')";
      $update = mysqli_query($this->_db, $query);
    } else {
      $query = "INSERT INTO `".ZE_PRE."_permissions`
        (perm_uid,
         perm_gid,
         perm_pid,
         perm_state)
        VALUES
         ('$uid',
          '0',
          '$pid',
          '$state')";
      $do_it = mysqli_query($this->_db, $query);
    }
  }

  public function resetPerm($uid) {
    $delete = "DELETE FROM `".ZE_PRE."_permissions` WHERE `perm_uid` = '$uid'";
      $do_it = mysqli_query($this->_db, $delete);
  }

/**
  public function checkRegister($acc_name, $email, $username) {
    $query =
      mysqli_query($this->_db, "SELECT `acc_id` FROM `".ZE_PRE."_account` WHERE `acc_name` = '$acc_name' OR `acc_name` = '$username' OR `acc_email` = '$email'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
  }
**/
  public function createAcc($registered, $pass, $mail, $age, $birthday, $activated, $act_code, $level = "10", $guest = "no") {
    if($guest == "no") {
      $query = "INSERT INTO `".ZE_PRE."_account`
       (acc_registered,
        acc_pass,
        acc_email,
        acc_age,
        acc_birthday,
        acc_main_user,
        acc_to_delete,
        acc_global_last_login,
        acc_global_level,
        acc_global_banned,
        acc_global_banned_to,
        acc_global_forced_room,
        acc_global_restricted_rooms,
        acc_global_activated,
        acc_global_activation_code,
        acc_global_user_count,
        acc_global_warns,
        acc_global_first_login,
        acc_coins,
        acc_coin_timeout)
      VALUES
       ('$registered',
        '$pass',
        '$mail',
        '$age',
        '$birthday',
        '0',
        '0',
        '0000-00-00 00:00:00',
        '$level',
        '',
        '0000-00-00 00:00:00',
        '0',
        '',
        '$activated',
        '$act_code',
        '1',
        '',
        '1',
        '',
        '')";
    } else {
      $aid = mt_rand(1000, 1999);
      $this->_count = 0;
      $works = 0;

      while($works == 0) {
        $query4 =
          mysqli_query($this->_db, "SELECT `acc_id` FROM `".ZE_PRE."_account` WHERE `acc_id` = '$aid'")
          OR die("Error: <br>".mysqli_error($this->_db));
        while($row4 = mysqli_fetch_object($query4)){
          $this->count++;
        }
        mysqli_free_result($query4);

        if($this->_count != 0) {
          $aid = mt_rand(1000, 1999);
        } else {
          $works = 1;
        }
      }

      $query = "INSERT INTO `".ZE_PRE."_account`
       (acc_id,
        acc_registered,
        acc_pass,
        acc_email,
        acc_age,
        acc_birthday,
        acc_main_user,
        acc_to_delete,
        acc_global_last_login,
        acc_global_level,
        acc_global_banned,
        acc_global_banned_to,
        acc_global_forced_room,
        acc_global_restricted_rooms,
        acc_global_activated,
        acc_global_activation_code,
        acc_global_user_count,
        acc_global_warns,
        acc_global_first_login,
        acc_coins,
        acc_coin_timeout)
      VALUES
       ('$aid',
        '$registered',
        '$pass',
        '$mail',
        '$age',
        '$birthday',
        '0',
        '0',
        '0000-00-00 00:00:00',
        '$level',
        '',
        '0000-00-00 00:00:00',
        '0',
        '',
        '$activated',
        '$act_code',
        '1',
        '',
        '1',
        '',
        '')";
    }
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
    $accid = mysqli_insert_id($this->_db);
    return $accid;
  }

  public function createUser($accid, $name, $nickcol, $lvl, $gender, $created, $design, $guest="no") {
    $this->_count = 0;
    $usip = getenv("REMOTE_ADDR");
    $query =
      mysqli_query($this->_db, "SELECT `user_id` FROM `".ZE_PRE."_user` WHERE `user_acc_id` = '$accid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
    $name = mysqli_real_escape_string($this->_db, $name);
    if($guest == "no") {
      $query = "INSERT INTO `".ZE_PRE."_user`
        (user_acc_id,
         user_name,
         user_color,
         user_level,
         user_level_orig,
         user_gender,
         user_tf_switch,
         user_clock_switch,
         user_min_ava,
         user_design_switch,
         user_smilie_switch,
         user_smilie_set,
         user_last_seen,
         user_last_login,
         user_created,
         user_banned,
         user_banned_to,
         user_to_delete,
         user_last_used_ip,
         user_online_points,
         user_online_points_total,
         user_mails,
         user_gbook,
         user_flist,
         user_presents,
         user_restricted_rooms,
         user_restricted_categorys,
         user_groups,
         user_age_switch,
         user_mail_switch,
         user_allow_mail,
         user_allow_priv,
         user_inform_priv,
         user_allow_gb,
         user_profile_public,
         user_alias)
      VALUES
       ('$accid',
        '$name',
        '$nickcol',
        '$lvl',
        '$lvl',
        '$gender',
        '',
        '',
        '1',
        '$design',
        '1',
        '1',
        '0000-00-00 00:00:00',
        '0000-00-00 00:00:00',
        '$created',
        '',
        '0000-00-00 00:00:00',
        '0',
        '$usip',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '0',
        '0',
        '0',
        '0',
        '1',
        '0',
        '1',
         '')";
      $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      $userid = mysqli_insert_id($this->_db);
    } else {
      $uid = '-'.mt_rand(1, 500);
      $query = "INSERT INTO `".ZE_PRE."_user`
        (user_id,
         user_acc_id,
         user_name,
         user_color,
         user_level,
         user_level_orig,
         user_gender,
         user_tf_switch,
         user_clock_switch,
         user_min_ava,
         user_design_switch,
         user_smilie_switch,
         user_smilie_set,
         user_last_seen,
         user_last_login,
         user_created,
         user_banned,
         user_banned_to,
         user_to_delete,
         user_last_used_ip,
         user_online_points,
         user_online_points_total,
         user_mails,
         user_gbook,
         user_flist,
         user_presents,
         user_restricted_rooms,
         user_restricted_categorys,
         user_groups,
         user_age_switch,
         user_mail_switch,
         user_allow_mail,
         user_allow_priv,
         user_inform_priv,
         user_allow_gb,
         user_profile_public,
         user_alias)
      VALUES
       ('$uid',
        '$accid',
        '$name',
        '$nickcol',
        '$lvl',
        '$lvl',
        '$gender',
        '',
        '',
        '0',
        '$design',
        '1',
        '1',
        '0000-00-00 00:00:00',
        '0000-00-00 00:00:00',
        '$created',
        '',
        '0000-00-00 00:00:00',
        '0',
        '$usip',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '0',
        '0',
        '0',
        '0',
        '1',
        '0',
        '0',
         '')";
      $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      $userid = $uid;
    }
    if($this->_count == 0) {
      $query = "UPDATE `".ZE_PRE."_account` Set `acc_main_user` = '$userid' WHERE `acc_id` = '$accid'";
      $update = mysqli_query($this->_db, $query);
    }
    return $userid;
  }
  
  public function cleanUpGuests($guestgroup, $accid = "0") {
    $this->_count = 0;
    $this->_data = array();
    if($accid == "0") {
    $query =
      mysqli_query($this->_db, "SELECT `acc_id` FROM `".ZE_PRE."_account` WHERE `acc_global_level` = '$guestgroup'")
        OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $this->_data[] = $row->acc_id;
        $this->_count++;
      }
      mysqli_free_result($query);
    } else {
      $this->_data[] = $accid;
    }

    for($i=0; $i < $this->_count; $i++) {
      $check = "Delete";
      $tmpid = $this->_data[$i];
      $query =
        mysqli_query($this->_db, "SELECT `sess_acc_id` FROM `".ZE_PRE."_session` WHERE `sess_acc_id` = '$tmpid'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $check = $row->sess_acc_id;
      }
      mysqli_free_result($query);

      if($check == "Delete") {
        $this->deleteAcc($this->_data[$i]);
      }
    }
  }
  
  public function deleteUser($data) {
    $delete = "DELETE FROM `".ZE_PRE."_user` WHERE `user_id` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);

    $query = mysqli_query($this->_db, "SELECT `ava_link` FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$data'")
      OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $file = './files/userpic/'.$row->ava_link;
      unlink($file);
    }

    $delete = "DELETE FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_blog` WHERE `blog_user_id` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_friendlist` WHERE `fl_friend_1` = '$data' OR `fl_friend_2` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_ignore` WHERE `ig_user` = '$data' OR `ig_target` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_mail` WHERE `mail_getter` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_guestbook` WHERE `gb_getter` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_inv` WHERE `inv_user_id` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_presents` WHERE `pres_getter_id` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_profile_field_content` WHERE `prof_content_user_id` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_rating` WHERE `ra_giver` = '$data' OR `ra_getter` = '$data'";
      $do_it = mysqli_query($this->_db, $delete);
  }

  public function deleteAcc($accid) {

    $this->_count = 0;
    $this->_data = array();

    $query =
      mysqli_query($this->_db, "SELECT `user_id` FROM `".ZE_PRE."_user` WHERE `user_acc_id` = '$accid' ORDER BY `user_id`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = array("user_id"=>"$row->user_id");
      $this->_count++;
    }

    for($i=0; $i < $this->_count; $i++) {
      $data = $this->_data[$i]["user_id"];
      $delete = "DELETE FROM `".ZE_PRE."_user` WHERE `user_id` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);

      $query = mysqli_query($this->_db, "SELECT `ava_link` FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$data'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $file = './files/userpic/'.$row->ava_link;
        unlink($file);
      }

      $delete = "DELETE FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_blog` WHERE `blog_user_id` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_friendlist` WHERE `fl_friend_1` = '$data' OR `fl_friend_2` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_ignore` WHERE `ig_user` = '$data' OR `ig_target` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_mail` WHERE `mail_getter` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_guestbook` WHERE `gb_getter` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_inv` WHERE `inv_user_id` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_presents` WHERE `pres_getter_id` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_profile_field_content` WHERE `prof_content_user_id` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
      $delete = "DELETE FROM `".ZE_PRE."_rating` WHERE `ra_giver` = '$data'";
        $do_it = mysqli_query($this->_db, $delete);
    }

    $delete = "DELETE FROM `".ZE_PRE."_account` WHERE `acc_id` = '$accid'";
        $do_it = mysqli_query($this->_db, $delete);
  }
  
  public function rateUser($uid, $target, $rating) {
    $rate = false;
    $checkdate = false;
    $query =
      mysqli_query($this->_db, "SELECT `ra_date` FROM `".ZE_PRE."_rating` WHERE `ra_giver` = '$uid' AND `ra_getter` = '$target' ORDER BY `ra_date` DESC LIMIT 1")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($query) > 0) {
      $tmp = mysqli_fetch_object($query);
      $checkdate = $tmp->ra_date;
    }
    if($checkdate != false) {
      $checkdate = $checkdate + 2592000;
      if($checkdate < time()) {
        $rate = true;
      }
    } else {
      $rate = true;
    }
    if($rate == true) {
      $now = time();
      $query = "INSERT INTO `".ZE_PRE."_rating`
       (ra_giver,
        ra_getter,
        ra_rating,
        ra_date)
      VALUES
       ('$uid',
        '$target',
        '$rating',
        '$now')";
      $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      return true;
    } else {
      return false;
    }
  }
  
  public function canRateUser($uid, $target) {
    $rate = false;
    $checkdate = false;
    $query =
      mysqli_query($this->_db, "SELECT `ra_date` FROM `".ZE_PRE."_rating` WHERE `ra_giver` = '$uid' AND `ra_getter` = '$target' ORDER BY `ra_date` DESC LIMIT 1")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($query) > 0) {
      $tmp = mysqli_fetch_object($query);
      $checkdate = $tmp->ra_date;
    }
    if($checkdate != false) {
      $checkdate = $checkdate + 2592000;
      if($checkdate < time()) {
        $rate = true;
      }
    } else {
      $rate = true;
    }
    return $rate;
  }
  
  public function getRating($target) {
    $ratings = 0;
    $rates = 0;
    $score = 0;
    $res = array("score"=>"0", "rates"=>"0");
    $query =
      mysqli_query($this->_db, "SELECT `ra_rating` FROM `".ZE_PRE."_rating` WHERE `ra_getter` = '$target'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $ratings = $ratings + $row->ra_rating;
      $rates++;
    }
    if($rates != 0) {
      $score = $ratings / $rates;
      $res = array("score"=>"$score", "rates"=>"$rates");
    }
    return $res;
  }
}