<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class category {
  private $_count = 0;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getCategorysFull() {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_category` ORDER BY `cat_id`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count]
      = array(
              "cat_id"                        => "$row->cat_id",
              "cat_name"                      => "$row->cat_name",
              "cat_visa_req_user_min_age"     => "$row->cat_visa_req_user_min_age",
              "cat_visa_req_user_max_age"     => "$row->cat_visa_req_user_max_age",
              "cat_can_create"                => "$row->cat_can_create");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getCategory($cid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_category` WHERE `cat_id` = '$cid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data
      = array("cat_id"                        => "$row->cat_id",
              "cat_name"                      => "$row->cat_name",
              "cat_visa_req_user_min_age"     => "$row->cat_visa_req_user_min_age",
              "cat_visa_req_user_max_age"     => "$row->cat_visa_req_user_max_age",
              "cat_can_create"                => "$row->cat_can_create");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function updateCategory($catid, $field, $value) {
    $query = "UPDATE `".ZE_PRE."_category` Set `$field` = '$value' WHERE `cat_id` = '$catid'";
      $update = mysqli_query($this->_db, $query);
  }

  public function switchCategory($catid, $newid) {
      $query = "UPDATE `".ZE_PRE."_category` Set `cat_id` = '0' WHERE `cat_id` = '$newid'";
        $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_room` Set `room_cat_id` = '0' WHERE `room_cat_id` = '$newid'";
        $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_category` Set `cat_id` = '$newid' WHERE `cat_id` = '$catid'";
        $update = mysqli_query($this->_db, $query) OR die("2Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_room` Set `room_cat_id` = '$newid' WHERE `room_cat_id` = '$catid'";
        $update = mysqli_query($this->_db, $query) OR die("2Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_category` Set `cat_id` = '$catid' WHERE `cat_id` = '0'";
        $update = mysqli_query($this->_db, $query) OR die("3Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_room` Set `room_cat_id` = '$catid' WHERE `room_cat_id` = '0'";
        $update = mysqli_query($this->_db, $query) OR die("3Error <br>".mysqli_error($this->_db));
  }

  public function getInfo($s_field, $s_param, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_category` WHERE `$s_field` = '$s_param'")
        OR die("Error <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        return $row->$field;
      }
    mysqli_free_result($query);
  }

  public function countCats($lvl, $age) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `cat_id` FROM `".ZE_PRE."_category` WHERE (`cat_visa_req_user_level` <= '$lvl') AND (`cat_visa_req_user_min_age` <= '$age' AND `cat_visa_req_user_max_age` >= '$age')")
        OR die("Error <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $this->_count++;
      }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function deleteCategory($catid) {
    $query = "DELETE FROM `".ZE_PRE."_category` WHERE `cat_id` = '$catid'";
      $delete = mysqli_query($this->_db, $query);
    $query = "DELETE FROM `".ZE_PRE."_room` WHERE `room_cat_id` = '$catid'";
      $delete = mysqli_query($this->_db, $query);
  }

  public function createCategory($name, $min_age, $max_age, $can_create) {
    $query = "INSERT INTO `".ZE_PRE."_category`
     (cat_name,
      cat_visa_req_user_min_age,
      cat_visa_req_user_max_age,
      cat_can_create)
      VALUES
     ('$name',
      '$min_age',
      '$max_age',
      '$can_create')";
    $create = mysqli_query($this->_db, $query);
    $cat_id = mysqli_insert_id($this->_db);
    return $cat_id;
  }
}

?>