<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2016
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2016
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class smilies {
  private $_count = 0;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function updateInfo($table, $selector, $ident, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_$table` Set `$field` = '$value' WHERE `$selector` = '$ident'";
    $update = mysqli_query($this->_db, $query);
  }

  public function deleteInfo($table, $selector, $ident) {
    $query = "DELETE FROM `".ZE_PRE."_$table` WHERE `$selector` = '$ident'";
      $delete = mysqli_query($this->_db, $query);
  }
  
  public function deleteSmilie($smiid) {
    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_smilies` WHERE `smi_id` = '$smiid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $file = './files/smilies/'.$row->smi_pic;
      unlink($file);
      $delete = "DELETE FROM `".ZE_PRE."_smilies` WHERE `smi_id` = '$smiid'";
      $do_it = mysqli_query($this->_db, $delete);
    }
    mysqli_free_result($query);
  }
  
  public function deleteCategory($id) {
    $query = "DELETE FROM `".ZE_PRE."_smilies_category` WHERE `sc_id` = '$id'";
      $delete = mysqli_query($this->_db, $query);
  }

  public function getInfo($table, $selector, $ident, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_$table` WHERE `$selector` = '$ident'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->$field;
    }
    mysqli_free_result($query);
  }

  public function getSmilie($id) {
    $count=0;
    $data2 = array();
    $data = array();
    
    $query =
      mysqli_query($this->_db, "SELECT *
                           FROM `".ZE_PRE."_smilies`
                             WHERE `smi_id` = '$id'")
                               OR die("Error: <br>".mysqli_error($db));
      while($row = mysqli_fetch_object($query)){
        $rankname = $this->getInfo('ranks', 'ranks_order', $row->smi_lvl, 'ranks_title');
        $catname = $this->getInfo('smilies_category', 'sc_id', $row->smi_cat, 'sc_name');
        $query2 =
          mysqli_query($this->_db, "SELECT `ranks_id`, `ranks_order`, `ranks_title` FROM `".ZE_PRE."_ranks` WHERE `ranks_title` != '$rankname' ORDER BY `ranks_order`")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row2 = mysqli_fetch_object($query2)) {
          $data2[$count] = array("id"    => "$row2->ranks_id",
                                 "order" => "$row2->ranks_order",
                                 "name"  => "$row2->ranks_title");
          $count++;
        }
        
        $cats = $this->getSmilieCategories();
        
        $data =
        array("smi_id"      => "$row->smi_id",
              "smi_order"   => "$row->smi_order",
              "smi_name"    => "$row->smi_name",
              "smi_sc"      => "$row->smi_sc",
              "smi_pic"     => "$row->smi_pic",
              "smi_cat"     => "$row->smi_cat",
              "smi_catname" => $catname,
              "smi_usk"     => "$row->smi_usk",
              "smi_lvl"     => "$row->smi_lvl",
              "smi_lvlname" => $rankname,
              "smi_ranks"   => $data2,
              "smi_cats"    => $cats);
      }
    mysqli_free_result($query);
    return $data;
  }

  public function getSmilieCategories() {
    $this->_data = array();
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_smilies_category` ORDER BY `sc_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] = array("id"    => "$row->sc_id",
                                          "name"  => "$row->sc_name");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getSmilieCat($id) {
    $this->_count=0;
    $this->_data = array();
    
    $query =
      mysqli_query($this->_db, "SELECT *
                           FROM ".ZE_PRE."_smilies_category
                             WHERE sc_id = '$id'")
                               OR die("Error: <br>".mysqli_error($db));
      while($row = mysqli_fetch_object($query)){
        $rankname = $this->getInfo('ranks', 'ranks_order', $row->sc_lvl, 'ranks_title');
        $query2 =
          mysqli_query($this->_db, "SELECT `ranks_id`, `ranks_order`, `ranks_title` FROM `".ZE_PRE."_ranks` WHERE `ranks_title` != '$rankname' ORDER BY `ranks_order`")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row2 = mysqli_fetch_object($query2)) {
          $this->_data[$this->_count] = array("id"    => "$row2->ranks_id",
                                              "order" => "$row2->ranks_order",
                                              "name"  => "$row2->ranks_title");
          $this->_count++;
        }
        
        
        
        $data =
        array("sc_id"      => "$row->sc_id",
              "sc_order"   => "$row->sc_order",
              "sc_name"    => "$row->sc_name",
              "sc_usk"     => "$row->sc_usk",
              "sc_lvl"     => "$row->sc_lvl",
              "sc_lvlname" => $rankname,
              "sc_ranks"   => $this->_data);
      }
    mysqli_free_result($query);
    return $data;
  }

  public function getSmilieCategoriesUSK($ulvl, $age) {
    $data = array();
    $counter = 0;
    $query =
      mysqli_query($this->_db, "SELECT *
                           FROM ".ZE_PRE."_smilies_category
                             WHERE (sc_lvl <= '$ulvl' AND sc_usk <= '$age') ORDER BY
                               case `sc_name`
                                 when 'Smilies' then 1
                                 else 2
                               end,
                               `sc_name`")
                               OR die("Error: <br>".mysqli_error($db));
      while($row = mysqli_fetch_object($query)){
        $rankname = $this->getInfo('ranks', 'ranks_order', $row->sc_lvl, 'ranks_title');
        $data[$counter] =
        array("sc_id"      => "$row->sc_id",
              "sc_order"   => "$row->sc_order",
              "sc_name"    => "$row->sc_name",
              "sc_usk"     => "$row->sc_usk",
              "sc_lvl"     => "$row->sc_lvl",
              "sc_lvlname" => $rankname,
              "sc_smilies" => array());
        $counter++;
      }
    mysqli_free_result($query);
    return $data;
  }

  public function getSmiliesUSK($cat, $ulvl, $age) {
    $data = array();
    $counter = 0;
    $query =
      mysqli_query($this->_db, "SELECT *
                           FROM ".ZE_PRE."_smilies
                             WHERE smi_cat = '$cat' AND (smi_lvl <= '$ulvl' AND smi_usk <= '$age') ORDER BY `smi_name`")
                               OR die("Error: <br>".mysqli_error($db));
      while($row = mysqli_fetch_object($query)){
        $rankname = $this->getInfo('ranks', 'ranks_order', $row->smi_lvl, 'ranks_title');
        $data[$counter] =
        array("smi_id"      => "$row->smi_id",
              "smi_order"   => "$row->smi_order",
              "smi_name"    => "$row->smi_name",
              "smi_sc"      => "$row->smi_sc",
              "smi_pic"     => "$row->smi_pic",
              "smi_cat"     => "$row->smi_cat",
              "smi_usk"     => "$row->smi_usk",
              "smi_lvl"     => "$row->smi_lvl",
              "smi_lvlname" => $rankname);
        $counter++;
      }
    mysqli_free_result($query);
    return $data;
  }

  public function buildSmilies($ulvl, $age) {
    $this->_data = array();
    $this->_count = 0;

    $data = $this->getSmilieCategoriesUSK($ulvl, $age);
    for($i=0; $i<count($data); $i++) {
      $cat = $data[$i]["sc_id"];
      $data[$i]["sc_smilies"] = $this->getSmiliesUSK($cat, $ulvl, $age);
    }
    return $data;
  }
  
  function replaceSmilies($lvl, $age, $text) {
    $text = ' '.$text.' ';
    $query =
      mysqli_query($this->_db, "SELECT *
                           FROM ".ZE_PRE."_smilies
                             WHERE (smi_lvl <= '$lvl' AND smi_usk <= '$age') ORDER BY `smi_order`")
                               OR die("Error: <br>".mysqli_error($db));
      while($row = mysqli_fetch_object($query)){
        $search = ' '.$row->smi_sc.' ';
        $replace = ' <span class="smiliePRE" data-pic="'.$row->smi_pic.'" data-usk="'.$row->smi_usk.'" data-name="'.$row->smi_name.'" data-sc="'.$row->smi_sc.'" data-lvl="'.$row->smi_lvl.'">'.$row->smi_sc.'</span> ';
        $text = str_replace($search, $replace, $text);
      }
    mysqli_free_result($query);
    $text = trim($text);
    return $text;
  }

  public function createSmilie($name, $code, $pic, $cat, $usk, $lvl) {
    $name = mysqli_real_escape_string($this->_db, $name);
    $code = mysqli_real_escape_string($this->_db, $code);
    
    $query = mysqli_query($this->_db, "SELECT MAX(smi_order) FROM ".ZE_PRE."_smilies WHERE smi_cat = '$cat'");
    $row = mysqli_fetch_array($query);
    $order = $row['MAX(smi_order)'] + 1;
    
    $query = "INSERT INTO `".ZE_PRE."_smilies`
     (smi_name,
      smi_order,
      smi_sc,
      smi_pic,
      smi_cat,
      smi_usk,
      smi_lvl)
      VALUES
     ('$name',
      '$order',
      '$code',
      '$pic',
      '$cat',
      '$usk',
      '$lvl')";
    $create = mysqli_query($this->_db, $query);
  }
  
  public function createSmilieCategory($name, $usk, $lvl) {
    $name = mysqli_real_escape_string($this->_db, $name);
    
//    $query = mysqli_query($this->_db, "SELECT MAX(sc_order) FROM ".ZE_PRE."_smilies_category");
//    $row = mysqli_fetch_array($query);
//    $order = $row['MAX(sc_order)'] + 1;
    $order = 0;
    
    $query = "INSERT INTO `".ZE_PRE."_smilies_category`
     (sc_name,
      sc_order,
      sc_usk,
      sc_lvl)
      VALUES
     ('$name',
      '$order',
      '$usk',
      '$lvl')";
    $create = mysqli_query($this->_db, $query);
  }

}
?>