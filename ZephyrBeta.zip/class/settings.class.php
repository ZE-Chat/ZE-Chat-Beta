<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class settings {

  private $_count;
  private $_data = array();
  private $_db;
  private $_holder;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getFullData() {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_settings` WHERE `sett_id` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data =
      array("chat_name"                => "$row->sett_chat_name",
            "chat_admin"               => "$row->sett_chat_admin",
            "chat_admin_mail"          => "$row->sett_chat_admin_mail",
            "chat_url"                 => "$row->sett_chat_url",
            "chat_regs"                => "$row->sett_chat_register_switch",
            "chat_open"                => "$row->sett_chat_open",
            "chat_guests"              => "$row->sett_chat_allow_guest",
            "chat_default_color"       => "$row->sett_chat_default_color",
            "chat_system_color"        => "$row->sett_chat_system_color",
            "chat_system_name"         => "$row->sett_chat_system_name",
            "chat_message_wait"        => "$row->sett_chat_message_wait",
            "chat_single_room"         => "$row->sett_chat_single_room",
            "chat_total_coins"         => "$row->sett_chat_total_coins",
            "chat_version"             => "$row->sett_chat_version",
            "chat_timeout"             => "$row->sett_chat_timeout",
            "chat_debug"               => "$row->sett_chat_debug",
            "chat_check_ava"           => "$row->sett_chat_check_ava",
            "min_age"                  => "$row->sett_min_age",
            "min_name_length"          => "$row->sett_min_name_length",
            "min_message_length"       => "$row->sett_min_message_length",
            "min_message_time"         => "$row->sett_min_message_time",
            "default_design"           => "$row->sett_default_design",
            "limit_newusers"   	       => "$row->sett_limit_newusers",
            "regmod"                   => "$row->sett_reg_mod",
            "daily_coins"              => "$row->sett_daily_coins",
            "lottery_mode"             => "$row->sett_chat_lottery_mode");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function updateInfo($field, $value) {
    $query = "UPDATE `".ZE_PRE."_settings` Set `$field` = '$value' WHERE `sett_id` = '1'";
    $update = mysqli_query($this->_db, $query);
  }

  public function countUsers() {
    $this->_count = 0;

    $query =
      mysqli_query($this->_db, "SELECT `user_id` FROM `".ZE_PRE."_user`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function checkUpdate($version) {
    $res = false;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_patch_history` WHERE `patch_version` = '$version'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $res = true;
    }
    mysqli_free_result($query);
    return $res;
  }

  public function getUpdate($version) {
    $update = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_patch_history` WHERE `patch_version` = '$version'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $update["ver"] = $row->patch_version;
      $update["ins"] = $row->patch_installed;
    }
    mysqli_free_result($query);
    return $update;
  }

  public function insertUpdate($version) {
    $now = time();
    $query = "INSERT INTO `".ZE_PRE."_patch_history`
     (patch_version,
      patch_installed)
    VALUES
     ('$version',
      '$now')";
    $do_it = mysqli_query($this->_db, $query) OR die ("Error2: <br>".mysqli_error($this->_db));
  }

  public function countAccounts() {
    $this->_count = 0;

    $query =
      mysqli_query($this->_db, "SELECT `acc_id` FROM `".ZE_PRE."_account`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function newestUsers($count) {
    $this->_holder = '';
    $query =
      mysqli_query($this->_db, "SELECT `user_name`, `user_created` FROM `".ZE_PRE."_user` WHERE `user_level` > '1' ORDER BY `user_created` DESC LIMIT $count")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $tmp_full_date = $row->user_created;
      $tmp_split_full_date = explode(" ", $tmp_full_date);
      $tmp_split_date = explode("-", $tmp_split_full_date[0]);
      $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
      $str = 'Registriert am '.$tmp_split_date.' um '.$tmp_split_full_date[1].' Uhr';
      $this->_holder .= '<span class="curpoint" title="'.$str.'">'.$row->user_name.'</span>';
    }
    mysqli_free_result($query);
    return $this->_holder;
  }

  public function calculateTotalCoins() {
    $this->_count = 0;

    $query =
      mysqli_query($this->db, "SELECT `acc_coins` FROM `".ZE_PRE."_account`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count = $this->_count + $row->acc_coins;
    }
    mysqli_free_result($query);

    $query = "UPDATE `".ZE_PRE."_settings` Set `sett_chat_total_coins` = '$this->_count' WHERE `sett_id` = '1'";
    $update = mysqli_query($this->_db, $query);

    return $this->_count;
  }

  public function addTotalCoins($amount) {
    $query = "UPDATE `".ZE_PRE."_settings` Set `sett_chat_total_coins` = sett_chat_total_coins+$amount WHERE `sett_id` = '1'";
    $update = mysqli_query($this->_db, $query);
  }

  public function getLoginText() {
    switch($this->regmod) {
      case 1: return 'ACC# oder Username'; break;
      case 2: return 'Email oder Username'; break;
      case 3: return 'ACC; oder Username'; break;
    }
  }
  
//----------------------------------------------------------
//-------------------Permissions----------------------------
//----------------------------------------------------------


  public function getAllPermissions() {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission_groups` ORDER BY `pg_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $helper = array();
      $query2 =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission` WHERE `perm_group` = '$row->pg_id' ORDER BY `perm_shown`")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $helper[] = array("id"      => "$row2->perm_id",
                          "name"    => "$row2->perm_name",
                          "desc"    => "$row2->perm_desc",
                          "shown"   => "$row2->perm_shown",
                          "group"   => "$row2->perm_group",
                          "default" => "$row2->perm_default",);
      }
      $this->_data[$this->_count] = array("gname" => "$row->pg_name",
                                          "entry" => $helper);
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getGroupPermissions($gid) {
    $this->_count=0;
    $this->_data = array();
    $query0 =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$gid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row0 = mysqli_fetch_object($query0)) {
      $tmpid = $row0->ranks_id;
      $tmptitle = $row0->ranks_title;
      $tmpicon = $row0->ranks_icon;
      $tmpstate = $row0->ranks_state;
    }
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission_groups` ORDER BY `pg_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $helper = array();
      $query2 =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission` WHERE `perm_group` = '$row->pg_id' ORDER BY `perm_shown`")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $holding = 'off';
        $query3 =
          mysqli_query($this->_db, "SELECT `perm_state` FROM `".ZE_PRE."_permissions` WHERE `perm_gid` = '$gid' AND `perm_pid` = '$row2->perm_id'")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row3 = mysqli_fetch_object($query3)) {
          if($row3->perm_state == 1) {
            $holding = 'on';
          }
        }
        $helper[] = array("id"      => "$row2->perm_id",
                          "name"    => "$row2->perm_name",
                          "desc"    => "$row2->perm_desc",
                          "shown"   => "$row2->perm_shown",
                          "group"   => "$row2->perm_group",
                          "default" => "$holding");
      }
      $this->_data[$this->_count] = array("gname" => "$row->pg_name",
                                          "gid" => $tmpid,
                                          "title" => $tmptitle,
                                          "icon" => $tmpicon,
                                          "state" => $tmpstate,
                                          "entry" => $helper);
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getAllGroups() {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_ranks` ORDER BY `ranks_order` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $tmpcount = 0;
      $tmplist = '';
      $query2 =
        mysqli_query($this->_db, "SELECT `user_name` FROM `".ZE_PRE."_user` WHERE `user_level` = '$row->ranks_id' ORDER BY `user_name`")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $tmpcount++;
        $tmplist .= $row2->user_name.', ';
      }
      $this->_data[$this->_count] = array("id"      => "$row->ranks_id",
                                          "gorder"  => "$row->ranks_order",
                                          "gname"   => "$row->ranks_title",
                                          "gicon"   => "$row->ranks_icon",
                                          "gstate"  => "$row->ranks_state",
                                          "gcount"  => $tmpcount,
                                          "gmember" => substr($tmplist, 0, -2));
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getPermissions($uid="dont", $gid="dont") {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permissions` WHERE `perm_uid` = '$id' OR `perm_gid` = '$gid' ORDER BY `perm_pid`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {

      $query2 =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission` WHERE `perm_id` = '$row->perm_state'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $this->_data[$this->_count] =
        array("id"    => "$row2->perm_id",
              "name"  => "$row2->perm_name",
              "did"   => "$row2->perm_desc",
              "state" => "$row->perm_state");
      }
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->data_array;
  }

  public function getDefaultRank() {
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id` FROM `".ZE_PRE."_ranks` WHERE `ranks_state` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->ranks_id;
    }
    mysqli_free_result($query);
  }
  
  public function getGuestRank() {
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id` FROM `".ZE_PRE."_ranks` WHERE `ranks_state` = '2'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->ranks_id;
    }
    mysqli_free_result($query);
  }

  public function getRankTitle($rid) {
    $query =
      mysqli_query($this->_db, "SELECT `ranks_title` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->ranks_title;
    }
    mysqli_free_result($query);
  }
  
  public function getRankOrder($rid) {
    $query =
      mysqli_query($this->_db, "SELECT `ranks_order` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->ranks_order;
    }
    mysqli_free_result($query);
  }
  
  public function getHighestRankOrder() {
    $query = mysqli_query($this->_db, "SELECT MAX(ranks_order) FROM ".ZE_PRE."_ranks");
    $row = mysqli_fetch_array($query);
    $order = $row['MAX(ranks_order)'];
    return $order;
  }
  
  public function getPermit($gid, $gid2) {
    $permit = false;
    $query =
      mysqli_query($this->_db, "SELECT `ranks_order` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$gid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $p1 = $row->ranks_order;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT `ranks_order` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$gid2'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $p2 = $row->ranks_order;
    }
    mysqli_free_result($query);
    if($p1 > $p2) {
      $permit = true;
    }
    return $permit;
  }
  
  public function getEvenPermit($gid, $gid2) {
    $permit = false;
    $query =
      mysqli_query($this->_db, "SELECT `ranks_order` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$gid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $p1 = $row->ranks_order;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT `ranks_order` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$gid2'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $p2 = $row->ranks_order;
    }
    mysqli_free_result($query);
    if($p1 >= $p2) {
      $permit = true;
    }
    return $permit;
  }

  function getRankIcons() {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id`, `ranks_order`, `ranks_title`, `ranks_icon` FROM `".ZE_PRE."_ranks`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] = array("id"    => "$row->ranks_id",
                                          "order" => "$row->ranks_order",
                                          "name"  => "$row->ranks_title",
                                          "icon"  => "$row->ranks_icon");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  function getRankList() {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id`, `ranks_order`, `ranks_title` FROM `".ZE_PRE."_ranks` ORDER BY `ranks_order` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] = array("id"    => "$row->ranks_id",
                                          "order" => "$row->ranks_order",
                                          "name"  => "$row->ranks_title");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  function getRankListDESC() {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id`, `ranks_order`, `ranks_title` FROM `".ZE_PRE."_ranks` ORDER BY `ranks_order`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] = array("id"    => "$row->ranks_id",
                                          "order" => "$row->ranks_order",
                                          "name"  => "$row->ranks_title");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getGroupInfo($gid, $field) {
    $res = false;
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$gid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $res = $row->$field;
    }
    mysqli_free_result($query);
    return $res;
  }

  public function cP($area, $uid, $gid) {
    $this->_count = 0;
    if(!ctype_digit($area)){
      $query =
        mysqli_query($this->_db, "SELECT `perm_id` FROM `".ZE_PRE."_permission` WHERE `perm_name` = '$area'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)) {
        $pid = $row->perm_id;
      }
      mysqli_free_result($query);
    } else {
      $pid = $area;
    }

    $state = 0;

    $query =
      mysqli_query($this->_db, "SELECT `perm_state` FROM `".ZE_PRE."_permissions` WHERE `perm_gid` = '$gid' AND `perm_pid` = '$pid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $state = $row->perm_state;
    }
    mysqli_free_result($query);

    $query =
      mysqli_query($this->_db, "SELECT `perm_state` FROM `".ZE_PRE."_permissions` WHERE `perm_uid` = '$uid' AND `perm_pid` = '$pid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $state = $row->perm_state;
    }
    mysqli_free_result($query);

    if($state > 0) {
      return $state;
    } else {
      return false;
    }
  }

  public function updateGroupPermState($gid, $perm, $state) {
    $found = false;
    $query =
      mysqli_query($this->_db, "SELECT `perm_id` FROM `".ZE_PRE."_permission` WHERE `perm_name` = '$perm'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $pid = $row->perm_id;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT `perm_id` FROM `".ZE_PRE."_permissions` WHERE (`perm_pid` = '$pid' AND `perm_gid` = '$gid')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $found = true;
    }
    mysqli_free_result($query);
    if($found != false) {
      $query = "UPDATE `".ZE_PRE."_permissions` Set `perm_state` = '$state' WHERE (`perm_pid` = '$pid' AND `perm_gid` = '$gid')";
      $update = mysqli_query($this->_db, $query);
    } else {
      $this->createGroupPerm($gid, $pid, $state);
    }
  }

  public function updateGroupInfo($gid, $field, $val) {
    $query = "UPDATE `".ZE_PRE."_ranks` Set `$field` = '$val' WHERE `ranks_id` = '$gid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function deleteGroup($gid) {
    $delete = "DELETE FROM `".ZE_PRE."_permissions` WHERE `perm_gid` = '$gid'";
      $do_it = mysqli_query($this->_db, $delete);
    $img = $this->getGroupInfo($gid, 'ranks_icon');
    if($img != false) {
      $file = './files/groupicons/'.$img;
      unlink($file);
    }
    $delete = "DELETE FROM `".ZE_PRE."_ranks` WHERE `ranks_id` = '$gid'";
      $do_it = mysqli_query($this->_db, $delete);

    $query =
      mysqli_query($this->_db, "SELECT `ranks_id` FROM `".ZE_PRE."_ranks` WHERE `ranks_state` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $res = $row->ranks_id;
    }
    mysqli_free_result($query);

    $query = "UPDATE `".ZE_PRE."_user` Set `user_level` = '$res' WHERE `user_level` = '$gid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function createGroup($order, $name, $icon, $state) {
    $name = mysqli_real_escape_string($this->_db, $name);
    $query = "INSERT INTO `".ZE_PRE."_ranks`
      (ranks_order,
       ranks_title,
       ranks_icon,
       ranks_state)
      VALUES
       ('$order',
        '$name',
        '$icon',
        '$state')";
    $do_it = mysqli_query($this->_db, $query);
    $gid = mysqli_insert_id($this->_db);
    return $gid;
  }

  public function createGroupPerm($gid, $pid, $state) {
    $query = "INSERT INTO `".ZE_PRE."_permissions`
      (perm_uid,
       perm_gid,
       perm_pid,
       perm_state)
      VALUES
       ('0',
        '$gid',
        '$pid',
        '$state')";
    $do_it = mysqli_query($this->_db, $query);
  }

  public function createPerm($name, $desc, $shown, $group, $def) {
    $query = "INSERT INTO `".ZE_PRE."_permission`
      (perm_name,
       perm_desc,
       perm_shown,
       perm_group,
       perm_default)
      VALUES
       ('$name',
        '$desc',
        '$shown',
        '$group',
        '$def')";
    $do_it = mysqli_query($this->_db, $query);
    $pid = mysqli_insert_id($this->_db);
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id` FROM `".ZE_PRE."_ranks`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->updateGroupPermState($row->ranks_id, $name, $def);
    }
    mysqli_free_result($query);
    return $pid;
  }

  public function createPermG($name) {
    $query = "INSERT INTO `".ZE_PRE."_permission_groups`
      (pg_name)
      VALUES
       ('$name')";
    $do_it = mysqli_query($this->_db, $query);
  }

  public function getPermG() {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission_groups`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] = array("id"    => "$row->pg_id",
                                          "name"  => "$row->pg_name");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getPGDeleteList() {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] = array("is"    => "perm",
                                          "id"    => "$row->perm_id",
                                          "name"  => "$row->perm_shown");
      $this->_count++;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_permission_groups`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] = array("is"    => "group",
                                          "id"    => "$row->pg_id",
                                          "name"  => "$row->pg_name");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function deletePerm($id) {
    $delete = "DELETE FROM `".ZE_PRE."_permissions` WHERE `perm_pid` = '$id'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_permission` WHERE `perm_id` = '$id'";
      $do_it = mysqli_query($this->_db, $delete);
  }

  public function deletePermG($id) {
    $query =
      mysqli_query($this->_db, "SELECT `perm_id` FROM `".ZE_PRE."_permission` WHERE `perm_group` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $delete = "DELETE FROM `".ZE_PRE."_permissions` WHERE `perm_pid` = '$row->perm_id'";
        $do_it = mysqli_query($this->_db, $delete);
    }
    $delete = "DELETE FROM `".ZE_PRE."_permission` WHERE `perm_group` = '$id'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_permission_groups` WHERE `pg_id` = '$id'";
      $do_it = mysqli_query($this->_db, $delete);
  }
  
  public function informModeration($content) {
    $content = mysqli_real_escape_string($this->_db, $content);
    $name = mysqli_real_escape_string($this->_db, "Moderation");
    $now = time();
    $query = "INSERT INTO `".ZE_PRE."_message`
     (mess_author_id,
      mess_author_name,
      mess_write_time,
      mess_room_id,
      mess_target_room_id,
      mess_target_user_id,
      mess_usk,
      mess_req_lvl,
      mess_private,
      mess_type,
      mess_area,
      mess_action,
      mess_form,
      mess_content)
    VALUES
     ('0',
      '$name',
      '$now',
      '0',
      '0',
      '0',
      '0',
      '0',
      '0',
      '10',
      'content',
      '0',
      '000000',
      '$content')";
    $do_it = mysqli_query($this->_db, $query) OR die ("Error: <br>".mysqli_error($this->_db));
  }

}

?>