<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class profiles {

  public $prof_field_id;
  public $prof_field_name;
  public $prof_field_type;
  public $prof_field_default_content;

  public $prof_content_field_id;
  public $prof_content_user_id;
  public $prof_content_field_content;

  private $_count;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getUserProfile($uid, $mode) {
    $tmp_content = '';
    $this->_count = 0;
    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_profile_fields` WHERE `prof_field_id` != '1' ORDER BY `prof_field_id`")
      OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $query2 = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_profile_field_content` WHERE `prof_content_user_id` = '$uid' AND `prof_content_field_id` = '$row->prof_field_id'")
        OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)){
        $tmp_content = $row2->prof_content_field_content;
      }
      if($row->prof_field_type == 3) { $default = explode('#', $row->prof_field_default_content); } else { $default = $row->prof_field_default_content; }
      if($mode != '' && $row->prof_field_type == 3) { $default = implode(", ", $default); }
      $this->_data[$this->_count] = array(
      "prof_field_id"      => "$row->prof_field_id",
      "prof_field_name"    => "$row->prof_field_name",
      "prof_field_type"    => "$row->prof_field_type",
      "prof_field_default" => $default,
      "prof_content"       => "$tmp_content");
      $this->_count++;
      $tmp_content = '';
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getProfileFields() {
    $this->_count = 0;
    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_profile_fields` WHERE `prof_field_id` != '1' ORDER BY `prof_field_id`")
      OR die("1Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = array(
      "prof_field_id"      => "$row->prof_field_id",
      "prof_field_name"    => "$row->prof_field_name",
      "prof_field_type"    => "$row->prof_field_type",
      "prof_field_default" => "$row->prof_field_default_content");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getProfileField($pid) {
    $this->_count = 0;
    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_profile_fields` WHERE `prof_field_id` = '$pid'")
      OR die("1Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data = array(
      "prof_field_id"      => "$row->prof_field_id",
      "prof_field_name"    => "$row->prof_field_name",
      "prof_field_type"    => "$row->prof_field_type",
      "prof_field_default" => "$row->prof_field_default_content");
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getMainText($uid) {
    $tmp_content = '';
    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_profile_field_content` WHERE `prof_content_user_id` = '$uid' AND `prof_content_field_id` = '1'")
      OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $tmp_content = $row->prof_content_field_content;
    }
    mysqli_free_result($query);
    return $tmp_content;
  }

  public function changeFieldContent($pid, $uid, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $do = 1;
    if($value == '') { $do = 0; }
    $check = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_profile_field_content` WHERE `prof_content_user_id` = '$uid' AND `prof_content_field_id` = '$pid'")
      OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($check) != 1) {
      if($do == 1) {
        $query = "INSERT INTO `".ZE_PRE."_profile_field_content` (prof_content_field_id, prof_content_user_id, prof_content_field_content)
                                                  VALUES ('$pid', '$uid', '$value')";
        $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      }
    } else {
      if($do == 1) {
        $query = "UPDATE `".ZE_PRE."_profile_field_content` Set `prof_content_field_content` = '$value' WHERE `prof_content_user_id` = '$uid' AND `prof_content_field_id` = '$pid'";
        $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      } else {
        $delete = "DELETE FROM `".ZE_PRE."_profile_field_content` WHERE `prof_content_user_id` = '$uid' AND `prof_content_field_id` = '$pid'";
        $do_it = mysqli_query($this->_db, $delete) OR die("Error: <br>".mysqli_error($this->_db));
      }
    }
    mysqli_free_result($check);
  }

  public function createProfileField($name, $type, $default) {
    $query = "INSERT INTO `".ZE_PRE."_profile_fields`
     (prof_field_name,
      prof_field_type,
      prof_field_default_content)
    VALUES
     ('$name',
      '$type',
      '$default')";
    $do_it = mysqli_query($this->_db, $query);
  }

  public function deleteProfileField($pid) {
    $delete = "DELETE FROM `".ZE_PRE."_profile_fields` WHERE `prof_field_id` = '$pid'";
      $do_it = mysqli_query($this->_db, $delete);
    $delete = "DELETE FROM `".ZE_PRE."_profile_field_content` WHERE `prof_content_field_id` = '$pid'";
      $do_it = mysqli_query($this->_db, $delete);
  }

  public function switchFields($pid, $newid) {
      $query = "UPDATE `".ZE_PRE."_profile_fields` Set `prof_field_id` = '0' WHERE `prof_field_id` = '$newid'";
        $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_profile_field_content` Set `prof_content_field_id` = '0' WHERE `prof_content_field_id` = '$newid'";
        $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_profile_fields` Set `prof_field_id` = '$newid' WHERE `prof_field_id` = '$pid'";
        $update = mysqli_query($this->_db, $query) OR die("2Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_profile_field_content` Set `prof_content_field_id` = '$newid' WHERE `prof_content_field_id` = '$pid'";
        $update = mysqli_query($this->_db, $query) OR die("2Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_profile_fields` Set `prof_field_id` = '$pid' WHERE `prof_field_id` = '0'";
        $update = mysqli_query($this->_db, $query) OR die("3Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_profile_field_content` Set `prof_content_field_id` = '$pid' WHERE `prof_content_field_id` = '0'";
        $update = mysqli_query($this->_db, $query) OR die("3Error <br>".mysqli_error($this->_db));
  }
  
  public function updateField($pid, $title, $type, $default) {
    $query = "UPDATE `".ZE_PRE."_profile_fields` Set `prof_field_name` = '$title', `prof_field_type` = '$type', `prof_field_default_content` = '$default' WHERE `prof_field_id` = '$pid'";
      $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));
  }

  public function makeEnterField($pid, $ptype, $pname, $pvalues, $pcontent) {
    switch($ptype) {
      //Input
      case '2':
        if($pcontent == '') { $pcontent = $pvalues; }
        $returner = '<tr><td class="form_tl"><label for="field_'.$pid.'">'.$pname.'</label></td>';
        $returner .= '<td class="form_tr"><input name="'.$pid.'" id="field_'.$pid.'" onblur="if (this.value==\'\') this.value=\''.$pcontent.'\';" onfocus="if (this.value==\''.$pcontent.'\') this.value=\'\';" value="'.$pcontent.'" /></td></tr>';
        return $returner;
      break;
      //Select
      case '3':
        $returner = '<tr><td class="form_tl">'.$pname.'</td>';
        $returner .= '<td class="form_tr"><select id="field_'.$pid.'" name="'.$pid.'">';
        $values = explode("#", $pvalues);
        $amount = count($values);
        if(in_array($pcontent, $values)) {
          $returner .= '<option value="'.$pcontent.'" checked>'.$pcontent.'</option>';
        }
        for($i=0; $i < $amount; $i++) {
          if($values[$i] != $pcontent) {
            $returner .= '<option value="'.$values[$i].'">'.$values[$i].'</option>';
          }
        }
        $returner .= '</select></td></tr>';
        return $returner;
      break;
    }
  }

}

?>