<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class message {

  private $_count;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getMessages($rid, $uid, $lvl, $default) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sess_acc_id`, `sess_last_message_id` FROM `".ZE_PRE."_session` WHERE `sess_user_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $lid = $row->sess_last_message_id;
      $aid = $row->sess_acc_id;
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT `acc_age` FROM `".ZE_PRE."_account` WHERE `acc_id` = '$aid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $age = $row->acc_age;
    }
    mysqli_free_result($query);

    $abort = 0;

    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_message` WHERE ((`mess_id` > '$lid' AND `mess_usk` <= '$age') AND ((`mess_room_id` = '$rid') OR ((`mess_type` = '2' OR `mess_type` = '10') AND `mess_room_id` = '0'))) ORDER BY `mess_id` ASC ") OR die("Error1: <br>".mysqli_error($this->_db));

    if($abort == 0) {
      while($row = mysqli_fetch_object($query)) {
        $this->_data[$this->_count] =
        array("mess_id"             => "$row->mess_id",
              "mess_author_id"      => "$row->mess_author_id",
              "mess_author_name"    => "$row->mess_author_name",
              "mess_write_time"     =>  date("d.m. H:i:s", $row->mess_write_time),
              "mess_room_id"        => "$row->mess_room_id",
              "mess_target_room_id" => "$row->mess_target_room_id",
              "mess_target_user_id" => "$row->mess_target_user_id",
              "mess_usk"            => "$row->mess_usk",
              "mess_req_lvl"        => "$row->mess_req_lvl",
              "mess_private"        => "$row->mess_private",
              "mess_type"           => "$row->mess_type",
              "mess_area"           => "$row->mess_area",
              "mess_action"         => "$row->mess_action",
              "mess_form"           => "$row->mess_form",
              "mess_content"        => "$row->mess_content",
              "mess_avatar"         => "");
        $this->_count++;
      }
      mysqli_free_result($query);
      return $this->_data;
    } else {
      return "error";
    }
  }
  
  public function getPrivMessages($uid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sess_last_message_id` FROM `".ZE_PRE."_session` WHERE `sess_user_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $lid = $row->sess_last_message_id;
    }
    mysqli_free_result($query);

    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_message` WHERE (`mess_id` > '$lid' AND ((`mess_room_id` = '0' AND `mess_type` = '3') AND ((`mess_author_id` = '$uid') OR (`mess_target_user_id` = '$uid')))) ORDER BY `mess_id` ASC ") OR die("Error2: <br>".mysqli_error($this->_db));

    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("mess_id"             => "$row->mess_id",
            "mess_author_id"      => "$row->mess_author_id",
            "mess_author_name"    => "$row->mess_author_name",
            "mess_write_time"     =>  date("d.m. H:i:s", $row->mess_write_time),
            "mess_room_id"        => "$row->mess_room_id",
            "mess_target_room_id" => "$row->mess_target_room_id",
            "mess_target_user_id" => "$row->mess_target_user_id",
            "mess_req_lvl"        => "$row->mess_req_lvl",
            "mess_private"        => "$row->mess_private",
            "mess_type"           => "$row->mess_type",
            "mess_area"           => "$row->mess_area",
            "mess_action"         => "$row->mess_action",
            "mess_form"           => "$row->mess_form",
            "mess_content"        => "$row->mess_content",
            "mess_avatar"         => "");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getADMMessages($rid, $uid, $date1, $date2, $hidden) {
    $this->_count = 0;
    $this->_data = array();
    if($hidden == "0") {
      $hidden = "AND (`mess_private` = '0')";
    } else {
      $hidden = "";
    }
    $abort = 0;
    if($rid != "0") {
      if($uid != "0") {
        $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_message` WHERE (`mess_room_id` = '$rid' OR `mess_target_room_id` = '$rid') AND (`mess_author_id` = '$uid' OR `mess_target_user_id` = '$uid') AND (`mess_write_time` > '$date1' AND `mess_write_time` < '$date2') $hidden ORDER BY `mess_id` ASC ") OR die("Error: <br>".mysqli_error($this->_db));
      } else {
        $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_message` WHERE (`mess_room_id` = '$rid' OR `mess_target_room_id` = '$rid') AND (`mess_write_time` > '$date1' AND `mess_write_time` < '$date2') $hidden ORDER BY `mess_id` ASC ") OR die("Error: <br>".mysqli_error($this->_db));
      }
    } else {
      if($uid != "0") {
        $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_message` WHERE (`mess_author_id` = '$uid' OR `mess_target_user_id` = '$uid') AND (`mess_write_time` > '$date1' AND `mess_write_time` < '$date2') $hidden ORDER BY `mess_id` ASC ") OR die("Error: <br>".mysqli_error($this->_db));
      } else {
        $abort = 1;
      }
    }

    if($abort == 0) {
      while($row = mysqli_fetch_object($query)) {
        $this->_data[$this->_count] =
        array("mess_id"             => "$row->mess_id",
              "mess_author_id"      => "$row->mess_author_id",
              "mess_author_name"    => "$row->mess_author_name",
              "mess_write_time"     => date("d.m. H:i:s", $row->mess_write_time),
              "mess_room_id"        => "$row->mess_room_id",
              "mess_target_room_id" => "$row->mess_target_room_id",
              "mess_target_user_id" => "$row->mess_target_user_id",
              "mess_req_lvl"        => "$row->mess_req_lvl",
              "mess_private"        => "$row->mess_private",
              "mess_type"           => "$row->mess_type",
              "mess_action"         => "$row->mess_action",
              "mess_form"           => "$row->mess_form",
              "mess_content"        => "$row->mess_content");
        $this->_count++;
      }
      mysqli_free_result($query);
      return $this->_data;
    } else {
      return "error";
    }
  }

  public function getPMInfo($area) {
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `pm_sid_1`, `pm_sid_2` FROM `".ZE_PRE."_private_messages` WHERE `pm_area_id` = '$area'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[0] = $row->pm_sid_1;
      $this->_data[1] = $row->pm_sid_2;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function createPM($sid1, $sid2, $areaid) {
    $query = "INSERT INTO `".ZE_PRE."_private_messages`
      (pm_sid_1,
       pm_sid_2,
       pm_open_1,
       pm_open_2,
       pm_area_id,
       pm_created)
    VALUES
      ('$sid1',
       '$sid2',
       '1',
       '1',
       '$areaid',
       '0')";
    $do_it = mysqli_query($this->_db, $query) OR die ("Error: <br>".mysqli_error($this->_db));
  }

  public function checkPMglobal($sysname = 'System') {
    $this->_count = 0;
    $this->_data = array();
    $data = array();
    $query =
      mysqli_query($this->_db, "SELECT `pm_id`, `pm_sid_1`, `pm_sid_2`, `pm_area_id` FROM `".ZE_PRE."_private_messages`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = array("pm_id" => "$row->pm_id", "pms1" => "$row->pm_sid_1", "pms2" => "$row->pm_sid_2", "pmaid" => "$row->pm_area_id");
      $this->_count++;
    }
    mysqli_free_result($query);

    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `sess_id` FROM `".ZE_PRE."_session`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $data[$this->_count] = $row->sess_id;
      $this->_count++;
    }
    mysqli_free_result($query);

    $this->_count = count($this->_data);
    for($i=0; $i<$this->_count; $i++) {
      $tmp_pmid = $this->_data[$i][pm_id];
      $check1 = 0;
      $check2 = 0;
      if(in_array($this->_data[$i][pms1], $data)) {
        $check1 = 1;
      } 
      if(in_array($this->_data[$i][pms2], $data)) {
        $check2 = 1;
      } 

      if($check1 == 0 || $check2 == 0) {
        $delete = "DELETE FROM `".ZE_PRE."_private_messages` WHERE `pm_id` = '$tmp_pmid'";
        $do_it = mysqli_query($this->_db, $delete);
        if($check1 == 1 && $check2 == 0) {
          $getsid = $this->_data[$i][pms1];
          $query =
            mysqli_query($this->_db, "SELECT `sess_user_id`, `sess_room_id` FROM `".ZE_PRE."_session` WHERE `sess_id` = '$getsid'")
              OR die("Error: <br>".mysqli_error($this->_db));
          while($row = mysqli_fetch_object($query)){
            $suid = $row->sess_user_id;
            $srid = $row->sess_room_id;
          }
          $this->insertMessage($suid,
                               $sysname,
                               $srid,
                               '0',
                               $suid,
                               '1',
                               '1',
                               '9',
                               '000000',
                               $this->_data[$i][pmaid].'-vvv-'.$sysname,
                               'content');
        }
        if($check2 == 1 && $check1 == 0) {
          $getsid = $this->_data[$i][pms2];
          $query =
            mysqli_query($this->_db, "SELECT `sess_user_id`, `sess_room_id` FROM `".ZE_PRE."_session` WHERE `sess_id` = '$getsid'")
              OR die("Error: <br>".mysqli_error($this->_db));
          while($row = mysqli_fetch_object($query)){
            $suid = $row->sess_user_id;
            $srid = $row->sess_room_id;
          }
          $this->insertMessage($suid,
                               $sysname,
                               $srid,
                               '0',
                               $suid,
                               '1',
                               '1',
                               '9',
                               '000000',
                               $this->_data[$i][pmaid],
                               'content');
        }
      }
    }
  }

  public function checkPM($sid1, $sid2) {
    $query =
      mysqli_query($this->_db, "SELECT `pm_area_id` FROM `".ZE_PRE."_private_messages` WHERE (`pm_sid_1` = '$sid1' OR `pm_sid_2` = '$sid1') AND (`pm_sid_1` = '$sid2' OR `pm_sid_2` = '$sid2')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $data = $row->pm_area_id;
    }
    mysqli_free_result($query);
    if(!$data || $data == '') {
      $data = 'none';
    }
    return $data;
  }

  public function countUserPM($csid) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `pm_area_id` FROM `".ZE_PRE."_private_messages` WHERE `pm_sid_1` = '$csid' OR `pm_sid_2` = '$csid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function deletePM($darea) {
    $delete = "DELETE FROM `".ZE_PRE."_private_messages` WHERE `pm_area_id` = '$darea'";
    $do_it = mysqli_query($delete);
  }

  public function insertMessage($author_id, $author_name, $rid, $target_room, $target_user, $private, $type, $action, $form, $content, $area = "content", $req_lvl = "0", $usk = "0") {
    if($area == '') { $area = 'content'; }
    if($req_lvl == '') { $req_lvl = '0'; }
    $author_name = mysqli_real_escape_string($this->_db, $author_name);
//    $content = utf8_decode($content);
    $content = mysqli_real_escape_string($this->_db, $content);
    $now = time();
    $query = "INSERT INTO `".ZE_PRE."_message`
     (mess_author_id,
      mess_author_name,
      mess_write_time,
      mess_room_id,
      mess_target_room_id,
      mess_target_user_id,
      mess_usk,
      mess_req_lvl,
      mess_private,
      mess_type,
      mess_area,
      mess_action,
      mess_form,
      mess_content)
    VALUES
     ('$author_id',
      '$author_name',
      '$now',
      '$rid',
      '$target_room',
      '$target_user',
      '$usk',
      '$req_lvl',
      '$private',
      '$type',
      '$area',
      '$action',
      '$form',
      '$content')";
    $do_it = mysqli_query($this->_db, $query) OR die ("Error: <br>".mysqli_error($this->_db));
  }

  public function getLastID() {
    $query = mysqli_query($this->_db, "SELECT `mess_id` FROM `".ZE_PRE."_message` ORDER BY `mess_id` DESC LIMIT 1")
      OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      return $row->mess_id;
    }
    mysqli_free_result($query);
  }

  public function getNeededData($uid) {
    $query = mysqli_query($this->_db, "SELECT `user_name`, `user_color`, `user_smilie_switch`,
                                 `sess_tf_switch`, `sess_mute_switch`, `sess_online_status`, `sess_user_level`, `sess_confusion`
                          FROM `".ZE_PRE."_user`, `".ZE_PRE."_session` 
                          WHERE `user_id` = '$uid' AND `sess_user_id` = '$uid'")
      OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data = array("name"     => "$row->user_name",
                                "color"    => "$row->user_color",
                                "sswitch"  => "$row->user_smilie_switch",
                                "tfswitch" => "$row->sess_tf_switch",
                                "confused" => "$row->sess_confusion",
                                "muted"    => "$row->sess_mute_switch",
                                "ostatus"  => "$row->sess_online_status",
                                "level"    => "$row->sess_user_level");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function floodProtect($uid, $protect) {
    $data = '';
    $query = mysqli_query($this->_db, "SELECT `mess_write_time` FROM `".ZE_PRE."_message` WHERE `mess_author_id` = '$uid' ORDER BY `mess_id` DESC LIMIT 5")
      OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $data = strtotime($row->mess_write_time);
    }
    mysqli_free_result($query);

    $timecheck = time() - $protect;

    if($data > $timecheck) {
      return 'flood';
    } else {
      return 'ok';
    }
  }

}

?>