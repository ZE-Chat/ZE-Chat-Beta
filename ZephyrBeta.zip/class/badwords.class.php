<?php
/**
 *	This file is part of "ZE Chat v0.9".
 *
 *	"ZE Chat v0.9" is free softwore. Feel free to use and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	"ZE Chat v0.9" is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	Developed by Alexander Pakusch aka Zion, 2010-2013
 *	You are not allowed to sell this software or remove the Copyrights.
 *
 *	<http://www.zevolutions.de/>
 *	<admin@zevolutions.de>
 */

class badwords {

  public $_count = 0;
  public $_data = array();

  public $detected = 0;

  public $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getBadwords() {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_badwords` ORDER BY `bad_word`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"      => "$row->bad_id",
            "word"    => "$row->bad_word",
            "minage"  => "$row->bad_min_age",
            "maxage"  => "$row->bad_max_age",
            "tswitch" => "$row->bad_text",
            "nswitch" => "$row->bad_name",
            "punish"  => "$row->bad_punish");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getBadword($bid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_badwords` WHERE `bad_id` = '$bid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data =
      array("id"      => "$row->bad_id",
            "word"    => "$row->bad_word",
            "minage"  => "$row->bad_min_age",
            "maxage"  => "$row->bad_max_age",
            "tswitch" => "$row->bad_text",
            "nswitch" => "$row->bad_name",
            "punish"  => "$row->bad_punish");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function checkForBadwordsText($uid, $rid, $string, $age) {
    $this->detected = 0;
    $this->_count=0;
    $this->_data = array();
    $num1 = 0;
    $num2 = 0;
    $num3 = 0;
    $num4 = 0;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_badwords` WHERE (`bad_min_age` < '$age' AND `bad_max_age` > '$age') AND `bad_text` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"     => "$row->bad_id",
            "word"   => "$row->bad_word",
            "tswitch" => "$row->bad_text",
            "nswitch" => "$row->bad_name",
            "punish" => "$row->bad_punish");
      $this->_count++;
    }
    mysqli_free_result($query);

    $done = 0;

    for($i=0; $i < $this->_count; $i++) {
      $hits = 0;
      $tmp_word = '/'.$this->_data[$i]["word"].'/i';
      $col = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
      $tmp_replace = '<span style="color: '.$col.'"><i class="fa fa-exclamation-triangle fa-fw badword" title="\''.$this->_data[$i]["word"].'\' wurde blockiert"></i></span>';
      $new_string = preg_replace($tmp_word, $tmp_replace, $string, -1, $hits);
      if($new_string != $string) {
        $string = $new_string;
        $punish = $this->_data[$i]["punish"];
        switch($punish) {
          case "1":
            $num1 = $num1 + $hits;
          break;
          case "2":
            $num2 = $num2 + $hits;
          break;
          case "3":
            $num3 = $num3 + $hits;
          break;
          case "4":
            $num4 = $num4 + $hits;
          break;
        }
      }
      $this->detected = $this->detected + $hits;
    }
    return array("mess" => $string,
                 "detections" => $this->detected,
                 "n1" => $num1,
                 "n2" => $num2,
                 "n3" => $num3,
                 "n4" => $num4);
  }

  public function checkNameForBadwords($string) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `bad_id`, `bad_word` FROM `".ZE_PRE."_badwords` WHERE `bad_name` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("word"   => "$row->bad_word");
      $this->_count++;
    }
    mysqli_free_result($query);

    $badName = 0;

    for($i=0; $i < $this->_count; $i++) {
      if(strpos(strtolower($string), strtolower($this->_data[$i][word])) !== false) {
        $badName = 1;
        break;
      }
    }
    return $badName;
  }


  public function createBadword($word, $minage, $maxage, $text, $name, $punish) {
    $word = mysqli_real_escape_string($this->_db, $word);
    $query = "INSERT INTO `".ZE_PRE."_badwords`
     (bad_word,
      bad_min_age,
      bad_max_age,
      bad_text,
      bad_name,
      bad_punish)
    VALUES
     ('$word',
      '$minage',
      '$maxage',
      '$text',
      '$name',
      '$punish')";
    $do_it = mysqli_query($this->_db, $query);
  }

  public function updateInfo($id, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_badwords` Set `$field` = '$value' WHERE `bad_id` = '$id'";
    $update = mysqli_query($this->_db, $query);
  }

  public function deleteInfo($id) {
    $query = "DELETE FROM `".ZE_PRE."_badwords` WHERE `bad_id` = '$id'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function getInfo($field, $s_field, $value) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_badwords` WHERE `$s_field` = '$value'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }
}

?>