<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class session {
  private $_count;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getFullData($field, $value){
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_session` WHERE `$field` = '$value'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] =
      array("sess_id"             => "$row->sess_id",
            "user_id"             => "$row->sess_user_id",
            "acc_id"              => "$row->sess_acc_id",
            "logged_in"           => "$row->sess_logged_in",
            "online_status"       => "$row->sess_online_status",
            "status"              => "$row->sess_status",
            "user_level"          => "$row->sess_user_level",
            "last_mess_id"        => "$row->sess_last_message_id",
            "last_mess_got"       => "$row->sess_last_message_got",
            "last_sent_mess_time" => "$row->sess_last_sent_message_time",
            "ping"                => "$row->sess_ping",
            "user_ip"             => "$row->sess_user_ip",
            "browser"             => "$row->sess_user_browser",
            "user_os"             => "$row->sess_user_os",
            "tf_switch"           => "$row->sess_tf_switch",
            "clock_switch"        => "$row->sess_clock_switch",
            "design_switch"       => "$row->sess_design_switch",
            "smilie_switch"       => "$row->sess_smilie_switch",
            "mute_switch"         => "$row->sess_mute_switch",
            "smilie_set"          => "$row->sess_smilie_set",
            "invites"             => "$row->sess_invites",
            "confusion"           => "$row->sess_confusion",
            "update"              => "$row->sess_update");
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function checkSesssion($sid){
    $logged = false;
    $query =
      mysqli_query($this->_db, "SELECT `sess_id` FROM `".ZE_PRE."_session` WHERE `sess_id` = '$sid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $logged = true;
    }
    mysqli_free_result($query);
    return $logged;
  }
  
  public function checkIsOnline($uid){
    $logged = false;
    $query =
      mysqli_query($this->_db, "SELECT `sess_id` FROM `".ZE_PRE."_session` WHERE `sess_user_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $logged = true;
    }
    mysqli_free_result($query);
    return $logged;
  }

  public function updateInfo($idfield, $knownid, $field, $value) {
    $query = "UPDATE `".ZE_PRE."_session` Set `$field` = '$value' WHERE `$idfield` = '$knownid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function updateInfo2($idfield, $knownid, $field, $value, $modi) {
    $query = "UPDATE `".ZE_PRE."_session` Set `$field` = '$value' WHERE `$idfield` $modi '$knownid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function updateInfo3($idfield, $knownid, $field, $value) {
    $query = "UPDATE `".ZE_PRE."_session_room` Set `$field` = '$value' WHERE `$idfield` = '$knownid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function confuseUserRoom($idfield, $knownid, $rid, $field, $value) {
    $query = "UPDATE `".ZE_PRE."_session_room` Set `$field` = '$value' WHERE `$idfield` = '$knownid' AND `sr_rid` = '$rid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function getInfo($s_field, $s_param, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_session` WHERE `$s_field` = '$s_param'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }

  public function getUserRoomInfo($s_field, $s_param, $rid, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_session_room` WHERE `$s_field` = '$s_param' AND `sr_rid` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }

  public function countUserOnline() {
    $this->_count = 0;

    $query =
      mysqli_query($this->_db, "SELECT `sess_id` FROM `".ZE_PRE."_session`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

  public function getOnlineUsers($roomid) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `sess_user_id`, `sess_online_status`, `sess_status`, `sess_user_level`, `sess_confusion` FROM `".ZE_PRE."_session` WHERE `sess_room_id` = '$roomid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $tmp_userid = $row->sess_user_id;
      $tmp_ava = '';
      $tmp_usk = '';
      $tmp_age = '';
      $query2 =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_user` WHERE `user_id` = '$tmp_userid'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)){

        $tmp_ava = '';
        $tmp_usk = '';
        $tmp_age = '';
        $tmp_sta = '';

        $query3 =
          mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$row2->user_id' AND `ava_main` = '1'")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row3 = mysqli_fetch_object($query3)){
          $tmp_ava = "$row3->ava_link";
          $tmp_usk = "$row3->ava_usk";
          $tmp_sta = "$row3->ava_state";
        }
        if($tmp_ava == "") {
          $tmp_ava = 'default_user.jpg';
        }
        if($tmp_sta == "0" && $tmp_ava != 'default_user.jpg') {
          $tmp_ava = 'waiting_user.jpg';
        }
        if($tmp_usk == '') {
          $tmp_usk = "0";
        }
        $this->_data[$this->_count] = array("user_id"=>"$row2->user_id",
                                                "user_name"=>"$row2->user_name",
                                                "user_color"=>"$row2->user_color",
                                                "user_gender"=>"$row2->user_gender",
                                                "user_level"=>"$row->sess_user_level",
                                                "user_online_status"=>"$row->sess_online_status",
                                                "user_status"=>"$row->sess_status",
                                                "user_confusion"=>"$row->sess_confusion",
                                                "user_ava"=>"$tmp_ava",
                                                "user_usk"=>"$tmp_usk");
        $this->_count++;
      }
    }
    mysqli_free_result($query);

    $query =
      mysqli_query($this->_db, "SELECT `room_bot` FROM `".ZE_PRE."_room` WHERE `room_id` = '$roomid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $tmp_botid = $row->room_bot;
    }

    if($tmp_botid != 0) {
      mysqli_free_result($query);
      $query =
        mysqli_query($this->_db, "SELECT `bot_name`, `bot_color`, `bot_pic` FROM `".ZE_PRE."_bots` WHERE `bot_id` = '$tmp_botid'")
          OR die("Error: <br>".mysqlii_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $this->_data[$this->_count] = array("user_id"=>"0",
                                                "user_name"=>"$row->bot_name",
                                                "user_color"=>"$row->bot_color",
                                                "user_gender"=>"3",
                                                "user_level"=>"00",
                                                "user_online_status"=>"1",
                                                "user_status"=>"",
                                                "user_confusion"=>"0",
                                                "user_ava"=>"$row->bot_pic");
        $this->_count++;
      }
    }

    if($this->_count != 0) {
      $this->_data = $this->subval_sort($this->_data, 'user_name'); 
    }

    return $this->_data;
  }

  private function subval_sort($a, $subkey) {
    foreach($a as $k=>$v) {
      $b[$k] = strtolower($v[$subkey]);
    }
    asort($b);
    foreach($b as $key=>$val) {
      $c[] = $a[$key];
    }
    return $c;
  }

  public function roomUserNames($rid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sr_uname` FROM `".ZE_PRE."_session_room` WHERE `sr_rid` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = array("user_name"=>"$row->sr_uname");
      $this->_count++;
    }
    mysqli_free_result($query);
    if($this->_count != 0) {
      $this->_data = $this->subval_sort($this->_data, 'user_name'); 
    }

    return $this->_data;
  }

  public function roomUserNamesFull($rid) {
    $this->_count = 0;
    $this->_data = array();
    $helper = array();
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id`, `ranks_order`, `ranks_title`, `ranks_icon` FROM `".ZE_PRE."_ranks`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $helper[$row->ranks_id] = array("name"  => "$row->ranks_title",
                                      "order" => "$row->ranks_order",
                                      "icon"  => "$row->ranks_icon");
    }
    mysqli_free_result($query);
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_session_room` WHERE `sr_rid` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $mutesw = $this->getInfo('sess_user_id', $row->sr_uid, 'sess_mute_switch');
      $this->_data[$this->_count] = array("uid"     => "$row->sr_uid",
                                          "uname"   => "$row->sr_uname",
                                          "rid"     => "$row->sr_rid",
                                          "owner"   => "$row->sr_owner",
                                          "forced"  => "$row->sr_forced",
                                          "color"   => "$row->sr_color",
                                          "gender"  => "$row->sr_gender",
                                          "level"   => "$row->sr_level",
                                          "rname"   => $helper[$row->sr_level]['name'],
                                          "ricon"   => $helper[$row->sr_level]['icon'],
                                          "rorder"  => $helper[$row->sr_level]['order'],
                                          "ostatus" => "$row->sr_ostatus",
                                          "status"  => "$row->sr_status",
                                          "conf"    => "$row->sr_conf",
                                          "mute"    => $mutesw,
                                          "ava"     => "$row->sr_ava",
                                          "usk"     => "$row->sr_usk");
      $this->_count++;
    }
    mysqli_free_result($query);
    if($this->_count != 0) {
      $this->_data = $this->subval_sort($this->_data, 'uname'); 
    }

    return $this->_data;
  }

  public function roomUserCounts() {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = array("rid" => "$row->sr_rid");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function checkOnlineUsers($roomid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sess_user_id`, `sess_acc_id` FROM `".ZE_PRE."_session` WHERE `sess_room_id` = '$roomid' AND (`sess_online_status` = '1' OR `sess_online_status` = '4')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_data[$this->_count] = array("user_id"=>"$row->sess_user_id",
                                              "user_acc"=>"$row->sess_acc_id");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->data_array;
  }

  public function getOnlineNames($sid) {
    $this->_count = 0;
      $query =
        mysqli_query($this->_db, "SELECT `sess_user_id`, `sess_user_level` FROM `".ZE_PRE."_session` WHERE `sess_id` != '$sid'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)) {
        $tmp_userid = $row->sess_user_id;
        $query2 =
          mysqli_query($this->_db, "SELECT `user_id`, `user_name`, `user_color` FROM `".ZE_PRE."_user` WHERE `user_id` = '$tmp_userid'")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row2 = mysqli_fetch_object($query2)) {
          $this->_data[$this->_count] = array("user_id"=>"$row2->user_id", "user_name"=>"$row2->user_name", "user_color"=>"$row2->user_color", "user_level"=>"$row->sess_user_level");
          $this->_count++;
        }
      }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getOnlineList() {
    $this->_data = array();
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `ranks_id`, `ranks_title`, `ranks_icon` FROM `".ZE_PRE."_ranks`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $helper[$row->ranks_id] = array("name"  => "$row->ranks_title",
                                      "icon"  => "$row->ranks_icon");
    }
    $query =
      mysqli_query($this->_db, "SELECT `sess_user_id`, `sess_online_status`, `sess_user_level` FROM `".ZE_PRE."_session` ORDER BY `sess_logged_in`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $tmp_userid = $row->sess_user_id;
      $tmp_ostatus = $row->sess_online_status;
      $tmp_level = $row->sess_user_level;
      $query2 =
        mysqli_query($this->_db, "SELECT `user_name`, `user_color`, `user_gender` FROM `".ZE_PRE."_user` WHERE `user_id` = '$tmp_userid'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $this->_data[$this->_count] = array("user_id"      => "$tmp_userid",
                                            "user_name"    => "$row2->user_name",
                                            "user_ostatus" => "$tmp_ostatus",
                                            "user_color"   => "$row2->user_color",
                                            "user_gender"  => "$row2->user_gender",
                                            "ricon"        => $helper[$tmp_level]['icon'],
                                            "rname"        => $helper[$tmp_level]['name']);
        $this->_count++;
      }
    }
    usort($this->_data, function($a, $b) {
      return $a['user_name'] <=> $b['user_name'];
    });
    mysqli_free_result($query);
    return $this->_data;
  }

  public function showMods() {
    $data = '';
    $query =
      mysqli_query($this->_db, "SELECT `sess_id`, `sess_user_id`, `sess_user_level`, `sess_online_status`, `sess_room_id` FROM `".ZE_PRE."_session` WHERE
                  `sess_user_level` > '80' AND (`sess_room_id` != '' AND `sess_room_id` != '0')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $query2 =
        mysqli_query($this->_db, "SELECT `user_name` FROM `".ZE_PRE."_user` WHERE
                    `user_id` = '$row->sess_user_id'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $data .= $row2->user_name.'-xxx-';
      }
      mysqli_free_result($query2);
      $query2 =
        mysqli_query($this->_db, "SELECT `ranks_title` FROM `".ZE_PRE."_ranks` WHERE
                    `ranks_level` = '$row->sess_user_level'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $data .= $row2->ranks_title.'-xxx-';
      }
      $data .= $row->sess_user_level.'-xxx-';
      $data .= $row->sess_online_status.'-xxx-';
      mysqli_free_result($query2);
      $query2 =
        mysqli_query($this->_db, "SELECT `room_name` FROM `".ZE_PRE."_room` WHERE
                    `room_id` = '$row->sess_room_id'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $data .= $row2->room_name.'-vvv- ';
      }
      mysqli_free_result($query2);
    }
    $data = substr($data, 0, -6);
    mysqli_free_result($query);
    return $data;
  }

  public function checkSessions($sid, $userid) {
    $query =
      mysqli_query($this->_db, "SELECT `sess_id`, `sess_user_id`, `sess_in_ac` FROM `".ZE_PRE."_session` WHERE
                  `sess_id` != '$sid' AND
                  `sess_user_id` = '$userid' AND
                  `sess_in_ac` = '0'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->deleteSession($row->sess_id);
    }
    mysqli_free_result($query);
  }

  public function checkNewSessions($sid, $currdate) {
    $data = '';
    $query =
      mysqli_query($this->_db, "SELECT `sess_user_id` FROM `".ZE_PRE."_session` WHERE
                  `sess_id` != '$sid' AND
                  `sess_in_ac` != '1' AND
                  `sess_logged_in` > '$currdate'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {

      $data .= '-xy-'.$row->sess_user_id;
      $stored_time = clock();

    }
    mysqli_free_result($query);
    if($data != '') {
      $data = $data.'-yx-'.$stored_time;
      $data = substr($data, 4);
    } else {
      $data = 'none';
    }

    return $data;
  }

  public function deleteSession($sid) {
    $tmpid = $this->getInfo('sess_id', $sid, 'sess_user_id');
    $this->deleteAllWaitings($tmpid);
    $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_id` = '$sid'";
      $do_it = mysqli_query($this->_db, $delete);
  }

  public function addWaiting($waiter, $waiting) {
    $query = "INSERT INTO `".ZE_PRE."_wait`
     (wait_waiter,
      wait_waiting)
    VALUES
     ('$waiter',
      '$waiting')";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function deleteWaiting($waiter, $waiting) {
    $delete = "DELETE FROM `".ZE_PRE."_wait` WHERE `wait_waiter` = '$waiter' AND `wait_waiting` = '$waiting'";
      $do_it = mysqli_query($this->_db, $delete);
  }

  public function deleteAllWaitings($uid) {
    $delete = "DELETE FROM `".ZE_PRE."_wait` WHERE `wait_waiter` = '$uid'";
      $do_it = mysqli_query($this->_db, $delete);
  }

  public function checkWaits($uid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_wait` WHERE `wait_waiting` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_count++;
      $this->_data[] = $row->wait_waiter;
    }
    mysqli_free_result($query);
    if($this->_count != 0) {
      return $this->_data;
    } else {
      return 'error';
    }
  }

  public function checkOwnWaits($uid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_wait` WHERE `wait_waiter` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_count++;
      $this->_data[] = $row->wait_waiting;
    }
    mysqli_free_result($query);
    if($this->_count != 0) {
      return $this->_data;
    } else {
      return 'error';
    }
  }

  public function checkOnAir($sessid, $rid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sess_id` FROM `".ZE_PRE."_session` WHERE `sess_id` != '$sessid' AND `sess_room_id` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[] = $row->sess_id;
      $this->_count++;
    }
    mysqli_free_result($query);
    if($this->_count != 0) {
      for($i=0;$i<$this->_count;$i++) {
        $query = "UPDATE `".ZE_PRE."_session` Set `sess_online_status` = '1' WHERE `sess_id` = '$this->data_array[$i]'";
        $update = mysqli_query($this->_db, $query);
      }
    }
  }

  public function getRooms($sid) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[] = $row->sr_rid;
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getDJ($rid) {
    $query =
      mysqli_query($this->_db, "SELECT `sess_user_id` FROM `".ZE_PRE."_session` WHERE `sess_online_status` = '4' AND `sess_room_id` = '$rid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $dj = $row->sess_user_id;
    }
    mysqli_free_result($query);
    return $dj;
  }

  public function updateSessionLevel() {
    $query =
      mysqli_query($this->_db, "SELECT `user_id`, `user_level` FROM `".ZE_PRE."_user`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $query2 = "UPDATE `".ZE_PRE."_session` Set `sess_user_level` = '$row->user_level' WHERE `sess_user_id` = '$row->user_id'";
      $update = mysqli_query($this->_db, $query2) OR die("Error: <br>".mysqli_error($this->_db));
      $query3 = "UPDATE `".ZE_PRE."_session_room` Set `sr_level` = '$row->user_level' WHERE `sr_uid` = '$row->user_id'";
      $update = mysqli_query($this->_db, $query3) OR die("Error: <br>".mysqli_error($this->_db));
    }
    mysqli_free_result($query);
  }

  public function forceUpdateUser($id) {
    $query = "UPDATE `".ZE_PRE."_session` Set `sess_update` = '1' WHERE `sess_user_id` = '$id'";
    $update = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function forceUpdateGroup($id) {
    $query = "UPDATE `".ZE_PRE."_session` Set `sess_update` = '1' WHERE `sess_user_level` = '$id'";
    $update = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function leaveRoom($sid, $rid) {
    $delete = "DELETE FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid' AND `sr_rid` = '$rid'";
      $do_it = mysqli_query($this->_db, $delete);
  }

  public function createSess($sid, $userid, $accid, $loggedin, $online_status, $userlvl, $ping, $userip, $browser, $useros, $tfswitch, $clockswitch, $dswitch, $smswitch) {
    $query = "INSERT INTO `".ZE_PRE."_session`
     (sess_id,
      sess_user_id,
      sess_acc_id,
      sess_logged_in,
      sess_in_ac,
      sess_online_status,
      sess_status,
      sess_user_level,
      sess_last_message_id,
      sess_last_message_got,
      sess_last_sent_message_time,
      sess_ping,
      sess_user_ip,
      sess_user_browser,
      sess_user_os,
      sess_tf_switch,
      sess_clock_switch,
      sess_design_switch,
      sess_smilie_switch,
      sess_mute_switch, 
      sess_smilie_set,
      sess_invites,
      sess_confusion,
      sess_update)
    VALUES
     ('$sid',
      '$userid',
      '$accid',
      '$loggedin',
      '1',
      '$online_status',
      '',
      '$userlvl',
      '',
      '',
      '$loggedin',
      '$ping',
      '$userip',
      '$browser',
      '$useros',
      '$tfswitch',
      '$clockswitch',
      '$dswitch',
      '$smswitch',
      '0',
      '1',
      '',
      '0',
      '0')";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function createSR($sid, $userid, $uname, $rid, $owner, $forced, $color, $gender, $level, $ava, $usk) {
    $query = "INSERT INTO `".ZE_PRE."_session_room`
     (sr_sid,
      sr_uid,
      sr_uname,
      sr_rid,
      sr_owner,
      sr_forced,
      sr_color,
      sr_gender,
      sr_level,
      sr_ostatus,
      sr_status,
      sr_conf,
      sr_ava,
      sr_usk)
    VALUES
     ('$sid',
      '$userid',
      '$uname',
      '$rid',
      '$owner',
      '$forced',
      '$color',
      '$gender',
      '$level',
      '1',
      '',
      '0',
      '$ava',
      '$usk')";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

}