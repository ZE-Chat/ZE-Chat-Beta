<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class shop {

  public $_count = 0;
  public $_data = array();

  public $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getShopCats($userage) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_item_cats` WHERE `item_cats_min_age` <= '$userage' ORDER BY `item_cats_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"      => "$row->item_cats_id",
            "name"    => "$row->item_cats_name",
            "age"     => "$row->item_cats_min_age");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getShopCat($cid) {
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_item_cats` WHERE `item_cats_id` = '$cid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data =
      array("id"      => "$row->item_cats_id",
            "name"    => "$row->item_cats_name",
            "age"     => "$row->item_cats_min_age");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function switchShopCats($catid, $newid) {
      $query = "UPDATE `".ZE_PRE."_item_cats` Set `item_cats_id` = '0' WHERE `item_cats_id` = '$newid'";
        $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_item` Set `item_cats_id` = '0' WHERE `item_cats_id` = '$newid'";
        $update = mysqli_query($this->_db, $query) OR die("1Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_item_cats` Set `item_cats_id` = '$newid' WHERE `item_cats_id` = '$catid'";
        $update = mysqli_query($this->_db, $query) OR die("2Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_item` Set `item_cats_id` = '$newid' WHERE `item_cats_id` = '$catid'";
        $update = mysqli_query($this->_db, $query) OR die("2Error <br>".mysqli_error($this->_db));

      $query = "UPDATE `".ZE_PRE."_item_cats` Set `item_cats_id` = '$catid' WHERE `item_cats_id` = '0'";
        $update = mysqli_query($this->_db, $query) OR die("3Error <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_item` Set `item_cats_id` = '$catid' WHERE `item_cats_id` = '0'";
        $update = mysqli_query($this->_db, $query) OR die("3Error <br>".mysqli_error($this->_db));
  }
  
  public function deleteItem($iid) {
    $query = "DELETE FROM `".ZE_PRE."_inv` WHERE `inv_item_id` = '$iid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
    $query = "DELETE FROM `".ZE_PRE."_presents` WHERE `pres_item` = '$iid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
    $query = "DELETE FROM `".ZE_PRE."_item` WHERE `item_id` = '$iid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function createItemCats($name, $age) {
    $query = "INSERT INTO `".ZE_PRE."_item_cats`
     (item_cats_name,
      item_cats_min_age)
      VALUES
     ('$name',
      '$age')";
    $create = mysqli_query($this->_db, $query);
    $cat_id = mysqli_insert_id($this->_db);
    return $cat_id;
  }

  public function createItem($name, $pic, $cats_id, $text, $duration, $avail, $avail_until, $cost, $age, $special, $code) {
    $query = "INSERT INTO `".ZE_PRE."_item`
     (item_name,
      item_pic,
      item_cats_id,
      item_text,
      item_duration,
      item_available,
      item_available_until,
      item_cost,
      item_discount_cost,
      item_discount_until,
      item_min_age,
      item_special,
      item_code)
      VALUES
     ('$name',
      '$pic',
      '$cats_id',
      '$text',
      '$duration',
      '$avail',
      '$avail_until',
      '$cost',
      '0',
      '0',
      '$age',
      '$special',
      '$code')";
    $create = mysqli_query($this->_db, $query);
    $item_id = mysqli_insert_id($this->_db);
    return $item_id;
  }

  public function getCatItems($catid, $userage) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `item_id`, `item_name`, `item_pic`, `item_available`, `item_available_until`, `item_cost`, `item_discount_cost`, `item_discount_until`, `item_special` FROM `".ZE_PRE."_item` WHERE `item_cats_id` = '$catid' AND `item_min_age` <= '$userage' ORDER BY `item_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"             => "$row->item_id",
            "name"           => "$row->item_name",
            "pic"            => "$row->item_pic",
            "avail"          => "$row->item_available",
            "until"          => "$row->item_available_until",
            "cost"           => "$row->item_cost",
            "discount_cost"  => "$row->item_discount_cost",
            "discount_until" => "$row->item_discount_until",
            "special"        => "$row->item_special");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getNoCatItems($catid) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `item_id`, `item_name`, `item_pic` FROM `".ZE_PRE."_item` WHERE ".$catid." ORDER BY `item_name`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"   => "$row->item_id",
            "name" => "$row->item_name",
            "pic"  => "$row->item_pic");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getShopItem($itemid, $userage) {
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_item` WHERE `item_id` = '$itemid' AND `item_min_age` <= '$userage'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data =
      array("id"             => "$row->item_id",
            "name"           => "$row->item_name",
            "pic"            => "$row->item_pic",
            "catid"          => "$row->item_cats_id",
            "text"           => "$row->item_text",
            "dura"           => "$row->item_duration",
            "avail"          => "$row->item_available",
            "until"          => "$row->item_available_until",
            "cost"           => "$row->item_cost",
            "discount_cost"  => "$row->item_discount_cost",
            "discount_until" => "$row->item_discount_until",
            "mage"           => "$row->item_min_age",
            "special"        => "$row->item_special",
            "code"           => "$row->item_code");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getShopItemNames($userage, $cat) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT `item_id`, `item_name`, `item_pic` FROM `".ZE_PRE."_item` WHERE `item_min_age` <= '$userage' AND `item_cats_id` = '$cat'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"   => "$row->item_id",
            "name" => "$row->item_name",
            "pic"  => "$row->item_pic");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function buyItem($itemid, $userid) {
    $itemid = mysqli_real_escape_string($this->_db, $itemid);
    $userid = mysqli_real_escape_string($this->_db, $userid);

    $bought = time();

    $query = "INSERT INTO `".ZE_PRE."_inv`
     (inv_user_id,
      inv_item_id,
      inv_item_bought,
      inv_item_is_present,
      inv_item_sender,
      inv_present_text)
      VALUES
     ('$userid',
      '$itemid',
      '$bought',
      '0',
      '',
      '')";
    $create = mysqli_query($this->_db, $query);
    $inv_id = mysqli_insert_id($this->_db);
    return $inv_id;
  }

  public function sendItem($sender, $getter, $item, $text, $invid) {
    $sender = mysqli_real_escape_string($this->_db, $sender);
    $getter = mysqli_real_escape_string($this->_db, $getter);
    $item = mysqli_real_escape_string($this->_db, $item);
    $text = mysqli_real_escape_string($this->_db, $text);

    $sent = time();

    $query = "DELETE FROM `".ZE_PRE."_inv` WHERE `inv_id` = '$invid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));

    $query = "INSERT INTO `".ZE_PRE."_presents`
     (pres_sender_id,
      pres_getter_id,
      pres_date,
      pres_item,
      pres_text,
      pres_state)
      VALUES
     ('$sender',
      '$getter',
      '$sent',
      '$item',
      '$text',
      '1')";
    $create = mysqli_query($this->_db, $query);
    $pres_id = mysqli_insert_id($this->_db);

    return $pres_id;
  }

  public function acceptItem($presid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_presents` WHERE `pres_id` = '$presid' AND `pres_state` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $sender = "$row->pres_sender_id";
      $getter = "$row->pres_getter_id";
      $item = "$row->pres_item";
      $text = "$row->pres_text";
    }
    $query = "UPDATE `".ZE_PRE."_presents` Set `pres_state` = '2' WHERE `pres_id` = '$presid'";
    $update = mysqli_query($this->_db, $query);

    $took = time();

    $query = "INSERT INTO `".ZE_PRE."_inv`
     (inv_user_id,
      inv_item_id,
      inv_item_bought,
      inv_item_is_present,
      inv_item_sender,
      inv_present_text)
      VALUES
     ('$getter',
      '$item',
      '$took',
      '1',
      '$sender',
      '$text')";
    $create = mysqli_query($this->_db, $query);

    $now = date('Y-m-d H:i:s');
    $subject = 'Geschenk angenommen';
    $mailtext = 'Geschenk wurde angenommen';

    $query = "INSERT INTO `".ZE_PRE."_mail`
     (mail_sender,
      mail_getter,
      mail_date,
      mail_subject, 
      mail_text,
      mail_state)
    VALUES
     ('0',
      '$sender',
      '$now',
      '$subject',
      '$mailtext',
      '1')";
    $insert = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));

  }

  public function denyItem($presid, $mode) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_presents` WHERE `pres_id` = '$presid' AND `pres_state` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $sender = "$row->pres_sender_id";
      $getter = "$row->pres_getter_id";
      $item = "$row->pres_item";
      $text = "$row->pres_text";
    }
    $query = "UPDATE `".ZE_PRE."_presents` Set `pres_state` = '3' WHERE `pres_id` = '$presid'";
    $update = mysqli_query($this->_db, $query);

    $took = time();

    $query = "INSERT INTO `".ZE_PRE."_inv`
     (inv_user_id,
      inv_item_id,
      inv_item_bought,
      inv_item_is_present,
      inv_item_sender,
      inv_present_text)
      VALUES
     ('$sender',
      '$item',
      '$took',
      '0',
      '',
      '')";
    $create = mysqli_query($this->_db, $query);

    if($mode == 1) {
      $now = date('Y-m-d H:i:s');
      $subject = 'Geschenk abgelehnt';
      $mailtext = 'Geschenk wurde abgelehnt!';

      $query = "INSERT INTO `".ZE_PRE."_mail`
       (mail_sender,
        mail_getter,
        mail_date,
        mail_subject, 
        mail_text,
        mail_state)
      VALUES
       ('0',
        '$sender',
        '$now',
        '$subject',
        '$mailtext',
        '1')";
      $insert = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
    } else {
      $query = "UPDATE `".ZE_PRE."_presents` Set `pres_state` = '4' WHERE `pres_id` = '$presid'";
      $update = mysqli_query($this->_db, $query);
    }
  }

  public function getInven($userid) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_inv` WHERE `inv_user_id` = '$userid' ORDER BY `inv_item_bought`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"      => "$row->inv_id",
            "item"    => "$row->inv_item_id",
            "bought"  => "$row->inv_item_bought",
            "present" => "$row->inv_item_is_present",
            "sender"  => "$row->inv_item_sender",
            "text"    => "$row->inv_present_text");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getInvenItem($invenid) {
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_inv` WHERE `inv_id` = '$invenid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data =
      array("id"      => "$row->inv_id",
            "item"    => "$row->inv_item_id",
            "bought"  => "$row->inv_item_bought",
            "present" => "$row->inv_item_is_present",
            "sender"  => "$row->inv_item_sender",
            "text"    => "$row->inv_present_text");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function getPresents($userid) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_presents` WHERE `pres_sender_id` = '$userid' OR `pres_getter_id` = '$userid' ORDER BY `pres_date`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_data[$this->_count] =
      array("id"      => "$row->pres_id",
            "sender"  => "$row->pres_sender_id",
            "getter"  => "$row->pres_getter_id",
            "date"    => "$row->pres_date",
            "item"    => "$row->pres_item",
            "text"    => "$row->pres_text",
            "state"   => "$row->pres_state");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function checkSpecialItems($userid) {
    $this->_count=0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_inv` WHERE `inv_user_id` = '$userid' ORDER BY `inv_item_bought`")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $query2 =
        mysqli_query($this->_db, "SELECT `item_id`, `item_code` FROM `".ZE_PRE."_item` WHERE `item_id` = '$row->inv_item_id' AND `item_special` = '1' LIMIT 1")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)) {
        $this->_data[$this->_count] =
        array("id"      => "$row2->item_id",
              "code"    => "$row2->item_code",
              "inv_id"  => "$row->inv_id");
        $this->_count++;
      }
    }
    return $this->_data;
  }
  
  public function checkDiscountItems() {
    $this->_count=0;
    $this->_data = array();
    $now = time();
    $query =
      mysqli_query($this->_db, "SELECT `item_id`, `item_discount_until` FROM `".ZE_PRE."_item` WHERE `item_discount_until` != '0'")
        OR die("GetError: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      if($now > $row->item_discount_until) {
        $this->updateInfo(ZE_PRE."_item", 'item_id', $row->item_id, 'item_discount_cost', '0');
        $this->updateInfo(ZE_PRE."_item", 'item_id', $row->item_id, 'item_discount_until', '0');
      }
    }
    mysqli_free_result($query);
  }

  public function countNewPresents($uid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_presents` WHERE `pres_getter_id` = '$uid' AND `pres_state` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    $this->_count = mysqli_num_rows($query);
    mysqli_free_result($query);
    return $this->_count;
  }

  public function countPresents($uid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_presents` WHERE `pres_getter_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    $this->_count = mysqli_num_rows($query);
    mysqli_free_result($query);
    return $this->_count;
  }

  public function updateInfo($table, $id_field, $id, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `$table` Set `$field` = '$value' WHERE `$id_field` = '$id'";
    $update = mysqli_query($this->_db, $query) OR die("UpdateError: <br>".mysqli_error($this->_db));
  }

  public function deleteInfo($table, $id_field, $id) {
    $query = "DELETE FROM `$table` WHERE `$id_field` = '$id'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  public function getInfo($table, $field, $s_field, $value) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `$table` WHERE `$s_field` = '$value'")
        OR die("GetError: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }
  
  public function consumeItem($uid, $hook) {
    $this->_count=0;
    $todel = '';
    $found = false;
    $query2 =
      mysqli_query($this->_db, "SELECT `inv_id`, `inv_item_id`, `inv_item_bought` FROM `".ZE_PRE."_inv` WHERE `inv_user_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row2 = mysqli_fetch_object($query2)){
      $query =
        mysqli_query($this->_db, "SELECT `item_id`, `item_duration`, `item_code` FROM `".ZE_PRE."_item` WHERE `item_code` = '$hook' AND `item_id` = '$row2->inv_item_id'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        if($found == false) {
          $found = true;
          $this->deleteInfo(ZE_PRE.'_inv', 'inv_id', $row2->inv_id);
          goto output;
        }
      }
    }
    output:
    mysqli_free_result($query2);
    return $found;
  }

  public function checkItems($uid) {
    $todel = '';
    $delitems = '';
    $delsmilie = '';
    $query2 =
      mysqli_query($this->_db, "SELECT `inv_id`, `inv_item_id`, `inv_item_bought` FROM `".ZE_PRE."_inv` WHERE `inv_user_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row2 = mysqli_fetch_object($query2)){
      $query =
        mysqli_query($this->_db, "SELECT `item_id`, `item_duration`, `item_code` FROM `".ZE_PRE."_item` WHERE `item_duration` != '0' AND `item_id` = '$row2->inv_item_id'")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row = mysqli_fetch_object($query)){
        $now = time();
        $check = $row2->inv_item_bought+$row->item_duration;
        if($now > $check) {
          $delsmilie = 'no';
          if($row->item_code != '') {
            $checker = explode("-", $row->item_code);
            if($checker[0] == 'smilie') {
              $delsmilie = 'yes';
            }
          }
          $todel .= ','.$row2->inv_id.'-'.$delsmilie;
          $delitems .= ','.$row->item_id;
        }
      }
    }
    if($todel != '') {
      if(substr_count($todel, ',') > 1) {
        $todel = explode(',', $todel);
        $tmpcount = count($todel);
      } else {
        $tmpdel = substr($todel, 1);
        $todel = array();
        $todel[0] = $tmpdel;
        $tmpcount = 1;
      }
      if(substr_count($delitems, ',') > 1) {
        $delitems = explode(',', $delitems);
      } else {
        $tmpdel = substr($delitems, 1);
        $delitems = array();
        $delitems[0] = $tmpdel;
      }
      for($i=0; $i < $tmpcount; $i++) {
        $query3 =
          mysqli_query($this->_db, "SELECT `item_name` FROM `".ZE_PRE."_item` WHERE `item_id` = '$delitems[$i]'")
            OR die("Error: <br>".mysqli_error($this->_db));
        while($row3 = mysqli_fetch_object($query3)){
          $tmp_name = $row3->item_name;
        }
        mysqli_free_result($query3);
        $tmp_holder = explode('-', $todel[$i]);
        $query = "DELETE FROM `".ZE_PRE."_inv` WHERE `inv_id` = '$tmp_holder[0]'";
        $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
        $now = date('Y-m-d H:i:s');
        $subject = 'Gegenstand abgelaufen!';
        $mailtext = 'Dein Gegenstand &quot;'.$tmp_name.'&quot; hat sein Verfallsdatum erreicht und wurde gel&ouml;scht.';
        if($tmp_holder[1] == 'yes') {
          $query = "UPDATE `".ZE_PRE."_user` Set `user_smilie_set` = '1' WHERE `user_id` = '$uid'";
          $update = mysqli_query($this->_db, $query);
          $subject = 'Smilies abgelaufen!';
          $mailtext = 'Deine Smilies &quot;'.$tmp_name.'&quot; haben ihr Verfallsdatum erreicht und wurden gel&ouml;scht. Das Standart-Set wurde wieder aktiviert.';
        }
        $query2 = "INSERT INTO `".ZE_PRE."_mail`
         (mail_sender,
          mail_getter,
          mail_date,
          mail_subject, 
          mail_text,
          mail_state)
        VALUES
         ('0',
          '$uid',
          '$now',
          '$subject',
          '$mailtext',
          '1')";
        $insert = mysqli_query($this->_db, $query2) OR die("Error: <br>".mysqli_error($this->_db));

      }
    }
//    mysqli_free_result($query);
  }
}

?>