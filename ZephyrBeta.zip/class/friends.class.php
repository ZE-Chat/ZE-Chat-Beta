<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class friends {

  public $_count = 0;
  public $_data = array();
  public $frid;

  public $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getFriendlist($uid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_friendlist` WHERE (`fl_friend_1` = '$uid' || `fl_friend_2` = '$uid')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $query2 =
        mysqli_query($this->_db, "SELECT `user_id`, `user_name`, `user_last_seen` FROM `".ZE_PRE."_user` WHERE ((`user_id` = '$row->fl_friend_1' OR `user_id` = '$row->fl_friend_2') AND `user_id` != '$uid')")
          OR die("Error: <br>".mysqli_error($this->_db));
      while($row2 = mysqli_fetch_object($query2)){
        $friendname = $row2->user_name;
        $friendid = $row2->user_id;
        $friendlast = $this->redoDate($row2->user_last_seen);
      }
      if($uid == $row->fl_friend_2) {
        $inviter = false;
      } else {
        $inviter = true;
      }
      mysqli_free_result($query2);
      $this->_data[$this->_count] =
      array("id"       => "$row->fl_id",
            "friend1"  => "$row->fl_friend_1",
            "friend2"  => "$row->fl_friend_2",
            "state"    => "$row->fl_state",
            "date"     => "$row->fl_date",
            "fid"      => $friendid,
            "fname"    => $friendname,
            "flast"    => $friendlast,
            "fava"     => "",
            "fhas"     => $this->FLcountFriends($friendid),
            "fonline"  => "",
            "finviter" => $inviter);
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function updateInfo($fid, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_friendlist` Set `$field` = '$value' WHERE `fl_id` = '$fid'";
    $update = mysqli_query($this->_db, $query);
  }

  public function getInfo($s_field, $s_param, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_friendlist` WHERE `$s_field` = '$s_param'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }
  
  private function redoDate($str) {
    $tmp_full_date = $str;
    $tmp_split_full_date = explode(" ", $tmp_full_date);
    $tmp_split_date = explode("-", $tmp_split_full_date[0]);
    $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
    $str = $tmp_split_date.', '.$tmp_split_full_date[1].' Uhr';
    return $str;
  }

  public function countFriends($uid) {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `fl_id` FROM `".ZE_PRE."_friendlist` WHERE (`fl_friend_1` = '$uid' || `fl_friend_2` = '$uid')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }
  
  public function FLcountFriends($uid) {
    $counter = 0;
    $query =
      mysqli_query($this->_db, "SELECT `fl_id` FROM `".ZE_PRE."_friendlist` WHERE ((`fl_friend_1` = '$uid' || `fl_friend_2` = '$uid') AND `fl_state` = '3')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)) {
      $counter++;
    }
    mysqli_free_result($query);
    return $counter;
  }

  public function checkFriends($uid1, $uid2) {
    $query =
      mysqli_query($this->_db, "SELECT `fl_id`, `fl_state` FROM `".ZE_PRE."_friendlist` WHERE (`fl_friend_1` = '$uid1' AND `fl_friend_2` = '$uid2') OR (`fl_friend_1` = '$uid2' AND `fl_friend_2` = '$uid1')")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $data = $row->fl_state;
      $this->frid = $row->fl_id;
    }
    if($data == 3 || $data == 4) {
      $data = 'friend';
    } else if($data == 2 || $data == 1) {
      $data = 'pending';
    } else {
      $data = 'none';
    }
    return $data;
    mysqli_free_result($query);
  }

//$state can be
//1 for open public request
//2 for open private request
//3 for closed public request
//4 for closed private request
  public function createFriends($uid1, $uid2, $state) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_friendlist` WHERE (`fl_friend_1` = '$uid1' AND `fl_friend_2` = '$uid2') OR (`fl_friend_1` = '$uid2' AND `fl_friend_2` = '$uid1')")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($query)==0) {
      $query = "INSERT INTO `".ZE_PRE."_friendlist`
       (fl_friend_1,
        fl_friend_2,
        fl_state,
        fl_date)
      VALUES
       ('$uid1',
        '$uid2',
        '$state',
        NOW())";
      $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_user` Set `user_flist` = user_flist+1 WHERE `user_id` = '$uid2'";
      $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      return true;
    } else {
      return false;
    }
  }

  public function acceptFriend($uid1, $uid2, $state) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_friendlist` WHERE ((`fl_friend_1` = '$uid1' AND `fl_friend_2` = '$uid2') OR (`fl_friend_1` = '$uid2' AND `fl_friend_2` = '$uid1')) AND (`fl_state` = '1' OR `fl_state` = '2')")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($query)==1) {
      while($row = mysqli_fetch_object($query)) {
        $tmpid = "$row->fl_id";
        $curr_state = "$row->fl_state";
        $go = '1';
      }
    } else {
      return false;
      $go = '0';
    }
    if($go == '1') {
      if($curr_state == '1') {
        $query = "UPDATE `".ZE_PRE."_friendlist` Set `fl_state` = '3' WHERE `fl_id` = '$tmpid'";
      } else {
        $query = "UPDATE `".ZE_PRE."_friendlist` Set `fl_state` = '4' WHERE `fl_id` = '$tmpid'";
      }
      $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
      $query = "UPDATE `".ZE_PRE."_user` Set `user_flist` = user_flist-1 WHERE `user_flist` > '0' AND `user_id` = '$uid1'";
      $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
    }
    return $tmpid;
  }

  public function deleteFriend($fid) {
    $query = "DELETE FROM `".ZE_PRE."_friendlist` WHERE `fl_id` = '$fid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }
  
  public function denyFriend($uid, $fid) {
    $query = "UPDATE `".ZE_PRE."_user` Set `user_flist` = user_flist-1 WHERE `user_flist` > '0' AND `user_id` = '$uid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
    $query = "DELETE FROM `".ZE_PRE."_friendlist` WHERE `fl_id` = '$fid'";
    $do_it = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }
}

?>