<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class news {

  private $_count;
  private $_data = array();
  private $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

  public function getNews() {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_news` ORDER BY `news_id` DESC")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $tdate = $this->redoDate($row->news_date);
      $this->_data[$this->_count] = array("nid"=>"$row->news_id",
                                          "date"=>"$tdate",
                                          "from"=>"$row->news_author",
                                          "title"=>"$row->news_title",
                                          "content"=>"$row->news_content");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function getSpecificNews($id) {
    $this->_count = 0;
    $this->_data = array();
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_news` WHERE `news_id` = '$id'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $tdate = $this->redoDate($row->news_date);
      $content = str_replace("<br />", " ", $row->news_content );
      $content = str_replace("<br>", " ", $row->news_content );
      $this->_data = array("nid"=>"$row->news_id",
                           "title"=>"$row->news_title",
                           "content"=>"$content");
     }
    mysqli_free_result($query);
    return $this->_data;
  }

  public function writeNews($date, $author, $title, $content) {
    $date = mysqli_real_escape_string($this->_db, $date);
    $author = mysqli_real_escape_string($this->_db, $author);
    $title = mysqli_real_escape_string($this->_db, $title);
    $content = trim(mysqli_real_escape_string($this->_db, $content));
    $query = "INSERT INTO `".ZE_PRE."_news`
     (news_date,
      news_author,
      news_title,
      news_content)
      VALUES
     ('$date',
      '$author',
      '$title',
      '$content')";
    $write = mysqli_query($this->_db, $query) OR die("Error: <br>".mysqli_error($this->_db));
  }

  private function redoDate($str) {
    $tmp_full_date = $str;
    $tmp_split_full_date = explode(" ", $tmp_full_date);
    $tmp_split_date = explode("-", $tmp_split_full_date[0]);
    $tmp_split_date = $tmp_split_date[2].'.'.$tmp_split_date[1].'.'.$tmp_split_date[0];
    $str = 'Am '.$tmp_split_date.' um '.$tmp_split_full_date[1].' Uhr';
    return $str;
  }

  public function deleteNews($newsid) {
    $newsid = mysqli_real_escape_string($this->_db, $newsid);
    $query = "DELETE FROM `".ZE_PRE."_news` WHERE `news_id` = '$newsid'";
      $delete = mysqli_query($this->_db, $query);
  }

  public function getInfo($nid, $field) {
    $query =
      mysqli_query($this->_db, "SELECT `$field` FROM `".ZE_PRE."_news` WHERE `news_id` = '$nid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      return $row->$field;
    }
    mysqli_free_result($query);
  }
  public function updateInfo($nid, $field, $value) {
    $query = "UPDATE `".ZE_PRE."_news` Set `$field` = '$value' WHERE `news_id` = '$nid'";
    $update = mysqli_query($this->_db, $query);
  }

}

?>