<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

class avatar {

//Initiate helper vars

  public $id;

  public $_count;
  public $_data = array();

  public $_db;

  public function __construct($dbdata) {
    $this->_db = $dbdata;
  }

//getMainAva(userid)
//Grabs main avatar for specified user with all needed information
//Returns data array for further usage

  public function getMainAva($uid) {
    $gender = 0;
    $query =
      mysqli_query($this->_db, "SELECT `user_gender` FROM `".ZE_PRE."_user` WHERE `user_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $gender = $row->user_gender;
    }
    mysqli_free_result($query);
    
    switch($gender) {
      case 0: $pic = 'default_user.jpg';   break;
      case 1: $pic = 'm_default_user.png'; break;
      case 2: $pic = 'f_default_user.png'; break;
    }
    
    $this->_data = array("ava_id"    => "0",
                         "ava_link"  => $pic,
                         "ava_usk"   => "0",
                         "ava_desc"  => "No Avatar set",
                         "ava_state" => "1");
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$uid' AND `ava_main` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      if($row->ava_state == '1') {
        $pic = $row->ava_link;
        $this->_data = array("ava_id"    => "$row->ava_id",
                             "ava_link"  => $pic,
                             "ava_usk"   => "$row->ava_usk",
                             "ava_desc"  => "$row->ava_desc",
                             "ava_state" => "$row->ava_state");
      } else {
        $this->_data = array("ava_id"    => "$row->ava_id",
                             "ava_link"  => "waiting_user.jpg",
                             "ava_usk"   => "0",
                             "ava_desc"  => "$row->ava_desc",
                             "ava_state" => "$row->ava_state");
      }
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
//getAva(avatarid)
//Grabs specified avatar with all needed information
//Returns data array for further usage
  
  public function getAva($aid) {
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_id` = '$aid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      if($row->ava_desc == '') { $desc = '&nbsp;'; } else { $desc = $row->ava_desc; }
      $this->_data = array("ava_id"      => "$row->ava_id",
                           "ava_user_id" => "$row->ava_user_id",
                           "ava_link"    => "$row->ava_link",
                           "ava_usk"     => "$row->ava_usk",
                           "ava_main"    => "$row->ava_main",
                           "ava_desc"    => "$row->ava_desc",
                           "ava_priv"    => "$row->ava_priv",
                           "ava_state"   => "$row->ava_state");
    }
    mysqli_free_result($query);
    return $this->_data;
  }

//getAllAva(userid, privatemode)
//Grabs all avatars for specified user with all needed information
//Privatemode can 0 (open to all) or 1 (only for user)
//Returns data array for further usage

  public function getAllAva($uid, $priv) {
    $this->_data = array();
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$uid' AND `ava_main` != '1' AND `ava_priv` = '$priv'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      if($row->ava_state == '1') {
        $this->_data[$this->_count] = array("ava_id"    => "$row->ava_id",
                                            "ava_link"  => "$row->ava_link",
                                            "ava_usk"   => "$row->ava_usk",
                                            "ava_main"  => "$row->ava_main",
                                            "ava_desc"  => "$row->ava_desc",
                                            "ava_state" => "$row->ava_state");
      } else {
        $this->_data[$this->_count] = array("ava_id"    => "$row->ava_id",
                                            "ava_link"  => "waiting_user.jpg",
                                            "ava_usk"   => "0",
                                            "ava_main"  => "$row->ava_main",
                                            "ava_desc"  => "$row->ava_desc",
                                            "ava_state" => "$row->ava_state");
      }
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }

//updateAva(avatarid, fieldname, value)

  public function updateAva($aid, $field, $value) {
    $value = mysqli_real_escape_string($this->_db, $value);
    $query = "UPDATE `".ZE_PRE."_avatar` Set `$field` = '$value' WHERE `ava_id` = '$aid'";
    $update = mysqli_query($this->_db, $query);
  }

//deleteAva(userid, avatarid)
//Deletes specified avatar from table and HDD

  public function deleteAva($uid, $aid) {
    $query = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_id` = '$aid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $file = './files/userpic/'.$row->ava_link;
      unlink($file);
      $delete = "DELETE FROM `".ZE_PRE."_avatar` WHERE `ava_id` = '$aid' AND `ava_user_id` = '$uid'";
      $do_it = mysqli_query($this->_db, $delete);
    }
    mysqli_free_result($query);
  }

//countAva(userid)
//Counts users avatar for maximum specified avatars
//Returns count for further usage

  public function countAva($uid) {
    $check = mysqli_query($this->_db, "SELECT `ava_user_id` FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$uid'")
        OR die("Error: <br>".mysqli_error($this->_db));
    return mysqli_num_rows($check);
    mysqli_free_result($check);
  }

//changeMainAva(userid, avatarid, privatemode)
//Updates main avatar for specified user
//Updates privatemode if needed

  public function changeMainAva($uid, $aid, $priv) {
    $query = "UPDATE `".ZE_PRE."_avatar` Set `ava_main` = '0' WHERE `ava_user_id` = '$uid' AND `ava_main` = '1'";
    $update = mysqli_query($this->_db, $query);
    $query = "UPDATE `".ZE_PRE."_avatar` Set `ava_main` = '1' WHERE `ava_user_id` = '$uid' AND `ava_id` = '$aid'";
    $update = mysqli_query($this->_db, $query);
    if($priv == '1') {
      $query = "UPDATE `".ZE_PRE."_avatar` Set `ava_priv` = '0' WHERE `ava_user_id` = '$uid' AND `ava_id` = '$aid'";
      $update = mysqli_query($this->_db, $query);
    }
  }
  
//listOpenAva(avatarid)
//avatarid can be empty
//Used for Adminpanel if avatars need to be verified by administrators
//Returns data array for further usage

  public function listOpenAva($aid) {
    $this->_count = 0;
    if($aid == '') {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_state` = '2' LIMIT 1")
          OR die("Error: <br>".mysqli_error($this->_db));
    } else {
      $query =
        mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_state` = '2' AND `ava_id` = '$aid'")
          OR die("Error: <br>".mysqli_error($this->_db));
    }
    while($row = mysqli_fetch_object($query)){
      if($row->ava_desc == '') { $desc = '&nbsp;'; } else { $desc = $row->ava_desc; }
      $this->_data = array("ava_id"      => "$row->ava_id",
                           "ava_user_id" => "$row->ava_user_id",
                           "ava_link"    => "$row->ava_link",
                           "ava_usk"     => "$row->ava_usk",
                           "ava_main"    => "$row->ava_main",
                           "ava_desc"    => $desc,
                           "ava_priv"    => "$row->ava_priv",
                           "ava_state"   => "$row->ava_state");
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_data;
  }
  
  public function countOpenAva() {
    $this->_count = 0;
    $query =
      mysqli_query($this->_db, "SELECT `ava_id` FROM `".ZE_PRE."_avatar` WHERE `ava_state` = '2'")
        OR die("Error: <br>".mysqli_error($this->_db));
    while($row = mysqli_fetch_object($query)){
      $this->_count++;
    }
    mysqli_free_result($query);
    return $this->_count;
  }

//newAva(userid, imagename(randomized), mainswitch, usk, description, privatemode, state)
//Writes all needed data to ze_avatar table and sets new avatar to main if mainswitch is 1

  public function newAva($uid, $aname, $amain, $ausk, $adesc, $apriv, $state) {
    $uid   = mysqli_real_escape_string($this->_db, $uid);
    $aname = mysqli_real_escape_string($this->_db, $aname);
    $amain = mysqli_real_escape_string($this->_db, $amain);
    $ausk  = mysqli_real_escape_string($this->_db, $ausk);
    $adesc = mysqli_real_escape_string($this->_db, $adesc);

    $check = mysqli_query($this->_db, "SELECT * FROM `".ZE_PRE."_avatar` WHERE `ava_user_id` = '$uid' AND `ava_main` = '1'")
        OR die("Error: <br>".mysqli_error($this->_db));
    if(mysqli_num_rows($check) == 0) {
      $amain = '1';
    } else {
      if($amain == 1) {
        $query = "UPDATE `".ZE_PRE."_avatar` Set `ava_main` = '0' WHERE `ava_user_id` = '$uid' AND `ava_main` = '1'";
        $update = mysqli_query($this->_db, $query);
      }
    }
    $query = "INSERT INTO `".ZE_PRE."_avatar`
     (ava_user_id,
      ava_link,
      ava_main,
      ava_usk,
      ava_desc,
      ava_priv,
      ava_state)
    VALUES
     ('$uid',
      '$aname',
      '$amain',
      '$ausk',
      '$adesc',
      '$apriv',
      '$state')";
    $do_it = mysqli_query($this->_db, $query);
    mysqli_free_result($check);
  }

}

?>