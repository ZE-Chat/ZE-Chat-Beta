<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
//Include UserClass
//Include SessionClass
//Include MessageClass
//Include AvatarClass
require_once './class/user.class.php';
require_once './class/session.class.php';
require_once './class/message.class.php';
require_once './class/avatar.class.php';

$ZE_USER = new user($db);
$ZE_SESS = new session($db);
$ZE_MESS = new message($db);
$ZE_AVA = new avatar($db);

$ZE_SID = htmlspecialchars($_POST["sid"]);
$ZE_oldid = htmlspecialchars($_POST["oldid"]);
$ZE_newid = htmlspecialchars($_POST["newid"]);
$new_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_newid, 'user_name');

$first = true;

//$ZE_SELR->checkRooms();
$count = 0;
$query =
  mysqli_query($db, "SELECT `sess_user_id`, `sess_acc_id`, `sess_user_ip` FROM `".ZE_PRE."_session` WHERE `sess_id` = '$ZE_SID'")
    OR die("Error: <br>".mysqli_error($db));
while($row = mysqli_fetch_object($query)){
    if($first == true) {
      $user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $row->sess_user_id, 'user_name');
      $accid = $row->sess_acc_id;
      $uid = $row->sess_user_id;
      $ip = $row->sess_user_ip;
      $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $accid, 'acc_global_last_login', clock());
      $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_last_seen', clock());
      $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_last_used_ip', $ip);
      $message = htmlspecialchars('"'.$user_name.'" ist nun "'.$new_user_name.'"! (Wechsel)');
      $first = false;
    }
    $helper = array();
    $query2 =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$ZE_SID'")
        OR die("Error: <br>".mysqli_error($db));
    while($row2 = mysqli_fetch_object($query2)){
      $helper[] = $row2->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              '0',
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
}
$new_level = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_newid, 'user_level');
$new_color = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_newid, 'user_color');
$new_gender = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_newid, 'user_gender');
$tmp_ava = $ZE_AVA->getMainAva($ZE_newid);

$ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_user_id', $ZE_newid);
$ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_user_level', $new_level);


$ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_uid', $ZE_newid);
$ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_uname', $new_user_name);
$ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_color', $new_color);
$ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_gender', $new_gender);
$ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_level', $new_level);
$ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_ava', $tmp_ava["ava_link"]);

if($ZE_SETTINGS->cp('show_acp', $ZE_newid, $new_level) != false) {
  $acp = 'yes';
} else {
  $acp = 'no';
}
if($ZE_SETTINGS->cp('bypass_room', $ZE_newid, $new_level) != false) {
  $bpr = 'yes';
} else {
  $bpr = 'no';
}

$data = array('aid' => $accid,
              'lvl' => $new_level,
              'name' => $new_user_name,
              'ucol' => $new_color,
              'acp' => $acp,
              'bpr' => $bpr);

echo json_encode($data);
?>