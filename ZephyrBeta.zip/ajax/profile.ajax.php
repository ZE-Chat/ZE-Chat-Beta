<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
 
//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);
 
 //Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

 //Include ProfileClass
require_once './class/profile.class.php';
$ZE_PROF = new profiles($db);

//Include GuestbookClass
require_once './class/gb.class.php';
$ZE_GB = new guestbook($db);

if(isset($_GET["pid"])) {
  $pid = htmlspecialchars($_GET["pid"]);
  } elseif(isset($_POST["pid"])) {
    $pid = htmlspecialchars($_POST["pid"]);
  } else {
  $pid = '';
}

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

if(isset($_GET["do"])) {
  $do = htmlspecialchars($_GET["do"]);
  } elseif(isset($_POST["do"])) {
    $do = htmlspecialchars($_POST["do"]);
  } else {
  $do = '';
}

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');

if($do == 'createGB') {
  $ZE_GB->makeEntry($pid, $uid, clock(), htmlspecialchars($_POST["content"]), htmlspecialchars($_POST["state"]));
}

if($do == 'rateuser') {
  $ZE_USER->rateUser($uid, $pid, htmlspecialchars($_POST["rating"]));
}
?>