<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
echo 'begin';
//Include UserClass
//Include SessionClass
//Include MessageClass
require_once './class/user.class.php';
require_once './class/session.class.php';
require_once './class/message.class.php';

$ZE_USER = new user($db);
$ZE_SESS = new session($db);
$ZE_MESS = new message($db);

$ZE_SID = htmlspecialchars($_POST["sid"]);

$first = true;

//$ZE_SELR->checkRooms();
$count = 0;
$query =
  mysqli_query($db, "SELECT `sess_user_id`, `sess_acc_id`, `sess_user_ip` FROM `".ZE_PRE."_session` WHERE `sess_id` = '$ZE_SID'")
    OR die("Error: <br>".mysqli_error($db));
while($row = mysqli_fetch_object($query)){
    if($first == true) {
      $user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $row->sess_user_id, 'user_name');
      $accid = $row->sess_acc_id;
      $uid = $row->sess_user_id;
      $ip = $row->sess_user_ip;
      $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_last_seen', clock());
      $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_last_used_ip', $ip);
      if($row->sess_acc_id < 2000) {
        $message = htmlspecialchars('Gast "'.$user_name.'" hat den Chat verlassen. (Logout)');
      } else {
        $message = htmlspecialchars('"'.$user_name.'" hat den Chat verlassen. (Logout)');
      }
      $first = false;
    }
    $helper = array();
    $query2 =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$ZE_SID'")
        OR die("Error: <br>".mysqli_error($db));
    while($row2 = mysqli_fetch_object($query2)){
      $helper[] = $row2->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              '0',
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
      $delete = "DELETE FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$ZE_SID' AND `sr_rid` = '$helper[$i]'";
      $do_it = mysqli_query($db, $delete);
    }
    $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_id` = '$ZE_SID'";
    $do_it = mysqli_query($db, $delete);
}
echo 'done';
?>