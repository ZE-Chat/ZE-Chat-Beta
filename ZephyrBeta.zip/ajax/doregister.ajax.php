<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include MailClass
require_once './class/mails.class.php';
$ZE_MAIL = new mails($db);

$confirm_state = 'true';

$reglogin  = '';
$regcolor  = '';
$regpass1  = '';
$regpass2  = '';
$regmail   = '';
$regday    = '';
$regmonth  = '';
$regyear   = '';
$regrules  = '';

$reglogin  = htmlspecialchars($_POST["reglogin"]) ?? '';
$regcolor  = htmlspecialchars($_POST["regcolor"]) ?? $ZE_SETT["chat_default_color"];
$regpass1  = htmlspecialchars($_POST["regpass1"]) ?? '';
$regpass2  = htmlspecialchars($_POST["regpass2"]) ?? '';
if(isset($_POST["reggender"])) { $gender = htmlspecialchars($_POST["reggender"]); } else { $gender = ''; }
$regmail   = htmlspecialchars($_POST["regmail"]) ?? '';
$regbday   = htmlspecialchars($_POST["regbirthday"]) ?? '';
if(isset($_POST["regrules"])) { $regrules = htmlspecialchars($_POST["regrules"]); } else { $regrules = ''; }
if(isset($_GET["regseen"])) {
  $regseen = htmlspecialchars($_GET["regseen"]);
  } elseif(isset($_POST["regseen"])) {
    $regseen = htmlspecialchars($_POST["regseen"]);
  } else {
  $regseen = '0';
}

if($regbday != '') {
  $age = calcAge($regbday);
}


if($reglogin  == '' || $regpass1  == '' || $regpass2  == '' || $regmail == '' || $regbday == '') {
  $confirm_state = array("state"=>"4", "title"=>"Fehler!", "msg"=>"Fehlende Angaben!"); 
  goto response;
}

if($regrules == '' || $regrules == '0') {
  $confirm_state = array("state"=>"5", "title"=>"Fehler!", "msg"=>"Regeln nicht akzeptiert!"); 
  goto response;
}

if($regpass1 != $regpass2) {
  $confirm_state = array("state"=>"6", "title"=>"Fehler!", "msg"=>"Passwörter stimmen nicht überein!"); 
  goto response;
}

if($ZE_USER->checkRegister($regmail, $reglogin) == 'bad') {
  $confirm_state = array("state"=>"7", "title"=>"Fehler!", "msg"=>"Benutzername oder E-Mail-Adresse bereits vergeben!"); 
  goto response;
}

//    if($ZE_BAD->checkNameForBadwords($reglogin) == 1 && $error == '0'){
//      $confirm_color = "#990000";
//      $confirm_state = 'Der gew&auml;hlte Name ist verboten!';
//      $error = '1';
//    }

if (!preg_match("/^[\p{L}0-9\-]*$/u", $reglogin)) {
  $confirm_state = array("state"=>"9", "title"=>"Fehler!", "msg"=>"Benutzername enthält unzulässige Zeichen!"); 
  goto response;
}

if($age < $ZE_SETT["min_age"]){
  $min_age = $ZE_SETT["min_age"];
  $confirm_state = array("state"=>"10", "title"=>"Fehler!", "msg"=>"Das Mindestalter für diesen Chat beträgt $min_age Jahre!"); 
  goto response;
}

response:

    if($confirm_state == 'true') {
      $name = $reglogin;
      $mail = $regmail;
      $now = clock();
      $pass = password_hash($regpass1, PASSWORD_BCRYPT);
      $rank = $ZE_SETTINGS->getDefaultRank();
      $mail2 = $ZE_SETT["chat_admin_mail"];
      $url = $ZE_SETT["chat_url"];

      switch($ZE_SETT["chat_regs"]) {
      case 0:
        $accid = $ZE_USER->createAcc($now, $pass, $mail, $age, $regbday, '1', '', $rank, 'no');
        $confirm_state = array("state"=>"1", "title"=>"Erfolgreich!", "msg"=>"Du kannst dich jetzt einloggen!");
      break;
      case 1:
        $act_code = random_gen(32);
        $accid = $ZE_USER->createAcc($now, $pass, $mail, $age, $regbday, '', $act_code, $rank, 'no');
        $head = $ZE_SETT["chat_name"]." - Registrierung";
        $mailtext = "$url/index.php?inc=activate&acc=$accid&act_code=$act_code";
        mail($mail, $head, $mailtext, "From: $mail2\nX-Mailer: PHP/".phpversion(), "-f $mail2");
        $confirm_state = array("state"=>"2", "title"=>"Fast fertig!", "msg"=>"Es wurde ein Aktivierungslink an die von dir angegebene E-Mail-Adresse geschickt!");
      break;
      case 2:
        $act_code = random_gen(32);
        $accid = $ZE_USER->createAcc($regacc, $now, $pass, $mail, $age, $birthday, '2', $act_code, '10', 'no');
//        $repsub = 'Account #'.$accid.' awaiting registration';
//        $reptext = 'Account #'.$accid.' awaiting registration';
//        $ZE_REPO->createReport($accid, getenv("REMOTE_ADDR"), $accid, getenv("REMOTE_ADDR"), $repsub, 'login', 'registration', $ZE_PERM->getInfo('perm_title', 'acp_user', 'perm_rank'), $reptext, 'yes2');
//        $ZE_SESS->updateInfo2('sess_user_level', '85', 'sess_update', '1', '>=');
        $confirm_state = array("state"=>"3", "title"=>"Erfolgreich!", "msg"=>"Die Administration wurde benachrichtigt und wird dich so bald wie möglich freischalten!");
      break;
      }
      $tmp_user_id = $ZE_USER->createUser($accid, $name, $regcolor, $rank, $gender, $now, 'default', 'no');
      $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $accid, 'acc_main_user', $tmp_user_id);

      $head = 'Zephyr - Registrierung';
      $mailtext = "AccountNo: $accid\nAt: $now\nName: $name\nEmail: $mail";

      if($ZE_SETT["chat_regs"] == 2) { $mailtext .= "\n\n\nErwartet Aktivierung!"; }

      mail($mail2, $head, $mailtext, "From: $mail2\nX-Mailer: PHP/".phpversion(), "-f $mail2");
//      $ZE_MAIL->sendMail($aid, $gid, $time, $subject, $text);
    }

echo json_encode($confirm_state);

?>