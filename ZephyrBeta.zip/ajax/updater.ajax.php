<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Setting up JSON document header

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT" ); 
header("Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . "GMT" ); 
header("Cache-Control: no-cache, must-revalidate" ); 
header("Pragma: no-cache" );
header("Content-Type: application/json; charset=utf-8");

$ZE_SID = htmlspecialchars($_POST["sid"]);

//Include UserClass
//Include SessionClass
//Include MessageClass
require_once './class/user.class.php';
require_once './class/session.class.php';
require_once './class/message.class.php';
require_once './class/rooms.class.php';

$ZE_USER = new user($db);
$ZE_SESS = new session($db);
$ZE_MESS = new message($db);
$ZE_ROOMSEL = new room($db);

if(!isset($ZE_SID) || !isset($_POST["sid"]) || $ZE_SID == '' || ($ZE_SESS->checkSesssion($ZE_SID) == false && $ZE_SID != 'none')) {
  $answer["logout"][] = array("session" => "$ZE_SID");
  echo json_encode($answer);
  die();
}

$now = clock();

$ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_ping', $now);
if($ZE_SID != 'none' && $ZE_SID != '' && isset($ZE_SID) && isset($_POST["sid"])) {
  $ZE_UID = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_user_id');
  $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $ZE_UID, 'user_last_seen', clock());
}

$answer = array();
$abort = false;

$ZE_ROOMSEL->checkRooms();
$count = 0;
$query =
  mysqli_query($db, "SELECT `sess_id`, `sess_user_id`, `sess_user_level`, `sess_acc_id`, `sess_ping`, `sess_user_ip`, `sess_last_sent_message_time` FROM `".ZE_PRE."_session`")
    OR die("Error: <br>".mysqli_error($db));
while($row = mysqli_fetch_object($query)){
  $ping   = $row->sess_ping;
  $ping = strtotime($ping);
  $check_time = time();
  $ping = $ping+$ZE_SETT["chat_timeout"];
  $ping_value = $check_time-$ping;
  if($ping_value > 0 || ($ZE_SETT["chat_open"] != '1' && $ZE_SETTINGS->cp('bypass_chatlock', $row->sess_user_id, $row->sess_user_level) == false)) {
    $helper = array();
    $query2 =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$row->sess_id'")
        OR die("Error: <br>".mysqli_error($db));
    while($row2 = mysqli_fetch_object($query2)){
      $helper[] = $row2->sr_rid;  
    }
    $tmp_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $row->sess_user_id, 'user_name');
    if($row->sess_acc_id < 2000) {
      $tmp_message = htmlspecialchars('Gast "'.$tmp_user_name.'" hat den Chat verlassen. (Disconnected)');
    } else {
      $tmp_message = htmlspecialchars('"'.$tmp_user_name.'" hat den Chat verlassen. (Disconnected)');
      $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $row->sess_user_id, 'user_last_seen', clock());
    }
    if($row->sess_id == $ZE_SID) {
      $answer["logout"][] = array("session" => "$row->sess_id");
      $abort = true;
    }
    if($ZE_SETT["chat_open"] != '1' && $ZE_SETTINGS->cp('bypass_chatlock', $row->sess_user_id, $row->sess_user_level) == false) {
      $tmp_message = htmlspecialchars('"'.$tmp_user_name.'" hat den Chat verlassen. (Chat gesperrt)');
    }
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              '0',
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $tmp_message,
                              'content',
                              '0');
      $delete = "DELETE FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$row->sess_id' AND `sr_rid` = '$helper[$i]'";
      $do_it = mysqli_query($db, $delete);
    }
    $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $row->sess_user_id, 'user_last_seen', $now);
    $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_id` = '$row->sess_id'";
    $do_it = mysqli_query($db, $delete);
  }
}

if($abort == true) {
  echo json_encode($answer);
  die();
}

$muteswitch = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_mute_switch');
if($muteswitch > 0) {
  $now = time();
  if($muteswitch < $now) {
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$ZE_SID'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }
    $uid = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_user_id');
    for($i=0; $i<count($helper); $i++) {
      $message = htmlspecialchars('Du kannst wieder schreiben!');
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $ZE_SESS->updateInfo('sess_user_id', $uid, 'sess_mute_switch', '0');
  }
}

$confuseswitch = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_confusion');
if($confuseswitch > 0) {
  $now = time();
  if($confuseswitch < $now) {
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$ZE_SID'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }
    $uid = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_user_id');
    for($i=0; $i<count($helper); $i++) {
      $message = htmlspecialchars('Du kannst wieder normal schreiben!');
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $ZE_SESS->updateInfo('sess_user_id', $uid, 'sess_confusion', '0');
    $ZE_SESS->updateInfo3('sr_uid', $uid, 'sr_conf', '0');
  }
}

/**
  if($row->sess_acc_id < 2000) {
    $countcheck = 0;
    $query2 =
      mysqli_query($db, "SELECT `user_id` FROM `".ZE_PRE."_user` WHERE `user_id` = '$row->sess_user_id'")
        OR die("Error: <br>".mysqli_error());
    while($row2 = mysqli_fetch_object($query2)){
      $countcheck++;
    }
    if($countcheck < 1) {
      if($row->sess_room_id != '' && $row->sess_room_id != '0' && $row->sess_id != '') {
        $tmp_user_name = $ZE_USER->getInfo('user_id', $row->sess_user_id, 'user_name');
        $tmp_message = htmlspecialchars('Ein Gast hat den Chat verlassen. (Fehler!)');
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT->chat_system_name,
                                $row->sess_room_id,
                                '0',
                                '0',
                                '0',
                                '1',
                                '0',
                                $ZE_SETT->chat_system_color,
                                $tmp_message);
        $ZE_SESS->updateInfo('sess_room_id', $row->sess_room_id, 'sess_update', '1');
      }

      $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_id` = '$row->sess_id'";
      $do_it = mysqli_query($db, $delete);
      if($row->sess_id == $ZE_session_id) {
        $json .= '"logout":[{"logout": "true"}, {"session": "'.$ZE_session_id.'"}]';
      }
    }
  }

  if($ZE_SETT->max_inactive != 0) {
    $inac = $row->sess_last_sent_message_time;
    $inac = strtotime($inac);
    $check = $inac+$ZE_SETT->max_inactive;
    $check_value = $check_time-$check;
    if($check_value > 0) {
      if($row->sess_room_id != '' && $row->sess_room_id != '0' && $row->sess_id != '') {
        $tmp_user_name = $ZE_USER->getInfo('user_id', $row->sess_user_id, 'user_name');
        if($row->sess_acc_id < 2000) {
          $tmp_message = htmlspecialchars('Gast "'.$tmp_user_name.'" hat den Chat verlassen. (Zu lange inaktiv!)');
        } else {
          $tmp_message = htmlspecialchars('"'.$tmp_user_name.'" hat den Chat verlassen. (Zu lange inaktiv!)');
        }
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT->chat_system_name,
                                $row->sess_room_id,
                                '0',
                                '0',
                                '0',
                                '1',
                                '0',
                                $ZE_SETT->chat_system_color,
                                $tmp_message);
        $ZE_SESS->updateInfo('sess_room_id', $row->sess_room_id, 'sess_update', '1');
      }

      $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_id` = '$row->sess_id'";
      $do_it = mysqli_query($db, $delete);
      if($row->sess_id == $ZE_session_id) {
        $json .= '"logout":[{"logout": "true"}, {"session": "'.$ZE_session_id.'"}]';
      }
    }
  }


  if($row->sess_id == $ZE_session_id) {
    $ip = getenv("REMOTE_ADDR");
    if($ip != $row->sess_user_ip) {
      if($row->sess_room_id != '' && $row->sess_room_id != '0' && $row->sess_id != '') {
        $tmp_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $row->sess_user_id, 'user_name');
        if($row->sess_acc_id < 2000) {
          $tmp_message = htmlspecialchars('Gast "'.$tmp_user_name.'" hat den Chat verlassen. (24Std Zwangstrennung!)');
        } else {
          $tmp_message = htmlspecialchars('"'.$tmp_user_name.'" hat den Chat verlassen. (24Std Zwangstrennung!)');
        }
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT->chat_system_name,
                                $row->sess_room_id,
                                '0',
                                '0',
                                '0',
                                '1',
                                '0',
                                $ZE_SETT->chat_system_color,
                                $tmp_message);
      }
      $ZE_SESS->updateInfo('sess_room_id', $row->sess_room_id, 'sess_update', '1');
      $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_id` = '$row->sess_id'";
      $do_it = mysqli_query($db, $delete);
      $answer["logout"][] = array("session" => "'.$ZE_session_id.'");
    }
  }

}

$ZE_MESS->checkPMglobal();

//Check if Session is established
if($ZE_session_id != '') {

  $check_session = $ZE_SESS->getInfo('sess_id', $ZE_session_id, 'sess_user_id');
  $session_activity = $ZE_SESS->getInfo('sess_id', $ZE_session_id, 'sess_online_status');
  $session_in_ac = $ZE_SESS->getInfo('sess_id', $ZE_session_id, 'sess_in_ac');
  $session_room_id = $ZE_SESS->getInfo('sess_id', $ZE_session_id, 'sess_room_id');
  if($check_session == '' && !isset($delete)) {
    $json .= '"logout":[{"logout": "true"}, {"session": "'.$ZE_session_id.'"}]';
  }
  $now = clock();
  $ZE_SESS->updateInfo('sess_id', $ZE_session_id, 'sess_ping', $now);
  if($session_activity != '2' && $session_activity != '3' && $session_in_ac == '0' && $session_room_id != '0') {
    $freezeop = $ZE_SELR->getInfo('room_id', $session_room_id, 'room_freeze_online_points');
    if($freezeop == 0) {
      $new_op = $ZE_USER->getInfo('user_id', $check_session, 'user_online_points');
      $new_op++;
      $ZE_USER->updateInfo($check_session, 'user_online_points', $new_op);
      $new_op = $ZE_USER->getInfo('user_id', $check_session, 'user_online_points_total');
      $new_op++;
      $ZE_USER->updateInfo($check_session, 'user_online_points_total', $new_op);
    }
  }
**/
$writesomemessage = false;

if($ZE_SID != 'none' && $ZE_SID != '' && isset($ZE_SID) && isset($_POST["sid"])) {
  $lsm = strtotime($ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_last_sent_message_time'));
  $onls = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_online_status');
  $csm = time()-$lsm;
  $writesomemessage = false;

  if($csm > 900 && $onls == '1') {
    $ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_online_status', '2');
    $ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_ostatus', '2');
    $tmp_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_UID, 'user_name');
    $writesomemessage = true;
    $tmp_message = '"'.$tmp_user_name.'" ist jetzt im Hintergrund.';
  }

  if($csm > 3600 && $onls == '2') {
    $ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_online_status', '3');
    $ZE_SESS->updateInfo3('sr_sid', $ZE_SID, 'sr_ostatus', '3');
    $tmp_user_name = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_UID, 'user_name');
    $writesomemessage = true;
    $tmp_message = '"'.$tmp_user_name.'" ist jetzt abwesend.';
  }

  if($onls == '1') {
    $cop = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_UID, 'user_online_points');
    $cop++;
    $ctop = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $ZE_UID, 'user_online_points_total');
    $ctop++;
    $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $ZE_UID, 'user_online_points', $cop);
    $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $ZE_UID, 'user_online_points_total', $ctop);
  }
}

if($writesomemessage == true) {
  $query =
    mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$ZE_SID'")
      OR die("Error: <br>".mysqli_error($db));
  while($row = mysqli_fetch_object($query)){
    $ZE_MESS->insertMessage('0',
                            $ZE_SETT["chat_system_name"],
                            $row->sr_rid,
                            '0',
                            '0',
                            '0',
                            '0',
                            '0',
                            $ZE_SETT["chat_system_color"],
                            $tmp_message,
                            'content',
                            '0');
  }
}

if(isset($_POST["onlinelist"]) && $_POST["onlinelist"] == 'true' && $abort == false) {
  require_once './ajax/showOnlinelist.ajax.php';
}

if(isset($_POST["userbar"]) && $_POST["userbar"] == 'true' && $abort == false) {
  require_once './ajax/userbar.ajax.php';
}

$refresh = false;

if($ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_update') == 1 && $abort == false) {
  $ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_update', '0');
  $refresh = true;
}

$answer["refresh"] = $refresh;

if($abort == false) {
  require_once './ajax/messages/getmess.ajax.php';
}

echo json_encode($answer);

?>