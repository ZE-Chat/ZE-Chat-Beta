<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

$ubar = array();

$uid = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_user_id');
$lvl = $ZE_SESS->getInfo('sess_id', $ZE_SID, 'sess_user_level');

$ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
$ZE_coins = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_coins');
$ubar["coins"] = $ZE_coins;

if($ZE_SETTINGS->cp('gbook', $uid, $lvl) != false) {
//Include GuestbookClass
  require_once './class/gb.class.php';
  $ZE_GB = new guestbook($db);
  $ZE_user_gb = $ZE_GB->countNewEntries($uid);
  $ZE_total_gb = $ZE_GB->countEntries($uid);
  $ubar["gb"] = array("gbn"=>$ZE_user_gb, "gbt"=>$ZE_total_gb);
}

if($ZE_SETTINGS->cp('friends', $uid, $lvl) != false) {
//Include FriendsClass
  require_once './class/friends.class.php';
  $ZE_FLIST = new friends($db);
  $ZE_user_friends = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_flist');
  $ZE_total_friends = $ZE_FLIST->countFriends($uid);
  $ubar["fl"] = array("fln"=>$ZE_user_friends, "flt"=>$ZE_total_friends);
}

if($ZE_SETTINGS->cp('mails', $uid, $lvl) != false) {
//Include MailClass
  require_once './class/mails.class.php';
  $ZE_MAIL = new mails($db);
  $ZE_user_mails = $ZE_MAIL->countNewMails($uid);
  $ZE_total_mails = $ZE_MAIL->countMails($uid);
  $ubar["mail"] = array("mailn"=>$ZE_user_mails, "mailt"=>$ZE_total_mails);
}

if($ZE_SETTINGS->cp('presents', $uid, $lvl) != false) {
//Include ShopClass
  require_once './class/shop.class.php';
  $ZE_SHOP = new shop($db);
  $ZE_user_presents = $ZE_SHOP->countNewPresents($uid);
  $ZE_total_presents = $ZE_SHOP->countPresents($uid);
  $ubar["pres"] = array("presn"=>$ZE_user_presents, "prest"=>$ZE_total_presents);
}

$answer["userbar"] = $ubar;

?>