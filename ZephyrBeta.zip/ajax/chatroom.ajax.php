<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
//Include SessionClass
//Include MessageClass
require_once './class/user.class.php';
require_once './class/session.class.php';
require_once './class/message.class.php';
require_once './class/rooms.class.php';
require_once './class/punish.func.php';

$ZE_USER = new user($db);
$ZE_SESS = new session($db);
$ZE_MESS = new message($db);
$ZE_ROOMSEL = new room($db);

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

if(isset($_GET["rid"])) {
  $rid = htmlspecialchars($_GET["rid"]);
  } elseif(isset($_POST["rid"])) {
    $rid = htmlspecialchars($_POST["rid"]);
  } else {
  $rid = '';
}

if(isset($_GET["do"])) {
  $do = htmlspecialchars($_GET["do"]);
  } elseif(isset($_POST["do"])) {
    $do = htmlspecialchars($_POST["do"]);
  } else {
  $do = '';
}

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');
$uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_name');
$aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
$lvl = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_level');
$ip = getenv("REMOTE_ADDR");

if($do == 'leaveroom') {
  $message = '"'.$uname.'" hat den Raum verlassen!';
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          $rid,
                          '0',
                          '0',
                          '0',
                          '0',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $message,
                          'content',
                          '0');
  $ZE_SESS->leaveRoom($sid, $rid);
  echo 'success';
}

if($do == 'leaveroomf') {
  $ZE_SESS->leaveRoom($sid, $rid);
  echo 'success';
}

if($do == 'toggletime') {
  $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_clock_switch', htmlspecialchars($_GET["to"]));
  $ZE_SESS->updateInfo('sess_id', $sid, 'sess_clock_switch', htmlspecialchars($_GET["to"]));
  echo 'success';
}

if($do == 'toggleava') {
  $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_min_ava', htmlspecialchars($_GET["to"]));
  echo 'success';
}

if($do == 'toggletf') {
  $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_tf_switch', htmlspecialchars($_GET["to"]));
  echo 'success';
}

if($do == 'changecolor') {
  $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_color', htmlspecialchars($_GET["to"]));
  $ZE_SESS->updateInfo3('sr_sid', $sid, 'sr_color', htmlspecialchars($_GET["to"]));
  echo 'success';
}

if($do == 'switchos') {
  $ZE_SESS->updateInfo('sess_id', $sid, 'sess_online_status', htmlspecialchars($_GET["to"]));
  $ZE_SESS->updateInfo3('sr_sid', $sid, 'sr_ostatus', htmlspecialchars($_GET["to"]));
  switch(htmlspecialchars($_GET["to"])) {
    case 1: $tmp_message = '"'.$uname.'" ist wieder anwesend.'; break;
    case 2: $tmp_message = '"'.$uname.'" ist jetzt im Hintergrund.'; break;
    case 3: $tmp_message = '"'.$uname.'" ist jetzt abwesend.'; break;
    case 4: $tmp_message = '"'.$uname.'" ist jetzt OnAir.'; break;
  }
  $query =
    mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
      OR die("Error: <br>".mysqli_error($db));
  while($row = mysqli_fetch_object($query)){
    $ZE_MESS->insertMessage('0',
                            $ZE_SETT["chat_system_name"],
                            $row->sr_rid,
                            '0',
                            '0',
                            '0',
                            '0',
                            '0',
                            $ZE_SETT["chat_system_color"],
                            $tmp_message,
                            'content',
                            '0');
  }
  echo 'success';
}

if($do == 'showscore') {
  $ucolor = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_color');
  $rid = htmlspecialchars($_GET["rid"]);
  $tmprates = $ZE_USER->getRating($uid);
  $score = $tmprates["score"];
  $rates = $tmprates["rates"];
  $message = $score.'-555-'.$rates;
  $ZE_MESS->insertMessage($uid,
                          $uname,
                          $rid,
                          '0',
                          '0',
                          '0',
                          '1',
                          '1',
                          $ucolor,
                          $message,
                          'content',
                          '-1',
                          '0');
  echo 'success';
}

if($do == 'notifyuser') {
  $target = htmlspecialchars($_GET["target"]);
  $rid = htmlspecialchars($_GET["rid"]);
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          $rid,
                          '0',
                          $target,
                          '0',
                          '5',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $uname,
                          'content',
                          '0');
  echo 'success';
}

if($do == 'confuseuser') {
  if($ZE_SETTINGS->cP('mod_confuse', $uid, $lvl) == true) {
    $target = htmlspecialchars($_GET["target"]);
    confuseUser(-1, '', $target, '', '');
  } else {
    writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL MODERATION TRY BY $ip USER \"$uname\"! ### confuseuser \n");
    $message = "Du hast keine Berechtigung für diesen Vorgang. Der Versuch dies zu tun resultiert in einer Verwarnung und wurde in das Log aufgenommen.";
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $tmp_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns');
    $tmp_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns', $tmp_warns);
  }
}

if($do == 'ownerconfuseuser') {
  $target = htmlspecialchars($_GET["target"]);
  $ZE_SESS->confuseUserRoom('sr_uid', $target, $rid, 'sr_conf', '1');
}

if($do == 'unconfuseuser') {
  if($ZE_SETTINGS->cP('mod_confuse', $uid, $lvl) == true) {
    $target = htmlspecialchars($_GET["target"]);
    $target_sid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
    $message = 'Du kannst wieder normal schreiben!';
    $ZE_SESS->updateInfo('sess_user_id', $target, 'sess_confusion', '0');
    $ZE_SESS->updateInfo3('sr_uid', $target, 'sr_conf', '0');
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$target_sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $target,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
  } else {
    writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL MODERATION TRY BY $ip USER \"$uname\"! ### unconfuseuser \n");
    $message = "Du hast keine Berechtigung für diesen Vorgang. Der Versuch dies zu tun resultiert in einer Verwarnung und wurde in das Log aufgenommen.";
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $tmp_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns');
    $tmp_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns', $tmp_warns);
  }
}

if($do == 'ownerunconfuseuser') {
  $target = htmlspecialchars($_GET["target"]);
  $message = 'Du kannst wieder normal schreiben!';
  $ZE_SESS->confuseUserRoom('sr_uid', $target, $rid, 'sr_conf', '0');
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          $rid,
                          '0',
                          $target,
                          '0',
                          '0',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $message,
                          'content',
                          '0');
}

if($do == 'callmod') {
  $rname = $ZE_ROOMSEL->getInfo('room_id', $rid, 'room_name');
  $mess = '"'.$uname.'" benötigt Hilfe von einem Moderator im Raum "'.$rname.'"';
  $ZE_SETTINGS->informModeration($mess);
}

if($do == 'warnuser') {
  if($ZE_SETTINGS->cP('mod_warn', $uid, $lvl) == true) {
    $target = htmlspecialchars($_GET["target"]);
    $target_uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_name');
    $target_aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_acc_id');
    $target_sid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
    $tmp_target_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $target_aid, 'acc_global_warns');
    $tmp_target_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $target_aid, 'acc_global_warns', $tmp_target_warns);
    $message = htmlspecialchars('"'.$target_uname.'" wurde von '.$uname.' verwarnt!');
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$target_sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              '0',
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
      if($i == 0) {
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT["chat_system_name"],
                                $helper[$i],
                                '0',
                                $target,
                                '0',
                                '7',
                                '0',
                                $ZE_SETT["chat_system_color"],
                                $tmp_target_warns,
                                'content',
                                '0');
      }
    }
  } else {
    writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL MODERATION TRY BY $ip USER \"$uname\"! ### warnuser \n");
    $message = "Du hast keine Berechtigung für diesen Vorgang. Der Versuch dies zu tun resultiert in einer Verwarnung und wurde in das Log aufgenommen.";
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $tmp_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns');
    $tmp_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns', $tmp_warns);
  }
}

if($do == 'unwarnuser') {
  if($ZE_SETTINGS->cP('mod_confuse', $uid, $lvl) == true) {
    $target = htmlspecialchars($_GET["target"]);
    $target_uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_name');
    $target_aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_acc_id');
    $target_sid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
    $tmp_target_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $target_aid, 'acc_global_warns');
    $tmp_target_warns--;
    if($tmp_target_warns > -1) {
      $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $target_aid, 'acc_global_warns', $tmp_target_warns);
      $message = htmlspecialchars('"'.$target_uname.'´s" Verwarnung wurde von '.$uname.' aufgehoben!');
      $helper = array();
      $query =
        mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$target_sid'")
          OR die("Error: <br>".mysqli_error($db));
      while($row = mysqli_fetch_object($query)){
        $helper[] = $row->sr_rid;  
      }    
      for($i=0; $i<count($helper); $i++) {
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT["chat_system_name"],
                                $helper[$i],
                                '0',
                                '0',
                                '0',
                                '0',
                                '0',
                                $ZE_SETT["chat_system_color"],
                                $message,
                                'content',
                                '0');
        if($i == 0) {
          $ZE_MESS->insertMessage('0',
                                  $ZE_SETT["chat_system_name"],
                                  $helper[$i],
                                  '0',
                                  $target,
                                  '0',
                                  '7',
                                  '0',
                                  $ZE_SETT["chat_system_color"],
                                  $tmp_target_warns,
                                  'content',
                                  '0');
        } 
      } 
    }
  } else {
    writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL MODERATION TRY BY $ip USER \"$uname\"! ### unwarnuser \n");
    $message = "Du hast keine Berechtigung für diesen Vorgang. Der Versuch dies zu tun resultiert in einer Verwarnung und wurde in das Log aufgenommen.";
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $tmp_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns');
    $tmp_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns', $tmp_warns);
  }
}

if($do == 'gaguser') {
  if($ZE_SETTINGS->cP('mod_mute', $uid, $lvl) == true) {
    $target = htmlspecialchars($_GET["target"]);
    $target_uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_name');
    $target_sid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
    gagUser($target_sid, $target, $target_uname, $uname, -1);
  } else {
    writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL MODERATION TRY BY $ip USER \"$uname\"! ### gaguser \n");
    $message = "Du hast keine Berechtigung für diesen Vorgang. Der Versuch dies zu tun resultiert in einer Verwarnung und wurde in das Log aufgenommen.";
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $tmp_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns');
    $tmp_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns', $tmp_warns);
  }
}

if($do == 'ungaguser') {
  if($ZE_SETTINGS->cP('mod_mute', $uid, $lvl) == true) {
    $target = htmlspecialchars($_GET["target"]);
    $target_uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_name');
    $target_sid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
    $ZE_SESS->updateInfo('sess_user_id', $target, 'sess_mute_switch', '0');
    $message = htmlspecialchars('"'.$target_uname.'" wurde von '.$uname.' entknebelt!');
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$target_sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              '0',
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
  } else {
    writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL MODERATION TRY BY $ip USER \"$uname\"! ### ungaguser \n");
    $message = "Du hast keine Berechtigung für diesen Vorgang. Der Versuch dies zu tun resultiert in einer Verwarnung und wurde in das Log aufgenommen.";
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $tmp_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns');
    $tmp_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns', $tmp_warns);
  }
}

if($do == 'kickuser') {
  if($ZE_SETTINGS->cP('mod_kick', $uid, $lvl) == true) {
    $target = htmlspecialchars($_GET["target"]);
    $target_uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_name');
    $target_aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_acc_id');
    $target_sid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
    $target_ip = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_user_ip');
    $message = htmlspecialchars('"'.$target_uname.'" wurde von '.$uname.' aus dem Chat geschmissen!');
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $target_aid, 'acc_global_last_login', clock());
    $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $target, 'user_last_seen', clock());
    $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $target, 'user_last_used_ip', $target_ip);
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$target_sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              '0',
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
      $delete = "DELETE FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$target_sid' AND `sr_rid` = '$helper[$i]'";
      $do_it = mysqli_query($db, $delete);
    }
    $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_id` = '$target_sid'";
    $do_it = mysqli_query($db, $delete);
  } else {
    writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL MODERATION TRY BY $ip USER \"$uname\"! ### kickuser \n");
    $message = "Du hast keine Berechtigung für diesen Vorgang. Der Versuch dies zu tun resultiert in einer Verwarnung und wurde in das Log aufgenommen.";
    $helper = array();
    $query =
      mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
        OR die("Error: <br>".mysqli_error($db));
    while($row = mysqli_fetch_object($query)){
      $helper[] = $row->sr_rid;  
    }    
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              $uid,
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $message,
                              'content',
                              '0');
    }
    $tmp_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns');
    $tmp_warns++;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $aid, 'acc_global_warns', $tmp_warns);
  }
}

if($do == 'ownerkickuser') {
  $target = htmlspecialchars($_GET["target"]);
  $rid = htmlspecialchars($_GET["rid"]);
  $target_uname = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $target, 'user_name');
  $target_sid = $ZE_SESS->getInfo('sess_user_id', $target, 'sess_id');
  $message = htmlspecialchars('"'.$target_uname.'" wurde von '.$uname.' aus dem Raum geschmissen!');
  $helper = array();
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          $rid,
                          '0',
                          '0',
                          '0',
                          '0',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $message,
                          'content',
                          '0');
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          $rid,
                          '0',
                          $target,
                          '0',
                          '9',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $target_sid,
                          'content',
                          '0');
}
?>