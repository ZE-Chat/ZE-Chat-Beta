<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
//Include SessionClass
//Include MessageClass
//Include ShopClass
require_once './class/shop.class.php';
require_once './class/user.class.php';
require_once './class/session.class.php';
require_once './class/message.class.php';
require_once './class/badwords.class.php';
require_once './class/smilies.class.php';
require_once './class/punish.func.php';

$ZE_USER = new user($db);
$ZE_SESS = new session($db);
$ZE_MESS = new message($db);
$ZE_BAD = new badwords($db);
$ZE_SMI = new smilies($db);
$ZE_SHOP = new shop($db);

$sid = mysqli_real_escape_string($db, htmlspecialchars($_POST["sid"]));
$rid = mysqli_real_escape_string($db, htmlspecialchars($_POST["rid"]));
$uid = mysqli_real_escape_string($db, htmlspecialchars($_POST["uid"]));
$ip = getenv("REMOTE_ADDR");
$prestg = $_POST["stg"] ?? '-1';
$preusk = $_POST["usk"] ?? '0';
$stg = mysqli_real_escape_string($db, htmlspecialchars($prestg));
$usk = mysqli_real_escape_string($db, htmlspecialchars($preusk));

$ZE_SESS->updateInfo('sess_id', $sid, 'sess_last_sent_message_time', clock());
$onls = $ZE_SESS->getInfo('sess_id', $sid, 'sess_online_status');

if($onls != '1') {
  $ZE_SESS->updateInfo('sess_id', $sid, 'sess_online_status', '1');
  $ZE_SESS->updateInfo3('sr_sid', $sid, 'sr_ostatus', '1');
}

$message = htmlspecialchars($_POST["mess"]);
$message = str_replace( '\\', '&#092;', $message );

$private = '0';
$target_id = '0';
$mess_type = '1';
$action = '0';
$reqlvl = $stg;
$area = 'content';

$mess_data = $ZE_MESS->getNeededData($uid);

$uname = $mess_data["name"];
$mcolor = $mess_data["color"];
$tf_switch = $mess_data["tfswitch"];
$smilie_switch = $mess_data["sswitch"];
$confusion = $mess_data["confused"];
$mute_switch = $mess_data["muted"];
$ZE_user_online_status = $mess_data["ostatus"];
$ZE_user_level = $mess_data["level"];
$ZE_tf = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_tf_switch');
$age = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_SESS->getInfo('sess_id', $sid, 'sess_acc_id'), 'acc_age');
$lvl = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_level');

$message = mysqli_real_escape_string($db, $message);

$muted = $ZE_SESS->getInfo('sess_user_id', $uid, 'sess_mute_switch');
if($muted != 0) {
  if($muted == -1) {
    $message = htmlspecialchars('Du bist geknebelt und kannst nicht schreiben!');
  } else {
    $muted = $muted - time();
    $message = htmlspecialchars('Du bist noch für '.$muted.' Sekunden geknebelt und kannst nicht schreiben!');
  }
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          $rid,
                          '0',
                          $uid,
                          '0',
                          '0',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $message,
                          'content',
                          '0');
  echo random_gen(32);
  die();
}

$allow_tf = $ZE_SETTINGS->cP('chat_tf', $uid, $ZE_user_level);
if($allow_tf == true && $ZE_tf == 1) {
  require_once './ajax/messages/textform.mess.php';
}

$rank = $ZE_SMI->getInfo('ranks', 'ranks_id', $lvl, 'ranks_order');
$message = $ZE_SMI->replaceSmilies($rank, $age, $message);

if($rid != 'priv') {
  if($message[0] == '/') {
  $tmp_mess = explode(" ", $message);
  
  switch($tmp_mess[0]) {
    case '/to':
      $mess_type = '3';
      $tmp_mess = explode("&quot;", $message);
      $tmp_name = $tmp_mess[1];
      unset($tmp_mess[0]);
      unset($tmp_mess[1]);
      $message = $tmp_name.'<span style="color: -REPME-">:&nbsp;</span>'.implode(" ", $tmp_mess);
    break;
    case '/w':
      $tmp_mess = explode("&quot;", $message);
      $tmp_name = $tmp_mess[1];
      unset($tmp_mess[0]);
      unset($tmp_mess[1]);
      require_once './ajax/messages/whisper.mess.php';
    break;
    case '/yt':
      $tmp_mess[0] = substr($tmp_mess[0], 1);
      if($ZE_SETTINGS->cP('com_yt', $uid, $lvl) == true || $ZE_SHOP->consumeItem($uid, $tmp_mess[0]) == true) {
        $tmp_url = explode("v=", $tmp_mess[1]);
        $tmp_url = explode("&", $tmp_url[1]);
        $code = $tmp_url[0];
        $mess_type = '6';
        $message = $code;
      } else {
        writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL COMMAND TRY BY $ip USER \"$uname\"! ### /yt \n");
        $message = "Du hast leider kein Youtube-Item. Im Shop solltest du fündig werden.";
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT["chat_system_name"],
                                $rid,
                                '0',
                                $uid,
                                '0',
                                '0',
                                '0',
                                $ZE_SETT["chat_system_color"],
                                $message,
                                'content',
                                '0');
        echo random_gen(32);
        die();
      }
    break;
    case '/rating':
      $action = '1';
      $tmprates = $ZE_USER->getRating($uid);
      $score = $tmprates["score"];
      $rates = $tmprates["rates"];
      $message = $score.'-555-'.$rates;
    break;
    case '/shout':
      $tmp_mess[0] = substr($tmp_mess[0], 1);
      if($ZE_SETTINGS->cP('com_shout', $uid, $lvl) == true || $ZE_SHOP->consumeItem($uid, $tmp_mess[0]) == true) {
        unset($tmp_mess[0]);
        $message = implode(" ", $tmp_mess);
        $ZE_MESS->insertMessage($uid,
                                $uname,
                                $rid,
                                '0',
                                $target_id,
                                $private,
                                '8',
                                '1',
                                $mcolor,
                                $message,
                                $area,
                                $reqlvl,
                                $usk);
      } else {
        writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL COMMAND TRY BY $ip USER \"$uname\"! ### /shout \n");
        $message = "Du hast leider keinen Shout. Im Shop solltest du fündig werden.";
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT["chat_system_name"],
                                $rid,
                                '0',
                                $uid,
                                '0',
                                '0',
                                '0',
                                $ZE_SETT["chat_system_color"],
                                $message,
                                'content',
                                '0');
        echo random_gen(32);
        die();
      }
    break;
    case '/gshout':
      $tmp_mess[0] = substr($tmp_mess[0], 1);
      if($ZE_SETTINGS->cP('com_gshout', $uid, $lvl) == true || $ZE_SHOP->consumeItem($uid, $tmp_mess[0]) == true) {
        unset($tmp_mess[0]);
        $message = implode(" ", $tmp_mess);
        $ZE_MESS->insertMessage($uid,
                                $uname,
                                $rid,
                                '0',
                                $target_id,
                                $private,
                                '8',
                                '2',
                                $mcolor,
                                $message,
                                $area,
                                $reqlvl,
                                $usk);
      } else {
        writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL COMMAND TRY BY $ip USER \"$uname\"! ### /gshout \n");
        $message = "Du hast leider keinen Shout. Im Shop solltest du fündig werden.";
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT["chat_system_name"],
                                $rid,
                                '0',
                                $uid,
                                '0',
                                '0',
                                '0',
                                $ZE_SETT["chat_system_color"],
                                $message,
                                'content',
                                '0');
        echo random_gen(32);
        die();
      }
    break;
    case '/dshout':
      $tmp_mess[0] = substr($tmp_mess[0], 1);
      if($ZE_SETTINGS->cP('com_dshout', $uid, $lvl) == true || $ZE_SHOP->consumeItem($uid, $tmp_mess[0]) == true) {
        unset($tmp_mess[0]);
        $message = implode(" ", $tmp_mess);
        $ZE_MESS->insertMessage($uid,
                                $uname,
                                $rid,
                                '0',
                                $target_id,
                                $private,
                                '8',
                                '3',
                                $mcolor,
                                $message,
                                $area,
                                $reqlvl,
                                $usk);
      } else {
        writeLog('violation', "@".date("Y-m-d H:i:s")." ### FAIL COMMAND TRY BY $ip USER \"$uname\"! ### /dshout \n");
        $message = "Du hast leider keinen Shout. Im Shop solltest du fündig werden.";
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT["chat_system_name"],
                                $rid,
                                '0',
                                $uid,
                                '0',
                                '0',
                                '0',
                                $ZE_SETT["chat_system_color"],
                                $message,
                                'content',
                                '0');
        echo random_gen(32);
        die();
      }
    break;
  }
  
  }
  if($ZE_SESS->getInfo('sess_user_id', $uid, 'sess_confusion') != '0' || $ZE_SESS->getUserRoomInfo('sr_uid', $uid, $rid, 'sr_conf') != '0') {
    $tmp_mess = explode(" ", $message);
    for($i=0; $i<count($tmp_mess); $i++) {
      $tmp = $tmp_mess[$i];
      $tmp_mess[$i] = str_shuffle_unicode($tmp);
    }
    $message = implode(" ", $tmp_mess);
  }
  $bwtest = $ZE_BAD->checkForBadwordsText($uid, $rid, $message, $age);
  if($bwtest["detections"] != 0) {
    $message = $bwtest["mess"].' <span style="font-size: 70%; font-style:italic; color: -REPME-;">('.$bwtest["detections"].' Badwords gefunden!)</span>';
  }
  $ZE_MESS->insertMessage($uid,
                          $uname,
                          $rid,
                          '0',
                          $target_id,
                          $private,
                          $mess_type,
                          $action,
                          $mcolor,
                          $message,
                          $area,
                          $reqlvl,
                          $usk);
  if($bwtest["detections"] != 0) {
    if($bwtest["n1"] != 0) {
      confuseUser($bwtest["n1"], $sid, $uid, $uname, 'Badwordfilter');
    }
    if($bwtest["n2"] != 0) {
      gagUser($sid, $uid, $uname, 'Badwordfilter', $bwtest["n2"]);
    }
    if($bwtest["n3"] != 0) {
      $target_aid = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
      $tmp_target_warns = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $target_aid, 'acc_global_warns') + $bwtest["n3"];
      $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $target_aid, 'acc_global_warns', $tmp_target_warns);
      $message = htmlspecialchars('"'.$uname.'" wurde vom Badwordfilter '.$bwtest["n3"].'x verwarnt!');
      $helper = array();
      $query =
        mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_sid` = '$sid'")
          OR die("Error: <br>".mysqli_error($db));
      while($row = mysqli_fetch_object($query)){
        $helper[] = $row->sr_rid;  
      }    
      for($i=0; $i<count($helper); $i++) {
        $ZE_MESS->insertMessage('0',
                                $ZE_SETT["chat_system_name"],
                                $helper[$i],
                                '0',
                                '0',
                                '0',
                                '0',
                                '0',
                                $ZE_SETT["chat_system_color"],
                                $message,
                                'content',
                                '0');
        if($i == 0) {
          $ZE_MESS->insertMessage('0',
                                  $ZE_SETT["chat_system_name"],
                                  $helper[$i],
                                  '0',
                                  $uid,
                                  '0',
                                  '7',
                                  '0',
                                  $ZE_SETT["chat_system_color"],
                                  $tmp_target_warns,
                                  'content',
                                  '0');
        }
      }
    }
  }
} else {
  $target = mysqli_real_escape_string($db, htmlspecialchars($_POST["tarid"]));
  $toid = mysqli_real_escape_string($db, htmlspecialchars($_POST["toid"]));
  $ZE_MESS->insertMessage($uid,
                          $uname,
                          '0',
                          $toid,
                          $target,
                          $private,
                          '3',
                          $action,
                          $mcolor,
                          $message,
                          $area,
                          $ZE_SETTINGS->getDefaultRank());
}

echo random_gen(32);

?>