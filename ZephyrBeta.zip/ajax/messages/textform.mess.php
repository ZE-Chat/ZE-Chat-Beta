<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

$string = $message;

$search = array('#\*\*#Ui', '#\~\~#Ui', '#\#\##Ui', '#\_\_#Ui');
$replace = array('TF551', 'TF552', 'TF553', 'TF554');
$string = preg_replace( $search, $replace, $string );

$search = array('#\*(.*)\*#Ui',);
$replace = array('<span style=\'font-style: italic;\'>${1}</span>',);
$string = preg_replace( $search, $replace, $string );

$search = array('#\*#Ui',);
$replace = array('<span style=\'font-style: italic;\'>',);
$string = preg_replace( $search, $replace, $string );

$tfcount1 = substr_count($string, '<span style=\'font-style: italic;\'>');
$tfcount2 = substr_count($string, '</span>');

if($tfcount1 > $tfcount2) {
  $string = $string.'</span>';
}

$search = array('#\~(.*)\~#Ui',);
$replace = array('<span style=\'text-decoration: line-through;\'>${1}</span>',);
$string = preg_replace( $search, $replace, $string );

$search = array('#\~#Ui',);
$replace = array('<span style=\'text-decoration: line-through;\'>',);
$string = preg_replace( $search, $replace, $string );

$tfcount1 = substr_count($string, '<span style=\'text-decoration: line-through;\'>');
$tfcount2 = substr_count($string, '</span>');

if($tfcount1 > $tfcount2) {
  $string = $string.'</span>';
}

$search = array('#\#(.*)\##Ui',);
$replace = array('<span style=\'font-weight: bold;\'>${1}</span>',);
$string = preg_replace( $search, $replace, $string );

$search = array('#\##Ui',);
$replace = array('<span style=\'font-weight: bold;\'>',);
$string = preg_replace( $search, $replace, $string );

$tfcount1 = substr_count($string, '<span style=\'font-weight: bold;\'>');
$tfcount2 = substr_count($string, '</span>');

if($tfcount1 > $tfcount2) {
  $string = $string.'</span>';
}
 
$search = array('#\_(.*)\_#Ui',);
$replace = array('<span style=\'text-decoration: underline;\'>${1}</span>',);
$string = preg_replace( $search, $replace, $string );

$search = array('#\_#Ui',);
$replace = array('<span style=\'text-decoration: underline;\'>',);
$string = preg_replace( $search, $replace, $string );

$tfcount1 = substr_count($string, '<span style=\'text-decoration: underline;\'>');
$tfcount2 = substr_count($string, '</span>');

if($tfcount1 > $tfcount2) {
  $string = $string.'</span>';
}

$search = array('#TF551#Ui', '#TF552#Ui', '#TF553#Ui', '#TF554#Ui');
$replace = array('\*', '\~', '\#', '\_');
$string = preg_replace( $search, $replace, $string );

$message = $string;

?>