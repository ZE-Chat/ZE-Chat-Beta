<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include MessageClass
require_once './class/message.class.php';
$ZE_MESS = new message($db);

//Include AvatarClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

$sid = mysqli_real_escape_string($db, htmlspecialchars($_POST["sid"]));
$uid = mysqli_real_escape_string($db, htmlspecialchars($_POST["uid"]));
$defrank = $ZE_SETTINGS->getDefaultRank();

if($uid != 'none') {
  $lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
  $mava = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_min_ava');
  $ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
  $ZE_userage = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_age');
  $update = '0';
  $lid = 0;
  $rooms = $ZE_SESS->getRooms($sid);
  $count = count($rooms);

  for($i=0; $i < $count; $i++) {
    $rid = $rooms[$i];
    $mess = $ZE_MESS->getMessages($rid, $uid, $lvl, $defrank);
    if(count($mess) > 0) {
      for($o=0; $o < count($mess); $o++) {
        $mess[$o]["mess_content"] = link2click($mess[$o]["mess_content"]);
        $mess[$o]["mess_content"] = textWrap($mess[$o]["mess_content"], '64');
        $mess[$o]["mess_content"] = stripslashes($mess[$o]["mess_content"]);
        if($lid < $mess[$o]["mess_id"]) {
          $lid = $mess[$o]["mess_id"];
        }
        if($mess[$o]["mess_type"] != '0' && $mava == 1) {
          $ZE_AVA = new avatar($db);
          $tmp_ava = $ZE_AVA->getMainAva($mess[$o]["mess_author_id"]);
          if($tmp_ava["ava_usk"] <= $ZE_userage) {
            $mess[$o]["mess_avatar"] = $tmp_ava["ava_link"];
          } else {
            $mess[$o]["mess_avatar"] = $tmp_ava["ava_usk"].'_user.jpg';
          }
          if($uid < 0 && $tmp_ava["ava_usk"] != 0) {
            $mess[$o]["mess_avatar"] = $tmp_ava["ava_usk"].'_user.jpg';
          }
        }
      }
      if($update == '0') {
        $update = 'mess';
        $messages = $mess;
      } else {
        $messages = array_merge($messages, $mess);
      }
      $update = 'mess';
    }
    $mess = '';
    $ZE_MESS = new message($db);
  }

  if($update == 'mess') {
    $tmpmess = $messages;
    for($i=0; $i < count($tmpmess); $i++) {
      $gone = false;
      if($tmpmess[$i]['mess_target_user_id'] != '0') {
        if($tmpmess[$i]['mess_author_id'] != $uid && $tmpmess[$i]['mess_target_user_id'] != $uid) {
          unset($messages[$i]);
          $gone = true;
        }
      }
      if($gone == false && $tmpmess[$i]['mess_req_lvl'] != -1 && $tmpmess[$i]['mess_author_id'] != 0) {
        if($ZE_SETTINGS->getEvenPermit($lvl, $tmpmess[$i]['mess_req_lvl']) == false) {
          unset($messages[$i]);
          $gone = true;
        }
      }
      if($gone == false && $tmpmess[$i]['mess_type'] == 10 && $tmpmess[$i]['mess_author_id'] == 0) {
        if($ZE_SETTINGS->cP('acp_livealert', $uid, $lvl) == false) {
          unset($messages[$i]);
          $gone = true;
        }
      }
      if($gone == false && $tmpmess[$i]['mess_req_lvl'] == -1 && $tmpmess[$i]['mess_author_id'] != 0) {
        $messages[$i]['mess_req_lvl'] = $defrank;
      }
    }
    unset($tmpmess);
    $answer["messages"] = $messages;
  }

  $priv = $ZE_MESS->getPrivMessages($uid);
  if(count($priv) > 0) {
    for($i=0; $i < count($priv); $i++) {
      if($priv[$i]["mess_type"] != '0' && $mava == 1) {
        $ZE_AVA = new avatar($db);
        $tmp_ava = $ZE_AVA->getMainAva($priv[$i]["mess_author_id"]);
        if($tmp_ava["ava_usk"] <= $ZE_userage) {
          $priv[$i]["mess_avatar"] = $tmp_ava["ava_link"];
        } else {
          $priv[$i]["mess_avatar"] = $tmp_ava["ava_usk"].'_user.jpg';
        }
        if($uid < 0 && $tmp_ava["ava_usk"] != 0) {
          $priv[$i]["mess_avatar"] = $tmp_ava["ava_usk"].'_user.jpg';
        }
      }
      if($lid < $priv[$i]["mess_id"]) {
        $lid = $priv[$i]["mess_id"];
      }
    }
    $update = 'priv';
    $answer["private"] = $priv;
  }

  if($update != '0') {
    $ZE_SESS->updateInfo('sess_id', $sid, 'sess_last_message_id', $lid);
  }
}

?>