<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

$confirm_state = 'true';

$login  = '';
$color  = '';

$login  = htmlspecialchars($_POST["aulogin"]) ?? '';
$color  = htmlspecialchars($_POST["aucolor"]) ?? $ZE_SETT["chat_default_color"];
$gender = htmlspecialchars($_POST["augender"]) ?? '0';

$uid  = htmlspecialchars($_POST["uid"]);
$sid  = htmlspecialchars($_POST["sid"]);
$accid  = htmlspecialchars($_POST["accid"]);

if($login  == '') {
  $confirm_state = array("state"=>"2", "title"=>"Fehler!", "msg"=>"Fehlender Benutzername!"); 
  goto response;
}

if($ZE_USER->checkRegister('ausgetrickst', $login) == 'bad') {
  $confirm_state = array("state"=>"2", "title"=>"Fehler!", "msg"=>"Benutzername bereits vergeben!"); 
  goto response;
}

//    if($ZE_BAD->checkNameForBadwords($reglogin) == 1 && $error == '0'){
//      $confirm_color = "#990000";
//      $confirm_state = 'Der gew&auml;hlte Name ist verboten!';
//      $error = '1';
//    }

if (!preg_match("/^[\p{L}0-9\-]*$/u", $login)) {
  $confirm_state = array("state"=>"2", "title"=>"Fehler!", "msg"=>"Benutzername enthält unzulässige Zeichen!"); 
  goto response;
}

response:
    if($confirm_state == 'true') {
      $name = $login;
      $now = clock();
      $rank = $ZE_SETTINGS->getDefaultRank();

      $tmp_user_id = $ZE_USER->createUser($accid, $name, $color, $rank, $gender, $now, 'default', 'no');
      $ucount = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $accid, 'acc_global_user_count');
      $ucount++;
      $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $accid, 'acc_global_user_count', $ucount);
      $confirm_state = array("state"=>"1", "title"=>"Erfolg!", "msg"=>"Benutzername '".$name."' wurde erstellt!"); 
    }

echo json_encode($confirm_state);

?>