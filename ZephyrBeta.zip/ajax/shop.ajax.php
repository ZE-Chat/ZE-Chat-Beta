<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
 
//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);
 
 //Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);

//Include ShopClass
require_once './class/shop.class.php';
$ZE_SHOP = new shop($db);

if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

if(isset($_GET["do"])) {
  $do = htmlspecialchars($_GET["do"]);
  } elseif(isset($_POST["do"])) {
    $do = htmlspecialchars($_POST["do"]);
  } else {
  $do = '';
}

if(isset($_GET["iid"])) {
  $iid = htmlspecialchars($_GET["iid"]);
  } elseif(isset($_POST["iid"])) {
    $iid = htmlspecialchars($_POST["iid"]);
  } else {
  $iid = '';
}

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');

if($do == 'buyitem') {
  $ZE_account_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_acc_id');
  $ZE_user_lvl = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $uid, 'user_level');
  $ZE_coins = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_coins');
  $item = $ZE_SHOP->getShopItem($iid, '99');
  $cost = $item["cost"];
  if($item["discount_cost"] != '0') { $cost = $item["discount_cost"]; }
  if($cost > $ZE_coins) {
    echo 'error';
  } else {
    $ZE_coins = $ZE_coins - $cost;
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $ZE_account_id, 'acc_coins', $ZE_coins);
    $ZE_SHOP->buyItem($iid, $uid);
    echo $item["name"];
  }
}

?>