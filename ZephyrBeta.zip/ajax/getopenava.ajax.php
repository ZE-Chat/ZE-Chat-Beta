<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
 
 if(isset($_GET["sid"])) {
  $sid = htmlspecialchars($_GET["sid"]);
  } elseif(isset($_POST["sid"])) {
    $sid = htmlspecialchars($_POST["sid"]);
  } else {
  $sid = '';
}

//Include SessionClass
require_once './class/session.class.php';
$ZE_SESS = new session($db);

//Include AvatarClass
require_once './class/avatar.class.php';
$ZE_AVA = new avatar($db);

$uid = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_id');
$lvl = $ZE_SESS->getInfo('sess_id', $sid, 'sess_user_level');
$auth = false;

if($ZE_SETTINGS->cP('acp_avatars', $uid, $lvl) != false) {
  $auth = true;
}

if($auth == false) {
  echo 'nope';
  die();
} else {
  echo $ZE_AVA->countOpenAva();
  die();
}
?>