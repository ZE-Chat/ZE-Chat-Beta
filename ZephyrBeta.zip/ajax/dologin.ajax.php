<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

//Include UserClass
//Include SessionClass
//Include MessageClass
//Include ShopClass
require_once './class/user.class.php';
require_once './class/session.class.php';
require_once './class/message.class.php';
require_once './class/shop.class.php';

$ZE_USER = new user($db);
$ZE_SESS = new session($db);
$ZE_MESS = new message($db);
$ZE_SHOP = new shop($db);

$login  = mysqli_real_escape_string($db, htmlspecialchars($_POST["login"]));

if(isset($_GET["pass"])) {
  $pass = mysqli_real_escape_string($db, htmlspecialchars($_GET["pass"]));
  } elseif(isset($_POST["pass"])) {
    $pass = mysqli_real_escape_string($db, htmlspecialchars($_POST["pass"]));
  } else {
  $pass = '';
}

if(isset($_GET["do"])) {
  $do = mysqli_real_escape_string($db, htmlspecialchars($_GET["do"]));
  } elseif(isset($_POST["do"])) {
    $do = mysqli_real_escape_string($db, htmlspecialchars($_POST["do"]));
  } else {
  $do = '';
}

$user_agent = getenv("HTTP_USER_AGENT");
$ip = getenv("REMOTE_ADDR");
$info = getInfo($user_agent);
$os = $info['platform'];
$agnt_name = $info['name'];
$agnt_name .= ' v'.$info['version'];

$acc_id = 'unknown';
$check_login_id = 'unknown';
$username = 'unknown';
$logstate = 'FAILED';
$usingpass = 'USING PASSWORD:NONE';
$mod = array('mconf' => '0',
             'mmute' => '0',
             'mwarn' => '0',
             'mkick' => '0');

switch($do) {
case 'guest':
$pass = 'bla';
  $gcolor  = (isset($_POST["gcolor"]) ? htmlspecialchars($_POST["gcolor"]) : $ZE_SETT["chat_default_color"]);
  $gender  = (isset($_POST["ggender"]) ? htmlspecialchars($_POST["ggender"]) : '0');
  $gbday   = (isset($_POST["gbirthday"]) ? htmlspecialchars($_POST["gbirthday"]) : '0');
  $grules  = (isset($_POST["grules"]) ? htmlspecialchars($_POST["grules"]) : '0');
  $ZE_USER->cleanUpGuests($ZE_SETTINGS->getGuestRank());
  
  if($ZE_SETT["chat_open"] != '1') {
    $usingpass = 'REJECTED ### CHAT CLOSED ### GUEST';
    $data = array('state' => 'closed',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }

  if($login == 'Benutzername') {
    $data = array('state' => 'gname',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }
  if($grules == '' || $grules == '0') {
    $data = array('state' => 'rules',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }
  $namebad = 'nope';
  $query =
    mysqli_query($db, "SELECT `user_name`
                 FROM `".ZE_PRE."_user`
                 WHERE `user_name` = '$login'");
    while($row = mysqli_fetch_object($query)){
      $namebad = $row->user_name;
    }
  if($login == $namebad){
    $data = array('state' => 'gnamebad',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }
  if (!preg_match("#^[a-zA-ZäÄöÖüÜß0-9\-\.]+$#", $login)) {
    $data = array('state' => 'gnamechar',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }
  $now = clock();
  $pass = random_gen(5);
  $pass2 = password_hash($pass, PASSWORD_BCRYPT);
  $age = calcAge($gbday);
  $mail = $login."@guest.com";
  $grank = $ZE_SETTINGS->getGuestRank();

  if($age < $ZE_SETT["min_age"]){
    $data = array('state' => 'gage',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }
  $accid = $ZE_USER->createAcc($now, $pass2, $mail, $age, $gbday, '1', '', $grank, 'yes');
  $tmp_user_id = $ZE_USER->createUser($accid, $login, $gcolor, $grank, $gender, $now, 'default', 'yes');
  $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $accid, 'acc_main_user', $tmp_user_id);
default:
  if($pass == '') {
    $data = array('state' => 'pass',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }
  
  if($ZE_USER->checkIfUserExist($login) == false) {
    $usingpass = 'REJECTED ### USER UNKNOWN';
    $data = array('state' => 'unknown',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }

  if(ctype_digit($login)) {
    $acc_id = $login;
    $check_login_id = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_main_user');
  } elseif(strpos($login, '@') !== false) {
    $acc_id = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_email', $login, 'acc_id');
    $check_login_id = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_main_user');
  } else {
    $acc_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_name', $login, 'user_acc_id');
    $check_login_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_name', $login, 'user_id');
  }

  $acc_id = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_acc_id');
  $stored_pw = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_pass');

  if(!password_verify($pass, $stored_pw)){
    $usingpass = 'USING PASSWORD:WRONG PASSWORD';
    $data = array('state' => 'pass',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '00',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }

  if($ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_global_banned') == 1) {
    $usingpass = 'USING PASSWORD:YES ### BANNED';
    $data = array('state' => 'ban',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }
  $tban = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_global_banned_to');
  if($tban != 0) {
    $atm = time();
    if($atm >= $tban) {
      $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_global_banned_to', '0');
    } else {
      $usingpass = 'USING PASSWORD:YES ### TEMPBANNED';
      $data = array('state' => 'tban',
                    'uid' => '0',
                    'aid' => '0',
                    'sid' => '0',
                    'lvl' => '0',
                    'name' => $tban,
                    'age'  => '0',
                    'ucol' => '000',
                    'acp' => 'no',
                    'mod' => $mod,
                    'bpr' => 'no');
      goto output;
    }
  }

  $act = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_global_activated');
  if($act != '1' || $act == '') {
    if($act == 2) {
      $usingpass = 'USING PASSWORD:YES ### AWAITING ADMIN ACTIVATION';
      $data = array('state' => 'act',
                    'uid' => '0',
                    'aid' => '0',
                    'sid' => '0',
                    'lvl' => '0',
                    'name' => '2',
                    'age'  => '0',
                    'ucol' => '000',
                    'acp' => 'no',
                    'mod' => $mod,
                    'bpr' => 'no');
      goto output;
    } else {
      $usingpass = 'USING PASSWORD:YES ### AWAITING USER ACTIVATION';
      $data = array('state' => 'act',
                    'uid' => '0',
                    'aid' => '0',
                    'sid' => '0',
                    'lvl' => '0',
                    'name' => '1',
                    'age'  => '0',
                    'ucol' => '000',
                    'acp' => 'no',
                    'mod' => $mod,
                    'bpr' => 'no');
      goto output;
    }
  }

  $username = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_name');
  
  if($ZE_SETT["chat_open"] != '1' && $ZE_SETTINGS->cp('bypass_chatlock', $check_login_id, $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level')) == false) {
    $usingpass = 'REJECTED ### CHAT CLOSED ### MISSING PERMISSION';
    $data = array('state' => 'closed',
                  'uid' => '0',
                  'aid' => '0',
                  'sid' => '0',
                  'lvl' => '0',
                  'name' => 'none',
                  'age'  => '0',
                  'ucol' => '000',
                  'acp' => 'no',
                  'mod' => $mod,
                  'bpr' => 'no');
    goto output;
  }

  $delete = "DELETE FROM `".ZE_PRE."_session` WHERE `sess_user_id` = '$check_login_id'";
  $do_it = mysqli_query($db, $delete);
  $helper = array();
  $query =
    mysqli_query($db, "SELECT `sr_rid` FROM `".ZE_PRE."_session_room` WHERE `sr_uid` = '$check_login_id'")
      OR die("Error: <br>".mysqli_error($db));
  while($row = mysqli_fetch_object($query)){
    $helper[] = $row->sr_rid;  
  }
  if(count($helper) > 0) {
    if($acc_id < 2000) {
      $tmp_message = htmlspecialchars('Gast "'.$username.'" hat den Raum verlassen. (Neu eingeloggt)');
    } else {
      $tmp_message = htmlspecialchars('"'.$username.'" hat den Raum verlassen. (Neu eingeloggt)');
    }
    for($i=0; $i<count($helper); $i++) {
      $ZE_MESS->insertMessage('0',
                              $ZE_SETT["chat_system_name"],
                              $helper[$i],
                              '0',
                              '0',
                              '0',
                              '0',
                              '0',
                              $ZE_SETT["chat_system_color"],
                              $tmp_message,
                              'content',
                              '0');
      $delete = "DELETE FROM `".ZE_PRE."_session_room` WHERE `sr_uid` = '$check_login_id' AND `sr_rid` = '$helper[$i]'";
      $do_it = mysqli_query($db, $delete);
    }
  }

  $ucs = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_clock_switch');
  $ZE_SID = random_gen(32);
  $now = clock();
  $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_age', calcAge($ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_birthday')));
  $ZE_SHOP->checkItems($check_login_id);
  $age = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_age');

  $lastloginday = date_format(date_create($ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_global_last_login')), 'Ymd');
  $today = date_format(date_create($now), 'Ymd');
  
  if($today > $lastloginday && $acc_id >= 2000 && $ZE_SETT["daily_coins"] != 0) {
    //Include MailClass
    require_once './class/mails.class.php';
    $ZE_MAIL = new mails($db);
    $ZE_coins = $ZE_USER->getInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_coins');
    $ZE_coins = $ZE_coins + $ZE_SETT["daily_coins"];
    $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_coins', $ZE_coins);
    $subject = "Loginbonus";
    $tomorrow = date("d.m.Y", strtotime('tomorrow'));
    $content = "Für deinen heutigen Login, wurden dir ".$ZE_SETT["daily_coins"]." Coins gutgeschrieben!\n\nDen nächsten Bonus gibt es am ".$tomorrow."!";
    $ZE_MAIL->sendMail(0, $check_login_id, clock(), $subject, $content);
  }

  $ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $acc_id, 'acc_global_last_login', date("Y-m-d H:i:s"));
  $ZE_USER->updateInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_last_login', date("Y-m-d H:i:s"));

  $ZE_LEVEL = $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level');
  $ZE_SESS->createSess($ZE_SID, $check_login_id, $acc_id, $now, '1', $ZE_LEVEL, $now, $ip, $agnt_name, $os, '0', $ucs, 'default', '1');
  $ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_last_sent_message_time', $now);
  $ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_last_message_got', time());
  $ZE_SESS->updateInfo('sess_id', $ZE_SID, 'sess_last_message_id', $ZE_MESS->getLastID());
  if($ZE_SETTINGS->cp('show_acp', $check_login_id, $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level')) != false) {
    $acp = 'yes';
  } else {
    $acp = 'no';
  }
  if($ZE_SETTINGS->cP('mod_confuse', $check_login_id, $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level')) != false) {
    $mod["mconf"] = '1';
  }
  if($ZE_SETTINGS->cP('mod_warn', $check_login_id, $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level')) != false) {
    $mod["mwarn"] = '1';
  }
  if($ZE_SETTINGS->cP('mod_mute', $check_login_id, $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level')) != false) {
    $mod["mmute"] = '1';
  }
  if($ZE_SETTINGS->cP('mod_kick', $check_login_id, $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level')) != false) {
    $mod["mkick"] = '1';
  }
  if($ZE_SETTINGS->cp('bypass_room', $check_login_id, $ZE_USER->getInfo(ZE_PRE.'_user', 'user_id', $check_login_id, 'user_level')) != false) {
    $bpr = 'yes';
  } else {
    $bpr = 'no';
  }

  $message = '"'.$username.'" hat sich soeben eingeloggt!';
  $ZE_MESS->insertMessage('0',
                          $ZE_SETT["chat_system_name"],
                          '0',
                          '0',
                          '0',
                          '0',
                          '2',
                          '0',
                          $ZE_SETT["chat_system_color"],
                          $message,
                          'content',
                          '0');

}
$logstate = 'PASSED';
$usingpass = 'USING PASSWORD:YES';
$data = array('state' => 'true',
              'uid' => $check_login_id,
              'aid' => $acc_id,
              'sid' => $ZE_SID,
              'lvl' => $ZE_LEVEL,
              'name' => $username,
              'age'  => $age,
              'ucol' => '000',
              'acp' => $acp,
              'mod' => $mod,
              'bpr' => $bpr);
output:

$file = './logs/logins.log';
$row = "ACCID $acc_id ### USERID $check_login_id ### IP $ip ### OS $os ### BROWSER $agnt_name ### @".date("Y-m-d H:i:s")." ### LOGIN@$username $logstate ";
if($logstate == 'FAILED') {
  $row .= "(USING:".$login.") ";
}
$row .= "### $usingpass\n";
file_put_contents($file, $row, FILE_APPEND | LOCK_EX);

echo json_encode($data);

?>