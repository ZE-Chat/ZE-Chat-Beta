CREATE TABLE `#ZEPRE#_account` (
  `acc_id` int(10) NOT NULL,
  `acc_registered` datetime NOT NULL,
  `acc_pass` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `acc_email` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `acc_age` tinyint(2) NOT NULL,
  `acc_birthday` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `acc_main_user` int(10) NOT NULL DEFAULT '0',
  `acc_to_delete` int(12) NOT NULL DEFAULT '0',
  `acc_global_last_login` datetime NOT NULL,
  `acc_global_level` tinyint(2) NOT NULL DEFAULT '1',
  `acc_global_banned` tinyint(1) NOT NULL DEFAULT '0',
  `acc_global_banned_to` int(10) NOT NULL,
  `acc_global_forced_room` int(10) NOT NULL DEFAULT '0',
  `acc_global_restricted_rooms` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `acc_global_activated` tinyint(1) NOT NULL DEFAULT '0',
  `acc_global_activation_code` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `acc_global_user_count` int(3) NOT NULL,
  `acc_global_warns` tinyint(2) NOT NULL DEFAULT '0',
  `acc_global_first_login` tinyint(1) NOT NULL,
  `acc_coins` int(10) NOT NULL DEFAULT '0',
  `acc_coin_timeout` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_avatar` (
  `ava_id` int(15) NOT NULL,
  `ava_user_id` int(15) NOT NULL,
  `ava_main` tinyint(1) NOT NULL DEFAULT '0',
  `ava_link` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ava_usk` tinyint(2) NOT NULL DEFAULT '0',
  `ava_desc` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ava_priv` tinyint(1) NOT NULL DEFAULT '0',
  `ava_state` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_badwords` (
  `bad_id` int(10) NOT NULL,
  `bad_word` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bad_min_age` tinyint(2) NOT NULL,
  `bad_max_age` tinyint(2) NOT NULL,
  `bad_text` tinyint(1) NOT NULL,
  `bad_name` tinyint(1) NOT NULL,
  `bad_punish` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE `#ZEPRE#_bans` (
  `ban_id` int(10) NOT NULL,
  `ban_ident` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ban_accid` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_blog` (
  `blog_id` int(10) NOT NULL,
  `blog_user_id` int(10) NOT NULL,
  `blog_date` int(10) NOT NULL,
  `blog_subject` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `blog_tags` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `blog_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `blog_votes` int(10) NOT NULL,
  `blog_state` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_blog_comments` (
  `bc_id` int(10) NOT NULL,
  `bc_blog_id` int(10) NOT NULL,
  `bc_author_id` int(10) NOT NULL,
  `bc_author_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bc_write_time` int(15) NOT NULL,
  `bc_state` tinyint(1) NOT NULL,
  `bc_content` varchar(2500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bc_votes` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_bots` (
  `bot_id` int(10) NOT NULL,
  `bot_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bot_key` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bot_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000',
  `bot_level` tinyint(2) NOT NULL DEFAULT '0',
  `bot_for_user` tinyint(1) NOT NULL DEFAULT '0',
  `bot_fee` int(10) NOT NULL DEFAULT '0',
  `bot_autotalk` tinyint(1) NOT NULL DEFAULT '0',
  `bot_at_next` int(15) NOT NULL,
  `bot_at_interval` int(11) NOT NULL,
  `bot_pic` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default_bot.jpg',
  `bot_desc` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_bot_answers` (
  `ba_id` int(10) NOT NULL,
  `ba_bot_id` int(10) NOT NULL,
  `ba_key` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ba_answer` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ba_fee` int(10) NOT NULL DEFAULT '0',
  `ba_for_autotalk` tinyint(1) NOT NULL DEFAULT '0',
  `ba_code` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ba_add_rule` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ba_add_key` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ba_add_answer` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ba_add_fee` int(10) NOT NULL DEFAULT '0',
  `ba_add_code` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_category` (
  `cat_id` int(10) NOT NULL,
  `cat_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cat_visa_req_user_min_age` tinyint(2) NOT NULL DEFAULT '0',
  `cat_visa_req_user_max_age` tinyint(2) NOT NULL DEFAULT '99',
  `cat_can_create` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_category` (`cat_id`, `cat_name`, `cat_visa_req_user_min_age`, `cat_visa_req_user_max_age`, `cat_can_create`) VALUES
(1, 'Öffentliche', 12, 65, 1),
(2, 'Interne', 0, 99, 0);

CREATE TABLE `#ZEPRE#_category_allow` (
  `cal_id` int(11) NOT NULL,
  `cal_catid` int(11) NOT NULL,
  `cal_gid` int(11) NOT NULL,
  `cal_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_category_create` (
  `cac_id` int(11) NOT NULL,
  `cac_catid` int(11) NOT NULL,
  `cac_gid` int(11) NOT NULL,
  `cac_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_colors` (
  `col_id` int(10) NOT NULL,
  `col_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `col_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `col_background` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `col_bimage` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `col_bora` tinyint(1) NOT NULL,
  `col_bors` varchar(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `col_border` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `col_other` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_dice` (
  `dice_id` int(10) NOT NULL,
  `dice_sess_1` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dice_sess_2` varchar(32) NOT NULL,
  `dice_bet` int(10) NOT NULL,
  `dice_created` int(12) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_friendlist` (
  `fl_id` int(10) NOT NULL,
  `fl_friend_1` int(10) NOT NULL,
  `fl_friend_2` int(10) NOT NULL,
  `fl_state` tinyint(1) NOT NULL,
  `fl_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_guestbook` (
  `gb_id` int(10) NOT NULL,
  `gb_sender` int(10) NOT NULL,
  `gb_getter` int(10) NOT NULL,
  `gb_date` datetime NOT NULL,
  `gb_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gb_state` tinyint(1) NOT NULL,
  `gb_new` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_ignore` (
  `ig_id` int(10) NOT NULL,
  `ig_user` int(10) NOT NULL,
  `ig_target` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_inv` (
  `inv_id` int(10) NOT NULL,
  `inv_user_id` int(10) NOT NULL,
  `inv_item_id` int(10) NOT NULL,
  `inv_item_bought` int(10) NOT NULL,
  `inv_item_is_present` int(10) NOT NULL,
  `inv_item_sender` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `inv_present_text` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_item` (
  `item_id` int(10) NOT NULL,
  `item_name` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `item_pic` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `item_cats_id` int(10) NOT NULL,
  `item_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `item_duration` int(10) NOT NULL,
  `item_available` tinyint(1) NOT NULL,
  `item_available_until` int(11) NOT NULL,
  `item_cost` int(10) NOT NULL,
  `item_discount_cost` int(10) NOT NULL DEFAULT '0',
  `item_discount_until` int(12) NOT NULL DEFAULT '0',
  `item_min_age` tinyint(2) NOT NULL,
  `item_special` tinyint(1) NOT NULL,
  `item_code` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_item` (`item_id`, `item_name`, `item_pic`, `item_cats_id`, `item_text`, `item_duration`, `item_available`, `item_available_until`, `item_cost`, `item_discount_cost`, `item_discount_until`, `item_min_age`, `item_special`, `item_code`) VALUES
(23, 'Trostpflaster', 'VrkZ1Zy36CxXGm8O.jpg', 8, 'Ein Trostpflaster für kleine Weh-Wehchen.', 0, 0, 2015, 10, 0, 0, 0, 0, ''),
(22, 'Kobold', 'Udai92RSzzD9QGR9.jpg', 8, 'Führt er euch zu seinem Topf voll Gold?', 0, 0, 2015, 20, 0, 0, 0, 0, ''),
(24, 'Schmerztablette ', 'RPpwJC8WNtj96Q4f.jpg', 8, 'Gegen Schmerzen, welche Ursache sie auch haben mögen. :D', 0, 0, 2015, 20, 0, 0, 0, 0, ''),
(30, 'Premium-Benutzer', 'Gu5YXJPIFNvYmV4U.jpg', 6, 'Mit diesem Gegenstand werdet ihr zum &quot;Premium Benutzer&quot; und erhaltet Zugang zu einigen Extras, wie mehr Smilies, mehr Coins für den täglichen Login und kostenlosen Zugriff auf den /yt Befehl.', 604800, 1, 0, 500, 0, 0, 0, 1, 'group->6'),
(39, 'SilverShout', 'kP9NaIoJYM71XKf3.jpg', 7, 'Benutze \"/shout MESSAGE\" um eine Nachricht (kleines Extrafenster) anzeigen zu lassen.', 0, 1, 0, 25, 0, 0, 0, 1, 'shout'),
(20, 'Energydrink', 'gOzZrE4s89QOVVvI.jpg', 8, 'Für den ultimativen Energieschub!', 0, 0, 2015, 50, 0, 0, 18, 0, ''),
(25, 'Teufelchen', 'FIp1wWduzoH2zRqe.jpg', 8, 'Ein kleines Teufelchen - zum verschenken oder selber behalten. ', 0, 0, 2015, 30, 0, 0, 0, 0, ''),
(28, 'Vrooommmm', 'ccpXVQ4gxy1Hq1sj.jpg', 8, 'Ein heißer Wagen - gebt Gas!', 0, 0, 2015, 50, 0, 0, 0, 0, ''),
(29, 'Hirn', 'BVNWsuN7fkxiwUxX.jpg', 8, 'Hirn zum verschenken. :D', 0, 0, 2015, 100, 0, 0, 18, 0, ''),
(40, 'GoldShout', 'WSk8tybhpFdotEMn.jpg', 7, 'Benutze \"/shout MESSAGE\" um eine Nachricht (kleines Extrafenster) in allen Räumen anzeigen zu lassen.', 0, 1, 0, 50, 0, 0, 0, 1, 'gshout'),
(41, 'Herz', 'VmI5DRSNcVaNrMeX.jpg', 8, 'Ein Zeichen der Liebe oder der Freundschaft.', 0, 0, 2015, 120, 0, 0, 0, 0, ''),
(42, 'PM Increase 1', 'D3KDavpIYyx8LfWj.png', 7, 'Eröht die Anzahl der privaten Chatfenster um 1.', 604800, 1, 0, 75, 0, 0, 0, 1, 'pm-1'),
(43, 'PM Increase 3', 'bCZ6eSAZiFtyGtU8.png', 7, 'Erhöht die maximale Anzahl privater Chatfenster um 3.', 604800, 1, 0, 200, 0, 0, 0, 1, 'pm-3'),
(48, 'YoutubeVideo', 'A1F765KjqZj4cj9I.jpg', 7, 'Ermöglicht dem Besitzer ein YoutubeVideo im Chatraum für alle anzeigen zu lassen.\r\n\r\n\"/yt LINK\"', 0, 1, 0, 20, 0, 0, 0, 1, 'yt');

CREATE TABLE `#ZEPRE#_item_cats` (
  `item_cats_id` int(10) NOT NULL,
  `item_cats_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `item_cats_min_age` tinyint(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_item_cats` (`item_cats_id`, `item_cats_name`, `item_cats_min_age`) VALUES
(7, 'Sondergegenstände', 0),
(6, 'Ränge', 0),
(8, 'Deko', 0);

CREATE TABLE `#ZEPRE#_lang` (
  `lang_id` int(15) NOT NULL,
  `lang_language` int(15) NOT NULL,
  `lang_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `lang_area` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'all',
  `lang_content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_lang` (`lang_id`, `lang_language`, `lang_code`, `lang_area`, `lang_content`) VALUES
(1, 1, 'login', 'loginbox', 'Login'),
(2, 1, 'password', 'loginbox', 'Passwort'),
(3, 1, 'desc', 'loginbox', 'Benutze bitte deine/n Accountname, Accountnummer, Email oder Nickname'),
(4, 1, 'submit', 'loginbox', 'Einloggen'),
(5, 2, 'login', 'loginbox', 'Login'),
(6, 2, 'password', 'loginbox', 'Password'),
(7, 2, 'desc', 'loginbox', 'Please use your Accountname, Accountnumber, E-Mail or Nickname'),
(8, 2, 'submit', 'loginbox', 'Login'),
(9, 1, 'langcode', 'langcode', 'Deutsch'),
(10, 2, 'langcode', 'langcode', 'English'),
(12, 1, 'head', '_acp_lang', 'Spracheinstellungen'),
(20, 1, 'picklang', '_acp_lang', 'Wähle Sprache'),
(22, 1, 'pickarea', '_acp_lang', 'Wähle Bereich'),
(23, 1, 'get', '_acp_lang', 'Holen'),
(24, 1, 'create', '_acp_lang', 'Erstellen'),
(25, 1, 'key', '_acp_lang', 'Schlüssel'),
(26, 1, 'area', '_acp_lang', 'Bereich'),
(30, 1, 'replacement', '_acp_lang', 'Ersetzung'),
(34, 1, 'validatetip', '_acp_lang', 'Alle Felder müssen gefüllt werden.'),
(35, 1, 'language', '_acp_lang', 'Sprache'),
(36, 1, 'makenew', '_acp_lang', 'Neu anlegen'),
(37, 1, 'keydesc', '_acp_lang', 'Im Quelltext verwendeter Begriff'),
(38, 1, 'replacementdesc', '_acp_lang', 'Im Browser angezeigte Ersetzung'),
(39, 1, 'alter', '_acp_lang', 'Anpassen'),
(40, 1, 'delete', '_acp_lang', 'Löschen'),
(41, 1, 'success', '_acp_lang', 'Erfolgreich!'),
(42, 1, 'updated', '_acp_lang', 'Eintrag aktualisiert!'),
(43, 1, 'created', '_acp_lang', 'Eintrag erstellt!'),
(44, 1, 'nav_menu', 'frontpage', 'Menü'),
(47, 1, 'sidebox', 'frontpage', 'Seitenbereich'),
(48, 1, 'loginmenu', 'frontpage', 'Loginmenü'),
(49, 1, 'navleft', 'frontpage', 'Links'),
(50, 1, 'navright', 'frontpage', 'Rechts'),
(51, 1, 'tab', 'frontpage', 'Tabs'),
(52, 1, 'navnews', 'frontpage', 'Community-News'),
(53, 1, 'navdialogs', 'frontpage', 'Dialoge'),
(54, 1, 'register', 'frontpage', 'Registrierung'),
(57, 1, 'cdelete', '_acp_lang', 'Achtung! Diesen Eintrag wirklich löschen?'),
(58, 1, 'deleted', '_acp_lang', 'Eintrag gelöscht!'),
(59, 1, 'head', '_acp_main', 'Adminpanel'),
(60, 1, 'totalonline', '_acp_main', 'Gesamt Online'),
(61, 1, 'cpuusage', '_acp_main', 'CPU Last'),
(62, 1, 'ramusage', '_acp_main', 'RAM Last'),
(63, 1, 'ressdesc', '_acp_main', 'Auslastungen beziehen sich auf die momentane Gesamtauslastung des Servers!'),
(64, 1, 'loaderror', '_acp_main', 'Konnte Seite leider nicht laden!'),
(65, 1, 'browser', 'langcode', 'de'),
(66, 2, 'browser', 'langcode', 'en'),
(67, 1, 'rules', 'roomsel', 'Raumregeln'),
(68, 1, 'inroom', 'roomsel', 'Im Raum'),
(69, 1, 'noone', 'roomsel', 'Niemand'),
(70, 1, 'locked', 'roomsel', 'Abgeschlossen'),
(71, 1, 'temp', 'roomsel', 'Temporär'),
(72, 1, 'reqpass', 'roomsel', 'Passwort nötig'),
(73, 1, 'enterpass', 'roomsel', 'Raumpasswort eingeben'),
(74, 1, 'pass', 'roomsel', 'Passwort'),
(75, 1, 'error', 'roomsel', 'Fehler!'),
(76, 1, 'info', 'roomsel', 'Info!'),
(77, 1, 'errort1', 'roomsel', 'Raum ist voll!'),
(78, 1, 'errort2', 'roomsel', 'Raum ist abgeschlossen!'),
(79, 1, 'infot1', 'roomsel', 'Raum erwartet Passwort!'),
(80, 1, 'errort3', 'roomsel', 'Unbekannter Fehler!'),
(81, 1, 'infot2', 'roomsel', 'Raum betreten!'),
(82, 1, 'ptitle', 'roomsel', 'Passworteingabe'),
(83, 1, 'abort', 'roomsel', 'Abbrechen'),
(84, 1, 'send', 'roomsel', 'Abschicken'),
(85, 2, 'loginmenu', 'frontpage', 'Login'),
(86, 2, 'lostpw', 'frontpage', 'Lost Password'),
(87, 2, 'nav_menu', 'frontpage', 'Menu'),
(88, 2, 'navdialogs', 'frontpage', 'Dialogs'),
(89, 2, 'navleft', 'frontpage', 'Left'),
(90, 2, 'navnews', 'frontpage', 'Community News'),
(91, 2, 'navright', 'frontpage', 'Right'),
(92, 2, 'register', 'frontpage', 'Registration'),
(93, 2, 'sidebox', 'frontpage', 'Sidebox'),
(94, 2, 'tab', 'frontpage', 'Tabs'),
(95, 2, 'abort', 'roomsel', 'Cancel'),
(96, 2, 'enterpass', 'roomsel', 'Enter Roompassword'),
(97, 2, 'error', 'roomsel', 'Error!'),
(98, 2, 'errort1', 'roomsel', 'Room is full!'),
(99, 2, 'errort2', 'roomsel', 'Room is closed!'),
(100, 2, 'errort3', 'roomsel', 'Unkown error!'),
(101, 2, 'info', 'roomsel', 'Info!'),
(102, 2, 'infot1', 'roomsel', 'Room expects password!'),
(103, 2, 'infot2', 'roomsel', 'Room entered!'),
(104, 2, 'inroom', 'roomsel', 'In Room'),
(105, 2, 'locked', 'roomsel', 'Locked'),
(106, 2, 'noone', 'roomsel', 'Nobody'),
(107, 2, 'pass', 'roomsel', 'Password'),
(108, 2, 'ptitle', 'roomsel', 'Enter Password'),
(109, 2, 'reqpass', 'roomsel', 'Password required!'),
(110, 2, 'rules', 'roomsel', 'Room rules'),
(111, 2, 'send', 'roomsel', 'Send'),
(112, 2, 'temp', 'roomsel', 'Temporary'),
(113, 2, 'alter', '_acp_lang', 'Change'),
(114, 2, 'area', '_acp_lang', 'Area'),
(115, 2, 'cdelete', '_acp_lang', 'Attention! Do you realy want to delete this entry?'),
(116, 2, 'create', '_acp_lang', 'Create'),
(117, 2, 'created', '_acp_lang', 'Entry created!'),
(118, 2, 'delete', '_acp_lang', 'Delete'),
(119, 2, 'deleted', '_acp_lang', 'Entry deleted!'),
(120, 2, 'get', '_acp_lang', 'Get'),
(121, 2, 'head', '_acp_lang', 'Languagesettings'),
(122, 2, 'key', '_acp_lang', 'Key'),
(123, 2, 'keydesc', '_acp_lang', 'In sourcecode used keyword'),
(124, 2, 'language', '_acp_lang', 'Language'),
(125, 2, 'makenew', '_acp_lang', 'Create new'),
(126, 2, 'pickarea', '_acp_lang', 'Pick area'),
(127, 2, 'picklang', '_acp_lang', 'Pick language'),
(128, 2, 'replacement', '_acp_lang', 'Replacement'),
(129, 2, 'replacementdesc', '_acp_lang', 'In browser shown replacement'),
(130, 2, 'success', '_acp_lang', 'Success!'),
(131, 2, 'updated', '_acp_lang', 'Entry updated!'),
(132, 2, 'validatetip', '_acp_lang', 'All fields need to be filled.'),
(133, 2, 'cpuusage', '_acp_main', 'CPU Usage'),
(134, 2, 'head', '_acp_main', 'Adminpanel'),
(135, 2, 'loaderror', '_acp_main', 'Couldnt load this site!'),
(136, 2, 'ramusage', '_acp_main', 'RAM Usage'),
(137, 2, 'ressdesc', '_acp_main', 'Usage means current complete usage of the server'),
(138, 2, 'totalonline', '_acp_main', 'Total online'),
(139, 1, 'accname', 'registerbox', 'Accountname'),
(140, 1, 'accdesc', 'registerbox', 'Nicht dein Nickname'),
(141, 1, 'nick', 'registerbox', 'Nickname'),
(142, 1, 'nickdesc', 'registerbox', 'Angezeigter Nickname in der Community'),
(143, 1, 'color', 'registerbox', 'Farbe'),
(144, 1, 'coldesc', 'registerbox', 'Deine angezeigte Farbe'),
(145, 1, 'password', 'registerbox', 'Passwort'),
(146, 1, 'reppass', 'registerbox', 'Passwort wiederholen'),
(147, 1, 'reppassdesc', 'registerbox', 'Wiederhole bitte dein Passwort'),
(148, 1, 'email', 'registerbox', 'E-Mail-Adresse'),
(149, 1, 'emaildesc', 'registerbox', 'Verwende bitte eine gültige E-Mail-Adresse'),
(150, 1, 'bday', 'registerbox', 'Geburtsdatum'),
(151, 1, 'bdaydesc', 'registerbox', 'Bitte gib dein korrektes Geburtsdatum ein'),
(152, 1, 'gender', 'registerbox', 'Geschlecht'),
(153, 1, 'male', 'registerbox', 'Männlich'),
(154, 1, 'female', 'registerbox', 'Weiblich'),
(155, 1, 'secret', 'registerbox', 'Geheim'),
(156, 1, 'rules', 'registerbox', 'Chat-Regeln'),
(157, 1, 'show', 'registerbox', 'Ansehen'),
(158, 1, 'rulesdesc', 'registerbox', 'Zum registrieren müssen diese angenommen werden'),
(159, 1, 'accept', 'registerbox', 'Annehmen'),
(160, 1, 'info', 'registerbox', 'Info!'),
(161, 1, 'infodesc', 'registerbox', 'Registrierung fast abgeschlossen! Überprüfe deine Emails für den letzten Schritt!'),
(162, 1, 'error', 'registerbox', 'Fehler!'),
(163, 1, 'errordesc', 'registerbox', 'Überprüfe deine Eingaben!'),
(164, 1, 'head1', 'onlinebox', 'User Online:'),
(165, 0, 'head2', 'none', 'Im Raum:'),
(166, 1, 'head2', 'onlinebox', 'Im Raum:'),
(167, 1, 'noone', 'onlinebox', 'Niemand'),
(168, 1, 'loading', 'onlinebox', 'Lade...'),
(169, 1, 'openprofil', 'onlinebox', '\'s Profil'),
(170, 1, 'talkto', 'onlinebox', 'Ansprechen'),
(171, 1, 'whisper', 'onlinebox', 'Anflüstern'),
(172, 1, 'talkprivate', 'onlinebox', 'Privat schreiben'),
(173, 1, 'alert', 'onlinebox', 'Aufmerksam machen'),
(174, 1, 'mail', 'onlinebox', 'Mailen'),
(175, 1, 'friendship', 'onlinebox', 'Freundschaft'),
(176, 1, 'recolor', 'onlinebox', 'Umfärben'),
(177, 1, 'ignore', 'onlinebox', 'Ignorieren'),
(178, 1, 'report', 'onlinebox', 'Melden'),
(179, 1, 'admin', 'onlinebox', 'Administrieren'),
(180, 1, 'modify', 'onlinebox', 'Bearbeiten'),
(181, 1, 'information', 'onlinebox', 'Informationen'),
(182, 1, 'confuse', 'onlinebox', 'Verwirren'),
(183, 1, 'move', 'onlinebox', 'Verschieben'),
(184, 1, 'stick', 'onlinebox', 'Festsetzen'),
(185, 1, 'unstick', 'onlinebox', 'Freilassen'),
(186, 1, 'warn', 'onlinebox', 'Verwarnen'),
(187, 1, 'parole', 'onlinebox', 'Entwarnen'),
(188, 1, 'mute', 'onlinebox', 'Knebeln'),
(189, 1, 'unmute', 'onlinebox', 'Entknebeln'),
(190, 1, 'kick', 'onlinebox', 'Rausschmeissen'),
(191, 1, 'userban', 'onlinebox', 'Benutzer&nbsp;bannen&nbsp;'),
(192, 1, 'accban', 'onlinebox', 'Accountban'),
(193, 1, 'lostpw', 'frontpage', 'Passwort vergessen');

CREATE TABLE `#ZEPRE#_lottery` (
  `lot_id` int(10) NOT NULL,
  `lot_uid` int(10) NOT NULL,
  `lot_uname` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `lot_1` int(10) NOT NULL,
  `lot_2` int(10) NOT NULL,
  `lot_3` int(10) NOT NULL,
  `lot_4` int(10) NOT NULL,
  `lot_5` int(10) NOT NULL,
  `lot_6` int(10) NOT NULL,
  `lot_7` int(10) NOT NULL,
  `lot_8` int(10) NOT NULL,
  `lot_9` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_lottery_history` (
  `lh_id` int(10) NOT NULL,
  `lh_date` int(12) NOT NULL,
  `lh_winner` int(10) NOT NULL,
  `lh_price` int(10) NOT NULL,
  `lh_1` int(10) NOT NULL,
  `lh_2` int(10) NOT NULL,
  `lh_3` int(10) NOT NULL,
  `lh_4` int(10) NOT NULL,
  `lh_5` int(10) NOT NULL,
  `lh_6` int(10) NOT NULL,
  `lh_7` int(10) NOT NULL,
  `lh_8` int(10) NOT NULL,
  `lh_9` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_lottery_settings` (
  `lot_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `lot_max_number` tinyint(2) NOT NULL DEFAULT '10',
  `lot_numbers` tinyint(3) NOT NULL,
  `lot_jackpot` int(11) NOT NULL DEFAULT '100',
  `lot_cost` int(10) NOT NULL DEFAULT '25',
  `lot_day` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `lot_hour` int(2) NOT NULL,
  `lot_minute` int(2) NOT NULL,
  `lot_next` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `#ZEPRE#_mail` (
  `mail_id` int(10) NOT NULL,
  `mail_sender` int(10) NOT NULL,
  `mail_getter` int(10) NOT NULL,
  `mail_date` datetime NOT NULL,
  `mail_subject` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mail_text` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mail_state` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_message` (
  `mess_id` int(20) NOT NULL,
  `mess_author_id` int(15) NOT NULL,
  `mess_author_name` varchar(84) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mess_write_time` int(15) NOT NULL,
  `mess_room_id` int(15) NOT NULL,
  `mess_target_room_id` int(15) NOT NULL,
  `mess_target_user_id` int(15) NOT NULL,
  `mess_usk` tinyint(1) NOT NULL DEFAULT '0',
  `mess_req_lvl` tinyint(2) NOT NULL DEFAULT '0',
  `mess_private` tinyint(1) NOT NULL DEFAULT '0',
  `mess_type` tinyint(1) NOT NULL DEFAULT '0',
  `mess_area` varchar(7) NOT NULL,
  `mess_action` int(10) NOT NULL DEFAULT '0',
  `mess_form` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mess_content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_news` (
  `news_id` int(10) NOT NULL,
  `news_date` datetime NOT NULL,
  `news_author` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `news_title` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `news_content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_news` (`news_id`, `news_date`, `news_author`, `news_title`, `news_content`) VALUES
(21, '2016-12-14 13:15:49', 'Zion', 'Nicknamen', 'Solltet ihr einen Nicknamen mit Leerzeichen darin verwendet haben, so ist dieser noch in selber Schreibweise, jedoch ohne Leerzeichen vorhanden und einloggbar.\r\n\r\n&quot;Max Mustermann&quot; =&gt; &quot;MaxMustermann&quot;'),
(10, '2016-01-07 14:53:27', 'Zion', 'BBCodeDemo', '[b][i][u]test[/u][/i][/b] \r\n[sup]test[/sup] \r\n[sub]test[/sub] \r\n[img]http://www.zevolutions.de/logo.png[/img] \r\n\r\n[url=http://www.zevolutions.de/index.php]zEvolutions[/url] \r\n \r\n[list][*]test[*]test[*]test[/list] [list=1][*]test[*]test[*]test[/list] \r\n[color=#00ff00][color=#cc0000]test[/color]\r\n[/color] test \r\n[size=50]test\r\n[/size] [size=100]test\r\n[/size] [size=150]test\r\n[/size] [size=200]test\r\n[size=200][color=#ff0000]t[/color][color=#9900ff]e[/color][color=#e69138]s[/color][color=#00ff00]t[/color][/size]\r\n[/size] [font=Comic Sans MS]test\r\n [center]test[/center]\r\n [right]test﻿﻿[/right]\r\n[/font] [quote]\r\ntest[/quote] \r\n \r\n[code]test[/code] \r\n \r\n[table][tr][td]test﻿[/td][td]test﻿[/td][td]test﻿[/td][/tr][tr][td]﻿test[/td][td]﻿test[/td][td]﻿test[/td][/tr][/table] test'),
(12, '2016-01-08 11:28:47', 'Zion', 'Zweite News aus dem ACP!', 'Nun auch mit [color=#9900ff][u]Bearbeitung[/u]![/color]'),
(19, '2016-02-09 04:04:55', 'Zion', 'Wipe', 'Aufgrund der Aktualisierung der Passwort-Verschlüsselung, wurden alle Accounts gelöscht.'),
(20, '2016-12-01 18:56:54', 'Holly', 'jQueryUI-Update!', 'Liebe Leute, \r\n\r\nwie euch vielleicht aufgefallen ist, sieht der Chat im Moment optisch ziemlich verhunzt aus. Dies liegt an einem Update auf jQueryUI v12, welches die Optik des Chats gekillt hat. \r\nSollten euch also Optikfehler auffallen (mal ganz abgesehen von dem offensichtlichen Optikfehler oben links), schickt Zion bitte eine Privatnachricht im Forum (mit Screenshot!).\r\n\r\nDanke für eure Mithilfe!\r\n\r\nCheerio,\r\nHolly');

CREATE TABLE `#ZEPRE#_patch_history` (
  `patch_id` int(10) NOT NULL,
  `patch_version` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `patch_installed` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_permission` (
  `perm_id` int(11) NOT NULL,
  `perm_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `perm_desc` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `perm_shown` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `perm_group` int(10) NOT NULL,
  `perm_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_permission` (`perm_id`, `perm_name`, `perm_desc`, `perm_shown`, `perm_group`, `perm_default`) VALUES
(1, 'friends', '', 'Freundschaftsfunktionen', 1, 1),
(2, 'gbook', '', 'Gästebuchfunktionen', 1, 1),
(3, 'mails', '', 'Chatmailfunktionen', 1, 1),
(4, 'presents', 'Sichtbarkeit von Inventarlisten und Shop', 'Gegenstandoptionen', 1, 1),
(5, 'avatar', 'Kann Avatar hochladen. Notwendig für die Galleriefunktionen.', 'Avatar setzen', 1, 1),
(6, 'bypass_room', 'Umgeht abgeschlossene, volle und Passwort geschützte Räume.', 'Raumumgehung', 2, 0),
(7, 'show_acp', 'Zugang zum Adminpanel', 'Adminpanel', 2, 0),
(13, 'acp_permissions', 'Zugang zum ACP Bereich Gruppen und Rechte', 'Rechteverwaltung', 2, 0),
(17, 'acp_usercenter', 'Zugang zum Adminbereich Benutzerverwaltung', 'Benutzerverwaltung', 2, 0),
(18, 'acp_languages', 'ACP Bereich Spracheinstellungen', 'Spracheinstellungen', 2, 0),
(19, 'chat_groupchat', 'Nachrichten nur an bestimmte Benutzergruppen schicken', 'Gruppenchat', 5, 0),
(20, 'editprofile', 'Zeige und erlaube den Profileditor', 'Profil bearbeiten', 1, 1),
(21, 'acp_global', 'ACP Zugang zu den globalen Einstellungen', 'Globale Einstellungen', 2, 0),
(22, 'acp_info', 'Infos einsehen wie OS, Browser und IP', 'Benutzerinformationen', 2, 0),
(23, 'acp_permit', 'Sicherheitspyramide bearbeiten', 'Gruppenreihenfolge', 2, 0),
(24, 'bypass_chatlock', 'Einloggen, obwohl der Chat abgeschlossen ist?', 'Chatsperre umgehen', 2, 0),
(25, 'acp_shop', 'Items, Kategorien und Preise festlegen', 'Shop bearbeiten', 2, 0),
(26, 'com_yt', 'Benutzung des YouTube-Befehls', 'Befehl /yt', 5, 0),
(27, 'com_shout', 'Benutzung des Shout-Befehls', 'Befehl /shout', 5, 0),
(28, 'com_gshout', 'Benutzung des GoldShout-Befehls', 'Befehl /gshout', 5, 0),
(29, 'com_dshout', 'Benutzung des DiamondShout-Befehls', 'Befehl /dshout', 5, 0),
(30, 'acp_room', 'Verwaltung der Kategorien und Räume', 'Räume bearbeiten', 2, 0),
(31, 'acp_badwords', 'Badwords anlegen, löschen, bearbeiten', 'Badword-Verwaltung', 2, 0),
(34, 'chat_miniava', 'Anzeige von kleinen Avataren im Chat', 'Mini-Avatare im Chat', 5, 1),
(35, 'chat_tf', 'Textformatierung in Chatnachrichten ändern', 'Chat Textformat', 5, 1),
(37, 'acp_livealert', 'Live-Meldungen über Verstoß-Meldungen, Bildfreigabe und mehr', 'Live-Moderation', 1, 0),
(38, 'acp_navi', 'Reihenfolge der Navigation ändern, Boxen, Links, Seiten und Dialoge hinzufügen oder entfernen', 'Navigation bearbeiten', 2, 0),
(40, 'acp_reports', 'Meldungen (Reports, Tickets) einsehen und bearbeiten', 'Reporthub', 2, 0),
(41, 'acp_avatars', 'Avatare freischalten oder verweigern', 'Avatarprüfung', 2, 0),
(42, 'daily_coins', 'Darf den unter Globale Einstellungen festgelegten Loginbonus (Coins) erhalten', 'Loginbonus', 1, 1),
(43, 'mod_info', 'Zeigt weitergehende Informationen über den Nutzer an', 'Informationen', 6, 0),
(44, 'mod_confuse', 'Vertauscht als milde Strafe die Buchstaben des Nutzers.', 'Verwirrung', 6, 0),
(45, 'mod_movestick', 'Verschiebt den Nutzer in einen anderen Raum und setzt ihn dort fest.', 'Verschieben', 6, 0),
(46, 'mod_warn', 'Verwarnt den Benutzer dauerhaft', 'Verwarnen', 6, 0),
(47, 'mod_mute', 'Verbietet einem Nutzer das Schreiben.', 'Knebeln', 6, 0),
(48, 'mod_kick', 'Benutzer aus dem Chat entfernen', 'Rauswerfen', 6, 0),
(49, 'mod_ban', 'Benutzer dauerhaft des Chats verweisen', 'Bannen', 6, 0),
(50, 'acp_archive', 'Zugang zum Nachrichtenarchiv', 'Archiv', 2, 0);

CREATE TABLE `#ZEPRE#_permissions` (
  `perm_id` int(10) NOT NULL,
  `perm_uid` int(32) NOT NULL COMMENT 'userid',
  `perm_gid` int(2) NOT NULL COMMENT 'groupid',
  `perm_pid` int(10) NOT NULL COMMENT 'permissionid',
  `perm_state` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `#ZEPRE#_permissions` (`perm_id`, `perm_uid`, `perm_gid`, `perm_pid`, `perm_state`) VALUES
(242, 0, 7, 13, 0),
(241, 0, 6, 13, 0),
(240, 0, 5, 13, 0),
(239, 0, 3, 13, 1),
(238, 0, 2, 13, 1),
(404, 0, 2, 25, 1),
(125, 0, 1, 3, 1),
(124, 0, 1, 5, 1),
(123, 0, 2, 2, 1),
(122, 0, 2, 1, 1),
(121, 0, 2, 3, 1),
(120, 0, 2, 5, 1),
(119, 0, 2, 6, 1),
(118, 0, 2, 7, 1),
(126, 0, 1, 2, 1),
(127, 0, 1, 7, 0),
(128, 0, 1, 6, 0),
(129, 0, 1, 1, 1),
(237, 0, 1, 13, 0),
(291, 0, 6, 4, 1),
(290, 0, 6, 2, 1),
(289, 0, 6, 1, 1),
(288, 0, 6, 3, 1),
(287, 0, 6, 5, 1),
(286, 0, 5, 6, 0),
(285, 0, 5, 7, 0),
(284, 0, 5, 4, 1),
(283, 0, 5, 2, 1),
(282, 0, 5, 1, 1),
(281, 0, 5, 3, 1),
(280, 0, 5, 5, 1),
(279, 0, 1, 4, 1),
(398, 0, 3, 24, 0),
(399, 0, 5, 24, 0),
(403, 0, 1, 25, 0),
(400, 0, 6, 24, 0),
(401, 0, 7, 24, 0),
(270, 0, 3, 4, 1),
(269, 0, 3, 2, 1),
(268, 0, 3, 1, 1),
(267, 0, 3, 3, 1),
(266, 0, 3, 5, 1),
(265, 0, 3, 6, 0),
(264, 0, 3, 7, 1),
(243, 0, 2, 4, 1),
(292, 0, 6, 7, 0),
(293, 0, 6, 6, 0),
(305, 0, 7, 17, 0),
(304, 0, 6, 17, 0),
(303, 0, 5, 17, 0),
(302, 0, 3, 17, 1),
(301, 0, 2, 17, 1),
(300, 0, 1, 17, 0),
(306, 0, 1, 18, 0),
(307, 0, 2, 18, 1),
(308, 0, 3, 18, 0),
(309, 0, 5, 18, 0),
(310, 0, 6, 18, 0),
(311, 0, 7, 18, 0),
(396, 0, 1, 24, 0),
(397, 0, 2, 24, 1),
(322, 0, 1, 19, 0),
(323, 0, 2, 19, 1),
(324, 0, 3, 19, 1),
(325, 0, 5, 19, 0),
(326, 0, 6, 19, 1),
(327, 0, 7, 19, 0),
(359, 0, 7, 1, 0),
(358, 0, 7, 3, 0),
(357, 0, 7, 5, 0),
(356, 0, 7, 6, 0),
(355, 0, 7, 7, 0),
(354, 0, 7, 20, 0),
(353, 0, 6, 20, 1),
(352, 0, 5, 20, 1),
(351, 0, 3, 20, 1),
(350, 0, 2, 20, 1),
(349, 0, 1, 20, 1),
(360, 0, 7, 2, 0),
(361, 0, 7, 4, 0),
(363, 0, 1, 21, 0),
(364, 0, 2, 21, 1),
(365, 0, 3, 21, 0),
(366, 0, 5, 21, 0),
(367, 0, 6, 21, 0),
(368, 0, 7, 21, 0),
(369, 0, 1, 22, 0),
(370, 0, 2, 22, 1),
(371, 0, 3, 22, 1),
(372, 0, 5, 22, 0),
(373, 0, 6, 22, 0),
(374, 0, 7, 22, 0),
(375, 0, 1, 23, 0),
(376, 0, 2, 23, 1),
(377, 0, 3, 23, 0),
(378, 0, 5, 23, 0),
(379, 0, 6, 23, 0),
(380, 0, 7, 23, 0),
(405, 0, 3, 25, 0),
(406, 0, 5, 25, 0),
(407, 0, 6, 25, 0),
(408, 0, 7, 25, 0),
(410, 0, 1, 26, 0),
(411, 0, 2, 26, 1),
(412, 0, 3, 26, 0),
(413, 0, 5, 26, 0),
(414, 0, 6, 26, 0),
(415, 0, 7, 26, 0),
(416, 0, 1, 27, 0),
(417, 0, 2, 27, 1),
(418, 0, 3, 27, 0),
(419, 0, 5, 27, 0),
(420, 0, 6, 27, 0),
(421, 0, 7, 27, 0),
(422, 0, 1, 28, 0),
(423, 0, 2, 28, 1),
(424, 0, 3, 28, 0),
(425, 0, 5, 28, 0),
(426, 0, 6, 28, 0),
(427, 0, 7, 28, 0),
(428, 0, 1, 29, 0),
(429, 0, 2, 29, 1),
(430, 0, 3, 29, 0),
(431, 0, 5, 29, 0),
(432, 0, 6, 29, 0),
(433, 0, 7, 29, 0),
(434, 0, 1, 30, 0),
(435, 0, 2, 30, 1),
(436, 0, 3, 30, 0),
(437, 0, 5, 30, 0),
(438, 0, 6, 30, 0),
(439, 0, 7, 30, 0),
(604, 0, 22, 19, 1),
(603, 0, 22, 35, 1),
(602, 0, 22, 26, 1),
(601, 0, 22, 27, 1),
(600, 0, 22, 28, 1),
(599, 0, 22, 29, 1),
(598, 0, 22, 20, 1),
(597, 0, 22, 42, 1),
(596, 0, 22, 37, 1),
(595, 0, 22, 4, 1),
(594, 0, 22, 2, 1),
(593, 0, 22, 1, 1),
(592, 0, 22, 3, 1),
(591, 0, 22, 5, 1),
(590, 0, 22, 18, 1),
(589, 0, 22, 25, 1),
(588, 0, 22, 40, 1),
(587, 0, 22, 13, 1),
(586, 0, 22, 6, 1),
(585, 0, 22, 30, 1),
(584, 0, 22, 38, 1),
(583, 0, 22, 23, 1),
(462, 0, 1, 31, 0),
(463, 0, 2, 31, 1),
(464, 0, 3, 31, 0),
(465, 0, 5, 31, 0),
(466, 0, 6, 31, 0),
(467, 0, 7, 31, 0),
(537, 0, 6, 38, 0),
(536, 0, 5, 38, 0),
(535, 0, 3, 38, 0),
(534, 0, 2, 38, 1),
(533, 0, 1, 38, 0),
(532, 0, 7, 37, 0),
(531, 0, 6, 37, 0),
(530, 0, 5, 37, 0),
(529, 0, 3, 37, 1),
(528, 0, 2, 37, 1),
(527, 0, 1, 37, 0),
(520, 0, 7, 35, 0),
(519, 0, 6, 35, 1),
(518, 0, 5, 35, 1),
(517, 0, 3, 35, 1),
(516, 0, 2, 35, 1),
(515, 0, 1, 35, 1),
(514, 0, 7, 34, 0),
(513, 0, 6, 34, 1),
(512, 0, 5, 34, 1),
(511, 0, 3, 34, 1),
(510, 0, 2, 34, 1),
(509, 0, 1, 34, 1),
(538, 0, 7, 38, 0),
(550, 0, 7, 40, 0),
(549, 0, 6, 40, 0),
(548, 0, 5, 40, 0),
(547, 0, 3, 40, 1),
(546, 0, 2, 40, 1),
(545, 0, 1, 40, 0),
(551, 0, 1, 41, 0),
(552, 0, 2, 41, 1),
(553, 0, 3, 41, 1),
(554, 0, 5, 41, 0),
(555, 0, 6, 41, 0),
(556, 0, 7, 41, 0),
(582, 0, 22, 21, 1),
(581, 0, 22, 24, 1),
(580, 0, 22, 17, 1),
(579, 0, 22, 22, 1),
(578, 0, 22, 31, 1),
(577, 0, 22, 41, 1),
(576, 0, 22, 7, 1),
(570, 0, 1, 42, 1),
(571, 0, 2, 42, 1),
(572, 0, 3, 42, 1),
(573, 0, 5, 42, 1),
(574, 0, 6, 42, 1),
(575, 0, 7, 42, 0),
(605, 0, 22, 34, 1),
(606, 0, 1, 43, 0),
(607, 0, 2, 43, 1),
(608, 0, 3, 43, 1),
(609, 0, 5, 43, 0),
(610, 0, 6, 43, 0),
(611, 0, 7, 43, 0),
(612, 0, 22, 43, 0),
(613, 0, 1, 44, 0),
(614, 0, 2, 44, 1),
(615, 0, 3, 44, 1),
(616, 0, 5, 44, 0),
(617, 0, 6, 44, 0),
(618, 0, 7, 44, 0),
(619, 0, 22, 44, 0),
(620, 0, 1, 45, 0),
(621, 0, 2, 45, 1),
(622, 0, 3, 45, 1),
(623, 0, 5, 45, 0),
(624, 0, 6, 45, 0),
(625, 0, 7, 45, 0),
(626, 0, 22, 45, 0),
(627, 0, 1, 46, 0),
(628, 0, 2, 46, 1),
(629, 0, 3, 46, 1),
(630, 0, 5, 46, 0),
(631, 0, 6, 46, 0),
(632, 0, 7, 46, 0),
(633, 0, 22, 46, 0),
(634, 0, 1, 47, 0),
(635, 0, 2, 47, 1),
(636, 0, 3, 47, 1),
(637, 0, 5, 47, 0),
(638, 0, 6, 47, 0),
(639, 0, 7, 47, 0),
(640, 0, 22, 47, 0),
(641, 0, 1, 48, 0),
(642, 0, 2, 48, 1),
(643, 0, 3, 48, 1),
(644, 0, 5, 48, 0),
(645, 0, 6, 48, 0),
(646, 0, 7, 48, 0),
(647, 0, 22, 48, 0),
(648, 0, 1, 49, 0),
(649, 0, 2, 49, 1),
(650, 0, 3, 49, 0),
(651, 0, 5, 49, 0),
(652, 0, 6, 49, 0),
(653, 0, 7, 49, 0),
(654, 0, 22, 49, 0),
(655, 0, 1, 50, 0),
(656, 0, 2, 50, 1),
(657, 0, 3, 50, 1),
(658, 0, 5, 50, 0),
(659, 0, 6, 50, 0),
(660, 0, 7, 50, 0),
(661, 0, 22, 50, 0);

CREATE TABLE `#ZEPRE#_permission_groups` (
  `pg_id` int(11) NOT NULL,
  `pg_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_permission_groups` (`pg_id`, `pg_name`) VALUES
(1, 'Allgemein'),
(2, 'Administrativ'),
(5, 'Chatraum'),
(6, 'Moderation');

CREATE TABLE `#ZEPRE#_presents` (
  `pres_id` int(10) NOT NULL,
  `pres_sender_id` int(10) NOT NULL,
  `pres_getter_id` int(10) NOT NULL,
  `pres_date` int(10) NOT NULL,
  `pres_item` int(10) NOT NULL,
  `pres_text` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pres_state` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_profile_fields` (
  `prof_field_id` int(10) NOT NULL,
  `prof_field_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `prof_field_type` tinyint(1) NOT NULL,
  `prof_field_default_content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_profile_fields` (`prof_field_id`, `prof_field_name`, `prof_field_type`, `prof_field_default_content`) VALUES
(1, 'Test', 2, 'Nothing'),
(18, 'Wohnort', 2, 'Spremberg'),
(20, 'Beziehungsstatus', 3, 'Single#Uninteressiert#Verliebt#Vergeben#Verlobt#Verheiratet#Getrennt'),
(19, 'Land/Country', 3, 'Deutschland#Schweiz#Österreich'),
(21, 'Partner', 2, 'Niemand'),
(24, 'Raucher', 3, 'Ja#Nein'),
(23, 'Alkohol', 3, 'Ja#Nein#Gelegentlich');

CREATE TABLE `#ZEPRE#_profile_field_content` (
  `prof_content_fid` int(11) NOT NULL,
  `prof_content_field_id` int(10) NOT NULL,
  `prof_content_user_id` int(15) NOT NULL,
  `prof_content_field_content` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_quiz_league` (
  `ql_id` int(10) NOT NULL,
  `ql_user_id` int(10) NOT NULL,
  `ql_points_total` int(15) NOT NULL,
  `ql_current_points` int(15) NOT NULL,
  `ql_quiz_won` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_quiz_questions` (
  `qq_id` int(10) NOT NULL,
  `qq_topic` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `qq_question` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `qq_answer` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `qq_tipp` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `qq_points` int(10) NOT NULL DEFAULT '1',
  `qq_tipp_time` int(10) NOT NULL DEFAULT '60',
  `qq_time` int(10) NOT NULL DEFAULT '120'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_quiz_runtime` (
  `qr_id` int(1) NOT NULL DEFAULT '1',
  `qr_in_room` int(10) NOT NULL,
  `qr_question_count` int(10) NOT NULL,
  `qr_used_questions` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `qr_question_given` int(10) NOT NULL,
  `qr_question_given_at` int(15) NOT NULL,
  `qr_tipp_given` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_quiz_settings` (
  `qs_id` int(10) NOT NULL DEFAULT '1',
  `qs_questions` int(10) NOT NULL DEFAULT '10',
  `qs_room` int(10) NOT NULL,
  `qs_level_start` int(2) NOT NULL DEFAULT '80',
  `qs_level_use` int(2) NOT NULL DEFAULT '10',
  `qs_pot` int(10) NOT NULL DEFAULT '50',
  `qs_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_radio` (
  `id` int(11) NOT NULL,
  `stream_name` varchar(64) NOT NULL,
  `stream_type` int(5) NOT NULL,
  `stream_id` int(5) NOT NULL,
  `stream_host` varchar(32) NOT NULL,
  `stream_port` varchar(10) NOT NULL,
  `stream_pass` varchar(64) NOT NULL,
  `stream_codec` varchar(12) NOT NULL,
  `stream_show` int(5) NOT NULL,
  `stream_update` int(15) NOT NULL DEFAULT '0',
  `stream_dj` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stream_buy` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stream_genre` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `#ZEPRE#_ranks` (
  `ranks_id` int(10) NOT NULL,
  `ranks_order` int(11) NOT NULL,
  `ranks_title` varchar(32) NOT NULL,
  `ranks_icon` varchar(32) NOT NULL,
  `ranks_state` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_ranks` (`ranks_id`, `ranks_order`, `ranks_title`, `ranks_icon`, `ranks_state`) VALUES
(1, 1, 'Benutzer', '', 1),
(2, 5, 'Administrator', '46OciScyXaWaSURF.png', 0),
(3, 4, 'Moderator', 'cAUJbTMGhznlQcXZ.png', 0),
(4, 3, 'DJ', '7hb0a7VyBliVFWAT.png', 0),
(5, 2, 'Premium', 'KmUuOOOsTfLBp3FF.png', 0),
(6, 0, 'Gast', '30htwmVf8zoGBFtJ.png', 2);

CREATE TABLE `#ZEPRE#_rating` (
  `ra_id` int(11) NOT NULL,
  `ra_giver` int(11) NOT NULL,
  `ra_getter` int(11) NOT NULL,
  `ra_rating` int(11) NOT NULL,
  `ra_date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_report` (
  `rep_id` int(10) NOT NULL,
  `rep_user` int(10) NOT NULL,
  `rep_user_ip` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_target` int(10) NOT NULL,
  `rep_target_ip` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_date` int(10) NOT NULL,
  `rep_subject` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_inc` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_area_id_1` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_area_id_2` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_state` tinyint(1) NOT NULL,
  `rep_solved_date` int(10) NOT NULL,
  `rep_solved_by` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rep_solved_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_room` (
  `room_id` int(15) NOT NULL,
  `room_cat_id` int(10) NOT NULL,
  `room_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `room_topic` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `room_rules` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `room_show_rules` tinyint(1) NOT NULL,
  `room_welcome` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `room_visa_req_user_min_age` tinyint(2) NOT NULL DEFAULT '0',
  `room_visa_req_user_max_age` tinyint(2) NOT NULL DEFAULT '99',
  `room_state` tinyint(1) NOT NULL DEFAULT '0',
  `room_temp` tinyint(1) NOT NULL DEFAULT '1',
  `room_owner_id` int(15) NOT NULL DEFAULT '0',
  `room_pass` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `room_freeze_online_points` tinyint(1) NOT NULL DEFAULT '0',
  `room_log_switch` tinyint(1) NOT NULL DEFAULT '1',
  `room_opened_time` datetime NOT NULL,
  `room_bot` int(10) NOT NULL DEFAULT '0',
  `room_max` int(10) NOT NULL DEFAULT '0',
  `room_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000',
  `room_background` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ffffff',
  `room_image` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_room` (`room_id`, `room_cat_id`, `room_name`, `room_topic`, `room_rules`, `room_show_rules`, `room_welcome`, `room_visa_req_user_min_age`, `room_visa_req_user_max_age`, `room_state`, `room_temp`, `room_owner_id`, `room_pass`, `room_freeze_online_points`, `room_log_switch`, `room_opened_time`, `room_bot`, `room_max`, `room_color`, `room_background`, `room_image`) VALUES
(123, 1, 'Gastraum', 'Raum für Gäste und Benutzer zum munteren Chatten.', 'Gastraum. Keine Onlinepunkte für User. Respektvoller Umgang miteinander ist Pflicht.\r\n\r\nDies ist kein Supportchat!\r\n\r\nAUCH GÄSTE KÖNNEN GEBANT WERDEN!', 1, 'Willkommen im Gastraum [UNAME]! www.zevolutions.de', 0, 99, 0, 0, 1, '', 0, 1, '2015-06-29 12:00:00', 0, 0, 'b3a212', 'ffffff', ''),
(124, 2, 'Planung', 'Unter Ausschluss der Öffentlichkeit', 'Gibts nicht.', 0, 'Lass knacken!', 0, 99, 1, 0, 1, '', 0, 1, '2015-07-01 18:00:00', 0, 0, '362bff', '000000', ''),
(146, 1, 'Girlie Corner', 'Girlspower!', 'Immer schön funkelig bleiben! Männer? Muss nicht sein!', 1, 'Willkommen [UNAME] im Hafen der Weiblichkeit!', 0, 99, 0, 0, 1, '', 0, 0, '2016-03-03 17:34:54', 0, 0, 'f05694', 'ffffff', ''),
(145, 1, 'Dark Place', 'Bisschen dunkler - perfekt für die Abendstunden!', 'Respektvoller Umgang miteinander ist Pflicht.\r\n\r\nDies ist kein Supportchat!\r\n\r\nAUCH GÄSTE KÖNNEN GEBANT WERDEN!', 1, 'Willkommen im Dark Place, [UNAME]!', 15, 50, 0, 0, 1, '', 0, 0, '2016-03-03 16:45:55', 0, 20, 'ff0000', '000000', '');

CREATE TABLE `#ZEPRE#_room_allow` (
  `ra_id` int(15) NOT NULL,
  `ra_group` int(15) NOT NULL,
  `ra_room` int(15) NOT NULL,
  `ra_state` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_room_log` (
  `rlog_id` int(15) NOT NULL,
  `rlog_room_id` int(15) NOT NULL,
  `rlog_opener_id` int(15) NOT NULL,
  `rlog_room_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rlog_cat_id` int(10) NOT NULL,
  `rlog_opened` datetime NOT NULL,
  `rlog_closed` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_session` (
  `sess_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sess_user_id` int(10) NOT NULL,
  `sess_acc_id` int(10) NOT NULL,
  `sess_logged_in` datetime NOT NULL,
  `sess_in_ac` tinyint(1) NOT NULL DEFAULT '1',
  `sess_online_status` tinyint(1) NOT NULL DEFAULT '1',
  `sess_status` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sess_user_level` tinyint(2) NOT NULL,
  `sess_last_message_id` int(20) NOT NULL,
  `sess_last_message_got` int(15) NOT NULL,
  `sess_last_sent_message_time` datetime NOT NULL,
  `sess_ping` datetime NOT NULL,
  `sess_user_ip` varchar(39) NOT NULL,
  `sess_user_browser` varchar(20) NOT NULL,
  `sess_user_os` varchar(20) NOT NULL,
  `sess_tf_switch` tinyint(1) NOT NULL,
  `sess_clock_switch` tinyint(1) NOT NULL DEFAULT '1',
  `sess_design_switch` varchar(32) NOT NULL,
  `sess_smilie_switch` tinyint(4) NOT NULL,
  `sess_mute_switch` int(12) NOT NULL,
  `sess_smilie_set` int(10) NOT NULL DEFAULT '1',
  `sess_invites` int(10) NOT NULL,
  `sess_confusion` int(12) NOT NULL,
  `sess_update` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_session_room` (
  `sr_id` int(10) NOT NULL,
  `sr_sid` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sr_uid` int(10) NOT NULL,
  `sr_uname` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sr_rid` int(10) NOT NULL,
  `sr_owner` tinyint(1) NOT NULL,
  `sr_forced` tinyint(1) NOT NULL,
  `sr_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sr_gender` int(1) NOT NULL,
  `sr_level` int(10) NOT NULL,
  `sr_ostatus` int(1) NOT NULL,
  `sr_status` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sr_conf` int(12) NOT NULL,
  `sr_ava` varchar(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sr_usk` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_settings` (
  `sett_id` tinyint(1) NOT NULL DEFAULT '1',
  `sett_chat_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sett_chat_admin` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sett_chat_admin_mail` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sett_chat_url` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sett_chat_register_switch` tinyint(1) NOT NULL,
  `sett_chat_single_room` int(10) NOT NULL DEFAULT '0',
  `sett_chat_open` tinyint(1) NOT NULL DEFAULT '1',
  `sett_chat_allow_guest` tinyint(1) NOT NULL,
  `sett_chat_default_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000',
  `sett_chat_system_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000',
  `sett_chat_system_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'System',
  `sett_chat_message_wait` int(1) NOT NULL DEFAULT '1',
  `sett_chat_total_coins` int(10) NOT NULL,
  `sett_chat_version` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sett_chat_timeout` int(3) NOT NULL DEFAULT '42',
  `sett_chat_debug` tinyint(1) NOT NULL DEFAULT '0',
  `sett_chat_check_ava` tinyint(1) NOT NULL DEFAULT '1',
  `sett_chat_lottery_mode` tinyint(1) NOT NULL DEFAULT '1',
  `sett_min_age` tinyint(2) NOT NULL DEFAULT '0',
  `sett_min_name_length` tinyint(1) NOT NULL DEFAULT '3',
  `sett_min_message_length` tinyint(10) NOT NULL DEFAULT '1',
  `sett_min_message_time` tinyint(2) NOT NULL DEFAULT '5',
  `sett_default_design` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `sett_limit_newusers` tinyint(2) DEFAULT NULL,
  `sett_reg_mod` tinyint(1) NOT NULL DEFAULT '1',
  `sett_daily_coins` int(11) NOT NULL DEFAULT '50'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



INSERT INTO `#ZEPRE#_settings` (`sett_id`, `sett_chat_name`, `sett_chat_admin`, `sett_chat_admin_mail`, `sett_chat_url`, `sett_chat_register_switch`, `sett_chat_single_room`, `sett_chat_open`, `sett_chat_allow_guest`, `sett_chat_default_color`, `sett_chat_system_color`, `sett_chat_system_name`, `sett_chat_message_wait`, `sett_chat_total_coins`, `sett_chat_version`, `sett_chat_timeout`, `sett_chat_debug`, `sett_chat_check_ava`, `sett_chat_lottery_mode`, `sett_min_age`, `sett_min_name_length`, `sett_min_message_length`, `sett_min_message_time`, `sett_default_design`, `sett_limit_newusers`, `sett_reg_mod`, `sett_daily_coins`) VALUES
(1, 'Zephyr', 'Zion', 'admin@zevolutions.de', 'http://zephyr.zevolutions.de', 1, 0, 1, 1, '1f91cf', 'b3a212', 'System', 3, 0, '08020917', 42, 0, 1, 1, 14, 3, 1, 5, 'default', 0, 1, 25);

CREATE TABLE `#ZEPRE#_smilies` (
  `smi_id` int(10) NOT NULL,
  `smi_order` int(10) NOT NULL,
  `smi_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `smi_sc` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `smi_pic` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `smi_cat` int(11) NOT NULL,
  `smi_usk` tinyint(2) NOT NULL DEFAULT '0',
  `smi_lvl` int(10) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_smilies` (`smi_id`, `smi_order`, `smi_name`, `smi_sc`, `smi_pic`, `smi_cat`, `smi_usk`, `smi_lvl`) VALUES
(132, 3, '2 Uhr', ';02', 'GaT0uTpTnMpqfHyy.png', 10, 0, 1),
(131, 4, 'Verliebt', ';inlove', 'Ndr0VOH0FdE1b6iE.png', 9, 0, 0),
(152, 15, 'Breites Grinsen', ';breitgrins', 'EkpyPvF6ILt6vUQD.png', 9, 0, 0),
(130, 2, '1 Uhr', ';01', 'KC9teGXDH2NZeZr5.png', 10, 0, 1),
(129, 3, 'Zufrieden', ';satisfied', 'Nyh7g3UYHAJy8HIQ.png', 9, 0, 0),
(126, 1, 'Verlegen', ':$', 'iBwjJYZfNdZKC8yy.png', 9, 0, 0),
(153, 16, 'Weinen 1', ';-(', 'W05sgQBSvj0vYgdS.png', 9, 0, 0),
(128, 1, '12 Uhr', ';12', '6h8fFdzoRSyv5jep.png', 10, 0, 1),
(133, 4, '3 Uhr', ';03', '2gqqo6Mmfdh3d2vB.png', 10, 0, 1),
(134, 5, 'Cool', ';cool', '6U10qUFY7ktWc6SP.png', 9, 0, 0),
(135, 5, '4 Uhr', ';04', 'In4FyP9K80YHZyJR.png', 10, 0, 1),
(136, 6, '5 Uhr', ';05', 'U1ygOeTDMiQ7j89M.png', 10, 0, 1),
(137, 6, 'Schelmisch', ':]', 'jjAIwQmIP3vMy7iE.png', 9, 0, 0),
(138, 7, '6 Uhr', ';06', 'ZuN2bSGhHG7JY84e.png', 10, 0, 1),
(139, 7, 'Küssen 1', ':*', 'Qx4nvnyeTWvPql5z.png', 9, 0, 0),
(140, 8, '7 Uhr', ';07', 'tdsBoPXn2wXUG6rV.png', 10, 0, 1),
(141, 8, 'Frech 1', ':P', 'pOSQNujQUL8zXVUm.png', 9, 0, 0),
(142, 9, '8 Uhr', ';08', 'APlFsSLf3HAAbgsV.png', 10, 0, 1),
(143, 10, '9 Uhr', ';09', 'Gn3SV6fc2KfM2oTZ.png', 10, 0, 1),
(144, 11, '10 Uhr', ';10', '9fq9crCCtcSOHVqb.png', 10, 0, 1),
(145, 9, 'Frech 2', ';P', 'X2s4nCGhzr0e3Z0n.png', 9, 0, 0),
(146, 12, '11 Uhr', ';11', 'sN5VAVd714fKmJIJ.png', 10, 0, 1),
(147, 10, 'Frech 3', 'xP', 'ywVFhUTzstHmWCJI.png', 9, 0, 0),
(148, 11, 'Müde', ';sleepy', 'vv3rZmBM4nT724GB.png', 9, 0, 0),
(149, 12, 'Bestürzt', ';o', 'MiLyJtMghUdLk3YW.png', 9, 0, 0),
(150, 13, 'Traurig 1', ';sad1', 'pKVcCk0NpPejmjxH.png', 9, 0, 0),
(151, 14, 'Verzweifelt 1', ';desperate1', 'FTu52os5ABR5ERRe.png', 9, 0, 0),
(154, 17, 'Überrascht 1', ';suprised1', 'pQlT11AGUcs3xULr.png', 9, 0, 0),
(155, 18, 'Erstaunt', ';amazed', 'omf8nEuVhkLIfQPi.png', 9, 0, 0),
(156, 19, 'Lachen 1', ':)', 'mCGr752MmjlwS5BJ.png', 9, 0, 0),
(157, 20, 'Lachen 2', ';D', '2dwJ5dW0mzWW2clU.png', 9, 0, 0),
(158, 21, 'Lachen 3', ';laugh3', 'Ahk6wbDWkigDFhpI.png', 9, 0, 0),
(159, 22, 'Lachen 4', ':D', 'uiSH8XMooev9zWxA.png', 9, 0, 0),
(160, 23, 'Lachen 5', ';laugh5', '9S7veFguSQuDrlGR.png', 9, 0, 0),
(161, 24, 'Lachen 6', ';laugh6', 't1m54k2141vv6I9w.png', 9, 0, 0),
(162, 25, 'Engelchen', ';angel', 'dRr477VUFAr7kte5.png', 9, 0, 0),
(163, 26, 'Teufelchen', ';devil', 'Lgx8fqr5J6Pf7b66.png', 9, 0, 0),
(164, 27, 'Zwinkern', ';)', 'wFmAnceknoXEWhXc.png', 9, 0, 0),
(165, 28, 'Höh?', ';bla', 'p2kW0uTXpaBRvNJG.png', 9, 0, 0),
(166, 29, 'ClosedEyes', ';closedeyes', 'y3muTZQKiJRqrkO9.png', 9, 0, 0),
(167, 30, 'Unzufrieden', ';unamused', 'aYXkPLpVkzQoIGPH.png', 9, 0, 0),
(168, 31, 'Verzweifelt 2', ';desperate2', 'F1mKKTnln7x4q0Hf.png', 9, 0, 0),
(169, 1, 'Krokodil', ';croco', 'fjtw7N5i6ODA6Ijg.png', 11, 0, 1),
(170, 32, 'Verzweifelt 3', ';desperate3', '8h6JxaMAXar4Fpkz.png', 9, 0, 0),
(171, 2, 'Wal', ';whale', 'ki7glymYmqnPWTBN.png', 11, 0, 1),
(172, 3, 'Schnecke', ';snail', '0e6CDs4yRG7CxtJp.png', 11, 0, 1),
(173, 4, 'Schlange', ';snake', '0OmYr80BQRc0cSJj.png', 11, 0, 1),
(174, 33, 'Traurig 2', ';sad2', 'LkjRVE63XAdWViW1.png', 9, 0, 0),
(175, 5, 'Pferd', ';horse', 'lQedo1TsJGxJJCt4.png', 11, 0, 1),
(176, 34, 'Sauer 4', ';sadsour', 'lh7VIjFqja4NPpH6.png', 9, 0, 0),
(177, 35, 'Küssen 2', ';kiss2', 'qzBmU2eeD0GVv3PS.png', 9, 0, 0),
(178, 6, 'Schaf', ';sheep', 'I5at65fBuz2fzbdz.png', 11, 0, 1),
(179, 7, 'Raupe', ';worm', 'usGxO6oXmd0E7jO2.png', 11, 0, 1),
(180, 36, 'Küssen 3', ';kiss3', 'IodLMdnJimBvUhKl.png', 9, 0, 0),
(181, 8, 'Ameise', ';ant', 'lEUikfTdIuppDu96.png', 11, 0, 1),
(182, 9, 'Biene', ';bee', 'Fj3zaNefR1eitBkK.png', 11, 0, 1),
(183, 37, 'Küssen 4', ';kiss4', 'n0ftbs7PNhmk2FXf.png', 9, 0, 0),
(184, 10, 'Marienkäfer', ';ladybug', 'Lgd6xpWL61IBKqMG.png', 11, 0, 1),
(185, 11, 'Fisch', ';fish', 'WuqtoTq8oFTw5R39.png', 11, 0, 1),
(186, 38, 'Sauer 1', ';grumpy1', 'sXkMI70XD1CMERsN.png', 9, 0, 0),
(187, 12, 'Delphin', ';dolphin', 'x5jQjvHyJXfUyeEU.png', 11, 0, 1),
(188, 39, 'Sauer 2', ';sauer2', '72KUYJqUppYybSe1.png', 9, 0, 0),
(189, 13, 'Maus', ';mouse', 'r8C9oB8ykVjipkQH.png', 11, 0, 1),
(190, 40, 'Weinen 2', ';weinen2', 'KSAmWE6b5lzVXONd.png', 9, 0, 0),
(192, 41, 'Verzweifelt 4', ';desperate4', 'kovHvoa3Xn3Nuzr8.png', 9, 0, 0),
(193, 42, 'Sauer 3', ';sauer3', 'FJi76OtTSInoqDxt.png', 9, 0, 0),
(194, 43, 'Weinen 3', ';weinen3', 'CY3hzjXtDNw0nqEz.png', 9, 0, 0),
(195, 15, 'Tigergesicht', ';ftiger', '1w7YZ9DwMzwuIhmU.png', 11, 0, 1),
(196, 16, 'Hund', ';dog', 'l6eSQMSYfQSkdbUO.png', 11, 0, 1),
(197, 44, 'Weinen 4', ';weinen4', 'ui1LAV4nHW94cPtm.png', 9, 0, 0),
(198, 17, 'Bär', ';bear', '5qqiCQW4t6WXTGUT.png', 11, 0, 1),
(199, 18, 'Panda', ';panda', 'gyoQSRzMrghffvfJ.png', 11, 0, 1),
(200, 19, 'Bulle', ';bull', 'YeT0kcdj6fQSDWc2.png', 11, 0, 1),
(201, 45, 'Küssen 5', ';küssen5', 'VTi5RkaBe2SBSxc3.png', 9, 0, 0),
(202, 20, 'Kuh', ';cow', '8JaXwND5GCch2kSD.png', 11, 0, 1),
(203, 46, 'Überrascht 2', ';surprised2', 'IreNcHIrT0PZHnNP.png', 9, 0, 0),
(204, 21, 'Tiger', ';tiger', '2iuyC0rjH8QpXlbo.png', 11, 0, 1),
(205, 22, 'Gepard', ';gepard', 'i48RfeHTTpaQc09g.png', 11, 0, 1),
(206, 47, 'Jammern', ';yammer', 'j0qkiZ3VFjUp9w7M.png', 9, 0, 0),
(207, 23, 'Hase', ';rabbit', 'GnNQ39prbbrTu9na.png', 11, 0, 1),
(208, 48, 'Schlafen', ';sleep', 'J68OdWEYnr6lkbWM.png', 9, 0, 0),
(209, 49, 'Erschrocken', ';scared', 'mCQrh4wUvq6RNTym.png', 9, 0, 0),
(210, 50, 'Tot 1', ';dead1', 'dss67R2B3swLSI2j.png', 9, 0, 0),
(211, 24, 'Seeschlange', ';seadrake', '1qzK6Izjvfmlhzu6.png', 11, 0, 1),
(212, 51, 'Tot 2', ';dead2', 'ogr1is3NrGyQ4SRz.png', 9, 0, 0),
(213, 25, 'Ziege', ';goat', '43dJDgcHlv4J4Dik.png', 11, 0, 1),
(214, 52, 'Sprachlos', ';spechless', 'VP5eytb9bso3GmGk.png', 9, 0, 0),
(215, 26, 'Affe', ';ape', 'CfTbxaC0EyRZVdj0.png', 11, 0, 1),
(216, 1, 'Grünes Herz', ';greenheart', 'rXDU6PP2OEBiSUyr.png', 12, 0, 1),
(217, 27, 'Huhn', ';chicken', 'tI1QSMyqI4skAMzl.png', 11, 0, 1),
(218, 2, 'Gelbes Herz', ';yellowheart', 'X9c8T5M3YL2Q2iBC.png', 12, 0, 1),
(219, 28, 'Hühnergesicht', ';fchicken', 'bDEfskgB7jJPhAab.png', 11, 0, 1),
(220, 3, 'Lila Herz', ';purpleheart', 'mCpoIUnfWqdYUHnf.png', 12, 0, 1),
(221, 29, 'Schwein', ';pig', 'RqggJ8foVyO9otFw.png', 11, 0, 1),
(222, 30, 'Schweinegesicht', ';fpig', 'xdAlwJQ0gl4GckXG.png', 11, 0, 1),
(223, 4, 'Doppelherz', ';doubleheart', 'QgyW3GmINzoIad3x.png', 12, 0, 1),
(224, 31, 'Elefant', ';elephant', 'b5D7YjWzhq27HZyE.png', 11, 0, 1),
(225, 5, 'Herzchen-Geschenk', ';presentheart', 'BH0onTkJ5x29dx02.png', 12, 0, 1),
(226, 32, 'Tintenfisch', ';squid', 'UY6XxKCHfxKJ2DaS.png', 11, 0, 1),
(227, 33, 'Schildkröte', ';turtle', 'xNmhdnL8VU17Narb.png', 11, 0, 1),
(228, 6, 'Gebrochenes Herz', ';brokenheart', 'c81Jxnb0HNhqFXuU.png', 12, 0, 1),
(229, 34, 'Küken 1', ';chick1', 'Z0ozL2kWI9AHPtQR.png', 11, 0, 1),
(230, 7, 'Armor', ';armor', 'v3wQTmtqBROh2aRb.png', 12, 0, 1),
(231, 8, 'Küken 2', ';chick2', 'vdppG38B5BO5BAZi.png', 11, 0, 1),
(232, 35, 'Küken 3', ';chick3', 'hP4ZHNvaWtmFo3WE.png', 11, 0, 1),
(233, 8, 'Blaues Herz', ';blueheart', 'uFabZAUAAgrE0DM9.png', 12, 0, 1),
(234, 36, 'Vogel', ';bird', '02N6wXIMqhO9iVjF.png', 11, 0, 1),
(235, 9, 'Beating Heart', ';heartbeats', '9itbLEngcwTLdLjG.png', 12, 0, 1),
(236, 37, 'Pinguin', ';penguin', '64xtr3EvHrQH3Jz9.png', 11, 0, 1),
(237, 38, 'Koala', ';coala', 'xJHWa39KP7gHZOeT.png', 11, 0, 1),
(238, 10, 'Funkelherz', ';funkyheart', 'b7ZSjmJLHok2dSSQ.png', 12, 0, 1),
(239, 39, 'Hasengesicht', ';frabbit', 'TsPmsysPybFI67t5.png', 11, 0, 1),
(240, 40, 'Katze', ';cat', '7U5fqRmb3bfHmOR6.png', 11, 0, 1),
(241, 41, 'Wal 2', ';purplewhale', '1iIdyyUoIhtQmqee.png', 11, 0, 1),
(242, 42, 'Frosch', ';frog', 'BiMeOPJenFRyW4su.png', 11, 0, 1),
(243, 43, 'Mausgesicht', ';fmouse', '2zz3sR7OMsQfHtX2.png', 11, 0, 1),
(244, 1, 'Singen', ';sing', 'S0M5GZSwSniOjpnF.png', 13, 0, 1),
(245, 2, 'Zylinder', ';zylinder', 'ZtuzLOMjj7R9BSSN.png', 13, 0, 1),
(246, 3, 'Zocken', ';controller', 'bJaZ5AV6PEcBt4Np.png', 13, 0, 1),
(247, 4, 'Glücksspiel', ';gambling', 'sivDOW2kuQGnDCRr.png', 13, 0, 1),
(248, 1, 'Orange', ';orange', 'YaLw0AQarollKT60.png', 14, 0, 1),
(249, 2, 'Zitrone', ';lemon', 'T1bebYFJPt9VWdnb.png', 14, 0, 1),
(250, 5, 'Billiard', ';billiard', 'Izjhfdc9L4dwREm1.png', 13, 0, 1),
(251, 3, 'Banane', ';banana', '5xO5zYYbvrhphow6.png', 14, 0, 1),
(252, 4, 'Ananas', ';pineapple', 'OFQPGvjPCjR3gvB2.png', 14, 0, 1),
(253, 6, 'Würfel', ';dice', 'Ed38hp9ju1dFNKIX.png', 13, 0, 1),
(254, 5, 'Roter Apfel', ';redapple', 'Vt34N595Yip2NpIe.png', 14, 0, 1),
(255, 7, 'Musik 1', ';music1', 'UrMuftyMlrGNoRxE.png', 13, 0, 1),
(256, 6, 'Grüner Apfel', ';greenapple', 'm26HuYeqznmVD55l.png', 14, 0, 1),
(257, 7, 'Reis', ';rice', 'OqInsC4IpNGSIDgQ.png', 14, 0, 1),
(258, 8, 'Reiscurry', ';curryrice', 'hebj012GCzvI8RDS.png', 14, 0, 1),
(259, 9, 'Ramen', ';ramen', 'NbOVyhVH45kt7p1Y.png', 14, 0, 1),
(260, 10, 'Spaghetti', ';spaghetti', 'kQQ4PoeDu5XdgbVy.png', 14, 0, 1),
(261, 11, 'Brot', ';bread', '26uU8iywslYGxgPW.png', 14, 0, 1),
(262, 8, 'Musik 2', ';music2', 'o5vKAtjaWcHOlpYR.png', 13, 0, 1),
(263, 12, 'Pommes', ';fries', 'dwun9MNHKM0DxVzS.png', 14, 0, 1),
(264, 13, 'Keks', ';cookie', 'AaXsERm0T1wrtTnm.png', 14, 0, 1),
(265, 9, 'Saxophon', ';saxophon', 'DDGis7wLvQjqse7r.png', 13, 0, 1),
(266, 14, 'Schokolade', ';chocolate', 'aM75wbMyRvjVKxCP.png', 14, 0, 1),
(267, 10, 'Gitarre', ';guitar', 'ESrgrpohSoa8f8Re.png', 13, 0, 1),
(268, 11, 'Klavier', ';piano', 'i7LgNtjKMN2bFLHK.png', 13, 0, 1),
(269, 15, 'Bonbon', ';candy', 'qn9sNetQUYmb4XVA.png', 14, 0, 1),
(270, 16, 'Lolli', ';lolly', 'D8JxSph1j2sFk7oP.png', 14, 0, 1),
(271, 12, 'Trompete', ';trumpet', 'Qahpfe8brQfGGhb3.png', 13, 0, 1),
(272, 17, 'Honig', ';honey', 'XI9V2xuahI3lQzHf.png', 14, 0, 1),
(273, 13, 'Cello', ';cello', 'c3tq5ROgg8n3kqQd.png', 13, 0, 1),
(274, 18, 'Bier', ';beer', 'gLwrwp6FcvQLvowW.png', 14, 0, 1),
(275, 19, 'Zwei Bier', ';twobeer', 'NtG7oMbGpjaCIb9b.png', 14, 0, 1),
(276, 14, 'Pokal', ';cup', 'DT8Aim7OVUpP5OVZ.png', 13, 0, 1),
(277, 20, 'Babyflasche', ';babymilk', 'vdGreB4d4eZbRVQi.png', 14, 0, 1),
(278, 15, 'Haus', ';house', 'nX1hXImYewjbM8JQ.png', 13, 0, 1),
(279, 21, 'Pilz', ';mushroom', 'O5jyE2SKSuVC8WKZ.png', 14, 0, 1),
(280, 22, 'Tomate', ';tomato', '8KIbcF51rXSnEm40.png', 14, 0, 1),
(281, 23, 'Trauben', ';grapes', 'DlJ5qdo4qmnS8R5L.png', 14, 0, 1),
(282, 16, 'Hochhaus', ';skyscraper', 'RoMLbQwlmhFcWDl9.png', 13, 0, 1),
(283, 24, 'Melone', ';melon', 'Y5GwAHwQaW63JNfu.png', 14, 0, 1),
(284, 17, 'Schloss', ';castle', '9DIqBsoVjUdq2kde.png', 13, 0, 1),
(285, 25, 'Melonenschnitz', ';slicedmelon', 'lrIg4ysWTvmeQ4KH.png', 14, 0, 1),
(286, 18, 'Bombe', ';bomb', '2grUjQpGoX2kt0QR.png', 13, 0, 1),
(287, 26, 'Birne', ';pear', 'oLqOPjwwXWMAM8pj.png', 14, 0, 1),
(288, 27, 'Pfirsich', ';peach', 'K3OtuC6paZ4apDb6.png', 14, 0, 1),
(289, 19, 'Boom!', ';boom', 'UHlUZhB52fOLiTGT.png', 13, 0, 1),
(290, 28, 'Kirsche', ';cherry', 'n4frSzJre33oN7mx.png', 14, 0, 1),
(291, 29, 'Erdbeere', ';strawberry', 'sXcYyk8nxqEBdcXi.png', 14, 0, 1),
(292, 20, 'Lächelnder Kackhaufen', ';poo', 'Cy6KEECGqm0Wzik9.png', 13, 0, 1),
(293, 30, 'Burger', ';burger', 'wiy69UvR4f7Ppp3S.png', 14, 0, 1),
(294, 31, 'Pizza', ';pizza', 'wzguE4jrGCABNYvL.png', 14, 0, 1),
(295, 32, 'Eisbein', ';meat', 'E1jbOl8HVe7CbxHh.png', 14, 0, 1),
(296, 21, 'Muskeln', ';muscle', '908HHqI1aflfxlku.png', 13, 0, 1),
(297, 33, 'Hähnchenkeule', ';chickendrums', 'kdwwINyNoib97hBN.png', 14, 0, 1),
(298, 22, 'Gedankenblase', ';think', 'CNzyWifJ9t5RVCvn.png', 13, 0, 1),
(299, 34, 'Sushi', ';sushi', 'rjmkC92x0V1ed0Uw.png', 14, 0, 1),
(300, 23, 'Koffer', ';bag', 'ujOEUG1uu2cvTBdO.png', 13, 0, 1),
(301, 35, 'Schrimp', ';shrimp', 'kXjuPVyg7yiVwcqG.png', 14, 0, 0),
(302, 36, 'Eiswaffel', ';ice1', 'ATUAeUHjXCihhqad.png', 14, 0, 1),
(303, 37, 'Erdbeereis', ';ice2', 'UupUsUplRpjuxfTD.png', 14, 0, 1),
(304, 24, 'Büroklammer', ';paperclip', 'UOp4KMVQzM78jFnO.png', 13, 0, 1),
(305, 38, 'Eiskugeln', ';ice3', 'sIxFuRIk37TLaiJ8.png', 14, 0, 1),
(306, 39, 'Donut', ';donut', 'oMFCF4lVnMV7VkkL.png', 14, 0, 1),
(307, 40, 'Kuchenstück', ';cake', '1I8KFgrL8Mkde3Nl.png', 14, 0, 1),
(308, 25, 'Ampel', ';trafficlight', 'XskYggKfBFWfgdgP.png', 13, 0, 1),
(309, 41, 'Eintopf', ';stew', 'KxTbHaX5ZAheluSC.png', 14, 0, 1),
(310, 42, 'Spiegelei', ';friedegg', '2yZmXv2IlcuaKVFR.png', 14, 0, 1),
(311, 43, 'Besteck', ';fork', 'wp3Kw0fl5HXtUIZC.png', 14, 0, 1),
(312, 44, 'Erbsensuppe', ';peasoup', 'sWpAwbsDcBudxb1Y.png', 14, 0, 1),
(313, 26, 'Verboten!', ';forbidden', '4Ty8HjOzdQv9CcJR.png', 13, 0, 1),
(314, 45, 'Sake', ';sake', 'f98jyA1BDwOlGZDe.png', 14, 0, 1),
(315, 46, 'Wein', ';wine', 'DNHxLrLnhhRs3KnH.png', 14, 0, 1),
(316, 27, 'Rauchen erlaubt :)', ';smoking', 'DlKDpn98F3Lctm3Z.png', 13, 0, 1),
(317, 47, 'Martini', ';martini', 'q7JS4EYurKaMRxbH.png', 14, 0, 1),
(318, 28, 'Rauchen verboten :(', ';notsmoking', 'EKqcBMGgInDM78qE.png', 13, 0, 1),
(319, 48, 'Cocktail', ';cocktail', 'rvJPnCgAu7pc9E5F.png', 14, 0, 1),
(320, 29, 'Alien', ';alien', 'jJ2guRG47khRZOUX.png', 13, 0, 1),
(321, 49, 'Geburtstagskuchen', ';birthdaycake', 'KJmPzW0MgONiDHHl.png', 14, 0, 1),
(322, 50, 'Tee', ';tea', '7LNyaFiVYyG2Jwjt.png', 14, 0, 1),
(323, 30, 'Liebesbrief', ';loveletter', 'fFhVtF8w2spgRsiz.png', 13, 0, 1),
(324, 31, 'USK', ';usk', 'sYUbr86ZdFMSdpQY.png', 13, 0, 1),
(325, 32, 'Geschenk', ';present', 'fRooqD8iSFVndr01.png', 13, 0, 1),
(326, 51, 'Feuerwerk1', ';firework1', '9RtPePHPP7WBNXbD.png', 13, 0, 1),
(327, 52, 'Feuerwerk2', ';firework2', 'shCHCRatb7S1HNr8.png', 13, 0, 1),
(328, 33, 'Luftballon', ';ballon', 'fbft4BIFQnqkWwiy.png', 13, 0, 1),
(329, 53, 'Party!', ';party', '1094LwXKsHtKEcDC.png', 13, 0, 1),
(330, 34, 'Krone', ';crown', 's7JEiyfTAFsOwxIx.png', 13, 0, 1),
(331, 35, 'Unterwäsche/Bikini', ';underwear', 'uLSR8hfP1tbdY2dH.png', 13, 0, 1),
(332, 36, 'Krampus', ';krampus', 'iCAdPLx5QjYFs3qB.png', 13, 0, 1),
(333, 54, 'Totenkopf', ';skull', '9F2k8bNdIr5dDhAy.png', 13, 0, 1),
(334, 55, 'Ton aus!', ';silence', 'OgkJpKoBLK9kDKMM.png', 13, 0, 1),
(335, 56, 'Hammer', ';hammer', 'Us2tmgUrgOwmyFMr.png', 13, 0, 1),
(336, 37, 'Stundenglas', ';hourglass', 'VOeO3X2WOeCFrVwx.png', 13, 0, 1),
(337, 57, 'Stop!', ';stop', 'p1zuHq4AbdiDAmhL.png', 13, 0, 1),
(338, 58, 'Pik', ';pik', '3Qu5HhKTOHU1sK8A.png', 13, 0, 1),
(339, 59, 'Kreuz', ';kreuz', 'MUIqpctj44IfObqE.png', 13, 0, 1),
(340, 38, 'Herz', '<3', 'zHzJ7jaLvn6KDXcK.png', 12, 0, 1),
(341, 39, 'Karo', ';karo', 'xIEgS87jndcl7MTs.png', 13, 0, 1),
(342, 40, 'Anker', ';anker', 'FKwevkbjxKl5DnOi.png', 13, 0, 1),
(343, 41, 'Sterne', ';stars', 'BmdWcHWmmeafU4xr.png', 13, 0, 1),
(344, 42, 'Schneeflocke 1', ';snowflake1', 'KRq8uK7giym7vTPw.png', 13, 0, 1),
(345, 43, 'Schneeflocke 2', ';snowflake2', 'vYC2yVomRUx2AaSU.png', 13, 0, 1);

CREATE TABLE `#ZEPRE#_smilies_category` (
  `sc_id` int(10) NOT NULL,
  `sc_order` int(10) NOT NULL,
  `sc_name` varchar(255) NOT NULL,
  `sc_usk` tinyint(2) NOT NULL DEFAULT '0',
  `sc_lvl` int(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `#ZEPRE#_smilies_category` (`sc_id`, `sc_order`, `sc_name`, `sc_usk`, `sc_lvl`) VALUES
(9, 0, 'Smilies', 0, 0),
(10, 0, 'Zeiten', 0, 1),
(11, 0, 'Tiere', 0, 1),
(12, 0, 'Herzen', 0, 1),
(13, 0, 'Sonstiges', 0, 1),
(14, 0, 'Essen und Trinken', 0, 1);

CREATE TABLE `#ZEPRE#_styles` (
  `style_id` int(10) NOT NULL,
  `style_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style_author` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style_comment` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style_folder` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style_version` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style_useownhtml` tinyint(1) NOT NULL,
  `style_useownsystemcolor` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style_minlvl` tinyint(2) NOT NULL,
  `style_minage` tinyint(2) NOT NULL,
  `style_forsale` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_teamspeak` (
  `id` int(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `query` varchar(64) NOT NULL,
  `admin` varchar(32) NOT NULL,
  `pass` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_user` (
  `user_id` int(10) NOT NULL,
  `user_acc_id` int(10) NOT NULL,
  `user_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_color` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_level` tinyint(2) NOT NULL DEFAULT '1',
  `user_level_orig` int(10) NOT NULL,
  `user_gender` tinyint(1) NOT NULL DEFAULT '0',
  `user_tf_switch` tinyint(1) NOT NULL DEFAULT '1',
  `user_clock_switch` tinyint(1) NOT NULL DEFAULT '1',
  `user_min_ava` tinyint(1) NOT NULL DEFAULT '1',
  `user_design_switch` varchar(32) NOT NULL DEFAULT 'default',
  `user_smilie_switch` tinyint(1) NOT NULL DEFAULT '1',
  `user_smilie_set` int(10) NOT NULL DEFAULT '1',
  `user_last_seen` datetime NOT NULL,
  `user_last_login` datetime NOT NULL,
  `user_created` datetime NOT NULL,
  `user_banned` tinyint(1) NOT NULL DEFAULT '0',
  `user_banned_to` int(15) NOT NULL,
  `user_to_delete` int(12) NOT NULL DEFAULT '0',
  `user_last_used_ip` varchar(39) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_online_points` int(15) NOT NULL DEFAULT '0',
  `user_online_points_total` int(15) NOT NULL,
  `user_mails` int(10) NOT NULL DEFAULT '0',
  `user_gbook` int(10) NOT NULL DEFAULT '0',
  `user_flist` int(10) NOT NULL DEFAULT '0',
  `user_presents` int(10) NOT NULL DEFAULT '0',
  `user_restricted_rooms` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `user_restricted_categorys` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `user_groups` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `user_age_switch` tinyint(1) NOT NULL DEFAULT '0',
  `user_mail_switch` tinyint(1) NOT NULL DEFAULT '0',
  `user_allow_mail` tinyint(1) NOT NULL DEFAULT '0',
  `user_allow_priv` tinyint(1) NOT NULL DEFAULT '0',
  `user_inform_priv` tinyint(1) NOT NULL DEFAULT '1',
  `user_allow_gb` tinyint(1) NOT NULL DEFAULT '0',
  `user_profile_public` tinyint(1) NOT NULL DEFAULT '1',
  `user_alias` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_usergroups` (
  `ug_id` int(10) NOT NULL,
  `ug_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ug_owner_id` int(10) NOT NULL,
  `ug_owner_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ug_level` tinyint(1) NOT NULL DEFAULT '1',
  `ug_topic` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ug_state` tinyint(2) NOT NULL,
  `ug_wallet` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_usergroups_avatar` (
  `ug_avatar_id` int(10) NOT NULL,
  `ug_group_id` int(10) NOT NULL,
  `ug_avatar_file` varchar(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_usergroups_members` (
  `ug_member_id` int(10) NOT NULL,
  `ug_group_id` int(10) NOT NULL,
  `ug_member_userid` int(10) NOT NULL,
  `ug_member_name` varchar(32) NOT NULL,
  `ug_member_ismod` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_usergroups_page` (
  `ug_page_id` int(10) NOT NULL,
  `ug_page_groupid` int(10) NOT NULL,
  `ug_page_theme` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ug_page_maincontent` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ug_page_stylefile` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `#ZEPRE#_wait` (
  `wait_id` int(10) NOT NULL,
  `wait_waiter` int(10) NOT NULL,
  `wait_waiting` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `#ZEPRE#_account`
  ADD PRIMARY KEY (`acc_id`);

ALTER TABLE `#ZEPRE#_avatar`
  ADD PRIMARY KEY (`ava_id`);

ALTER TABLE `#ZEPRE#_badwords`
  ADD PRIMARY KEY (`bad_id`);

ALTER TABLE `#ZEPRE#_bans`
  ADD PRIMARY KEY (`ban_id`);

ALTER TABLE `#ZEPRE#_blog`
  ADD PRIMARY KEY (`blog_id`);

ALTER TABLE `#ZEPRE#_blog_comments`
  ADD PRIMARY KEY (`bc_id`);

ALTER TABLE `#ZEPRE#_bots`
  ADD PRIMARY KEY (`bot_id`);

ALTER TABLE `#ZEPRE#_bot_answers`
  ADD PRIMARY KEY (`ba_id`);

ALTER TABLE `#ZEPRE#_category`
  ADD PRIMARY KEY (`cat_id`);

ALTER TABLE `#ZEPRE#_category_allow`
  ADD PRIMARY KEY (`cal_id`);

ALTER TABLE `#ZEPRE#_category_create`
  ADD PRIMARY KEY (`cac_id`);

ALTER TABLE `#ZEPRE#_colors`
  ADD PRIMARY KEY (`col_id`);

ALTER TABLE `#ZEPRE#_dice`
  ADD PRIMARY KEY (`dice_id`);

ALTER TABLE `#ZEPRE#_friendlist`
  ADD PRIMARY KEY (`fl_id`);

ALTER TABLE `#ZEPRE#_guestbook`
  ADD PRIMARY KEY (`gb_id`);

ALTER TABLE `#ZEPRE#_ignore`
  ADD PRIMARY KEY (`ig_id`);

ALTER TABLE `#ZEPRE#_inv`
  ADD PRIMARY KEY (`inv_id`);

ALTER TABLE `#ZEPRE#_item`
  ADD PRIMARY KEY (`item_id`);

ALTER TABLE `#ZEPRE#_item_cats`
  ADD PRIMARY KEY (`item_cats_id`);

ALTER TABLE `#ZEPRE#_lang`
  ADD PRIMARY KEY (`lang_id`);

ALTER TABLE `#ZEPRE#_lottery`
  ADD PRIMARY KEY (`lot_id`);

ALTER TABLE `#ZEPRE#_lottery_history`
  ADD PRIMARY KEY (`lh_id`);

ALTER TABLE `#ZEPRE#_lottery_settings`
  ADD UNIQUE KEY `lot_name` (`lot_name`);

ALTER TABLE `#ZEPRE#_mail`
  ADD PRIMARY KEY (`mail_id`);

ALTER TABLE `#ZEPRE#_message`
  ADD PRIMARY KEY (`mess_id`);

ALTER TABLE `#ZEPRE#_news`
  ADD PRIMARY KEY (`news_id`);

ALTER TABLE `#ZEPRE#_patch_history`
  ADD PRIMARY KEY (`patch_id`);

ALTER TABLE `#ZEPRE#_permission`
  ADD PRIMARY KEY (`perm_id`);

ALTER TABLE `#ZEPRE#_permissions`
  ADD PRIMARY KEY (`perm_id`);

ALTER TABLE `#ZEPRE#_permission_groups`
  ADD PRIMARY KEY (`pg_id`);

ALTER TABLE `#ZEPRE#_presents`
  ADD PRIMARY KEY (`pres_id`);

ALTER TABLE `#ZEPRE#_profile_fields`
  ADD PRIMARY KEY (`prof_field_id`);

ALTER TABLE `#ZEPRE#_profile_field_content`
  ADD PRIMARY KEY (`prof_content_fid`);

ALTER TABLE `#ZEPRE#_quiz_league`
  ADD PRIMARY KEY (`ql_id`);

ALTER TABLE `#ZEPRE#_quiz_questions`
  ADD PRIMARY KEY (`qq_id`);

ALTER TABLE `#ZEPRE#_quiz_runtime`
  ADD PRIMARY KEY (`qr_id`);

ALTER TABLE `#ZEPRE#_quiz_settings`
  ADD PRIMARY KEY (`qs_id`);

ALTER TABLE `#ZEPRE#_radio`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `#ZEPRE#_ranks`
  ADD PRIMARY KEY (`ranks_id`);

ALTER TABLE `#ZEPRE#_rating`
  ADD PRIMARY KEY (`ra_id`);

ALTER TABLE `#ZEPRE#_report`
  ADD PRIMARY KEY (`rep_id`);

ALTER TABLE `#ZEPRE#_room`
  ADD PRIMARY KEY (`room_id`);

ALTER TABLE `#ZEPRE#_room_allow`
  ADD PRIMARY KEY (`ra_id`);

ALTER TABLE `#ZEPRE#_room_log`
  ADD PRIMARY KEY (`rlog_id`);

ALTER TABLE `#ZEPRE#_session`
  ADD UNIQUE KEY `sess_id` (`sess_id`);

ALTER TABLE `#ZEPRE#_session_room`
  ADD PRIMARY KEY (`sr_id`);

ALTER TABLE `#ZEPRE#_settings`
  ADD PRIMARY KEY (`sett_id`);

ALTER TABLE `#ZEPRE#_smilies`
  ADD PRIMARY KEY (`smi_id`);

ALTER TABLE `#ZEPRE#_smilies_category`
  ADD PRIMARY KEY (`sc_id`);

ALTER TABLE `#ZEPRE#_styles`
  ADD PRIMARY KEY (`style_id`);

ALTER TABLE `#ZEPRE#_teamspeak`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `#ZEPRE#_user`
  ADD PRIMARY KEY (`user_id`);

ALTER TABLE `#ZEPRE#_usergroups`
  ADD PRIMARY KEY (`ug_id`);

ALTER TABLE `#ZEPRE#_usergroups_avatar`
  ADD PRIMARY KEY (`ug_avatar_id`);

ALTER TABLE `#ZEPRE#_usergroups_members`
  ADD PRIMARY KEY (`ug_member_id`);

ALTER TABLE `#ZEPRE#_usergroups_page`
  ADD PRIMARY KEY (`ug_page_id`);

ALTER TABLE `#ZEPRE#_wait`
  ADD PRIMARY KEY (`wait_id`);

ALTER TABLE `#ZEPRE#_account`
  MODIFY `acc_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2000;

ALTER TABLE `#ZEPRE#_avatar`
  MODIFY `ava_id` int(15) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_badwords`
  MODIFY `bad_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_bans`
  MODIFY `ban_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_blog`
  MODIFY `blog_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_blog_comments`
  MODIFY `bc_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_bots`
  MODIFY `bot_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_bot_answers`
  MODIFY `ba_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_category`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_category_allow`
  MODIFY `cal_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_category_create`
  MODIFY `cac_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_colors`
  MODIFY `col_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_dice`
  MODIFY `dice_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_friendlist`
  MODIFY `fl_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_guestbook`
  MODIFY `gb_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_ignore`
  MODIFY `ig_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_inv`
  MODIFY `inv_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_item`
  MODIFY `item_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

ALTER TABLE `#ZEPRE#_item_cats`
  MODIFY `item_cats_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

ALTER TABLE `#ZEPRE#_lang`
  MODIFY `lang_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=194;

ALTER TABLE `#ZEPRE#_lottery`
  MODIFY `lot_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_lottery_history`
  MODIFY `lh_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_mail`
  MODIFY `mail_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_message`
  MODIFY `mess_id` int(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_news`
  MODIFY `news_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

ALTER TABLE `#ZEPRE#_patch_history`
  MODIFY `patch_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_permission`
  MODIFY `perm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

ALTER TABLE `#ZEPRE#_permissions`
  MODIFY `perm_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=662;

ALTER TABLE `#ZEPRE#_permission_groups`
  MODIFY `pg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `#ZEPRE#_presents`
  MODIFY `pres_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_profile_fields`
  MODIFY `prof_field_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

ALTER TABLE `#ZEPRE#_profile_field_content`
  MODIFY `prof_content_fid` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_quiz_league`
  MODIFY `ql_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_quiz_questions`
  MODIFY `qq_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_radio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_ranks`
  MODIFY `ranks_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

ALTER TABLE `#ZEPRE#_rating`
  MODIFY `ra_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

ALTER TABLE `#ZEPRE#_report`
  MODIFY `rep_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_room`
  MODIFY `room_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;

ALTER TABLE `#ZEPRE#_room_allow`
  MODIFY `ra_id` int(15) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_room_log`
  MODIFY `rlog_id` int(15) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_session_room`
  MODIFY `sr_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_smilies`
  MODIFY `smi_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=346;

ALTER TABLE `#ZEPRE#_smilies_category`
  MODIFY `sc_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `#ZEPRE#_styles`
  MODIFY `style_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_teamspeak`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_user`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_usergroups`
  MODIFY `ug_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_usergroups_avatar`
  MODIFY `ug_avatar_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_usergroups_members`
  MODIFY `ug_member_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_usergroups_page`
  MODIFY `ug_page_id` int(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#ZEPRE#_wait`
  MODIFY `wait_id` int(10) NOT NULL AUTO_INCREMENT;