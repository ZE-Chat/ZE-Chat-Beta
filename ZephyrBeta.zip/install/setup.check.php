<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

if(substr(decoct(fileperms(ZE_PATH.'/files/groupicons/')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/files/groupicons/', 0777)) {
    $grpico = true;
  } else {
    $grpico = false; 
  }
} else {
  $grpico = true;
}

if(substr(decoct(fileperms(ZE_PATH.'/files/roombg/')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/files/roombg/', 0777)) {
    $rbg = true;
  } else {
    $rbg = false; 
  }
} else {
  $rbg = true;
}

if(substr(decoct(fileperms(ZE_PATH.'/files/shopitems/')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/files/shopitems/', 0777)) {
    $shop = true;
  } else {
    $shop = false; 
  }
} else {
  $shop = true;
}

if(substr(decoct(fileperms(ZE_PATH.'/files/smilies/')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/files/smilies/', 0777)) {
    $smi = true;
  } else {
    $smi = false; 
  }
} else {
  $smi = true;
}
if(substr(decoct(fileperms(ZE_PATH.'/files/userpic/')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/files/userpic/', 0777)) {
    $upic = true;
  } else {
    $upic = false; 
  }
} else {
  $upic = true;
}

if(substr(decoct(fileperms(ZE_PATH.'/logs/acp.log')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/logs/acp.log', 0777)) {
    $acpl = true;
  } else {
    $acpl = false; 
  }
} else {
  $acpl = true;
}

if(substr(decoct(fileperms(ZE_PATH.'/logs/logins.log')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/logs/logins.log', 0777)) {
    $logl = true;
  } else {
    $logl = false; 
  }
} else {
  $logl = true;
}

if(substr(decoct(fileperms(ZE_PATH.'/logs/moderation.log')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/logs/moderation.log', 0777)) {
    $modl = true;
  } else {
    $modl = false; 
  }
} else {
  $modl = true;
}

if(substr(decoct(fileperms(ZE_PATH.'/logs/violation.log')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/logs/violation.log', 0777)) {
    $viol = true;
  } else {
    $viol = false; 
  }
} else {
  $viol = true;
}

if(substr(sprintf('%o', fileperms(ZE_PATH.'/main/db.main.php')), -4) != "0777") {
  if(@chmod(ZE_PATH.'/main/db.main.php', 0777)) {
    $mdb = true;
  } else {
    $mdb = false; 
  }
} else {
  $mdb = true;
}

$ZE_TPL->assign("ZE_GRPICO", $grpico);
$ZE_TPL->assign("ZE_RBG", $rbg);
$ZE_TPL->assign("ZE_SHOP", $shop);
$ZE_TPL->assign("ZE_SMI", $smi);
$ZE_TPL->assign("ZE_UPIC", $upic);
$ZE_TPL->assign("ZE_ACPL", $acpl);
$ZE_TPL->assign("ZE_LOGL", $logl);
$ZE_TPL->assign("ZE_MODL", $modl);
$ZE_TPL->assign("ZE_VIOL", $viol);
$ZE_TPL->assign("ZE_MDB", $mdb);

?>