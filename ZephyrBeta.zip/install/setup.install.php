<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */

$HOST = htmlspecialchars($_POST["connection"]);
$USER = htmlspecialchars($_POST["user"]);
$PASS = htmlspecialchars($_POST["pw"]);
$DABA = htmlspecialchars($_POST["database"]);
$PREF = htmlspecialchars($_POST["prefix"]);

if (@mysqli_connect ($HOST, $USER, $PASS, $DABA)) {
  $prefab = file_get_contents(ZE_PATH."/main/db.main.php");

  $search = array('#MYSQLHOST#', '#MYSQLUSER#', '#MYSQLPW#', '#MYSQLDB#', '#MYSQLPRE#');
  $replace = array($HOST, $USER, $PASS, $DABA, $PREF);
  $prefab = preg_replace( $search, $replace, $prefab );

  file_put_contents(ZE_PATH."/main/db.main.php", $prefab);
} else {
  echo 'Konnte keine Verbindung herstellen! Zugangsdaten falsch?<br />';
  echo '<a href="./index.php?inc=setup&loc=mysql">Zurück</a>';
  die();
}

if(file_exists(ZE_PATH."/main/db.main.php")) {
  require_once './main/db.main.php';
  $MRK = array('DROP', 'CREATE', 'INSERT', 'ALTER');
  $SQL = file('./install/install.sql');
  $query = '';
  foreach($SQL as $line) {
    $line = trim($line);
    $AA = explode(' ', $line);
    if (in_Array(strtoupper($AA[0]), $MRK)) {
      $query = $line;
    } elseif (strlen($query) > 1) {
      $query .= "\n".$line;
    }
    $x = strlen($query) - 1;
    if (substr($query,$x) == ';') {
      $query = str_replace("#ZEPRE#", $PREF, $query);
      mysqli_query($db, $query);
      $query = '';
    }
  }
}
?>