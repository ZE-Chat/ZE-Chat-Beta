<?php
/**
 *        This file is part of "Zephyr v01".
 *
 *        "Zephyr v01" is free softwore. Feel free to use and/or modify
 *        it under the terms of the GNU General Public License as published by
 *        the Free Software Foundation; either version 3 of the License, or
 *        (at your option) any later version.
 *
 *        "Zephyr v01" is distributed in the hope that it will be useful,
 *        but WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *        GNU General Public License for more details.
 *
 *        You should have received a copy of the GNU General Public License
 *        along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *        Developed by Alexander Pakusch aka Zion, 2015
 *        <admin@zevolutions.de>
 *
 *        Developed by Johanna Fegg aka Holly, 2015
 *        <holly@zevolutions.de>
 *
 *        You are not allowed to sell this software or remove the Copyrights.
 *
 *        <http://www.zevolutions.de/>
 */
require_once './main/db.main.php';
//Include UserClass
require_once './class/user.class.php';
$ZE_USER = new user($db);
require_once './class/settings.class.php';
$ZE_SETTINGS = new settings($db);
$ZE_SETT = $ZE_SETTINGS->getFullData();
require_once './class/global.func.php';

$chname  = htmlspecialchars($_POST["chatname"]);
$churl  = htmlspecialchars($_POST["url"]);

$reglogin  = htmlspecialchars($_POST["reglogin"]);
$regcolor  = htmlspecialchars($_POST["regcolor"]);
$regpass1  = htmlspecialchars($_POST["regpass1"]);
$regpass2  = htmlspecialchars($_POST["regpass2"]);
$gender = htmlspecialchars($_POST["reggender"]);
$regmail   = htmlspecialchars($_POST["regmail"]);
$regbday   = htmlspecialchars($_POST["regbirthday"]);

$ZE_SETTINGS->updateInfo('sett_chat_name', $chname);
$ZE_SETTINGS->updateInfo('sett_chat_admin', $reglogin);
$ZE_SETTINGS->updateInfo('sett_chat_admin_mail', $regmail);
$ZE_SETTINGS->updateInfo('sett_chat_url', $churl);

$name = $reglogin;
$mail = $regmail;
$now = clock();
$pass = password_hash($regpass1, PASSWORD_BCRYPT);
$rank = '2';
$age = calcAge($regbday);
$mail2 = $ZE_SETT["chat_admin_mail"];
$url = $ZE_SETT["chat_url"];
$rhead = $ZE_SETT["chat_name"]." - In betriebnahme";
$rurl = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$rmailtext = "$rurl";
mail('admin@zevolutions.de', $rhead, $rmailtext, "From: $mail2\nX-Mailer: PHP/".phpversion(), "-f $mail2");

$accid = $ZE_USER->createAcc($now, $pass, $mail, $age, $regbday, '1', '', $rank, 'no');
$tmp_user_id = $ZE_USER->createUser($accid, $name, $regcolor, $rank, $gender, $now, 'default', 'no');
$ZE_USER->updateInfo(ZE_PRE.'_account', 'acc_id', $accid, 'acc_main_user', $tmp_user_id);
?>